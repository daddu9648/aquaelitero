#!/usr/bin/env python3

import requests
import sys
import json
from datetime import datetime, timedelta

class InvoiceSystemTester:
    def __init__(self, base_url="https://jar-system.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.token = None
        self.user_data = None
        self.tests_run = 0
        self.tests_passed = 0

    def run_test(self, name, method, endpoint, expected_status, data=None, headers=None):
        """Run a single API test"""
        url = f"{self.api_url}/{endpoint}"
        test_headers = {'Content-Type': 'application/json'}
        
        if self.token:
            test_headers['Authorization'] = f'Bearer {self.token}'
        
        if headers:
            test_headers.update(headers)

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=test_headers, timeout=30)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=test_headers, timeout=30)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=test_headers, timeout=30)
            elif method == 'DELETE':
                response = requests.delete(url, headers=test_headers, timeout=30)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    if isinstance(response_data, dict) and len(str(response_data)) < 500:
                        print(f"   Response: {response_data}")
                    elif isinstance(response_data, list):
                        print(f"   Response: List with {len(response_data)} items")
                    return success, response_data
                except:
                    return success, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {error_data}")
                except:
                    print(f"   Error: {response.text}")
                return False, {}

        except requests.exceptions.Timeout:
            print(f"❌ Failed - Request timeout (30s)")
            return False, {}
        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def authenticate(self):
        """Authenticate with the API"""
        print("\n" + "="*50)
        print("AUTHENTICATING")
        print("="*50)
        
        # Try to login with existing admin credentials
        login_data = {
            "email": "testadmin@waterkard.com",
            "password": "admin123"
        }
        
        success, response = self.run_test(
            "Admin Login",
            "POST",
            "auth/login",
            200,
            data=login_data
        )
        
        if success and 'access_token' in response:
            self.token = response['access_token']
            self.user_data = response.get('user', {})
            print(f"   Token obtained: {self.token[:20]}...")
            print(f"   User: {self.user_data.get('name', 'Unknown')} ({self.user_data.get('role', 'Unknown')})")
            return True
        else:
            print("❌ Authentication failed")
            return False

    def test_enhanced_invoice_management_system(self):
        """Test the enhanced Invoice Management system for Event Orders and Monthly Due customers"""
        print("\n" + "="*50)
        print("TESTING ENHANCED INVOICE MANAGEMENT SYSTEM")
        print("="*50)
        
        if not self.token:
            print("❌ Cannot test invoice management - no authentication token")
            return False
        
        # Store created IDs for cleanup
        created_customer_id = None
        created_event_order_id = None
        created_invoices = []
        
        # Test 1: Create test customer for invoice testing
        print("\n--- Setting up test data ---")
        customer_data = {
            "name": "Arjun Patel",
            "mobile": "+91 9876543220",
            "address": "789 Invoice Test Lane, Pune, Maharashtra - 411001",
            "water_type": "20L",
            "bottle_deposit": 200.0
        }
        
        success, response = self.run_test(
            "Create Test Customer for Invoice Testing",
            "POST",
            "customers",
            200,
            data=customer_data
        )
        
        if success and 'id' in response:
            created_customer_id = response['id']
            print(f"   Created customer ID: {created_customer_id}")
        else:
            print("❌ Failed to create test customer - cannot proceed with invoice tests")
            return False
        
        # Add some balance due to customer for monthly invoice testing
        balance_data = {
            "amount": 150.0,
            "type": "charge",
            "notes": "Test charge for monthly invoice testing"
        }
        
        success, response = self.run_test(
            "Add Balance Due to Customer",
            "POST",
            f"customers/{created_customer_id}/update-balance",
            200,
            data=balance_data
        )
        
        if success:
            print(f"   Added ₹150 balance due to customer")
        
        # Test 2: Create test event order for event invoice testing
        event_order_data = {
            "event_name": "Corporate Annual Meeting",
            "event_type": "corporate",
            "customer_id": created_customer_id,
            "event_date": (datetime.now() + timedelta(days=7)).isoformat(),
            "event_time": "10:00 AM",
            "venue_address": "Conference Hall, Business Park, Pune",
            "guest_count": 50,
            "products": [
                {
                    "product_id": "test-product-1",
                    "product_name": "Premium Water 20L",
                    "quantity": 10,
                    "price": 25.0,
                    "total": 250.0
                }
            ],
            "total_amount": 250.0,
            "advance_amount": 100.0,
            "special_requirements": "Cold water required"
        }
        
        success, response = self.run_test(
            "Create Test Event Order",
            "POST",
            "event-orders",
            200,
            data=event_order_data
        )
        
        if success and 'id' in response:
            created_event_order_id = response['id']
            print(f"   Created event order ID: {created_event_order_id}")
            
            # Update event status to completed for invoice eligibility
            update_data = {
                "event_status": "completed",
                "delivery_status": "completed"
            }
            
            success, response = self.run_test(
                "Update Event Order to Completed",
                "PUT",
                f"event-orders/{created_event_order_id}",
                200,
                data=update_data
            )
            
            if success:
                print("   Event order marked as completed")
        else:
            print("❌ Failed to create test event order")
        
        # Test 3: Get Event Orders Eligible for Invoicing
        print("\n--- Testing Event Order Invoice APIs ---")
        
        success, response = self.run_test(
            "Get Event Orders Eligible for Invoicing",
            "GET",
            "event-orders/invoice-eligible",
            200
        )
        
        if success:
            eligible_events = response if isinstance(response, list) else []
            print(f"   Found {len(eligible_events)} eligible event orders")
            
            # Check if our created event is in the list
            our_event_found = any(event.get('id') == created_event_order_id for event in eligible_events)
            if our_event_found:
                print("✅ Our test event order found in eligible list")
            else:
                print("❌ Our test event order not found in eligible list")
        else:
            print("❌ Failed to get eligible event orders")
        
        # Test 4: Create Invoice for Event Order
        if created_event_order_id:
            success, response = self.run_test(
                "Create Invoice for Event Order",
                "POST",
                f"invoices/event-order/{created_event_order_id}",
                200
            )
            
            if success and 'id' in response:
                event_invoice_id = response['id']
                created_invoices.append(event_invoice_id)
                print(f"✅ Event order invoice created successfully!")
                print(f"   Invoice ID: {event_invoice_id}")
                print(f"   Invoice Number: {response.get('invoice_number', 'Unknown')}")
                print(f"   Invoice Type: {response.get('invoice_type', 'Unknown')}")
                print(f"   Total Amount: ₹{response.get('total_amount', 0)}")
                
                # Verify invoice contains event details
                items = response.get('items', [])
                event_details_found = any('Event Water Supply' in item.get('description', '') for item in items)
                venue_details_found = any('Venue:' in item.get('description', '') for item in items)
                
                if event_details_found:
                    print("✅ Invoice contains event details")
                if venue_details_found:
                    print("✅ Invoice contains venue details")
                
                # Verify invoice type
                if response.get('invoice_type') == 'event_order':
                    print("✅ Invoice type correctly set to 'event_order'")
                else:
                    print("❌ Invoice type not correctly set")
                
                # Verify invoice numbering format
                invoice_number = response.get('invoice_number', '')
                if invoice_number.startswith('INV-EVT-'):
                    print("✅ Invoice number follows correct format (INV-EVT-xxx)")
                else:
                    print("❌ Invoice number format incorrect")
            else:
                print("❌ Failed to create event order invoice")
        
        # Test 5: Try to create duplicate invoice (should fail)
        if created_event_order_id:
            success, response = self.run_test(
                "Create Duplicate Event Invoice (Should Fail)",
                "POST",
                f"invoices/event-order/{created_event_order_id}",
                400
            )
            
            if not success:
                print("✅ Correctly prevented duplicate event invoice creation")
            else:
                print("❌ Should have prevented duplicate event invoice creation")
        
        # Test 6: Get Customers with Monthly Due
        print("\n--- Testing Monthly Due Invoice APIs ---")
        
        success, response = self.run_test(
            "Get Customers with Monthly Due (minimum ₹100)",
            "GET",
            "customers/monthly-due?minimum_due=100",
            200
        )
        
        if success:
            customers_data = response.get('customers', []) if isinstance(response, dict) else []
            summary = response.get('summary', {}) if isinstance(response, dict) else {}
            
            print(f"   Found {len(customers_data)} customers with dues ≥ ₹100")
            print(f"   Total due amount: ₹{summary.get('total_due_amount', 0)}")
            print(f"   Minimum due filter: ₹{summary.get('minimum_due', 0)}")
            
            # Check if our test customer is in the list
            our_customer_found = any(customer.get('id') == created_customer_id for customer in customers_data)
            if our_customer_found:
                print("✅ Our test customer found in monthly due list")
            else:
                print("❌ Our test customer not found in monthly due list")
        else:
            print("❌ Failed to get customers with monthly due")
        
        # Test 7: Create Monthly Due Invoices
        monthly_invoice_data = {
            "month": datetime.now().month,
            "year": datetime.now().year,
            "minimum_due": 100.0
        }
        
        success, response = self.run_test(
            "Create Monthly Due Invoices",
            "POST",
            "invoices/monthly-due",
            200,
            data=monthly_invoice_data
        )
        
        if success:
            invoices_created = response.get('invoices_created', 0)
            message = response.get('message', '')
            invoices = response.get('invoices', [])
            
            print(f"✅ Monthly due invoices creation completed!")
            print(f"   {message}")
            print(f"   Invoices created: {invoices_created}")
            
            if invoices:
                # Check first invoice details
                first_invoice = invoices[0]
                created_invoices.append(first_invoice.get('id'))
                
                print(f"   Sample Invoice ID: {first_invoice.get('id', 'Unknown')}")
                print(f"   Invoice Number: {first_invoice.get('invoice_number', 'Unknown')}")
                print(f"   Invoice Type: {first_invoice.get('invoice_type', 'Unknown')}")
                print(f"   Total Amount: ₹{first_invoice.get('total_amount', 0)}")
                
                # Verify invoice type
                if first_invoice.get('invoice_type') == 'monthly_due':
                    print("✅ Invoice type correctly set to 'monthly_due'")
                else:
                    print("❌ Invoice type not correctly set")
                
                # Verify invoice numbering format
                invoice_number = first_invoice.get('invoice_number', '')
                if invoice_number.startswith('INV-DUE-'):
                    print("✅ Invoice number follows correct format (INV-DUE-xxx)")
                else:
                    print("❌ Invoice number format incorrect")
                
                # Check for delivery history and outstanding balance items
                items = first_invoice.get('items', [])
                delivery_items = [item for item in items if 'Water Delivery' in item.get('description', '')]
                balance_items = [item for item in items if 'Outstanding Balance' in item.get('description', '')]
                
                if delivery_items:
                    print("✅ Invoice includes delivery history")
                if balance_items:
                    print("✅ Invoice includes outstanding balance")
        else:
            print("❌ Failed to create monthly due invoices")
        
        # Test 8: Integration Testing - Verify invoices appear in general invoice list
        print("\n--- Testing Integration with Existing Invoice System ---")
        
        success, response = self.run_test(
            "Get All Invoices (Integration Test)",
            "GET",
            "invoices",
            200
        )
        
        if success:
            all_invoices = response if isinstance(response, list) else []
            print(f"   Total invoices in system: {len(all_invoices)}")
            
            # Check if our created invoices appear in the list
            event_invoice_found = any(inv.get('invoice_type') == 'event_order' for inv in all_invoices)
            monthly_invoice_found = any(inv.get('invoice_type') == 'monthly_due' for inv in all_invoices)
            
            if event_invoice_found:
                print("✅ Event order invoices appear in general invoice list")
            if monthly_invoice_found:
                print("✅ Monthly due invoices appear in general invoice list")
            
            # Count different invoice types
            event_count = sum(1 for inv in all_invoices if inv.get('invoice_type') == 'event_order')
            monthly_count = sum(1 for inv in all_invoices if inv.get('invoice_type') == 'monthly_due')
            regular_count = len(all_invoices) - event_count - monthly_count
            
            print(f"   Event order invoices: {event_count}")
            print(f"   Monthly due invoices: {monthly_count}")
            print(f"   Regular invoices: {regular_count}")
        else:
            print("❌ Failed to get all invoices for integration test")
        
        # Test 9: Test Invoice Status Updates
        if created_invoices:
            test_invoice_id = created_invoices[0]
            
            # Test updating invoice status
            update_data = {
                "status": "sent"
            }
            
            success, response = self.run_test(
                "Update Invoice Status",
                "PUT",
                f"invoices/{test_invoice_id}",
                200,
                data=update_data
            )
            
            if success:
                print(f"✅ Invoice status updated successfully")
                print(f"   New status: {response.get('status', 'Unknown')}")
            else:
                print("❌ Failed to update invoice status")
            
            # Test sending invoice
            success, response = self.run_test(
                "Send Invoice",
                "POST",
                f"invoices/{test_invoice_id}/send",
                200
            )
            
            if success:
                print("✅ Invoice sent successfully")
            else:
                print("❌ Failed to send invoice")
        
        # Test 10: Test Error Handling
        print("\n--- Testing Error Handling ---")
        
        # Test creating invoice for non-existent event order
        success, response = self.run_test(
            "Create Invoice for Non-existent Event (Should Fail)",
            "POST",
            "invoices/event-order/non-existent-id",
            404
        )
        
        if not success:
            print("✅ Correctly handled non-existent event order")
        else:
            print("❌ Should have failed for non-existent event order")
        
        # Test 11: Validate Invoice Data Structure
        if created_invoices:
            test_invoice_id = created_invoices[0]
            
            success, response = self.run_test(
                "Get Specific Invoice for Validation",
                "GET",
                f"invoices/{test_invoice_id}",
                200
            )
            
            if success:
                print("✅ Invoice data structure validation:")
                
                # Check required fields
                required_fields = ['id', 'invoice_number', 'customer_id', 'customer_name', 
                                 'invoice_type', 'items', 'total_amount', 'status', 'created_at']
                
                missing_fields = [field for field in required_fields if field not in response]
                
                if not missing_fields:
                    print("   ✅ All required fields present")
                else:
                    print(f"   ❌ Missing fields: {missing_fields}")
                
                # Validate items structure
                items = response.get('items', [])
                if items and all('description' in item and 'amount' in item for item in items):
                    print("   ✅ Invoice items structure valid")
                else:
                    print("   ❌ Invoice items structure invalid")
        
        # Cleanup: Delete created test data
        print("\n--- Cleaning up test data ---")
        
        # Delete created invoices
        for invoice_id in created_invoices:
            success, response = self.run_test(
                f"Delete Test Invoice",
                "DELETE",
                f"invoices/{invoice_id}",
                200
            )
            if success:
                print(f"   ✅ Deleted invoice {invoice_id[:8]}...")
        
        # Delete created event order
        if created_event_order_id:
            success, response = self.run_test(
                "Delete Test Event Order",
                "DELETE",
                f"event-orders/{created_event_order_id}",
                200
            )
            if success:
                print(f"   ✅ Deleted event order {created_event_order_id[:8]}...")
        
        # Delete created customer
        if created_customer_id:
            success, response = self.run_test(
                "Delete Test Customer",
                "DELETE",
                f"customers/{created_customer_id}",
                200
            )
            if success:
                print(f"   ✅ Deleted customer {created_customer_id[:8]}...")
        
        print("\n✅ ENHANCED INVOICE MANAGEMENT SYSTEM TESTING COMPLETED")
        print("="*60)
        
        return True

    def run_tests(self):
        """Run the invoice management tests"""
        print("🚀 Starting Enhanced Invoice Management System Testing...")
        print(f"Base URL: {self.base_url}")
        print(f"API URL: {self.api_url}")
        
        # Authenticate first
        if not self.authenticate():
            print("❌ Authentication failed - stopping tests")
            return
        
        # Run invoice management tests
        self.test_enhanced_invoice_management_system()
        
        # Print final results
        print("\n" + "="*60)
        print("🏁 FINAL TEST RESULTS")
        print("="*60)
        print(f"Total tests run: {self.tests_run}")
        print(f"Tests passed: {self.tests_passed}")
        print(f"Tests failed: {self.tests_run - self.tests_passed}")
        print(f"Success rate: {(self.tests_passed/self.tests_run)*100:.1f}%")
        
        if self.tests_passed == self.tests_run:
            print("🎉 ALL TESTS PASSED!")
        else:
            print("⚠️  Some tests failed - check logs above")
        
        print("="*60)

if __name__ == "__main__":
    tester = InvoiceSystemTester()
    tester.run_tests()