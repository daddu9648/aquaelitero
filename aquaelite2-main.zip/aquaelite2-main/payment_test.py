import requests
import sys
import json
from datetime import datetime, timedelta

class PaymentCollectionTester:
    def __init__(self, base_url="https://jar-system.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.token = None
        self.user_data = None
        self.tests_run = 0
        self.tests_passed = 0

    def run_test(self, name, method, endpoint, expected_status, data=None, headers=None):
        """Run a single API test"""
        url = f"{self.api_url}/{endpoint}"
        test_headers = {'Content-Type': 'application/json'}
        
        if self.token:
            test_headers['Authorization'] = f'Bearer {self.token}'
        
        if headers:
            test_headers.update(headers)

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=test_headers, timeout=30)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=test_headers, timeout=30)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=test_headers, timeout=30)
            elif method == 'DELETE':
                response = requests.delete(url, headers=test_headers, timeout=30)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    if isinstance(response_data, dict) and len(str(response_data)) < 500:
                        print(f"   Response: {response_data}")
                    elif isinstance(response_data, list):
                        print(f"   Response: List with {len(response_data)} items")
                    return success, response_data
                except:
                    return success, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {error_data}")
                except:
                    print(f"   Error: {response.text}")
                return False, {}

        except requests.exceptions.Timeout:
            print(f"❌ Failed - Request timeout (30s)")
            return False, {}
        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def authenticate(self):
        """Authenticate with admin credentials"""
        print("\n" + "="*50)
        print("AUTHENTICATION")
        print("="*50)
        
        # Try different admin credentials
        admin_credentials = [
            {"email": "testadmin@waterkard.com", "password": "admin123"},
            {"email": "admin2@waterkard.com", "password": "admin123"},
            {"email": "admin@waterkard.com", "password": "admin123"}
        ]
        
        for i, login_data in enumerate(admin_credentials):
            print(f"   Trying admin credentials {i+1}: {login_data['email']}")
            
            success, response = self.run_test(
                f"Admin Login Attempt {i+1}",
                "POST",
                "auth/login",
                200,
                data=login_data
            )
            
            if success and 'access_token' in response:
                self.token = response['access_token']
                self.user_data = response.get('user', {})
                print(f"   Token obtained: {self.token[:20]}...")
                print(f"   User: {self.user_data.get('name', 'Unknown')} ({self.user_data.get('role', 'Unknown')})")
                return True
        
        print("❌ Login failed - cannot proceed with tests")
        return False

    def test_payment_collection_functionality(self):
        """Test the collect payment functionality specifically for customer management"""
        print("\n" + "="*50)
        print("TESTING PAYMENT COLLECTION FUNCTIONALITY")
        print("="*50)
        
        if not self.token:
            print("❌ Cannot test payment collection - no authentication token")
            return False
        
        # Create a test customer for payment collection
        customer_data = {
            "name": "Rajesh Gupta",
            "mobile": "+91 9876543210",
            "address": "123 Payment Test Street, Delhi - 110001",
            "water_type": "20L",
            "bottle_deposit": 100.0
        }
        
        success, response = self.run_test(
            "Create Customer for Payment Testing",
            "POST",
            "customers",
            200,
            data=customer_data
        )
        
        test_customer_id = None
        if success and 'id' in response:
            test_customer_id = response['id']
            print(f"   Created test customer ID: {test_customer_id}")
        else:
            print("❌ Failed to create test customer - cannot proceed")
            return False
        
        # Test 1: Valid payment collection with all required fields
        print("\n--- Test 1: Valid Payment Collection ---")
        
        valid_payment_data = {
            "customer_id": test_customer_id,
            "customer_name": "Rajesh Gupta",
            "amount": 150.0,
            "payment_mode": "cash",
            "collected_by": self.user_data.get('id', 'test-user-id'),
            "collected_by_name": self.user_data.get('name', 'Test Admin'),
            "payment_type": "customer_payment",
            "notes": "Regular payment collection",
            "collected_at": datetime.now().isoformat()
        }
        
        success, response = self.run_test(
            "Valid Payment Collection",
            "POST",
            "payments",
            200,
            data=valid_payment_data
        )
        
        payment_id = None
        if success and 'id' in response:
            payment_id = response['id']
            print(f"   Created payment ID: {payment_id}")
            print(f"   Amount: ₹{response.get('amount', 0)}")
            print(f"   Payment mode: {response.get('payment_mode', 'Unknown')}")
            print(f"   Collected by: {response.get('collected_by_name', 'Unknown')}")
        else:
            print("❌ Valid payment collection failed")
        
        # Test 2: Missing required field - customer_id
        print("\n--- Test 2: Missing customer_id (Should Fail) ---")
        
        missing_customer_id_data = {
            "customer_name": "Rajesh Gupta",
            "amount": 100.0,
            "collected_by": self.user_data.get('id', 'test-user-id'),
            "collected_by_name": self.user_data.get('name', 'Test Admin'),
            "collected_at": datetime.now().isoformat()
        }
        
        success, response = self.run_test(
            "Missing customer_id",
            "POST",
            "payments",
            422,
            data=missing_customer_id_data
        )
        
        if not success:
            print("✅ Correctly rejected payment without customer_id")
        else:
            print("❌ Should have rejected payment without customer_id")
        
        # Test 3: Missing required field - customer_name
        print("\n--- Test 3: Missing customer_name (Should Fail) ---")
        
        missing_customer_name_data = {
            "customer_id": test_customer_id,
            "amount": 100.0,
            "collected_by": self.user_data.get('id', 'test-user-id'),
            "collected_by_name": self.user_data.get('name', 'Test Admin'),
            "collected_at": datetime.now().isoformat()
        }
        
        success, response = self.run_test(
            "Missing customer_name",
            "POST",
            "payments",
            422,
            data=missing_customer_name_data
        )
        
        if not success:
            print("✅ Correctly rejected payment without customer_name")
        else:
            print("❌ Should have rejected payment without customer_name")
        
        # Test 4: Missing required field - amount
        print("\n--- Test 4: Missing amount (Should Fail) ---")
        
        missing_amount_data = {
            "customer_id": test_customer_id,
            "customer_name": "Rajesh Gupta",
            "collected_by": self.user_data.get('id', 'test-user-id'),
            "collected_by_name": self.user_data.get('name', 'Test Admin'),
            "collected_at": datetime.now().isoformat()
        }
        
        success, response = self.run_test(
            "Missing amount",
            "POST",
            "payments",
            422,
            data=missing_amount_data
        )
        
        if not success:
            print("✅ Correctly rejected payment without amount")
        else:
            print("❌ Should have rejected payment without amount")
        
        # Test 5: Missing required field - collected_by
        print("\n--- Test 5: Missing collected_by (Should Fail) ---")
        
        missing_collected_by_data = {
            "customer_id": test_customer_id,
            "customer_name": "Rajesh Gupta",
            "amount": 100.0,
            "collected_by_name": self.user_data.get('name', 'Test Admin'),
            "collected_at": datetime.now().isoformat()
        }
        
        success, response = self.run_test(
            "Missing collected_by",
            "POST",
            "payments",
            422,
            data=missing_collected_by_data
        )
        
        if not success:
            print("✅ Correctly rejected payment without collected_by")
        else:
            print("❌ Should have rejected payment without collected_by")
        
        # Test 6: Missing required field - collected_by_name
        print("\n--- Test 6: Missing collected_by_name (Should Fail) ---")
        
        missing_collected_by_name_data = {
            "customer_id": test_customer_id,
            "customer_name": "Rajesh Gupta",
            "amount": 100.0,
            "collected_by": self.user_data.get('id', 'test-user-id'),
            "collected_at": datetime.now().isoformat()
        }
        
        success, response = self.run_test(
            "Missing collected_by_name",
            "POST",
            "payments",
            422,
            data=missing_collected_by_name_data
        )
        
        if not success:
            print("✅ Correctly rejected payment without collected_by_name")
        else:
            print("❌ Should have rejected payment without collected_by_name")
        
        # Test 7: Missing required field - collected_at
        print("\n--- Test 7: Missing collected_at (Should Fail) ---")
        
        missing_collected_at_data = {
            "customer_id": test_customer_id,
            "customer_name": "Rajesh Gupta",
            "amount": 100.0,
            "collected_by": self.user_data.get('id', 'test-user-id'),
            "collected_by_name": self.user_data.get('name', 'Test Admin')
        }
        
        success, response = self.run_test(
            "Missing collected_at",
            "POST",
            "payments",
            422,
            data=missing_collected_at_data
        )
        
        if not success:
            print("✅ Correctly rejected payment without collected_at")
        else:
            print("❌ Should have rejected payment without collected_at")
        
        # Test 8: Null values in required fields
        print("\n--- Test 8: Null Values in Required Fields (Should Fail) ---")
        
        null_values_data = {
            "customer_id": None,
            "customer_name": "Rajesh Gupta",
            "amount": 100.0,
            "collected_by": self.user_data.get('id', 'test-user-id'),
            "collected_by_name": self.user_data.get('name', 'Test Admin'),
            "collected_at": datetime.now().isoformat()
        }
        
        success, response = self.run_test(
            "Null customer_id",
            "POST",
            "payments",
            422,
            data=null_values_data
        )
        
        if not success:
            print("✅ Correctly rejected payment with null customer_id")
        else:
            print("❌ Should have rejected payment with null customer_id")
        
        # Test 9: Invalid data types
        print("\n--- Test 9: Invalid Data Types ---")
        
        invalid_amount_data = {
            "customer_id": test_customer_id,
            "customer_name": "Rajesh Gupta",
            "amount": "invalid_amount",  # String instead of number
            "collected_by": self.user_data.get('id', 'test-user-id'),
            "collected_by_name": self.user_data.get('name', 'Test Admin'),
            "collected_at": datetime.now().isoformat()
        }
        
        success, response = self.run_test(
            "Invalid amount data type",
            "POST",
            "payments",
            422,
            data=invalid_amount_data
        )
        
        if not success:
            print("✅ Correctly handled invalid amount data type")
        else:
            print("❌ Should have handled invalid amount data type")
        
        # Test 10: Optional fields with default values
        print("\n--- Test 10: Optional Fields with Defaults ---")
        
        minimal_payment_data = {
            "customer_id": test_customer_id,
            "customer_name": "Rajesh Gupta",
            "amount": 75.0,
            "collected_by": self.user_data.get('id', 'test-user-id'),
            "collected_by_name": self.user_data.get('name', 'Test Admin'),
            "collected_at": datetime.now().isoformat()
            # payment_mode, payment_type, notes are optional
        }
        
        success, response = self.run_test(
            "Payment with Optional Fields Missing",
            "POST",
            "payments",
            200,
            data=minimal_payment_data
        )
        
        if success:
            print(f"   Payment mode (default): {response.get('payment_mode', 'Missing')}")
            print(f"   Payment type (default): {response.get('payment_type', 'Missing')}")
            print(f"   Notes (default): '{response.get('notes', 'Missing')}'")
            
            # Verify defaults
            if response.get('payment_mode') == 'cash' and response.get('payment_type') == 'customer_payment':
                print("✅ Default values applied correctly")
            else:
                print("❌ Default values not applied correctly")
        else:
            print("❌ Payment with optional fields missing failed")
        
        # Test 11: Get all payments to verify storage
        print("\n--- Test 11: Verify Payment Storage ---")
        
        success, response = self.run_test(
            "Get All Payments",
            "GET",
            "payments",
            200
        )
        
        if success:
            payment_count = len(response)
            print(f"   Total payments in system: {payment_count}")
            
            # Find our test payments
            test_payments = [p for p in response if p.get('customer_id') == test_customer_id]
            print(f"   Test customer payments: {len(test_payments)}")
            
            if len(test_payments) >= 2:  # Should have at least 2 successful payments
                print("✅ Payments correctly stored in database")
                
                # Display payment details
                for i, payment in enumerate(test_payments[:3]):  # Show first 3
                    print(f"   Payment {i+1}:")
                    print(f"     Amount: ₹{payment.get('amount', 0)}")
                    print(f"     Mode: {payment.get('payment_mode', 'Unknown')}")
                    print(f"     Type: {payment.get('payment_type', 'Unknown')}")
                    print(f"     Collected by: {payment.get('collected_by_name', 'Unknown')}")
            else:
                print("❌ Test payments not found in database")
        else:
            print("❌ Failed to retrieve payments")
        
        # Test 12: Authentication requirement
        print("\n--- Test 12: Authentication Requirement ---")
        
        success, response = self.run_test(
            "Payment Collection without Authentication",
            "POST",
            "payments",
            401,
            data=valid_payment_data,
            headers={"Authorization": "Bearer invalid_token"}
        )
        
        if not success:
            print("✅ Correctly blocked payment collection without authentication")
        else:
            print("❌ Should have blocked payment collection without authentication")
        
        # Test 13: Frontend data format simulation
        print("\n--- Test 13: Frontend Data Format Simulation ---")
        
        frontend_payment_data = {
            "customer_id": test_customer_id,
            "customer_name": "Rajesh Gupta",
            "amount": 200.0,
            "payment_mode": "upi",
            "collected_by": self.user_data.get('id', 'test-user-id'),
            "collected_by_name": self.user_data.get('name', 'Test Admin'),
            "payment_type": "advance_payment",
            "notes": "Payment collected via UPI",
            "collected_at": datetime.now().isoformat()
        }
        
        success, response = self.run_test(
            "Frontend Format Payment Data",
            "POST",
            "payments",
            200,
            data=frontend_payment_data
        )
        
        if success:
            print("✅ Frontend format payment data processed successfully")
            print(f"   Payment ID: {response.get('id', 'Unknown')}")
            print(f"   Amount: ₹{response.get('amount', 0)}")
            print(f"   Mode: {response.get('payment_mode', 'Unknown')}")
            print(f"   Type: {response.get('payment_type', 'Unknown')}")
        else:
            print("❌ Frontend format payment data failed")
        
        # Cleanup: Delete test customer
        print("\n--- Cleanup ---")
        
        if test_customer_id:
            success, response = self.run_test(
                "Delete Test Customer",
                "DELETE",
                f"customers/{test_customer_id}",
                200
            )
            
            if success:
                print(f"✅ Deleted test customer {test_customer_id}")
            else:
                print(f"❌ Failed to delete test customer {test_customer_id}")
        
        print("✅ Payment Collection Functionality testing completed")
        return True

    def run_tests(self):
        """Run payment collection tests"""
        print("🚀 Starting Payment Collection API Testing...")
        print(f"   Base URL: {self.base_url}")
        print(f"   API URL: {self.api_url}")
        
        # Test authentication first
        if not self.authenticate():
            print("❌ Authentication failed - stopping tests")
            return
        
        # Run payment collection tests
        self.test_payment_collection_functionality()
        
        # Print final results
        print("\n" + "="*60)
        print("FINAL TEST RESULTS")
        print("="*60)
        print(f"Total tests run: {self.tests_run}")
        print(f"Tests passed: {self.tests_passed}")
        print(f"Tests failed: {self.tests_run - self.tests_passed}")
        print(f"Success rate: {(self.tests_passed / self.tests_run * 100):.1f}%")
        
        if self.tests_passed == self.tests_run:
            print("🎉 All tests passed!")
        else:
            print("⚠️  Some tests failed - check logs above")

if __name__ == "__main__":
    tester = PaymentCollectionTester()
    tester.run_tests()