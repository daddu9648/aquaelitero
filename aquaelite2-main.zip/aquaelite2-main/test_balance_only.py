#!/usr/bin/env python3

import requests
import sys
import json
from datetime import datetime, timedelta

class BalanceAPITester:
    def __init__(self, base_url="https://jar-system.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.token = None
        self.user_data = None
        self.tests_run = 0
        self.tests_passed = 0

    def run_test(self, name, method, endpoint, expected_status, data=None, headers=None):
        """Run a single API test"""
        url = f"{self.api_url}/{endpoint}"
        test_headers = {'Content-Type': 'application/json'}
        
        if self.token:
            test_headers['Authorization'] = f'Bearer {self.token}'
        
        if headers:
            test_headers.update(headers)

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=test_headers, timeout=30)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=test_headers, timeout=30)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=test_headers, timeout=30)
            elif method == 'DELETE':
                response = requests.delete(url, headers=test_headers, timeout=30)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    if isinstance(response_data, dict) and len(str(response_data)) < 500:
                        print(f"   Response: {response_data}")
                    elif isinstance(response_data, list):
                        print(f"   Response: List with {len(response_data)} items")
                    return success, response_data
                except:
                    return success, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {error_data}")
                except:
                    print(f"   Error: {response.text}")
                return False, {}

        except requests.exceptions.Timeout:
            print(f"❌ Failed - Request timeout (30s)")
            return False, {}
        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def authenticate(self):
        """Authenticate with admin credentials"""
        print("\n" + "="*50)
        print("AUTHENTICATION")
        print("="*50)
        
        # Create admin user first
        register_data = {
            "name": "Balance Test Admin",
            "email": "balanceadmin@waterkard.com", 
            "mobile": "+91 8888888888",
            "password": "admin123",
            "role": "admin"
        }
        
        success, response = self.run_test(
            "Create Balance Test Admin User",
            "POST",
            "auth/register",
            200,
            data=register_data
        )
        
        if success:
            print("   Balance test admin created, trying login...")
            login_data = {
                "email": "balanceadmin@waterkard.com",
                "password": "admin123"
            }
            
            success, response = self.run_test(
                "Login with Balance Test Admin",
                "POST",
                "auth/login",
                200,
                data=login_data
            )
            
            if success and 'access_token' in response:
                self.token = response['access_token']
                self.user_data = response.get('user', {})
                print(f"   Token obtained: {self.token[:20]}...")
                print(f"   User: {self.user_data.get('name', 'Unknown')} ({self.user_data.get('role', 'Unknown')})")
                return True
        
        print("❌ Authentication failed")
        return False

    def test_customer_balance_management(self):
        """Test Customer Balance Management API endpoints comprehensively"""
        print("\n" + "="*50)
        print("TESTING CUSTOMER BALANCE MANAGEMENT")
        print("="*50)
        
        # Create test customers
        test_customers = [
            {
                "name": "Rajesh Kumar",
                "mobile": "+91 9876543100",
                "address": "123 MG Road, Bangalore, Karnataka - 560001",
                "water_type": "20L",
                "bottle_deposit": 100.0
            },
            {
                "name": "Priya Sharma",
                "mobile": "+91 9876543101", 
                "address": "456 Park Street, Mumbai, Maharashtra - 400001",
                "water_type": "20L",
                "bottle_deposit": 150.0
            }
        ]
        
        created_customer_ids = []
        
        for i, customer_data in enumerate(test_customers):
            success, response = self.run_test(
                f"Create Test Customer {i+1} for Balance Testing",
                "POST",
                "customers",
                200,
                data=customer_data
            )
            
            if success and 'id' in response:
                customer_id = response['id']
                created_customer_ids.append(customer_id)
                print(f"   Created customer ID: {customer_id}")
                print(f"   Initial balance due: ₹{response.get('balance_due', 0.0)}")
        
        if len(created_customer_ids) < 2:
            print("❌ Failed to create test customers - cannot proceed with balance tests")
            return False
        
        customer1_id = created_customer_ids[0]
        customer2_id = created_customer_ids[1]
        
        # Test Scenario 1: Customer with ₹100 balance due
        print("\n--- Test Scenario 1: Customer with ₹100 balance due ---")
        
        # Add ₹100 charge to customer1
        charge_data = {
            "amount": 100.0,
            "type": "charge",
            "notes": "Initial delivery charge"
        }
        
        success, response = self.run_test(
            "Add ₹100 Charge to Customer 1",
            "POST",
            f"customers/{customer1_id}/update-balance",
            200,
            data=charge_data
        )
        
        if success:
            print(f"   Previous balance: ₹{response.get('previous_balance', 0.0)}")
            print(f"   New balance: ₹{response.get('new_balance', 0.0)}")
            print(f"   Transaction ID: {response.get('transaction_id', 'Unknown')}")
            
            if response.get('new_balance') == 100.0:
                print("✅ ₹100 charge applied correctly")
            else:
                print("❌ ₹100 charge not applied correctly")
        
        # Record ₹50 payment (should become ₹50 due)
        payment_data = {
            "amount": 50.0,
            "type": "payment",
            "notes": "Partial payment received"
        }
        
        success, response = self.run_test(
            "Record ₹50 Payment (should become ₹50 due)",
            "POST",
            f"customers/{customer1_id}/update-balance",
            200,
            data=payment_data
        )
        
        if success:
            print(f"   Previous balance: ₹{response.get('previous_balance', 0.0)}")
            print(f"   New balance: ₹{response.get('new_balance', 0.0)}")
            
            if response.get('new_balance') == 50.0:
                print("✅ ₹50 payment processed correctly - balance now ₹50")
            else:
                print("❌ ₹50 payment not processed correctly")
        
        # Add ₹25 charge (should become ₹75 due)
        additional_charge_data = {
            "amount": 25.0,
            "type": "charge",
            "notes": "Additional delivery charge"
        }
        
        success, response = self.run_test(
            "Add ₹25 Charge (should become ₹75 due)",
            "POST",
            f"customers/{customer1_id}/update-balance",
            200,
            data=additional_charge_data
        )
        
        if success:
            print(f"   Previous balance: ₹{response.get('previous_balance', 0.0)}")
            print(f"   New balance: ₹{response.get('new_balance', 0.0)}")
            
            if response.get('new_balance') == 75.0:
                print("✅ ₹25 charge applied correctly - balance now ₹75")
            else:
                print("❌ ₹25 charge not applied correctly")
        
        # Record ₹75 payment (should become ₹0)
        final_payment_data = {
            "amount": 75.0,
            "type": "payment",
            "notes": "Full payment received"
        }
        
        success, response = self.run_test(
            "Record ₹75 Payment (should become ₹0)",
            "POST",
            f"customers/{customer1_id}/update-balance",
            200,
            data=final_payment_data
        )
        
        if success:
            print(f"   Previous balance: ₹{response.get('previous_balance', 0.0)}")
            print(f"   New balance: ₹{response.get('new_balance', 0.0)}")
            
            if response.get('new_balance') == 0.0:
                print("✅ ₹75 payment processed correctly - balance now ₹0")
            else:
                print("❌ ₹75 payment not processed correctly")
        
        # Test Scenario 2: New customer (₹0 balance)
        print("\n--- Test Scenario 2: New customer (₹0 balance) ---")
        
        # Add ₹200 charge for delivery
        delivery_charge_data = {
            "amount": 200.0,
            "type": "charge",
            "notes": "Delivery charge for new customer"
        }
        
        success, response = self.run_test(
            "Add ₹200 Charge for Delivery",
            "POST",
            f"customers/{customer2_id}/update-balance",
            200,
            data=delivery_charge_data
        )
        
        if success:
            print(f"   Previous balance: ₹{response.get('previous_balance', 0.0)}")
            print(f"   New balance: ₹{response.get('new_balance', 0.0)}")
            
            if response.get('new_balance') == 200.0:
                print("✅ ₹200 delivery charge applied correctly")
            else:
                print("❌ ₹200 delivery charge not applied correctly")
        
        # Record ₹150 payment
        partial_payment_data = {
            "amount": 150.0,
            "type": "payment",
            "notes": "Partial payment from new customer"
        }
        
        success, response = self.run_test(
            "Record ₹150 Payment",
            "POST",
            f"customers/{customer2_id}/update-balance",
            200,
            data=partial_payment_data
        )
        
        if success:
            print(f"   Previous balance: ₹{response.get('previous_balance', 0.0)}")
            print(f"   New balance: ₹{response.get('new_balance', 0.0)}")
            
            if response.get('new_balance') == 50.0:
                print("✅ ₹150 payment processed correctly - ₹50 balance remains due")
            else:
                print("❌ ₹150 payment not processed correctly")
        
        # Test Balance History API
        print("\n--- Testing Balance History API ---")
        
        # Get balance history for customer 1
        success, response = self.run_test(
            "Get Customer 1 Balance History",
            "GET",
            f"customers/{customer1_id}/balance-history",
            200
        )
        
        if success:
            print(f"   Customer ID: {response.get('customer_id', 'Unknown')}")
            print(f"   Current balance: ₹{response.get('current_balance', 0.0)}")
            transactions = response.get('transactions', [])
            print(f"   Transaction count: {len(transactions)}")
            
            if len(transactions) >= 4:  # Should have 4 transactions from scenario 1
                print("✅ Transaction history properly recorded")
                
                # Display transaction details
                for i, transaction in enumerate(transactions[:5]):  # Show first 5
                    print(f"   Transaction {i+1}:")
                    print(f"     Type: {transaction.get('type', 'Unknown')}")
                    print(f"     Amount: ₹{transaction.get('amount', 0.0)}")
                    print(f"     Previous balance: ₹{transaction.get('previous_balance', 0.0)}")
                    print(f"     New balance: ₹{transaction.get('new_balance', 0.0)}")
                    print(f"     Notes: {transaction.get('notes', 'No notes')}")
            else:
                print("❌ Transaction history incomplete")
        else:
            print("❌ Failed to get balance history for customer 1")
        
        # Get balance history for customer 2
        success, response = self.run_test(
            "Get Customer 2 Balance History",
            "GET",
            f"customers/{customer2_id}/balance-history",
            200
        )
        
        if success:
            print(f"   Customer ID: {response.get('customer_id', 'Unknown')}")
            print(f"   Current balance: ₹{response.get('current_balance', 0.0)}")
            transactions = response.get('transactions', [])
            print(f"   Transaction count: {len(transactions)}")
            
            if len(transactions) >= 2:  # Should have 2 transactions from scenario 2
                print("✅ Transaction history properly recorded")
            else:
                print("❌ Transaction history incomplete")
        else:
            print("❌ Failed to get balance history for customer 2")
        
        # Test Error Cases
        print("\n--- Testing Error Cases ---")
        
        # Test invalid customer ID
        success, response = self.run_test(
            "Update Balance - Invalid Customer ID",
            "POST",
            "customers/invalid-customer-id/update-balance",
            404,
            data={"amount": 100.0, "type": "payment"}
        )
        
        if not success:
            print("✅ Correctly returned 404 for invalid customer ID")
        else:
            print("❌ Should have returned 404 for invalid customer ID")
        
        # Test balance history for invalid customer
        success, response = self.run_test(
            "Get Balance History - Invalid Customer ID",
            "GET",
            "customers/invalid-customer-id/balance-history",
            404
        )
        
        if not success:
            print("✅ Correctly returned 404 for invalid customer ID in balance history")
        else:
            print("❌ Should have returned 404 for invalid customer ID in balance history")
        
        # Test Balance Persistence in Customer Records
        print("\n--- Testing Balance Persistence ---")
        
        # Get customer 1 details to verify balance is persisted
        success, response = self.run_test(
            "Get Customer 1 Details - Verify Balance Persistence",
            "GET",
            f"customers/{customer1_id}",
            200
        )
        
        if success:
            balance_due = response.get('balance_due', 0.0)
            print(f"   Customer 1 balance in record: ₹{balance_due}")
            
            if balance_due == 0.0:  # Should be 0 after full payment in scenario 1
                print("✅ Balance correctly persisted in customer record")
            else:
                print("❌ Balance not correctly persisted in customer record")
        
        # Get customer 2 details to verify balance is persisted
        success, response = self.run_test(
            "Get Customer 2 Details - Verify Balance Persistence",
            "GET",
            f"customers/{customer2_id}",
            200
        )
        
        if success:
            balance_due = response.get('balance_due', 0.0)
            print(f"   Customer 2 balance in record: ₹{balance_due}")
            
            if balance_due == 50.0:  # Should be 50 after partial payment in scenario 2
                print("✅ Balance correctly persisted in customer record")
            else:
                print("❌ Balance not correctly persisted in customer record")
        
        # Cleanup
        print("\n--- Cleaning up test data ---")
        
        for customer_id in created_customer_ids:
            success, response = self.run_test(
                f"Delete Test Customer",
                "DELETE",
                f"customers/{customer_id}",
                200
            )
            
            if success:
                print(f"✅ Deleted customer {customer_id}")
            else:
                print(f"❌ Failed to delete customer {customer_id}")
        
        return True

    def run_tests(self):
        """Run all balance management tests"""
        print("🚀 Starting Customer Balance Management API Tests")
        print(f"Base URL: {self.base_url}")
        
        # Authenticate first
        if not self.authenticate():
            print("\n❌ Authentication failed - stopping tests")
            return 1
        
        # Run balance management tests
        self.test_customer_balance_management()
        
        # Print final results
        print("\n" + "="*60)
        print("FINAL RESULTS")
        print("="*60)
        print(f"📊 Tests passed: {self.tests_passed}/{self.tests_run}")
        print(f"📈 Success rate: {(self.tests_passed/self.tests_run)*100:.1f}%")
        
        if self.tests_passed == self.tests_run:
            print("🎉 All tests passed!")
            return 0
        else:
            print(f"⚠️  {self.tests_run - self.tests_passed} test(s) failed")
            return 1

def main():
    tester = BalanceAPITester()
    return tester.run_tests()

if __name__ == "__main__":
    sys.exit(main())