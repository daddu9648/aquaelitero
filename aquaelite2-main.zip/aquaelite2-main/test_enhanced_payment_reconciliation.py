#!/usr/bin/env python3

import requests
import sys
import json
from datetime import datetime, timedelta

class EnhancedPaymentReconciliationTester:
    def __init__(self, base_url="https://jar-system.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.token = None
        self.user_data = None
        self.tests_run = 0
        self.tests_passed = 0

    def run_test(self, name, method, endpoint, expected_status, data=None, headers=None):
        """Run a single API test"""
        url = f"{self.api_url}/{endpoint}"
        test_headers = {'Content-Type': 'application/json'}
        
        if self.token:
            test_headers['Authorization'] = f'Bearer {self.token}'
        
        if headers:
            test_headers.update(headers)

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=test_headers, timeout=30)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=test_headers, timeout=30)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=test_headers, timeout=30)
            elif method == 'DELETE':
                response = requests.delete(url, headers=test_headers, timeout=30)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    if isinstance(response_data, dict) and len(str(response_data)) < 500:
                        print(f"   Response: {response_data}")
                    elif isinstance(response_data, list):
                        print(f"   Response: List with {len(response_data)} items")
                    return success, response_data
                except:
                    return success, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {error_data}")
                except:
                    print(f"   Error: {response.text}")
                return False, {}

        except requests.exceptions.Timeout:
            print(f"❌ Failed - Request timeout (30s)")
            return False, {}
        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def authenticate(self):
        """Authenticate with the API"""
        print("\n" + "="*50)
        print("AUTHENTICATION")
        print("="*50)
        
        # Try different admin credentials
        admin_credentials = [
            {"email": "testadmin@waterkard.com", "password": "admin123"},
            {"email": "admin2@waterkard.com", "password": "admin123"},
            {"email": "admin@waterkard.com", "password": "admin123"}
        ]
        
        for i, login_data in enumerate(admin_credentials):
            print(f"   Trying admin credentials {i+1}: {login_data}")
            
            success, response = self.run_test(
                f"Admin Login Attempt {i+1}",
                "POST",
                "auth/login",
                200,
                data=login_data
            )
            
            if success and 'access_token' in response:
                self.token = response['access_token']
                self.user_data = response.get('user', {})
                print(f"   ✅ Authentication successful!")
                print(f"   User: {self.user_data.get('name', 'Unknown')} ({self.user_data.get('role', 'Unknown')})")
                return True
        
        print("❌ Authentication failed - cannot proceed")
        return False

    def test_enhanced_payment_reconciliation_system(self):
        """Test the enhanced payment reconciliation system with event order payments"""
        print("\n" + "="*50)
        print("TESTING ENHANCED PAYMENT RECONCILIATION SYSTEM")
        print("="*50)
        
        # Store created IDs for cleanup
        created_customer_id = None
        created_event_payment_id = None
        created_quick_delivery_payment_id = None
        created_regular_payment_id = None
        
        # Test 1: Create a test customer for payment testing
        customer_data = {
            "name": "Arjun Patel",
            "mobile": "+91 9876543220",
            "address": "789 Event Street, Pune, Maharashtra - 411001",
            "water_type": "20L",
            "bottle_deposit": 200.0
        }
        
        success, response = self.run_test(
            "Create Test Customer for Event Payment Reconciliation",
            "POST",
            "customers",
            200,
            data=customer_data
        )
        
        if success and 'id' in response:
            created_customer_id = response['id']
            print(f"   Created customer ID: {created_customer_id}")
        else:
            print("❌ Failed to create test customer - cannot proceed")
            return False
        
        # Test 2: Create Event Order Payment with event_id and event_name
        print("\n--- Testing Event Order Payment Creation ---")
        
        event_payment_data = {
            "customer_id": created_customer_id,
            "customer_name": "Arjun Patel",
            "amount": 500.0,
            "payment_mode": "cash",
            "collected_by": self.user_data.get('id', 'test-user'),
            "collected_by_name": self.user_data.get('name', 'Test Admin'),
            "payment_type": "event_order_payment",
            "event_id": "event_123",
            "event_name": "Wedding Reception - Patel Family",
            "notes": "Payment for wedding event water supply",
            "collected_at": datetime.now().isoformat()
        }
        
        success, response = self.run_test(
            "Create Event Order Payment",
            "POST",
            "customer-payments",
            200,
            data=event_payment_data
        )
        
        if success and 'id' in response:
            created_event_payment_id = response['id']
            print(f"   ✅ Event order payment created successfully!")
            print(f"   Payment ID: {created_event_payment_id}")
            print(f"   Payment type: {response.get('payment_type', 'Unknown')}")
            print(f"   Event ID: {response.get('event_id', 'Unknown')}")
            print(f"   Event name: {response.get('event_name', 'Unknown')}")
            print(f"   Reconciliation status: {response.get('reconciliation_status', 'Unknown')}")
            
            # Verify event order specific fields
            if response.get('payment_type') == 'event_order_payment':
                print("   ✅ Payment type correctly set to 'event_order_payment'")
            else:
                print("   ❌ Payment type not set correctly")
                
            if response.get('event_id') == 'event_123':
                print("   ✅ Event ID correctly stored")
            else:
                print("   ❌ Event ID not stored correctly")
                
            if response.get('event_name') == 'Wedding Reception - Patel Family':
                print("   ✅ Event name correctly stored")
            else:
                print("   ❌ Event name not stored correctly")
                
            if response.get('reconciliation_status') == 'pending':
                print("   ✅ Reconciliation status correctly set to 'pending'")
            else:
                print("   ❌ Reconciliation status not set correctly")
        else:
            print("   ❌ Event order payment creation failed")
            return False
        
        # Test 3: Create Quick Delivery Payment
        print("\n--- Testing Quick Delivery Payment Creation ---")
        
        quick_delivery_payment_data = {
            "customer_id": created_customer_id,
            "customer_name": "Arjun Patel",
            "amount": 75.0,
            "payment_mode": "upi",
            "collected_by": self.user_data.get('id', 'test-user'),
            "collected_by_name": self.user_data.get('name', 'Test Admin'),
            "payment_type": "quick_delivery_payment",
            "notes": "Quick delivery payment",
            "collected_at": datetime.now().isoformat()
        }
        
        success, response = self.run_test(
            "Create Quick Delivery Payment",
            "POST",
            "customer-payments",
            200,
            data=quick_delivery_payment_data
        )
        
        if success and 'id' in response:
            created_quick_delivery_payment_id = response['id']
            print(f"   ✅ Quick delivery payment created successfully!")
            print(f"   Payment ID: {created_quick_delivery_payment_id}")
            print(f"   Payment type: {response.get('payment_type', 'Unknown')}")
        else:
            print("   ❌ Quick delivery payment creation failed")
        
        # Test 4: Create Regular Customer Payment
        print("\n--- Testing Regular Customer Payment Creation ---")
        
        regular_payment_data = {
            "customer_id": created_customer_id,
            "customer_name": "Arjun Patel",
            "amount": 150.0,
            "payment_mode": "cash",
            "collected_by": self.user_data.get('id', 'test-user'),
            "collected_by_name": self.user_data.get('name', 'Test Admin'),
            "payment_type": "customer_payment",
            "notes": "Regular customer payment",
            "collected_at": datetime.now().isoformat()
        }
        
        success, response = self.run_test(
            "Create Regular Customer Payment",
            "POST",
            "customer-payments",
            200,
            data=regular_payment_data
        )
        
        if success and 'id' in response:
            created_regular_payment_id = response['id']
            print(f"   ✅ Regular customer payment created successfully!")
            print(f"   Payment ID: {created_regular_payment_id}")
            print(f"   Payment type: {response.get('payment_type', 'Unknown')}")
        else:
            print("   ❌ Regular customer payment creation failed")
        
        # Test 5: Test Admin Reconciliation - Get Pending Payments (should include event payments)
        print("\n--- Testing Admin Reconciliation - Pending Payments ---")
        
        success, response = self.run_test(
            "Get Pending Reconciliation Payments",
            "GET",
            "payments/pending-reconciliation",
            200
        )
        
        if success:
            pending_payments = response if isinstance(response, list) else []
            print(f"   Found {len(pending_payments)} pending payments")
            
            # Find our created payments
            event_payment_found = False
            quick_delivery_payment_found = False
            regular_payment_found = False
            
            for payment in pending_payments:
                if payment.get('id') == created_event_payment_id:
                    event_payment_found = True
                    print(f"   ✅ Event order payment found in pending list")
                    print(f"     Event name: {payment.get('event_name', 'Unknown')}")
                    print(f"     Payment type: {payment.get('payment_type', 'Unknown')}")
                elif payment.get('id') == created_quick_delivery_payment_id:
                    quick_delivery_payment_found = True
                    print(f"   ✅ Quick delivery payment found in pending list")
                elif payment.get('id') == created_regular_payment_id:
                    regular_payment_found = True
                    print(f"   ✅ Regular customer payment found in pending list")
            
            if not event_payment_found:
                print("   ❌ Event order payment not found in pending list")
            if not quick_delivery_payment_found:
                print("   ❌ Quick delivery payment not found in pending list")
            if not regular_payment_found:
                print("   ❌ Regular customer payment not found in pending list")
        else:
            print("   ❌ Failed to get pending payments")
        
        # Test 6: Test Admin Receives Event Order Payment
        print("\n--- Testing Admin Receives Event Order Payment ---")
        
        if created_event_payment_id:
            reconciliation_data = {
                "notes": "Event order payment received from delivery team"
            }
            
            success, response = self.run_test(
                "Admin Receives Event Order Payment",
                "POST",
                f"payments/{created_event_payment_id}/receive",
                200,
                data=reconciliation_data
            )
            
            if success:
                print(f"   ✅ Event order payment received by admin successfully!")
                print(f"   Reconciliation status: {response.get('reconciliation_status', 'Unknown')}")
                print(f"   Received by: {response.get('received_by_admin_name', 'Unknown')}")
                print(f"   Received at: {response.get('received_at', 'Unknown')}")
                
                if response.get('reconciliation_status') == 'received_by_admin':
                    print("   ✅ Status correctly changed to 'received_by_admin'")
                else:
                    print("   ❌ Status not changed correctly")
            else:
                print("   ❌ Failed to receive event order payment")
        
        # Test 7: Test Enhanced Reconciliation Summary (should show payment type breakdowns)
        print("\n--- Testing Enhanced Reconciliation Summary ---")
        
        success, response = self.run_test(
            "Get Enhanced Reconciliation Summary",
            "GET",
            "payments/reconciliation-summary",
            200
        )
        
        if success:
            print(f"   ✅ Reconciliation summary retrieved successfully!")
            
            # Check collectors summary
            collectors = response.get('collectors', [])
            print(f"   Found {len(collectors)} collectors")
            
            for collector in collectors:
                collector_name = collector.get('collector_name', 'Unknown')
                total_amount = collector.get('total_amount', 0)
                pending_amount = collector.get('pending_amount', 0)
                received_amount = collector.get('received_amount', 0)
                payment_types = collector.get('payment_types', {})
                
                print(f"   Collector: {collector_name}")
                print(f"     Total: ₹{total_amount}, Pending: ₹{pending_amount}, Received: ₹{received_amount}")
                print(f"     Payment types: {list(payment_types.keys())}")
            
            # Check payment types summary
            payment_types = response.get('payment_types', {})
            print(f"   Payment types breakdown:")
            
            expected_types = ['event_order_payment', 'quick_delivery_payment', 'customer_payment']
            for payment_type in expected_types:
                if payment_type in payment_types:
                    type_data = payment_types[payment_type]
                    print(f"     {payment_type}: ₹{type_data.get('amount', 0)} ({type_data.get('count', 0)} payments)")
                    print(f"       Pending: ₹{type_data.get('pending', 0)}, Received: ₹{type_data.get('received', 0)}")
                else:
                    print(f"     {payment_type}: Not found")
            
            # Check totals
            totals = response.get('totals', {})
            total_pending = totals.get('total_pending_amount', 0)
            total_received = totals.get('total_received_amount', 0)
            total_amount = totals.get('total_amount', 0)
            
            print(f"   Overall totals:")
            print(f"     Total pending: ₹{total_pending}")
            print(f"     Total received: ₹{total_received}")
            print(f"     Grand total: ₹{total_amount}")
            
            # Verify payment type breakdown is working
            if 'event_order_payment' in payment_types:
                print("   ✅ Event order payment type found in summary")
            else:
                print("   ❌ Event order payment type not found in summary")
                
            if 'quick_delivery_payment' in payment_types:
                print("   ✅ Quick delivery payment type found in summary")
            else:
                print("   ❌ Quick delivery payment type not found in summary")
                
            if 'customer_payment' in payment_types:
                print("   ✅ Customer payment type found in summary")
            else:
                print("   ❌ Customer payment type not found in summary")
        else:
            print("   ❌ Failed to get reconciliation summary")
        
        # Test 8: Test Complete Workflow - Event order payment collection → admin sees in pending → admin receives payment → payment reconciled
        print("\n--- Testing Complete Event Order Payment Workflow ---")
        
        # Create another event order payment for workflow test
        workflow_event_payment_data = {
            "customer_id": created_customer_id,
            "customer_name": "Arjun Patel",
            "amount": 750.0,
            "payment_mode": "cash",
            "collected_by": self.user_data.get('id', 'test-user'),
            "collected_by_name": self.user_data.get('name', 'Test Admin'),
            "payment_type": "event_order_payment",
            "event_id": "event_456",
            "event_name": "Corporate Conference - Tech Summit 2024",
            "notes": "Payment for corporate event water supply",
            "collected_at": datetime.now().isoformat()
        }
        
        success, response = self.run_test(
            "Workflow Step 1: Create Event Order Payment",
            "POST",
            "customer-payments",
            200,
            data=workflow_event_payment_data
        )
        
        workflow_payment_id = None
        if success and 'id' in response:
            workflow_payment_id = response['id']
            print(f"   ✅ Step 1 Complete: Event payment created - ID: {workflow_payment_id}")
            
            # Step 2: Admin sees in pending
            success, response = self.run_test(
                "Workflow Step 2: Admin Sees in Pending",
                "GET",
                "payments/pending-reconciliation",
                200
            )
            
            if success:
                pending_payments = response if isinstance(response, list) else []
                workflow_payment_found = any(p.get('id') == workflow_payment_id for p in pending_payments)
                
                if workflow_payment_found:
                    print(f"   ✅ Step 2 Complete: Payment found in pending list")
                    
                    # Step 3: Admin receives payment
                    reconciliation_data = {
                        "notes": "Corporate event payment received and verified"
                    }
                    
                    success, response = self.run_test(
                        "Workflow Step 3: Admin Receives Payment",
                        "POST",
                        f"payments/{workflow_payment_id}/receive",
                        200,
                        data=reconciliation_data
                    )
                    
                    if success and response.get('reconciliation_status') == 'received_by_admin':
                        print(f"   ✅ Step 3 Complete: Payment received by admin")
                        
                        # Step 4: Verify payment is reconciled (not in pending anymore)
                        success, response = self.run_test(
                            "Workflow Step 4: Verify Payment Reconciled",
                            "GET",
                            "payments/pending-reconciliation",
                            200
                        )
                        
                        if success:
                            pending_payments = response if isinstance(response, list) else []
                            workflow_payment_still_pending = any(p.get('id') == workflow_payment_id for p in pending_payments)
                            
                            if not workflow_payment_still_pending:
                                print(f"   ✅ Step 4 Complete: Payment no longer in pending (reconciled)")
                                print(f"   ✅ COMPLETE WORKFLOW SUCCESSFUL!")
                            else:
                                print(f"   ❌ Step 4 Failed: Payment still in pending list")
                        else:
                            print(f"   ❌ Step 4 Failed: Could not verify reconciliation")
                    else:
                        print(f"   ❌ Step 3 Failed: Admin could not receive payment")
                else:
                    print(f"   ❌ Step 2 Failed: Payment not found in pending list")
            else:
                print(f"   ❌ Step 2 Failed: Could not get pending payments")
        else:
            print(f"   ❌ Step 1 Failed: Could not create workflow payment")
        
        # Test 9: Test Error Handling
        print("\n--- Testing Error Handling ---")
        
        # Test receiving already received payment
        if created_event_payment_id:
            success, response = self.run_test(
                "Try to Receive Already Received Payment (Should Fail)",
                "POST",
                f"payments/{created_event_payment_id}/receive",
                400,
                data={"notes": "Should fail"}
            )
            
            if not success:
                print("   ✅ Correctly prevented receiving already received payment")
            else:
                print("   ❌ Should have prevented receiving already received payment")
        
        # Test receiving non-existent payment
        success, response = self.run_test(
            "Try to Receive Non-existent Payment (Should Fail)",
            "POST",
            "payments/non-existent-id/receive",
            404,
            data={"notes": "Should fail"}
        )
        
        if not success:
            print("   ✅ Correctly handled non-existent payment")
        else:
            print("   ❌ Should have handled non-existent payment")
        
        # Cleanup: Delete created customer
        print("\n--- Cleaning up test data ---")
        
        if created_customer_id:
            success, response = self.run_test(
                "Delete Test Customer",
                "DELETE",
                f"customers/{created_customer_id}",
                200
            )
            if success:
                print(f"   ✅ Deleted customer {created_customer_id}")
        
        print("\n✅ ENHANCED PAYMENT RECONCILIATION SYSTEM TESTING COMPLETED")
        print("="*70)
        
        return True

    def run_tests(self):
        """Run the enhanced payment reconciliation tests"""
        print("🚀 Starting Enhanced Payment Reconciliation System Testing...")
        print(f"Base URL: {self.base_url}")
        print(f"API URL: {self.api_url}")
        
        # Authenticate first
        if not self.authenticate():
            return 1
        
        # Run the enhanced payment reconciliation test
        self.test_enhanced_payment_reconciliation_system()
        
        # Print final results
        print("\n" + "="*60)
        print("FINAL TEST RESULTS")
        print("="*60)
        print(f"Total tests run: {self.tests_run}")
        print(f"Tests passed: {self.tests_passed}")
        print(f"Tests failed: {self.tests_run - self.tests_passed}")
        print(f"Success rate: {(self.tests_passed / self.tests_run * 100):.1f}%")
        
        if self.tests_passed == self.tests_run:
            print("🎉 ALL TESTS PASSED!")
            return 0
        else:
            print("⚠️  Some tests failed - check logs above")
            return 1

if __name__ == "__main__":
    tester = EnhancedPaymentReconciliationTester()
    sys.exit(tester.run_tests())