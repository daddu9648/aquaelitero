#!/usr/bin/env python3
"""
Focused test for User Registration Edge Cases as requested in the review
"""
import requests
import json

class UserRegistrationTester:
    def __init__(self, base_url="https://jar-system.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.token = None
        self.tests_run = 0
        self.tests_passed = 0

    def login_admin(self):
        """Login with admin credentials"""
        login_data = {
            "email": "testadmin@example.com",
            "password": "admin123"
        }
        
        response = requests.post(f"{self.api_url}/auth/login", json=login_data)
        if response.status_code == 200:
            self.token = response.json()['access_token']
            print("✅ Admin login successful")
            return True
        else:
            print(f"❌ Admin login failed: {response.status_code}")
            return False

    def run_test(self, name, data, expected_status):
        """Run a single registration test"""
        self.tests_run += 1
        print(f"\n🔍 Testing: {name}")
        
        headers = {'Authorization': f'Bearer {self.token}'}
        response = requests.post(f"{self.api_url}/auth/register", json=data, headers=headers)
        
        success = response.status_code == expected_status
        if success:
            self.tests_passed += 1
            print(f"✅ PASSED - Status: {response.status_code}")
            try:
                response_data = response.json()
                if 'id' in response_data:
                    print(f"   User ID: {response_data['id']}")
                    print(f"   Name: {response_data.get('name', 'N/A')}")
                    print(f"   Email: {response_data.get('email', 'N/A')}")
                    print(f"   Mobile: {response_data.get('mobile', 'N/A')}")
                    print(f"   Role: {response_data.get('role', 'N/A')}")
                    return response_data['id']
                else:
                    print(f"   Response: {response_data}")
            except:
                pass
        else:
            print(f"❌ FAILED - Expected {expected_status}, got {response.status_code}")
            try:
                error_data = response.json()
                print(f"   Error: {error_data.get('detail', 'Unknown error')}")
            except:
                print(f"   Error: {response.text}")
        
        return None

    def cleanup_user(self, user_id, name):
        """Delete a test user"""
        if user_id:
            headers = {'Authorization': f'Bearer {self.token}'}
            response = requests.delete(f"{self.api_url}/users/{user_id}", headers=headers)
            if response.status_code == 200:
                print(f"✅ Cleaned up {name}")
            else:
                print(f"❌ Failed to cleanup {name}")

    def run_focused_tests(self):
        """Run the specific test scenarios requested in the review"""
        print("🚀 Starting Focused User Registration Tests")
        print("="*60)
        
        if not self.login_admin():
            return 1
        
        created_users = []
        
        # Test 1: Create user with email (as specified in test request)
        user_with_email_data = {
            "name": "Test With Email",
            "mobile": "+91 8888888001",
            "email": "testemail1@example.com",
            "password": "pass123",
            "role": "delivery_boy"
        }
        user_id = self.run_test("User with Email", user_with_email_data, 200)
        if user_id:
            created_users.append((user_id, "User with Email"))
        
        # Test 2: Create user without email (as specified in test request)
        user_without_email_data = {
            "name": "Test No Email",
            "mobile": "+91 8888888002",
            "password": "pass123",
            "role": "delivery_boy"
        }
        user_id = self.run_test("User without Email", user_without_email_data, 200)
        if user_id:
            created_users.append((user_id, "User without Email"))
        
        # Test 3: Create user with empty email string (CRITICAL TEST)
        user_empty_email_data = {
            "name": "Test Empty Email",
            "mobile": "+91 8888888003",
            "email": "",
            "password": "pass123",
            "role": "admin"
        }
        user_id = self.run_test("User with Empty Email String (CRITICAL)", user_empty_email_data, 200)
        if user_id:
            created_users.append((user_id, "User with Empty Email"))
        
        # Test 4: Test duplicate mobile (should fail)
        duplicate_mobile_data = {
            "name": "Duplicate Mobile",
            "mobile": "+91 8888888001",  # Same as first user
            "password": "pass123",
            "role": "delivery_boy"
        }
        self.run_test("Duplicate Mobile (Should Fail)", duplicate_mobile_data, 400)
        
        # Test 5: Test duplicate email (should fail)
        duplicate_email_data = {
            "name": "Duplicate Email",
            "mobile": "+91 8888888099",
            "email": "testemail1@example.com",  # Same as first user
            "password": "pass123",
            "role": "delivery_boy"
        }
        self.run_test("Duplicate Email (Should Fail)", duplicate_email_data, 400)
        
        # Test 6: Test invalid email format (should fail)
        invalid_email_data = {
            "name": "Invalid Email",
            "mobile": "+91 9999999098",
            "email": "invalid-email-format",
            "password": "pass123",
            "role": "delivery_boy"
        }
        self.run_test("Invalid Email Format (Should Fail)", invalid_email_data, 422)
        
        # Test 7: Test missing required field - name (should fail)
        missing_name_data = {
            "mobile": "+91 9999999097",
            "email": "test@example.com",
            "password": "pass123",
            "role": "delivery_boy"
        }
        self.run_test("Missing Name (Should Fail)", missing_name_data, 422)
        
        # Test 8: Test missing required field - mobile (should fail)
        missing_mobile_data = {
            "name": "Test User",
            "email": "test@example.com",
            "password": "pass123",
            "role": "delivery_boy"
        }
        self.run_test("Missing Mobile (Should Fail)", missing_mobile_data, 422)
        
        # Test 9: Test missing required field - password (should fail)
        missing_password_data = {
            "name": "Test User",
            "mobile": "+91 9999999096",
            "email": "test@example.com",
            "role": "delivery_boy"
        }
        self.run_test("Missing Password (Should Fail)", missing_password_data, 422)
        
        # Test 10: Create admin/manager user (role assignment testing)
        admin_user_data = {
            "name": "Test Admin Manager",
            "mobile": "+91 8888888095",
            "email": "admintest@example.com",
            "password": "pass123",
            "role": "admin"
        }
        user_id = self.run_test("Admin/Manager User", admin_user_data, 200)
        if user_id:
            created_users.append((user_id, "Admin User"))
        
        # Cleanup
        print("\n" + "="*60)
        print("CLEANUP")
        print("="*60)
        for user_id, name in created_users:
            self.cleanup_user(user_id, name)
        
        # Final results
        print("\n" + "="*60)
        print("FINAL RESULTS")
        print("="*60)
        print(f"📊 Tests passed: {self.tests_passed}/{self.tests_run}")
        print(f"📈 Success rate: {(self.tests_passed/self.tests_run)*100:.1f}%")
        
        if self.tests_passed == self.tests_run:
            print("🎉 All tests passed!")
            return 0
        else:
            print(f"⚠️  {self.tests_run - self.tests_passed} test(s) failed")
            return 1

def main():
    tester = UserRegistrationTester()
    return tester.run_focused_tests()

if __name__ == "__main__":
    exit(main())