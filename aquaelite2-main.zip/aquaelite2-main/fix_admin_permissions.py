import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
import os
from dotenv import load_dotenv

load_dotenv('backend/.env')
mongo_url = os.environ['MONGO_URL']
db_name = os.environ['DB_NAME']

async def update_admin_permissions():
    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]
    
    # Update admin user permissions
    result = await db.users.update_one(
        {'email': 'admin@waterkard.com'},
        {'$set': {'permissions': ['admin.*']}}
    )
    
    if result.modified_count > 0:
        print('✅ Admin user permissions updated successfully')
    else:
        print('❌ Failed to update admin user permissions')
    
    # Verify the update
    user = await db.users.find_one({'email': 'admin@waterkard.com'})
    if user:
        print(f'   Permissions: {user.get("permissions", [])}')
    
    client.close()

if __name__ == "__main__":
    asyncio.run(update_admin_permissions())