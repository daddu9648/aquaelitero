#!/usr/bin/env python3

import requests
import sys
import json
from datetime import datetime, timedelta

class PaymentReconciliationTester:
    def __init__(self, base_url="https://jar-system.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.token = None
        self.user_data = None
        self.tests_run = 0
        self.tests_passed = 0

    def run_test(self, name, method, endpoint, expected_status, data=None, headers=None):
        """Run a single API test"""
        url = f"{self.api_url}/{endpoint}"
        test_headers = {'Content-Type': 'application/json'}
        
        if self.token:
            test_headers['Authorization'] = f'Bearer {self.token}'
        
        if headers:
            test_headers.update(headers)

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=test_headers, timeout=30)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=test_headers, timeout=30)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=test_headers, timeout=30)
            elif method == 'DELETE':
                response = requests.delete(url, headers=test_headers, timeout=30)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    if isinstance(response_data, dict) and len(str(response_data)) < 500:
                        print(f"   Response: {response_data}")
                    elif isinstance(response_data, list):
                        print(f"   Response: List with {len(response_data)} items")
                    return success, response_data
                except:
                    return success, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {error_data}")
                except:
                    print(f"   Error: {response.text}")
                return False, {}

        except requests.exceptions.Timeout:
            print(f"❌ Failed - Request timeout (30s)")
            return False, {}
        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def authenticate(self):
        """Authenticate with admin credentials"""
        print("\n" + "="*50)
        print("AUTHENTICATION")
        print("="*50)
        
        # Try different admin credentials
        admin_credentials = [
            {"email": "testadmin@waterkard.com", "password": "admin123"},
            {"email": "admin2@waterkard.com", "password": "admin123"},
            {"email": "admin@waterkard.com", "password": "admin123"}
        ]
        
        for i, login_data in enumerate(admin_credentials):
            print(f"   Trying admin credentials {i+1}: {login_data}")
            
            success, response = self.run_test(
                f"Admin Login Attempt {i+1}",
                "POST",
                "auth/login",
                200,
                data=login_data
            )
            
            if success and 'access_token' in response:
                self.token = response['access_token']
                self.user_data = response.get('user', {})
                print(f"   ✅ Authentication successful!")
                print(f"   User: {self.user_data.get('name', 'Unknown')} ({self.user_data.get('role', 'Unknown')})")
                return True
        
        print("❌ Authentication failed - cannot proceed")
        return False

    def test_payment_reconciliation_system(self):
        """Test the comprehensive payment reconciliation system"""
        print("\n" + "="*50)
        print("TESTING PAYMENT RECONCILIATION SYSTEM")
        print("="*50)
        
        if not self.token:
            print("❌ Cannot test payment reconciliation - no authentication token")
            return False
        
        # Store created data for cleanup
        created_customer_ids = []
        created_payment_ids = []
        
        # Test 1: Create test customers for reconciliation testing
        test_customers = [
            {
                "name": "Arjun Patel",
                "mobile": "+91 9876543200",
                "address": "123 Reconciliation Street, Ahmedabad, Gujarat - 380001",
                "water_type": "20L",
                "bottle_deposit": 100.0
            },
            {
                "name": "Meera Singh",
                "mobile": "+91 9876543201", 
                "address": "456 Payment Lane, Jaipur, Rajasthan - 302001",
                "water_type": "20L",
                "bottle_deposit": 150.0
            }
        ]
        
        for i, customer_data in enumerate(test_customers):
            success, response = self.run_test(
                f"Create Test Customer {i+1} for Reconciliation",
                "POST",
                "customers",
                200,
                data=customer_data
            )
            
            if success and 'id' in response:
                customer_id = response['id']
                created_customer_ids.append(customer_id)
                print(f"   Created customer ID: {customer_id}")
        
        if len(created_customer_ids) < 2:
            print("❌ Failed to create test customers - cannot proceed with reconciliation tests")
            return False
        
        customer1_id = created_customer_ids[0]
        customer2_id = created_customer_ids[1]
        
        # Test 2: Create customer payments with reconciliation fields (delivery boy as collector)
        print("\n--- Test Scenario 1: Create customer payment with delivery boy as collector ---")
        
        # Get delivery boys for collector assignment
        success, delivery_boys = self.run_test(
            "Get Delivery Boys for Collector Assignment",
            "GET",
            "delivery-boys",
            200
        )
        
        delivery_boy_id = None
        delivery_boy_name = "Test Delivery Boy"
        if success and delivery_boys and len(delivery_boys) > 0:
            delivery_boy_id = delivery_boys[0]['id']
            delivery_boy_name = delivery_boys[0]['name']
            print(f"   Using delivery boy: {delivery_boy_name} (ID: {delivery_boy_id})")
        else:
            # Use admin as collector if no delivery boys available
            delivery_boy_id = self.user_data.get('id', 'test-admin')
            delivery_boy_name = self.user_data.get('name', 'Test Admin')
            print(f"   No delivery boys found, using admin as collector: {delivery_boy_name}")
        
        # Create payment with delivery boy as collector - should show as pending
        payment_data_1 = {
            "customer_id": customer1_id,
            "customer_name": "Arjun Patel",
            "amount": 250.0,
            "payment_mode": "cash",
            "collected_by": delivery_boy_id,
            "collected_by_name": delivery_boy_name,
            "payment_type": "customer_payment",
            "notes": "Payment collected by delivery boy - should be pending reconciliation",
            "collected_at": datetime.now().isoformat()
        }
        
        success, response = self.run_test(
            "Create Customer Payment with Delivery Boy Collector",
            "POST",
            "customer-payments",
            200,
            data=payment_data_1
        )
        
        payment_1_id = None
        if success and 'id' in response:
            payment_1_id = response['id']
            created_payment_ids.append(payment_1_id)
            print(f"   ✅ Payment created successfully!")
            print(f"   Payment ID: {payment_1_id}")
            print(f"   Amount: ₹{response.get('amount', 0.0)}")
            print(f"   Collected by: {response.get('collected_by_name', 'Unknown')}")
            print(f"   Reconciliation status: {response.get('reconciliation_status', 'Unknown')}")
            
            # Verify reconciliation status is pending
            if response.get('reconciliation_status') == 'pending':
                print("   ✅ Payment correctly marked as pending reconciliation")
            else:
                print("   ❌ Payment should be marked as pending reconciliation")
        else:
            print("   ❌ Failed to create customer payment")
            return False
        
        # Create another payment with manager as collector
        payment_data_2 = {
            "customer_id": customer2_id,
            "customer_name": "Meera Singh",
            "amount": 180.0,
            "payment_mode": "upi",
            "collected_by": self.user_data.get('id', 'test-admin'),
            "collected_by_name": f"Manager {self.user_data.get('name', 'Test Admin')}",
            "payment_type": "customer_payment",
            "notes": "Payment collected by manager - should be pending reconciliation",
            "collected_at": datetime.now().isoformat()
        }
        
        success, response = self.run_test(
            "Create Customer Payment with Manager Collector",
            "POST",
            "customer-payments",
            200,
            data=payment_data_2
        )
        
        payment_2_id = None
        if success and 'id' in response:
            payment_2_id = response['id']
            created_payment_ids.append(payment_2_id)
            print(f"   ✅ Second payment created successfully!")
            print(f"   Payment ID: {payment_2_id}")
            print(f"   Amount: ₹{response.get('amount', 0.0)}")
            print(f"   Reconciliation status: {response.get('reconciliation_status', 'Unknown')}")
        
        # Test 3: Admin should see payments in pending reconciliation list
        print("\n--- Test Scenario 2: Admin views pending reconciliation payments ---")
        
        success, response = self.run_test(
            "Get Pending Reconciliation Payments (Admin Only)",
            "GET",
            "payments/pending-reconciliation",
            200
        )
        
        if success:
            pending_payments = response if isinstance(response, list) else []
            print(f"   Found {len(pending_payments)} pending payments")
            
            # Check if our created payments are in the list
            our_payment_ids = [payment_1_id, payment_2_id]
            found_payments = []
            
            for payment in pending_payments:
                if payment.get('id') in our_payment_ids:
                    found_payments.append(payment)
                    print(f"   ✅ Found our payment: {payment.get('id')} - ₹{payment.get('amount', 0)} by {payment.get('collected_by_name', 'Unknown')}")
            
            if len(found_payments) == 2:
                print("   ✅ Both payments correctly appear in pending reconciliation list")
            else:
                print(f"   ❌ Expected 2 payments in pending list, found {len(found_payments)}")
        else:
            print("   ❌ Failed to get pending reconciliation payments")
        
        # Test 4: Admin receives payment - status should change to received_by_admin
        print("\n--- Test Scenario 3: Admin receives payment from collector ---")
        
        if payment_1_id:
            reconciliation_data = {
                "notes": "Payment received from delivery boy - cash verified and deposited"
            }
            
            success, response = self.run_test(
                "Admin Receives Payment from Delivery Boy",
                "POST",
                f"payments/{payment_1_id}/receive",
                200,
                data=reconciliation_data
            )
            
            if success:
                print(f"   ✅ Payment received successfully!")
                print(f"   Payment ID: {response.get('id', 'Unknown')}")
                print(f"   Reconciliation status: {response.get('reconciliation_status', 'Unknown')}")
                print(f"   Received by: {response.get('received_by_admin_name', 'Unknown')}")
                print(f"   Received at: {response.get('received_at', 'Unknown')}")
                print(f"   Notes: {response.get('reconciliation_notes', 'No notes')}")
                
                # Verify status changed to received_by_admin
                if response.get('reconciliation_status') == 'received_by_admin':
                    print("   ✅ Payment status correctly changed to received_by_admin")
                else:
                    print("   ❌ Payment status should be received_by_admin")
                
                # Verify admin details are recorded
                if response.get('received_by_admin_name') == self.user_data.get('name'):
                    print("   ✅ Admin details correctly recorded")
                else:
                    print("   ❌ Admin details not correctly recorded")
            else:
                print("   ❌ Failed to receive payment")
        
        # Test 5: Reconciliation summary should show correct amounts by collector
        print("\n--- Test Scenario 4: Reconciliation summary by collector ---")
        
        success, response = self.run_test(
            "Get Reconciliation Summary by Collector",
            "GET",
            "payments/reconciliation-summary",
            200
        )
        
        if success:
            collectors = response.get('collectors', [])
            totals = response.get('totals', {})
            
            print(f"   Found {len(collectors)} collectors")
            print(f"   Total pending amount: ₹{totals.get('total_pending_amount', 0)}")
            print(f"   Total received amount: ₹{totals.get('total_received_amount', 0)}")
            print(f"   Total amount: ₹{totals.get('total_amount', 0)}")
            
            # Find our collectors in the summary
            for collector in collectors:
                collector_name = collector.get('collector_name', 'Unknown')
                pending_amount = collector.get('pending_amount', 0)
                received_amount = collector.get('received_amount', 0)
                total_amount = collector.get('total_amount', 0)
                
                print(f"   Collector: {collector_name}")
                print(f"     Pending: ₹{pending_amount} ({collector.get('pending_count', 0)} payments)")
                print(f"     Received: ₹{received_amount} ({collector.get('received_count', 0)} payments)")
                print(f"     Total: ₹{total_amount} ({collector.get('total_count', 0)} payments)")
            
            # Verify totals make sense
            expected_total = 250.0 + 180.0  # Our two payments
            if abs(totals.get('total_amount', 0) - expected_total) < 0.01:
                print("   ✅ Total amounts in summary are correct")
            else:
                print(f"   ⚠️  Total amount mismatch: expected ₹{expected_total}, got ₹{totals.get('total_amount', 0)}")
        else:
            print("   ❌ Failed to get reconciliation summary")
        
        # Test 6: Test authentication - only admin should access reconciliation APIs
        print("\n--- Test Scenario 5: Authentication and authorization ---")
        
        # Test with invalid token
        success, response = self.run_test(
            "Pending Reconciliation - Invalid Token (Should Fail)",
            "GET",
            "payments/pending-reconciliation",
            401,
            headers={"Authorization": "Bearer invalid_token"}
        )
        
        if not success:
            print("   ✅ Correctly blocked access with invalid token")
        else:
            print("   ❌ Should have blocked access with invalid token")
        
        # Test receiving payment with invalid token
        if payment_2_id:
            success, response = self.run_test(
                "Receive Payment - Invalid Token (Should Fail)",
                "POST",
                f"payments/{payment_2_id}/receive",
                401,
                data={"notes": "Test"},
                headers={"Authorization": "Bearer invalid_token"}
            )
            
            if not success:
                print("   ✅ Correctly blocked payment receive with invalid token")
            else:
                print("   ❌ Should have blocked payment receive with invalid token")
        
        # Test 7: Test edge cases
        print("\n--- Test Scenario 6: Edge cases and error handling ---")
        
        # Try to receive non-existent payment
        success, response = self.run_test(
            "Receive Non-existent Payment (Should Fail)",
            "POST",
            "payments/non-existent-id/receive",
            404,
            data={"notes": "Test"}
        )
        
        if not success:
            print("   ✅ Correctly handled non-existent payment")
        else:
            print("   ❌ Should have failed for non-existent payment")
        
        # Try to receive already received payment
        if payment_1_id:
            success, response = self.run_test(
                "Receive Already Received Payment (Should Fail)",
                "POST",
                f"payments/{payment_1_id}/receive",
                400,
                data={"notes": "Trying to receive again"}
            )
            
            if not success:
                print("   ✅ Correctly prevented double receiving of payment")
            else:
                print("   ❌ Should have prevented double receiving of payment")
        
        # Test 8: Verify integration with customer management reports
        print("\n--- Test Scenario 7: Integration with customer management reports ---")
        
        # Check if reconciliation status appears in payment reports
        success, response = self.run_test(
            "Get All Customer Payments (Check Reconciliation Status)",
            "GET",
            "customer-payments",
            200
        )
        
        if success:
            payments = response if isinstance(response, list) else []
            reconciliation_payments = [p for p in payments if 'reconciliation_status' in p]
            
            print(f"   Found {len(payments)} total payments")
            print(f"   Found {len(reconciliation_payments)} payments with reconciliation status")
            
            if len(reconciliation_payments) >= 2:
                print("   ✅ Reconciliation status properly integrated in payment reports")
                
                # Show status breakdown
                pending_count = len([p for p in reconciliation_payments if p.get('reconciliation_status') == 'pending'])
                received_count = len([p for p in reconciliation_payments if p.get('reconciliation_status') == 'received_by_admin'])
                
                print(f"   Status breakdown: {pending_count} pending, {received_count} received")
            else:
                print("   ❌ Reconciliation status not properly integrated")
        else:
            print("   ❌ Failed to get customer payments for integration check")
        
        # Cleanup: Delete created customers and payments
        print("\n--- Cleaning up test data ---")
        
        for i, customer_id in enumerate(created_customer_ids):
            success, response = self.run_test(
                f"Delete Test Customer {i+1}",
                "DELETE",
                f"customers/{customer_id}",
                200
            )
            if success:
                print(f"   ✅ Deleted customer {customer_id}")
        
        print("\n✅ PAYMENT RECONCILIATION SYSTEM TESTING COMPLETED")
        print("="*60)
        
        return True

    def run_tests(self):
        """Run all payment reconciliation tests"""
        print("🚀 Starting Payment Reconciliation System Testing...")
        print(f"Base URL: {self.base_url}")
        print(f"API URL: {self.api_url}")
        
        # Test authentication first
        if not self.authenticate():
            print("❌ Authentication failed - stopping tests")
            return
        
        # Run payment reconciliation tests
        self.test_payment_reconciliation_system()
        
        # Print final results
        print("\n" + "="*60)
        print("🏁 FINAL TEST RESULTS")
        print("="*60)
        print(f"Total tests run: {self.tests_run}")
        print(f"Tests passed: {self.tests_passed}")
        print(f"Tests failed: {self.tests_run - self.tests_passed}")
        print(f"Success rate: {(self.tests_passed / self.tests_run * 100):.1f}%")
        
        if self.tests_passed == self.tests_run:
            print("🎉 ALL TESTS PASSED!")
        else:
            print("⚠️  Some tests failed - check logs above")
        
        print("="*60)

if __name__ == "__main__":
    tester = PaymentReconciliationTester()
    tester.run_tests()