#!/usr/bin/env python3
import requests
import json

def setup_admin_user():
    """Create admin user if it doesn't exist"""
    base_url = "https://jar-system.preview.emergentagent.com"
    api_url = f"{base_url}/api"
    
    # Try to register admin user
    admin_data = {
        "email": "admin@waterkard.com",
        "name": "Admin User",
        "mobile": "+91 9876543210",
        "password": "admin123",
        "role": "admin"
    }
    
    print("🔧 Setting up admin user...")
    
    try:
        response = requests.post(
            f"{api_url}/auth/register",
            json=admin_data,
            headers={'Content-Type': 'application/json'},
            timeout=30
        )
        
        if response.status_code == 200:
            print("✅ Admin user created successfully")
            user_data = response.json()
            print(f"   User: {user_data.get('name')} ({user_data.get('email')})")
            return True
        elif response.status_code == 400:
            error_data = response.json()
            if "already registered" in error_data.get('detail', ''):
                print("✅ Admin user already exists")
                return True
            else:
                print(f"❌ Registration failed: {error_data}")
                return False
        else:
            print(f"❌ Registration failed with status {response.status_code}")
            print(f"   Response: {response.text}")
            return False
            
    except Exception as e:
        print(f"❌ Error setting up admin user: {str(e)}")
        return False

def test_login():
    """Test login with admin credentials"""
    base_url = "https://jar-system.preview.emergentagent.com"
    api_url = f"{base_url}/api"
    
    login_data = {
        "email": "admin@waterkard.com",
        "password": "admin123"
    }
    
    print("🔍 Testing admin login...")
    
    try:
        response = requests.post(
            f"{api_url}/auth/login",
            json=login_data,
            headers={'Content-Type': 'application/json'},
            timeout=30
        )
        
        if response.status_code == 200:
            print("✅ Login successful")
            data = response.json()
            print(f"   Token: {data.get('access_token', '')[:20]}...")
            print(f"   User: {data.get('user', {}).get('name', 'Unknown')}")
            return True
        else:
            print(f"❌ Login failed with status {response.status_code}")
            print(f"   Response: {response.text}")
            return False
            
    except Exception as e:
        print(f"❌ Error testing login: {str(e)}")
        return False

if __name__ == "__main__":
    print("🚀 Admin Setup Script")
    print("=" * 50)
    
    if setup_admin_user():
        test_login()
    else:
        print("❌ Failed to setup admin user")