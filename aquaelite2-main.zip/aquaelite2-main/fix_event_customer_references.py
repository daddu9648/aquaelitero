#!/usr/bin/env python3
"""
Fix Event Orders with Invalid Customer References
This script fixes event orders that reference deleted/non-existent customers
"""

import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv

load_dotenv('/app/backend/.env')

MONGO_URL = os.getenv('MONGO_URL', 'mongodb://localhost:27017')
DB_NAME = os.getenv('DB_NAME', 'test_database')

async def fix_invalid_customer_references():
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]
    
    print("\n" + "="*70)
    print("🔧 Fixing Event Orders with Invalid Customer References")
    print("="*70 + "\n")
    
    # Get all event orders
    event_orders = await db.event_orders.find().to_list(1000)
    print(f"📋 Total event orders found: {len(event_orders)}\n")
    
    # Get all valid customer IDs
    customers = await db.customers.find().to_list(1000)
    valid_customer_ids = {c['id'] for c in customers}
    print(f"👥 Total customers in database: {len(customers)}\n")
    
    if len(customers) == 0:
        print("❌ No customers found! Please add customers first.")
        print("   Go to Customer Management and add at least one customer.\n")
        client.close()
        return
    
    # Find event orders with invalid customer references
    invalid_events = []
    for event in event_orders:
        if event.get('customer_id') not in valid_customer_ids:
            invalid_events.append(event)
    
    if len(invalid_events) == 0:
        print("✅ All event orders have valid customer references!")
        print("   No fixes needed.\n")
        client.close()
        return
    
    print(f"⚠️  Found {len(invalid_events)} event orders with invalid customer references:\n")
    for event in invalid_events:
        print(f"   • {event.get('event_name')} (ID: {event['id'][:8]}...)")
        print(f"     Invalid Customer ID: {event.get('customer_id')[:8]}...\n")
    
    # Ask for confirmation
    print("="*70)
    confirm = input("\n❓ Fix these event orders by assigning first available customer? (YES/no): ")
    
    if confirm != "YES":
        print("\n❌ Fix cancelled. No changes made.\n")
        client.close()
        return
    
    # Get first customer to assign
    default_customer = customers[0]
    print(f"\n🔄 Assigning events to customer: {default_customer['name']}\n")
    
    # Fix each invalid event order
    fixed_count = 0
    for event in invalid_events:
        result = await db.event_orders.update_one(
            {"id": event['id']},
            {"$set": {
                "customer_id": default_customer['id'],
                "customer_name": default_customer['name'],
                "customer_mobile": default_customer['mobile'],
                "customer_address": default_customer.get('address', '')
            }}
        )
        
        if result.modified_count > 0:
            print(f"   ✅ Fixed: {event.get('event_name')}")
            fixed_count += 1
        else:
            print(f"   ❌ Failed: {event.get('event_name')}")
    
    print("\n" + "="*70)
    print(f"📊 Summary: Fixed {fixed_count} out of {len(invalid_events)} event orders")
    print("="*70)
    
    print("\n💡 Next Steps:")
    print("   1. Refresh your browser (Ctrl + Shift + R)")
    print("   2. Go to Invoice Management")
    print("   3. Try creating invoice again")
    print("   4. You can edit event orders to assign correct customers\n")
    
    client.close()

if __name__ == "__main__":
    asyncio.run(fix_invalid_customer_references())
