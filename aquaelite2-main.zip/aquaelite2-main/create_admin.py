#!/usr/bin/env python3
import asyncio
import sys
import os
sys.path.append('/app/backend')

from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
import bcrypt
import uuid
from datetime import datetime, timezone

# Load environment variables
load_dotenv('/app/backend/.env')
MONGO_URL = os.environ.get('MONGO_URL', 'mongodb://localhost:27017')
DB_NAME = os.environ.get('DB_NAME', 'test_database')

def hash_password(password: str) -> str:
    """Hash password using bcrypt"""
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')

async def create_admin_user():
    """Create admin user in database"""
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]
    
    print("🔍 Checking database connection...")
    try:
        # Test connection
        await client.admin.command('ping')
        print("✅ Database connection successful")
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
        return
    
    # Check if admin user exists
    admin_email = "admin@waterkard.com"
    existing_admin = await db.users.find_one({"email": admin_email})
    
    if existing_admin:
        print(f"🔍 Found existing admin user: {existing_admin.get('name', 'Unknown')}")
        print(f"   Email: {existing_admin.get('email')}")
        print(f"   Mobile: {existing_admin.get('mobile')}")
        print(f"   Role: {existing_admin.get('role')}")
        print(f"   Permissions: {existing_admin.get('permissions', [])}")
        
        # Update permissions if missing
        if not existing_admin.get('permissions'):
            print("🔧 Updating admin permissions...")
            result = await db.users.update_one(
                {"email": admin_email},
                {"$set": {"permissions": ["admin.*"]}}
            )
            if result.modified_count > 0:
                print("✅ Admin permissions updated")
            else:
                print("❌ Failed to update admin permissions")
    else:
        print("👤 Creating new admin user...")
        
        admin_data = {
            "id": str(uuid.uuid4()),
            "email": admin_email,
            "name": "Admin User",
            "mobile": "+91 9876543210",
            "role": "admin",
            "is_active": True,
            "permissions": ["admin.*"],
            "assigned_area": None,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "password_hash": hash_password("admin123")
        }
        
        try:
            result = await db.users.insert_one(admin_data)
            if result.inserted_id:
                print("✅ Admin user created successfully")
                print(f"   ID: {admin_data['id']}")
                print(f"   Email: {admin_data['email']}")
                print(f"   Name: {admin_data['name']}")
                print(f"   Mobile: {admin_data['mobile']}")
                print(f"   Role: {admin_data['role']}")
                print(f"   Permissions: {admin_data['permissions']}")
            else:
                print("❌ Failed to create admin user")
        except Exception as e:
            print(f"❌ Error creating admin user: {e}")
    
    # List all users
    print("\n📋 All users in database:")
    users = await db.users.find({}).to_list(1000)
    if users:
        for i, user in enumerate(users, 1):
            print(f"   {i}. {user.get('name', 'Unknown')} ({user.get('email', 'No email')}) - {user.get('role', 'Unknown role')}")
    else:
        print("   No users found in database")
    
    client.close()
    print("\n✅ Database operations completed")

if __name__ == "__main__":
    asyncio.run(create_admin_user())