#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from backend_test import WaterKardAPITester

def main():
    """Run PDF reports with common header test"""
    tester = WaterKardAPITester()
    
    # Test authentication first
    if not tester.test_authentication():
        print("❌ Authentication failed - stopping tests")
        return 1
    
    # Run the PDF reports test
    success = tester.test_pdf_reports_with_common_header()
    
    if success:
        print("\n🎉 PDF REPORTS WITH COMMON HEADER TEST COMPLETED SUCCESSFULLY!")
        return 0
    else:
        print("\n❌ PDF REPORTS WITH COMMON HEADER TEST FAILED!")
        return 1

if __name__ == "__main__":
    exit(main())