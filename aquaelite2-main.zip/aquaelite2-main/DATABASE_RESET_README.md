# Database Reset Instructions

## ⚠️ IMPORTANT WARNING

This script will **DELETE ALL DATA** from your AquaElite database. This action is **IRREVERSIBLE**.

## What will be deleted?

- ✅ All Customers
- ✅ All Customer Groups
- ✅ All Products
- ✅ All Orders (Regular & Quick Delivery)
- ✅ All Event Orders
- ✅ All Archived Event Orders
- ✅ All Invoices
- ✅ All Payments
- ✅ All Expenses
- ✅ All Delivery Boys
- ✅ All Users (except new admin)
- ✅ All Jar Entries
- ✅ All Scheduled Deliveries

## What will remain?

After reset, you will have:
- One Admin User
  - Email: `admin@aquaelite.com`
  - Password: `admin123`
  - Mobile: `+91-9876543210`

## How to Run

### Step 1: Navigate to app directory
```bash
cd /app
```

### Step 2: Run the reset script
```bash
python3 reset_database.py
```

### Step 3: Confirm reset
When prompted, type **YES** (in capital letters) to confirm.

### Step 4: Login with new credentials
After reset completes:
1. Go to your application URL
2. Login with:
   - Email: `admin@aquaelite.com`
   - Password: `admin123`

## After Reset

1. **Update Admin Profile**
   - Change name, email, mobile number
   - Add GST number if needed
   - Change password

2. **Setup Fresh Data**
   - Add your customers
   - Add products
   - Add delivery boys
   - Start using the application fresh!

## Need Help?

If you encounter any issues:
1. Check MongoDB is running
2. Check MONGO_URL environment variable
3. Ensure you have necessary permissions

---

**Created by:** AquaElite Database Management
**Last Updated:** October 2025
