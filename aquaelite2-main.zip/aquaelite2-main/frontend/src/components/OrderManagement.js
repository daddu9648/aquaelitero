import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../App';
import axios from 'axios';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { 
  Plus, 
  Search, 
  Filter, 
  ShoppingCart, 
  Calendar as CalendarIcon,
  Clock,
  CheckCircle,
  IndianRupee,
  User,
  Package,
  Truck,
  Edit3,
  Eye
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

function OrderManagement() {
  const { API, user } = useContext(AuthContext);
  const [orders, setOrders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [deliveryBoys, setDeliveryBoys] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterPayment, setFilterPayment] = useState('all');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [showOrderDetails, setShowOrderDetails] = useState(false);
  
  const [orderForm, setOrderForm] = useState({
    customer_id: '',
    products: [{ product_id: '', product_name: '', quantity: 1, price: 0 }],
    total_amount: 0,
    payment_mode: 'cash',
    delivery_date: new Date(),
    notes: ''
  });

  const [updateForm, setUpdateForm] = useState({
    payment_status: '',
    delivery_status: '',
    delivery_boy_id: '',
    notes: ''
  });

  const paymentModes = ['cash', 'upi', 'online'];
  const deliveryStatuses = ['pending', 'delivered', 'returned'];
  const paymentStatuses = ['pending', 'paid'];

  const fetchData = async () => {
    try {
      setLoading(true);
      const [ordersRes, customersRes, productsRes, deliveryBoysRes] = await Promise.all([
        axios.get(`${API}/orders`),
        axios.get(`${API}/customers`),
        axios.get(`${API}/products`),
        axios.get(`${API}/delivery-boys`)
      ]);
      
      setOrders(ordersRes.data);
      setCustomers(customersRes.data);
      setProducts(productsRes.data);
      setDeliveryBoys(deliveryBoysRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleCreateOrder = async (e) => {
    e.preventDefault();
    try {
      const orderData = {
        ...orderForm,
        delivery_date: orderForm.delivery_date.toISOString()
      };
      
      await axios.post(`${API}/orders`, orderData);
      toast.success('Order created successfully!');
      setShowCreateDialog(false);
      resetOrderForm();
      fetchData();
    } catch (error) {
      console.error('Error creating order:', error);
      toast.error('Failed to create order');
    }
  };

  const handleUpdateOrder = async (e) => {
    e.preventDefault();
    try {
      const updateData = {
        ...updateForm,
        delivery_boy_id: updateForm.delivery_boy_id === 'unassigned' ? null : updateForm.delivery_boy_id
      };
      await axios.put(`${API}/orders/${selectedOrder.id}`, updateData);
      toast.success('Order updated successfully!');
      setShowEditDialog(false);
      setSelectedOrder(null);
      fetchData();
    } catch (error) {
      console.error('Error updating order:', error);
      toast.error('Failed to update order');
    }
  };

  const resetOrderForm = () => {
    setOrderForm({
      customer_id: '',
      products: [{ product_id: '', product_name: '', quantity: 1, price: 0 }],
      total_amount: 0,
      payment_mode: 'cash',
      delivery_date: new Date(),
      notes: ''
    });
  };

  const addProduct = () => {
    setOrderForm({
      ...orderForm,
      products: [...orderForm.products, { product_id: '', product_name: '', quantity: 1, price: 0 }]
    });
  };

  const removeProduct = (index) => {
    const newProducts = orderForm.products.filter((_, i) => i !== index);
    setOrderForm({ ...orderForm, products: newProducts });
    calculateTotal(newProducts);
  };

  const updateProduct = (index, field, value) => {
    const newProducts = [...orderForm.products];
    newProducts[index][field] = value;
    
    if (field === 'product_id') {
      const product = products.find(p => p.id === value);
      if (product) {
        newProducts[index].product_name = product.name;
        newProducts[index].price = product.price;
      }
    }
    
    setOrderForm({ ...orderForm, products: newProducts });
    calculateTotal(newProducts);
  };

  const calculateTotal = (productList) => {
    const total = productList.reduce((sum, product) => {
      return sum + (product.price * product.quantity);
    }, 0);
    setOrderForm(prev => ({ ...prev, total_amount: total }));
  };

  const openEditDialog = (order) => {
    setSelectedOrder(order);
    setUpdateForm({
      payment_status: order.payment_status,
      delivery_status: order.delivery_status,
      delivery_boy_id: order.delivery_boy_id || 'unassigned',
      notes: order.notes || ''
    });
    setShowEditDialog(true);
  };

  const openOrderDetails = (order) => {
    setSelectedOrder(order);
    setShowOrderDetails(true);
  };

  const filteredOrders = orders.filter(order => {
    const matchesSearch = 
      order.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.id.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || order.delivery_status === filterStatus;
    const matchesPayment = filterPayment === 'all' || order.payment_status === filterPayment;
    
    return matchesSearch && matchesStatus && matchesPayment;
  });

  const getStatusBadge = (status, type) => {
    const variants = {
      delivery: {
        pending: 'bg-yellow-100 text-yellow-800',
        delivered: 'bg-green-100 text-green-800',
        returned: 'bg-red-100 text-red-800'
      },
      payment: {
        pending: 'bg-orange-100 text-orange-800',
        paid: 'bg-blue-100 text-blue-800'
      }
    };
    
    return variants[type][status] || 'bg-gray-100 text-gray-800';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const todaysOrders = orders.filter(order => {
    const orderDate = new Date(order.created_at);
    const today = new Date();
    return orderDate.toDateString() === today.toDateString();
  });

  const pendingOrders = orders.filter(order => order.delivery_status === 'pending');
  const deliveredOrders = orders.filter(order => order.delivery_status === 'delivered');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900" data-testid="order-management-title">
            Order Management
          </h1>
          <p className="text-gray-600 mt-1">
            Manage customer orders and track deliveries
          </p>
        </div>
        
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button 
              className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 transition-all duration-200"
              data-testid="create-order-btn"
              onClick={resetOrderForm}
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Order
            </Button>
          </DialogTrigger>
          
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Order</DialogTitle>
              <DialogDescription>
                Fill in the order details below
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleCreateOrder} className="space-y-6">
              {/* Customer Selection */}
              <div className="space-y-2">
                <Label htmlFor="customer">Customer</Label>
                <Select 
                  value={orderForm.customer_id} 
                  onValueChange={(value) => setOrderForm({...orderForm, customer_id: value})}
                >
                  <SelectTrigger data-testid="order-customer-select">
                    <SelectValue placeholder="Select customer" />
                  </SelectTrigger>
                  <SelectContent>
                    {customers.map(customer => (
                      <SelectItem key={customer.id} value={customer.id}>
                        {customer.name} - {customer.mobile}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Products */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Products</Label>
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm" 
                    onClick={addProduct}
                    data-testid="add-product-to-order-btn"
                  >
                    <Plus className="w-4 h-4 mr-1" />
                    Add Product
                  </Button>
                </div>
                
                {orderForm.products.map((product, index) => (
                  <div key={index} className="border rounded-lg p-4 space-y-3">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                      <div className="md:col-span-2">
                        <Label>Product</Label>
                        <Select 
                          value={product.product_id} 
                          onValueChange={(value) => updateProduct(index, 'product_id', value)}
                        >
                          <SelectTrigger data-testid={`product-select-${index}`}>
                            <SelectValue placeholder="Select product" />
                          </SelectTrigger>
                          <SelectContent>
                            {products.map(p => (
                              <SelectItem key={p.id} value={p.id}>
                                {p.name} - ₹{p.price}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label>Quantity</Label>
                        <Input
                          type="number"
                          min="1"
                          value={product.quantity}
                          onChange={(e) => updateProduct(index, 'quantity', parseInt(e.target.value) || 1)}
                          data-testid={`quantity-input-${index}`}
                        />
                      </div>
                      
                      <div className="flex items-end">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removeProduct(index)}
                          disabled={orderForm.products.length === 1}
                          className="w-full"
                          data-testid={`remove-product-${index}`}
                        >
                          Remove
                        </Button>
                      </div>
                    </div>
                    
                    <div className="text-sm text-gray-600">
                      Subtotal: ₹{(product.price * product.quantity).toFixed(2)}
                    </div>
                  </div>
                ))}
              </div>

              {/* Order Details */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="paymentMode">Payment Mode</Label>
                  <Select 
                    value={orderForm.payment_mode} 
                    onValueChange={(value) => setOrderForm({...orderForm, payment_mode: value})}
                  >
                    <SelectTrigger data-testid="payment-mode-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {paymentModes.map(mode => (
                        <SelectItem key={mode} value={mode}>
                          {mode.toUpperCase()}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Delivery Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !orderForm.delivery_date && "text-muted-foreground"
                        )}
                        data-testid="delivery-date-picker"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {orderForm.delivery_date ? format(orderForm.delivery_date, "PPP") : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={orderForm.delivery_date}
                        onSelect={(date) => setOrderForm({...orderForm, delivery_date: date})}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="notes">Notes (Optional)</Label>
                <Textarea
                  id="notes"
                  value={orderForm.notes}
                  onChange={(e) => setOrderForm({...orderForm, notes: e.target.value})}
                  placeholder="Any special instructions..."
                  data-testid="order-notes-input"
                />
              </div>
              
              {/* Total */}
              <div className="border-t pt-4">
                <div className="flex justify-between items-center text-lg font-semibold">
                  <span>Total Amount:</span>
                  <span className="text-green-600" data-testid="order-total-amount">
                    ₹{orderForm.total_amount.toFixed(2)}
                  </span>
                </div>
              </div>
              
              <div className="flex space-x-2 pt-4">
                <Button 
                  type="submit" 
                  className="flex-1 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
                  disabled={!orderForm.customer_id || orderForm.products.some(p => !p.product_id)}
                  data-testid="save-order-btn"
                >
                  Create Order
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowCreateDialog(false)}
                  data-testid="cancel-order-btn"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and Filter */}
      <Card className="shadow-soft">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input 
                placeholder="Search by customer name or order ID..." 
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                data-testid="order-search-input"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-40" data-testid="delivery-status-filter">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  {deliveryStatuses.map(status => (
                    <SelectItem key={status} value={status}>
                      {status.charAt(0).toUpperCase() + status.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={filterPayment} onValueChange={setFilterPayment}>
                <SelectTrigger className="w-40" data-testid="payment-status-filter">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Payments</SelectItem>
                  {paymentStatuses.map(status => (
                    <SelectItem key={status} value={status}>
                      {status.charAt(0).toUpperCase() + status.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Order Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Today's Orders</p>
                <p className="text-2xl font-bold text-blue-600" data-testid="todays-orders-stat">
                  {todaysOrders.length}
                </p>
              </div>
              <ShoppingCart className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending Orders</p>
                <p className="text-2xl font-bold text-yellow-600" data-testid="pending-orders-stat">
                  {pendingOrders.length}
                </p>
              </div>
              <Clock className="w-8 h-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Delivered Orders</p>
                <p className="text-2xl font-bold text-green-600" data-testid="delivered-orders-stat">
                  {deliveredOrders.length}
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Revenue</p>
                <p className="text-2xl font-bold text-purple-600" data-testid="total-revenue-stat">
                  ₹{orders.filter(o => o.payment_status === 'paid').reduce((sum, o) => sum + o.total_amount, 0).toFixed(2)}
                </p>
              </div>
              <IndianRupee className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Order List */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle>Order List</CardTitle>
          <CardDescription>
            {filteredOrders.length} order(s) found
          </CardDescription>
        </CardHeader>
        
        <CardContent className="p-0">
          {filteredOrders.length === 0 ? (
            <div className="text-center py-12" data-testid="no-orders-message">
              <ShoppingCart className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No orders found</h3>
              <p className="text-gray-600 mb-4">Get started by creating your first order.</p>
              <Button 
                onClick={() => setShowCreateDialog(true)}
                className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
                data-testid="create-first-order-btn"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Order
              </Button>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {filteredOrders.map((order) => (
                <div key={order.id} className="p-6 hover:bg-gray-50 transition-colors" data-testid={`order-item-${order.id}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-3">
                        <h3 className="text-lg font-semibold text-gray-900" data-testid={`order-id-${order.id}`}>
                          #{order.id.slice(-8)}
                        </h3>
                        
                        <Badge className={getStatusBadge(order.delivery_status, 'delivery')}>
                          {order.delivery_status.charAt(0).toUpperCase() + order.delivery_status.slice(1)}
                        </Badge>
                        
                        <Badge className={getStatusBadge(order.payment_status, 'payment')}>
                          {order.payment_status.charAt(0).toUpperCase() + order.payment_status.slice(1)}
                        </Badge>
                        
                        <Badge variant="outline" className="bg-gray-50">
                          {order.payment_mode.toUpperCase()}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm text-gray-600">
                        <div className="flex items-center space-x-2">
                          <User className="w-4 h-4" />
                          <span data-testid={`order-customer-${order.id}`}>{order.customer_name}</span>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <Package className="w-4 h-4" />
                          <span data-testid={`order-products-${order.id}`}>
                            {order.products.length} item(s)
                          </span>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <IndianRupee className="w-4 h-4" />
                          <span className="font-medium text-green-600" data-testid={`order-amount-${order.id}`}>
                            ₹{order.total_amount}
                          </span>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <CalendarIcon className="w-4 h-4" />
                          <span data-testid={`order-delivery-date-${order.id}`}>
                            {format(new Date(order.delivery_date), "MMM dd, yyyy")}
                          </span>
                        </div>
                      </div>
                      
                      {order.delivery_boy_name && (
                        <div className="mt-2">
                          <div className="flex items-center space-x-2 text-sm text-blue-600">
                            <Truck className="w-4 h-4" />
                            <span>Assigned to: {order.delivery_boy_name}</span>
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openOrderDetails(order)}
                        className="hover:bg-blue-50 hover:text-blue-600"
                        data-testid={`view-order-${order.id}`}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openEditDialog(order)}
                        className="hover:bg-green-50 hover:text-green-600"
                        data-testid={`edit-order-${order.id}`}
                      >
                        <Edit3 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Order Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Update Order</DialogTitle>
            <DialogDescription>
              Update order status and assignment
            </DialogDescription>
          </DialogHeader>
          
          {selectedOrder && (
            <form onSubmit={handleUpdateOrder} className="space-y-4">
              <div className="space-y-2">
                <Label>Order ID: #{selectedOrder.id.slice(-8)}</Label>
                <p className="text-sm text-gray-600">Customer: {selectedOrder.customer_name}</p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="deliveryStatus">Delivery Status</Label>
                <Select 
                  value={updateForm.delivery_status} 
                  onValueChange={(value) => setUpdateForm({...updateForm, delivery_status: value})}
                >
                  <SelectTrigger data-testid="edit-delivery-status-select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {deliveryStatuses.map(status => (
                      <SelectItem key={status} value={status}>
                        {status.charAt(0).toUpperCase() + status.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="paymentStatus">Payment Status</Label>
                <Select 
                  value={updateForm.payment_status} 
                  onValueChange={(value) => setUpdateForm({...updateForm, payment_status: value})}
                >
                  <SelectTrigger data-testid="edit-payment-status-select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentStatuses.map(status => (
                      <SelectItem key={status} value={status}>
                        {status.charAt(0).toUpperCase() + status.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              {/* Delivery Boy Assignment - Only for Admin/Manager */}
              {(user?.role === 'admin' || user?.role === 'manager') && (
                <div className="space-y-2">
                  <Label htmlFor="deliveryBoy">Assign Delivery Boy</Label>
                  <Select 
                    value={updateForm.delivery_boy_id} 
                    onValueChange={(value) => setUpdateForm({...updateForm, delivery_boy_id: value})}
                  >
                    <SelectTrigger data-testid="edit-delivery-boy-select">
                      <SelectValue placeholder="Select delivery boy" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="unassigned">Unassigned</SelectItem>
                      {deliveryBoys.map(boy => (
                        <SelectItem key={boy.id} value={boy.id}>
                          {boy.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="updateNotes">Notes</Label>
                <Textarea
                  id="updateNotes"
                  value={updateForm.notes}
                  onChange={(e) => setUpdateForm({...updateForm, notes: e.target.value})}
                  placeholder="Update notes..."
                  data-testid="edit-order-notes-input"
                />
              </div>
              
              <div className="flex space-x-2 pt-4">
                <Button 
                  type="submit" 
                  className="flex-1 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
                  data-testid="update-order-btn"
                >
                  Update Order
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowEditDialog(false)}
                  data-testid="cancel-update-order-btn"
                >
                  Cancel
                </Button>
              </div>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* Order Details Dialog */}
      <Dialog open={showOrderDetails} onOpenChange={setShowOrderDetails}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Order Details</DialogTitle>
            <DialogDescription>
              Complete order information
            </DialogDescription>
          </DialogHeader>
          
          {selectedOrder && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">Order ID:</span>
                  <p>#{selectedOrder.id.slice(-8)}</p>
                </div>
                <div>
                  <span className="font-medium">Customer:</span>
                  <p>{selectedOrder.customer_name}</p>
                </div>
                <div>
                  <span className="font-medium">Delivery Date:</span>
                  <p>{format(new Date(selectedOrder.delivery_date), "PPP")}</p>
                </div>
                <div>
                  <span className="font-medium">Payment Mode:</span>
                  <p>{selectedOrder.payment_mode.toUpperCase()}</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-3">Products:</h4>
                <div className="space-y-2">
                  {selectedOrder.products.map((product, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium">{product.product_name}</p>
                        <p className="text-sm text-gray-600">Quantity: {product.quantity}</p>
                      </div>
                      <p className="font-medium">₹{(product.price * product.quantity).toFixed(2)}</p>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="border-t pt-4">
                <div className="flex justify-between items-center text-lg font-semibold">
                  <span>Total Amount:</span>
                  <span className="text-green-600">₹{selectedOrder.total_amount}</span>
                </div>
              </div>
              
              {selectedOrder.notes && (
                <div>
                  <span className="font-medium">Notes:</span>
                  <p className="text-gray-600 mt-1">{selectedOrder.notes}</p>
                </div>
              )}
              
              <Button 
                onClick={() => setShowOrderDetails(false)}
                className="w-full"
                data-testid="close-order-details-btn"
              >
                Close
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default OrderManagement;