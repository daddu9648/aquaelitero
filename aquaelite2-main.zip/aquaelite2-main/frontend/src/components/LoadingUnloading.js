import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../App';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { 
  PackageOpen, 
  ArrowUpCircle,
  Truck,
  Users,
  Plus,
  Calendar,
  UserCheck
} from 'lucide-react';
import { toast } from 'sonner';
import axios from 'axios';

function LoadingUnloading() {
  const { user, API } = useContext(AuthContext);
  const [loading, setLoading] = useState(true);
  const [deliveryBoys, setDeliveryBoys] = useState([]);
  const [customerGroups, setCustomerGroups] = useState([]);
  const [eventOrders, setEventOrders] = useState([]);
  const [jarEntries, setJarEntries] = useState([]);
  const [showEntryDialog, setShowEntryDialog] = useState(false);
  
  const [entryData, setEntryData] = useState({
    operation_type: 'loading', // loading or unloading
    delivery_boy_id: '',
    delivery_boy_name: '',
    vehicle_number: '',
    jar_count: '',
    assignment_type: 'none', // customer_group, event_order, or none
    assignment_id: '',
    assignment_name: '',
    notes: ''
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Fetch delivery boys - handle permission errors gracefully
      try {
        const deliveryBoysRes = await axios.get(`${API}/users?role=delivery_boy`);
        setDeliveryBoys(deliveryBoysRes.data || []);
      } catch (error) {
        console.warn('Could not fetch delivery boys:', error.response?.status);
        setDeliveryBoys([]);
      }
      
      // Fetch customer groups
      try {
        const groupsRes = await axios.get(`${API}/customer-groups`);
        setCustomerGroups(groupsRes.data || []);
      } catch (error) {
        console.warn('Could not fetch customer groups:', error.response?.status);
        setCustomerGroups([]);
      }
      
      // Fetch event orders
      try {
        const eventsRes = await axios.get(`${API}/event-orders`);
        setEventOrders(eventsRes.data || []);
      } catch (error) {
        console.warn('Could not fetch event orders:', error.response?.status);
        setEventOrders([]);
      }
      
      // Fetch existing jar entries (we can store these in a new collection)
      fetchJarEntries();
      
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Error loading data');
    } finally {
      setLoading(false);
    }
  };

  const fetchJarEntries = async () => {
    try {
      // This would be a new API endpoint to store jar loading/unloading entries
      const response = await axios.get(`${API}/jar-entries`);
      setJarEntries(response.data || []);
    } catch (error) {
      console.warn('Jar entries endpoint not available:', error.response?.status);
      // If endpoint doesn't exist, use empty array
      setJarEntries([]);
    }
  };

  const openLoadingDialog = () => {
    setEntryData({
      operation_type: 'loading',
      delivery_boy_id: '',
      delivery_boy_name: '',
      vehicle_number: '',
      jar_count: '',
      assignment_type: 'none',
      assignment_id: '',
      assignment_name: '',
      notes: ''
    });
    setShowEntryDialog(true);
  };

  const openUnloadingDialog = () => {
    setEntryData({
      operation_type: 'unloading',
      delivery_boy_id: '',
      delivery_boy_name: '',
      vehicle_number: '',
      jar_count: '',
      assignment_type: 'none',
      assignment_id: '',
      assignment_name: '',
      notes: ''
    });
    setShowEntryDialog(true);
  };

  const handleSaveEntry = async () => {
    try {
      // Validation
      if (!entryData.delivery_boy_id) {
        toast.error('Please select delivery boy');
        return;
      }
      if (!entryData.vehicle_number.trim()) {
        toast.error('Please enter vehicle number');
        return;
      }
      if (!entryData.jar_count || parseInt(entryData.jar_count) <= 0) {
        toast.error('Please enter valid jar count');
        return;
      }

      // Prepare entry data
      const entryRequest = {
        operation_type: entryData.operation_type,
        delivery_boy_id: entryData.delivery_boy_id,
        delivery_boy_name: entryData.delivery_boy_name,
        vehicle_number: entryData.vehicle_number,
        jar_count: parseInt(entryData.jar_count),
        assignment_type: entryData.assignment_type === 'none' ? '' : entryData.assignment_type,
        assignment_id: entryData.assignment_id,
        assignment_name: entryData.assignment_name,
        notes: entryData.notes
      };

      // Save to backend
      const response = await axios.post(`${API}/jar-entries`, entryRequest);
      
      if (response.data) {
        // Add to local state for immediate UI update
        const newEntry = { 
          ...entryRequest, 
          id: response.data.id, 
          created_at: new Date().toISOString(),
          created_by: user?.id
        };
        setJarEntries(prev => [newEntry, ...prev]);
        
        toast.success(`${entryData.operation_type === 'loading' ? 'Loading' : 'Unloading'} entry saved successfully!`);
        setShowEntryDialog(false);
        
        // Refresh data
        fetchData();
      }
      
    } catch (error) {
      console.error('Error saving entry:', error);
      toast.error(error.response?.data?.detail || 'Failed to save entry');
    }
  };

  const handleDeliveryBoyChange = (boyId) => {
    const selectedBoy = deliveryBoys.find(boy => boy.id === boyId);
    if (selectedBoy) {
      setEntryData({
        ...entryData,
        delivery_boy_id: boyId,
        delivery_boy_name: selectedBoy.name
      });
    }
  };

  const handleAssignmentChange = (assignmentId) => {
    if (entryData.assignment_type === 'customer_group') {
      const group = customerGroups.find(g => g.id === assignmentId);
      setEntryData({
        ...entryData,
        assignment_id: assignmentId,
        assignment_name: group ? group.name : ''
      });
    } else if (entryData.assignment_type === 'event_order') {
      const event = eventOrders.find(e => e.id === assignmentId);
      setEntryData({
        ...entryData,
        assignment_id: assignmentId,
        assignment_name: event ? event.event_name : ''
      });
    }
  };

  const getTodayEntries = () => {
    const today = new Date().toDateString();
    return jarEntries.filter(entry => 
      new Date(entry.created_at).toDateString() === today
    );
  };

  const getLoadingEntries = () => {
    return jarEntries.filter(entry => entry.operation_type === 'loading');
  };

  const getUnloadingEntries = () => {
    return jarEntries.filter(entry => entry.operation_type === 'unloading');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900" data-testid="loading-unloading-title">
            Loading & Unloading Management
          </h1>
          <p className="text-gray-600 mt-1">
            Manage jar loading, unloading entries and delivery boy assignments
          </p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <PackageOpen className="w-5 h-5 text-blue-500" />
              <span>Loading Entry</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <PackageOpen className="w-12 h-12 text-blue-500 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">
                Record jar loading on vehicles and assign to delivery boys
              </p>
              <Button 
                onClick={openLoadingDialog}
                className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
                data-testid="open-loading-entry"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Loading Entry
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <ArrowUpCircle className="w-5 h-5 text-orange-500" />
              <span>Unloading Entry</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <ArrowUpCircle className="w-12 h-12 text-orange-500 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">
                Record jar unloading and empty jar collection
              </p>
              <Button 
                onClick={openUnloadingDialog}
                className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700"
                data-testid="open-unloading-entry"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Unloading Entry
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-green-500" />
              <span>Today's Entries</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {getTodayEntries().length}
            </div>
            <p className="text-sm text-gray-600">Total entries today</p>
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <PackageOpen className="w-5 h-5 text-blue-500" />
              <span>Loading Entries</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {getLoadingEntries().length}
            </div>
            <p className="text-sm text-gray-600">Total loading entries</p>
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <ArrowUpCircle className="w-5 h-5 text-orange-500" />
              <span>Unloading Entries</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {getUnloadingEntries().length}
            </div>
            <p className="text-sm text-gray-600">Total unloading entries</p>
          </CardContent>
        </Card>

        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Users className="w-5 h-5 text-purple-500" />
              <span>Delivery Boys</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
              {deliveryBoys.length}
            </div>
            <p className="text-sm text-gray-600">Active delivery boys</p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Entries */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <UserCheck className="w-5 h-5" />
            <span>Recent Loading/Unloading Entries</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {jarEntries.length === 0 ? (
            <div className="text-center py-8">
              <Truck className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No entries found. Add your first loading or unloading entry.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {jarEntries.slice(0, 10).map((entry) => (
                <div 
                  key={entry.id} 
                  className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50"
                >
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      {entry.operation_type === 'loading' ? (
                        <PackageOpen className="w-5 h-5 text-blue-500" />
                      ) : (
                        <ArrowUpCircle className="w-5 h-5 text-orange-500" />
                      )}
                      <span className="font-medium">
                        {entry.operation_type === 'loading' ? 'Loading' : 'Unloading'} Entry
                      </span>
                      <Badge className={entry.operation_type === 'loading' ? 'bg-blue-100 text-blue-800' : 'bg-orange-100 text-orange-800'}>
                        {entry.jar_count} Jars
                      </Badge>
                    </div>
                    
                    <div className="text-sm text-gray-600 space-y-1">
                      <p><strong>Delivery Boy:</strong> {entry.delivery_boy_name}</p>
                      <p><strong>Vehicle:</strong> {entry.vehicle_number}</p>
                      <p><strong>Jar Count:</strong> {entry.jar_count}</p>
                      {entry.assignment_name && (
                        <p><strong>Assignment:</strong> {entry.assignment_name} ({entry.assignment_type?.replace('_', ' ')})</p>
                      )}
                      {entry.notes && <p><strong>Notes:</strong> {entry.notes}</p>}
                      <p><strong>Date:</strong> {new Date(entry.created_at).toLocaleString()}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Entry Dialog */}
      <Dialog open={showEntryDialog} onOpenChange={setShowEntryDialog} modal={true}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto z-50">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              {entryData.operation_type === 'loading' ? (
                <PackageOpen className="w-5 h-5 text-blue-500" />
              ) : (
                <ArrowUpCircle className="w-5 h-5 text-orange-500" />
              )}
              <span>
                {entryData.operation_type === 'loading' ? 'Loading Entry' : 'Unloading Entry'}
              </span>
            </DialogTitle>
            <DialogDescription>
              {entryData.operation_type === 'loading' 
                ? 'Record jar loading on vehicle and assign to delivery boy'
                : 'Record jar unloading and empty jar collection'
              }
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Delivery Boy Selection */}
            <div className="space-y-2">
              <Label>Select Delivery Boy</Label>
              <Select value={entryData.delivery_boy_id} onValueChange={handleDeliveryBoyChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose delivery boy" />
                </SelectTrigger>
                <SelectContent>
                  {deliveryBoys.map(boy => (
                    <SelectItem key={boy.id} value={boy.id}>
                      {boy.name} - {boy.assigned_area || 'No area assigned'}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Vehicle Number & Jar Count */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="vehicle-number">Vehicle Number</Label>
                <Input
                  id="vehicle-number"
                  value={entryData.vehicle_number}
                  onChange={(e) => setEntryData({...entryData, vehicle_number: e.target.value})}
                  placeholder="e.g., MH12AB1234"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="jar-count">
                  {entryData.operation_type === 'loading' ? 'Jars to Load' : 'Jars to Unload'}
                </Label>
                <Input
                  id="jar-count"
                  type="number"
                  min="1"
                  value={entryData.jar_count}
                  onChange={(e) => setEntryData({...entryData, jar_count: e.target.value})}
                  placeholder="Number of jars"
                />
              </div>
            </div>

            {/* Assignment Type */}
            <div className="space-y-2">
              <Label>Assignment Type (Optional)</Label>
              <Select 
                value={entryData.assignment_type} 
                onValueChange={(value) => setEntryData({...entryData, assignment_type: value === 'none' ? '' : value, assignment_id: '', assignment_name: ''})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select assignment type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No Assignment</SelectItem>
                  <SelectItem value="customer_group">Customer Group</SelectItem>
                  <SelectItem value="event_order">Event Order</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Customer Group Assignment */}
            {entryData.assignment_type === 'customer_group' && (
              <div className="space-y-2">
                <Label>Select Customer Group</Label>
                <Select value={entryData.assignment_id} onValueChange={handleAssignmentChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose customer group" />
                  </SelectTrigger>
                  <SelectContent>
                    {customerGroups.map(group => (
                      <SelectItem key={group.id} value={group.id}>
                        {group.name} - {group.discount_percentage}% discount
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Event Order Assignment */}
            {entryData.assignment_type === 'event_order' && (
              <div className="space-y-2">
                <Label>Select Event Order</Label>
                <Select value={entryData.assignment_id} onValueChange={handleAssignmentChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose event order" />
                  </SelectTrigger>
                  <SelectContent>
                    {eventOrders.map(event => (
                      <SelectItem key={event.id} value={event.id}>
                        {event.event_name} - {event.event_date}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Notes */}
            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea
                id="notes"
                value={entryData.notes}
                onChange={(e) => setEntryData({...entryData, notes: e.target.value})}
                placeholder="Any additional notes or observations..."
                rows={3}
              />
            </div>

            {/* Summary */}
            <div className={`p-4 rounded-lg ${entryData.operation_type === 'loading' ? 'bg-blue-50' : 'bg-orange-50'}`}>
              <h4 className={`font-medium mb-2 ${entryData.operation_type === 'loading' ? 'text-blue-900' : 'text-orange-900'}`}>
                Entry Summary
              </h4>
              <div className={`space-y-1 text-sm ${entryData.operation_type === 'loading' ? 'text-blue-700' : 'text-orange-700'}`}>
                <p><strong>Operation:</strong> {entryData.operation_type === 'loading' ? 'Loading' : 'Unloading'}</p>
                <p><strong>Delivery Boy:</strong> {entryData.delivery_boy_name || 'Not selected'}</p>
                <p><strong>Vehicle:</strong> {entryData.vehicle_number || 'Not entered'}</p>
                <p><strong>Jar Count:</strong> {entryData.jar_count || '0'}</p>
                {entryData.assignment_name && (
                  <p><strong>Assignment:</strong> {entryData.assignment_name} ({entryData.assignment_type?.replace('_', ' ')})</p>
                )}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEntryDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleSaveEntry}
              className={entryData.operation_type === 'loading' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-orange-600 hover:bg-orange-700'}
            >
              Save {entryData.operation_type === 'loading' ? 'Loading' : 'Unloading'} Entry
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default LoadingUnloading;