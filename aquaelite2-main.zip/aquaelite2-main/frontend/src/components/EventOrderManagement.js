import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../App';
import axios from 'axios';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  Plus, 
  Search, 
  Calendar as CalendarIcon, 
  MapPin, 
  Users,
  IndianRupee,
  Clock,
  CheckCircle,
  Edit3,
  Trash2,
  Eye,
  Filter,
  PartyPopper,
  Building,
  Heart,
  Briefcase,
  Star,
  MoreHorizontal,
  Truck,
  UserCheck,
  Package,
  ArrowUpCircle,
  X,
  XCircle
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

function EventOrderManagement() {
  const { API, user } = useContext(AuthContext);
  const [eventOrders, setEventOrders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [deliveryBoys, setDeliveryBoys] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [showAssignDeliveryDialog, setShowAssignDeliveryDialog] = useState(false);
  const [showDeliveryExecutionDialog, setShowDeliveryExecutionDialog] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  
  const [eventForm, setEventForm] = useState({
    event_name: '',
    event_type: 'wedding',
    customer_id: '',
    create_new_customer: false,
    new_customer_name: '',
    new_customer_mobile: '',
    new_customer_address: '',
    event_date: new Date(),
    event_time: '10:00',
    venue_address: '',
    products: [{ product_id: '', product_name: '', quantity: '', price: 0, total: 0 }],
    total_amount: 0,
    advance_amount: 0,
    special_requirements: '',
    setup_required: false,
    delivery_instructions: ''
  });

  const [deliveryAssignmentForm, setDeliveryAssignmentForm] = useState({
    event_id: '',
    delivery_boy_id: '',
    delivery_boy_name: '',
    delivery_date: new Date(),
    delivery_time: '10:00',
    vehicle_number: '',
    special_instructions: ''
  });

  const [deliveryExecutionForm, setDeliveryExecutionForm] = useState({
    event_id: '',
    customer_balance: 0,
    jars_delivered: '',
    empty_jars_collected: '',
    setup_completed: false,
    payment_received: '',
    payment_mode: 'cash',
    payment_status: 'no_payment', // no_payment, partial_payment, full_payment
    delivery_notes: '',
    customer_signature: false,
    delivery_status: 'completed'
  });

  const eventTypes = [
    { value: 'wedding', label: 'Wedding', icon: Heart, color: 'bg-pink-500' },
    { value: 'corporate', label: 'Corporate Event', icon: Briefcase, color: 'bg-blue-500' },
    { value: 'party', label: 'Party', icon: PartyPopper, color: 'bg-purple-500' },
    { value: 'conference', label: 'Conference', icon: Building, color: 'bg-green-500' },
    { value: 'festival', label: 'Festival', icon: Star, color: 'bg-orange-500' },
    { value: 'other', label: 'Other', icon: MoreHorizontal, color: 'bg-gray-500' }
  ];

  const eventStatuses = ['confirmed', 'in_progress', 'completed', 'cancelled'];
  const paymentStatuses = ['pending', 'advance_paid', 'fully_paid'];

  const fetchData = async () => {
    try {
      setLoading(true);
      const [eventsRes, customersRes, productsRes, deliveryBoysRes] = await Promise.all([
        axios.get(`${API}/event-orders`, {
          headers: {
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
          }
        }),
        axios.get(`${API}/customers`, {
          headers: {
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
          }
        }),
        axios.get(`${API}/products`, {
          headers: {
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
          }
        }),
        axios.get(`${API}/delivery-boys`, {
          headers: {
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
          }
        }).catch(() => ({ data: [] }))
      ]);
      
      // Force state update with new reference
      setEventOrders([...eventsRes.data]);
      setCustomers([...customersRes.data]);
      setProducts([...productsRes.data]);
      setDeliveryBoys([...deliveryBoysRes.data]);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load event orders');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleCreateEvent = async (e) => {
    e.preventDefault();
    try {
      let finalCustomerId = eventForm.customer_id;
      let customerName = 'Customer';
      
      // If creating new customer, create customer first
      if (eventForm.create_new_customer) {
        const newCustomerData = {
          name: eventForm.new_customer_name,
          mobile: eventForm.new_customer_mobile,
          address: eventForm.new_customer_address,
          water_type: "20L", // Default water type
          bottle_deposit: 0.0
        };
        
        const customerResponse = await axios.post(`${API}/customers`, newCustomerData);
        finalCustomerId = customerResponse.data.id;
        customerName = eventForm.new_customer_name;
        
        // Refresh customers list to include the new customer
        fetchData();
      } else {
        // Find customer name for automatic event name generation
        const selectedCustomer = customers.find(c => c.id === eventForm.customer_id);
        customerName = selectedCustomer ? selectedCustomer.name : 'Customer';
      }
      
      // Auto-generate event name based on event type and customer
      const eventTypeLabel = eventTypes.find(t => t.value === eventForm.event_type)?.label || 'Event';
      const autoEventName = `${customerName}'s ${eventTypeLabel}`;
      
      const eventData = {
        ...eventForm,
        customer_id: finalCustomerId,
        event_name: autoEventName,
        special_requirements: eventForm.special_requirements || '', // Keep empty if not provided
        event_date: eventForm.event_date.toISOString()
      };
      
      // Remove new customer fields from event data
      delete eventData.create_new_customer;
      delete eventData.new_customer_name;
      delete eventData.new_customer_mobile;
      delete eventData.new_customer_address;
      
      await axios.post(`${API}/event-orders`, eventData);
      toast.success(`Event order created successfully for ${customerName}!`);
      setShowCreateDialog(false);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Error creating event order:', error);
      if (error.response?.data?.detail) {
        toast.error(`Failed to create event order: ${error.response.data.detail}`);
      } else {
        toast.error('Failed to create event order');
      }
    }
  };

  const handleUpdateEvent = async (e) => {
    e.preventDefault();
    try {
      const updateData = {
        ...eventForm,
        event_date: eventForm.event_date.toISOString()
      };
      
      await axios.put(`${API}/event-orders/${selectedEvent.id}`, updateData);
      toast.success('Event order updated successfully!');
      setShowEditDialog(false);
      setSelectedEvent(null);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Error updating event order:', error);
      toast.error('Failed to update event order');
    }
  };

  const handleCancelEvent = async (event) => {
    try {
      console.log('Cancel event clicked for:', event.event_name, 'Current status:', event.event_status);
      
      // Show confirmation dialog
      const confirmed = window.confirm(
        `Are you sure you want to cancel "${event.event_name}"?\n\n` +
        `⚠️ IMPORTANT: Advance payment of ₹${event.advance_amount} will be NON-REFUNDABLE and will be retained by the company.\n\n` +
        `This action cannot be undone.`
      );
      
      if (!confirmed) return;

      const cancelData = {
        event_status: 'cancelled', // This should be event_status not just status
        cancellation_reason: 'Customer requested cancellation',
        cancelled_at: new Date().toISOString(),
        cancelled_by: user?.id,
        cancelled_by_name: user?.name,
        advance_forfeited: true, // Mark advance as forfeited
        refund_amount: 0 // No refund given
      };
      
      console.log('Sending cancel data:', cancelData);
      
      const response = await axios.put(`${API}/event-orders/${event.id}`, cancelData);
      console.log('Cancel response:', response.data);
      
      // Note: Advance forfeiture is recorded in the event order itself
      
      toast.success(
        `Event cancelled successfully!\nAdvance payment ₹${event.advance_amount} has been forfeited (non-refundable).`
      );
      
      console.log('Fetching updated data...');
      await fetchData();
      console.log('Data refresh completed');
    } catch (error) {
      console.error('Error cancelling event:', error);
      toast.error('Failed to cancel event order');
    }
  };

  const handleDeleteEvent = async (eventId, eventName) => {
    if (window.confirm(`Are you sure you want to delete event: ${eventName}?`)) {
      try {
        await axios.delete(`${API}/event-orders/${eventId}`);
        toast.success('Event order deleted successfully!');
        fetchData();
      } catch (error) {
        console.error('Error deleting event:', error);
        toast.error('Failed to delete event order');
      }
    }
  };

  const handleCompleteEvent = async (eventId) => {
    try {
      await axios.post(`${API}/event-orders/${eventId}/complete`);
      toast.success('Event marked as completed!');
      fetchData();
    } catch (error) {
      console.error('Error completing event:', error);
      toast.error('Failed to complete event');
    }
  };

  const resetForm = () => {
    setEventForm({
      event_name: '',
      event_type: 'wedding',
      customer_id: '',
      create_new_customer: false,
      new_customer_name: '',
      new_customer_mobile: '',
      new_customer_address: '',
      event_date: new Date(),
      event_time: '10:00',
      venue_address: '',
      products: [{ product_id: '', product_name: '', quantity: '', price: 0, total: 0 }],
      total_amount: 0,
      advance_amount: 0,
      special_requirements: '',
      setup_required: false,
      delivery_instructions: ''
    });
  };

  const addProduct = () => {
    setEventForm({
      ...eventForm,
      products: [...eventForm.products, { product_id: '', product_name: '', quantity: '', price: 0, total: 0 }]
    });
  };

  const removeProduct = (index) => {
    const newProducts = eventForm.products.filter((_, i) => i !== index);
    setEventForm({ ...eventForm, products: newProducts });
    calculateTotal(newProducts);
  };

  const updateProduct = (index, field, value) => {
    const newProducts = [...eventForm.products];
    newProducts[index][field] = value;
    
    if (field === 'product_id') {
      const product = products.find(p => p.id === value);
      if (product) {
        newProducts[index].product_name = product.name;
        newProducts[index].price = product.price;
      }
    }
    
    if (field === 'quantity' || field === 'price') {
      newProducts[index].total = newProducts[index].quantity * newProducts[index].price;
    }
    
    setEventForm({ ...eventForm, products: newProducts });
    calculateTotal(newProducts);
  };

  const calculateTotal = (productList) => {
    const total = productList.reduce((sum, product) => {
      return sum + (product.total || 0);
    }, 0);
    setEventForm(prev => ({ ...prev, total_amount: total }));
  };

  const handleProductSelection = (productId, checked) => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    let newProducts = [...eventForm.products];
    
    if (checked) {
      // Add product if not already selected
      if (!newProducts.some(p => p.product_id === productId)) {
        newProducts.push({
          product_id: productId,
          name: product.name,
          price: product.price,
          quantity: '',
          total: 0
        });
      }
    } else {
      // Remove product
      newProducts = newProducts.filter(p => p.product_id !== productId);
    }
    
    setEventForm({ ...eventForm, products: newProducts });
    calculateTotal(newProducts);
  };

  const handleQuantityChange = (productId, newQuantity) => {
    // Allow empty string or numbers >= 1
    if (newQuantity !== '' && newQuantity < 1) return;
    
    const newProducts = eventForm.products.map(product => {
      if (product.product_id === productId) {
        return {
          ...product,
          quantity: newQuantity,
          total: newQuantity * product.price
        };
      }
      return product;
    });
    
    setEventForm({ ...eventForm, products: newProducts });
    calculateTotal(newProducts);
  };

  const openEditDialog = (event) => {
    setSelectedEvent(event);
    setEventForm({
      event_name: event.event_name,
      event_type: event.event_type,
      customer_id: event.customer_id,
      event_date: new Date(event.event_date),
      event_time: event.event_time,
      venue: event.venue || event.venue_address,
      products: event.products,
      total_amount: event.total_amount,
      advance_amount: event.advance_amount,
      special_requirements: event.special_requirements || '',
      setup_required: event.setup_required,
      delivery_instructions: event.delivery_instructions || ''
    });
    setShowEditDialog(true);
  };

  const viewEventDetails = (event) => {
    setSelectedEvent(event);
    setShowDetailsDialog(true);
  };

  // Delivery Assignment Functions
  const openAssignDeliveryDialog = (event) => {
    setSelectedEvent(event);
    setDeliveryAssignmentForm({
      event_id: event.id,
      delivery_boy_id: '',
      delivery_boy_name: '',
      delivery_date: new Date(event.event_date),
      delivery_time: event.event_time,
      vehicle_number: '',
      special_instructions: event.delivery_instructions || ''
    });
    setShowAssignDeliveryDialog(true);
  };

  const handleAssignDeliveryBoy = async (e) => {
    e.preventDefault();
    try {
      if (!deliveryAssignmentForm.delivery_boy_id) {
        toast.error('Please select a delivery boy');
        return;
      }

      const assignmentData = {
        ...deliveryAssignmentForm,
        assigned_by: user?.id,
        assigned_by_name: user?.name,
        assignment_date: new Date().toISOString()
      };

      // Update event with delivery boy assignment
      await axios.put(`${API}/event-orders/${selectedEvent.id}`, {
        delivery_boy_id: assignmentData.delivery_boy_id,
        delivery_boy_name: assignmentData.delivery_boy_name,
        delivery_date: assignmentData.delivery_date.toISOString(),
        delivery_time: assignmentData.delivery_time,
        vehicle_number: assignmentData.vehicle_number,
        delivery_instructions: assignmentData.special_instructions,
        event_status: 'in_progress'
      });

      toast.success(`Delivery boy ${assignmentData.delivery_boy_name} assigned successfully!`);
      setShowAssignDeliveryDialog(false);
      fetchData(); // Refresh data
    } catch (error) {
      console.error('Error assigning delivery boy:', error);
      toast.error('Failed to assign delivery boy');
    }
  };

  const handleDeliveryBoySelection = (deliveryBoyId) => {
    const deliveryBoy = deliveryBoys.find(db => db.id === deliveryBoyId);
    if (deliveryBoy) {
      setDeliveryAssignmentForm({
        ...deliveryAssignmentForm,
        delivery_boy_id: deliveryBoyId,
        delivery_boy_name: deliveryBoy.name
      });
    }
  };

  // Delivery Execution Functions
  const openDeliveryExecutionDialog = async (event) => {
    setSelectedEvent(event);
    
    // Fetch customer balance information
    let customerBalance = 0;
    try {
      const customerRes = await axios.get(`${API}/customers`);
      const customer = customerRes.data.find(c => c.id === event.customer_id);
      customerBalance = customer?.balance_due || 0;
    } catch (error) {
      console.warn('Could not fetch customer balance:', error);
    }
    
    const jarsDeliveredCount = event.products?.reduce((sum, p) => sum + (p.quantity || 0), 0) || '';
    
    setDeliveryExecutionForm({
      event_id: event.id,
      customer_balance: customerBalance,
      jars_delivered: jarsDeliveredCount,
      empty_jars_collected: jarsDeliveredCount, // Auto-fill with same number as delivered jars
      setup_completed: false,
      payment_received: '',
      payment_mode: 'cash',
      delivery_notes: '',
      customer_signature: false,
      delivery_status: 'completed'
    });
    setShowDeliveryExecutionDialog(true);
  };

  const handleExecuteDelivery = async (e) => {
    e.preventDefault();
    try {
      if (!deliveryExecutionForm.jars_delivered || deliveryExecutionForm.jars_delivered <= 0) {
        toast.error('Please enter valid number of jars delivered');
        return;
      }

      const paymentAmount = parseFloat(deliveryExecutionForm.payment_received) || 0;
      const customerBalance = deliveryExecutionForm.customer_balance || 0;
      
      // Determine payment status
      let paymentStatus = 'no_payment';
      if (paymentAmount > 0) {
        if (paymentAmount >= customerBalance) {
          paymentStatus = 'full_payment';
        } else {
          paymentStatus = 'partial_payment';
        }
      }

      const executionData = {
        ...deliveryExecutionForm,
        delivered_by: user?.id,
        delivered_by_name: user?.name,
        delivery_completed_at: new Date().toISOString(),
        payment_received: paymentAmount,
        payment_status: paymentStatus
      };

      // Validate empty jars collection
      const jarsDelivered = parseInt(executionData.jars_delivered);
      const emptyJarsCollected = parseInt(executionData.empty_jars_collected) || 0;
      
      if (emptyJarsCollected > jarsDelivered) {
        toast.error(`Cannot collect ${emptyJarsCollected} empty jars when only ${jarsDelivered} jars were delivered!`);
        return;
      }
      
      const missingEmptyJars = Math.max(0, jarsDelivered - emptyJarsCollected);

      await axios.put(`${API}/event-orders/${selectedEvent.id}`, {
        event_status: 'completed',
        delivery_status: executionData.delivery_status,
        jars_delivered: jarsDelivered,
        empty_jars_collected: emptyJarsCollected,
        missing_empty_jars: missingEmptyJars,
        setup_completed: executionData.setup_completed,
        delivery_notes: executionData.delivery_notes,
        delivery_completed_at: executionData.delivery_completed_at,
        delivered_by: executionData.delivered_by,
        delivered_by_name: executionData.delivered_by_name,
        payment_status: paymentStatus
      });

      // Update customer balance if payment received
      if (paymentAmount > 0) {
        try {
          await axios.put(`${API}/customers/${selectedEvent.customer_id}/balance`, {
            amount_received: paymentAmount,
            payment_mode: executionData.payment_mode,
            notes: `Payment received during event delivery by ${user?.name} on ${new Date().toLocaleDateString()}`
          });
        } catch (error) {
          console.warn('Could not update customer balance:', error);
        }
      }

      // Record delivery boy payment collection (legacy)
      if (paymentAmount > 0) {
        try {
          await axios.post(`${API}/delivery-boy-payments`, {
            delivery_boy_id: selectedEvent.delivery_boy_id,
            delivery_boy_name: selectedEvent.delivery_boy_name,
            event_id: selectedEvent.id,
            customer_id: selectedEvent.customer_id,
            customer_name: selectedEvent.customer_name,
            amount_collected: paymentAmount,
            payment_mode: executionData.payment_mode,
            payment_type: 'event_delivery',
            notes: `Payment collected during event delivery: ${selectedEvent.event_name}`
          });
        } catch (error) {
          console.warn('Could not record delivery boy payment:', error);
        }

        // Record payment in reconciliation system for admin tracking
        try {
          await axios.post(`${API}/customer-payments`, {
            customer_id: selectedEvent.customer_id,
            customer_name: selectedEvent.customer_name,
            amount: paymentAmount,
            payment_mode: executionData.payment_mode,
            collected_by: selectedEvent.delivery_boy_id || user?.id,
            collected_by_name: selectedEvent.delivery_boy_name || user?.name,
            payment_type: 'event_order_payment',
            notes: `Event order payment collected - ${selectedEvent.event_name} by ${selectedEvent.delivery_boy_name || user?.name}`,
            collected_at: new Date().toISOString(),
            event_id: selectedEvent.id,
            event_name: selectedEvent.event_name
          });
        } catch (error) {
          console.warn('Could not record payment for reconciliation:', error);
        }
      }

      toast.success(`Event delivery completed successfully! ${executionData.jars_delivered} jars delivered.`);
      setShowDeliveryExecutionDialog(false);
      fetchData(); // Refresh data
    } catch (error) {
      console.error('Error executing delivery:', error);
      toast.error('Failed to complete delivery');
    }
  };

  const filteredEvents = eventOrders.filter(event => {
    const matchesSearch = 
      event.event_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.venue_address.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || event.event_status === filterStatus;
    const matchesType = filterType === 'all' || event.event_type === filterType;
    
    return matchesSearch && matchesStatus && matchesType;
  });

  const getEventTypeInfo = (type) => {
    return eventTypes.find(t => t.value === type) || eventTypes.find(t => t.value === 'other');
  };

  const getStatusBadge = (status) => {
    const variants = {
      confirmed: 'bg-blue-100 text-blue-800',
      in_progress: 'bg-yellow-100 text-yellow-800',
      completed: 'bg-green-100 text-green-800',
      cancelled: 'bg-red-100 text-red-800'
    };
    
    return variants[status] || 'bg-gray-100 text-gray-800';
  };

  const getPaymentStatusBadge = (status) => {
    const variants = {
      pending: 'bg-red-100 text-red-800',
      advance_paid: 'bg-yellow-100 text-yellow-800',
      fully_paid: 'bg-green-100 text-green-800'
    };
    
    return variants[status] || 'bg-gray-100 text-gray-800';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const totalEvents = eventOrders.length;
  
  // Calculate total collection (advance + last payment amounts) - excluding forfeited advances
  const totalCollection = eventOrders.reduce((sum, e) => {
    // Don't include forfeited advances in total collection
    if (e.event_status === 'cancelled' && e.advance_forfeited) {
      return sum;
    }
    const advanceAmount = e.advance_amount || 0;
    const lastPaymentAmount = e.last_payment_amount || 0;
    return sum + advanceAmount + lastPaymentAmount;
  }, 0);
  
  // Calculate advance forfeited collection
  const advanceForfeitedCollection = eventOrders.reduce((sum, e) => {
    if (e.event_status === 'cancelled' && e.advance_forfeited) {
      return sum + (e.advance_amount || 0);
    }
    return sum;
  }, 0);
  
  const upcomingEvents = eventOrders.filter(e => new Date(e.event_date) > new Date() && ['confirmed', 'in_progress'].includes(e.event_status)).length;
  const completedEvents = eventOrders.filter(e => e.event_status === 'completed').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900" data-testid="event-order-management-title">
            Event Order Management
          </h1>
          <p className="text-gray-600 mt-1">
            Manage bulk orders for weddings, corporate events, parties and festivals
          </p>
        </div>
        
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button 
              className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700 transition-all duration-200"
              data-testid="create-event-order-btn"
              onClick={resetForm}
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Event Order
            </Button>
          </DialogTrigger>
          
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Event Order</DialogTitle>
              <DialogDescription>
                Create a bulk order for events, weddings, parties or corporate functions
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleCreateEvent} className="space-y-6">
              {/* Event Basic Info */}
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="eventType">Event Type</Label>
                  <Select 
                    value={eventForm.event_type} 
                    onValueChange={(value) => setEventForm({...eventForm, event_type: value})}
                  >
                    <SelectTrigger data-testid="event-type-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {eventTypes.map(type => {
                        const Icon = type.icon;
                        return (
                          <SelectItem key={type.value} value={type.value}>
                            <div className="flex items-center gap-2">
                              <div className={`w-4 h-4 rounded ${type.color} flex items-center justify-center`}>
                                <Icon className="w-2.5 h-2.5 text-white" />
                              </div>
                              {type.label}
                            </div>
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Customer Selection Toggle */}
              <div className="space-y-4">
                <Label>Customer Information</Label>
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="existing-customer"
                      name="customer-type"
                      checked={!eventForm.create_new_customer}
                      onChange={() => setEventForm({
                        ...eventForm, 
                        create_new_customer: false,
                        customer_id: '',
                        new_customer_name: '',
                        new_customer_mobile: '',
                        new_customer_address: ''
                      })}
                    />
                    <Label htmlFor="existing-customer">Select Existing Customer</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="new-customer"
                      name="customer-type"
                      checked={eventForm.create_new_customer}
                      onChange={() => setEventForm({
                        ...eventForm, 
                        create_new_customer: true,
                        customer_id: ''
                      })}
                    />
                    <Label htmlFor="new-customer">Create New Customer</Label>
                  </div>
                </div>
                
                {/* Existing Customer Selection */}
                {!eventForm.create_new_customer && (
                  <div className="space-y-2">
                    <Label htmlFor="customer">Select Customer</Label>
                    <Select 
                      value={eventForm.customer_id} 
                      onValueChange={(value) => setEventForm({...eventForm, customer_id: value})}
                    >
                      <SelectTrigger data-testid="event-customer-select">
                        <SelectValue placeholder="Select customer" />
                      </SelectTrigger>
                      <SelectContent>
                        {customers.map(customer => (
                          <SelectItem key={customer.id} value={customer.id}>
                            {customer.name} - {customer.mobile}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
                
                {/* New Customer Form */}
                {eventForm.create_new_customer && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="new-customer-name">Customer Name</Label>
                      <Input
                        id="new-customer-name"
                        value={eventForm.new_customer_name}
                        onChange={(e) => setEventForm({...eventForm, new_customer_name: e.target.value})}
                        placeholder="Enter customer name"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="new-customer-mobile">Mobile Number</Label>
                      <Input
                        id="new-customer-mobile"
                        type="tel"
                        value={eventForm.new_customer_mobile}
                        onChange={(e) => {
                          const value = e.target.value.replace(/\D/g, ''); // Only digits
                          if (value.length <= 10) {
                            setEventForm({...eventForm, new_customer_mobile: value});
                          }
                        }}
                        placeholder="Enter 10 digit mobile number"
                        required
                        maxLength={10}
                        pattern="[0-9]{10}"
                      />
                      {eventForm.new_customer_mobile && eventForm.new_customer_mobile.length !== 10 && (
                        <p className="text-xs text-red-600 mt-1">Mobile number must be exactly 10 digits</p>
                      )}
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="new-customer-address">Address</Label>
                      <Input
                        id="new-customer-address"
                        value={eventForm.new_customer_address}
                        onChange={(e) => setEventForm({...eventForm, new_customer_address: e.target.value})}
                        placeholder="Enter customer address"
                        required
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Event Date & Time */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Event Date</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !eventForm.event_date && "text-muted-foreground"
                        )}
                        data-testid="event-date-picker"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {eventForm.event_date ? format(eventForm.event_date, "PPP") : <span>Pick date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={eventForm.event_date}
                        onSelect={(date) => setEventForm({...eventForm, event_date: date})}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="eventTime">Event Time</Label>
                  <Input
                    id="eventTime"
                    type="time"
                    value={eventForm.event_time}
                    onChange={(e) => setEventForm({...eventForm, event_time: e.target.value})}
                    data-testid="event-time-input"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="venueAddress">Venue Address</Label>
                <Textarea
                  id="venueAddress"
                  value={eventForm.venue_address}
                  onChange={(e) => setEventForm({...eventForm, venue_address: e.target.value})}
                  placeholder="Complete venue address with landmarks"
                  required
                  data-testid="event-venue-input"
                />
              </div>

              {/* Products Section */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-base font-medium">Products Required</Label>
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm" 
                    onClick={addProduct}
                    data-testid="add-event-product-btn"
                  >
                    <Plus className="w-4 h-4 mr-1" />
                    Add Product
                  </Button>
                </div>
                
                {eventForm.products.map((product, index) => (
                  <div key={index} className="border rounded-lg p-4 space-y-3">
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
                      <div className="md:col-span-2">
                        <Label>Product</Label>
                        <Select 
                          value={product.product_id} 
                          onValueChange={(value) => updateProduct(index, 'product_id', value)}
                        >
                          <SelectTrigger data-testid={`event-product-select-${index}`}>
                            <SelectValue placeholder="Select product" />
                          </SelectTrigger>
                          <SelectContent>
                            {products.map(p => (
                              <SelectItem key={p.id} value={p.id}>
                                {p.name} - ₹{p.price}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <Label>Quantity</Label>
                        <Input
                          type="number"
                          min="1"
                          value={product.quantity}
                          onChange={(e) => {
                            const value = e.target.value;
                            updateProduct(index, 'quantity', value === '' ? '' : parseInt(value) || '');
                          }}
                          placeholder="Enter quantity"
                          data-testid={`event-quantity-input-${index}`}
                        />
                      </div>
                      
                      <div>
                        <Label>Price</Label>
                        <Input
                          type="number"
                          value={product.price}
                          onChange={(e) => updateProduct(index, 'price', parseFloat(e.target.value) || 0)}
                          data-testid={`event-price-input-${index}`}
                        />
                      </div>
                      
                      <div className="flex items-end">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removeProduct(index)}
                          disabled={eventForm.products.length === 1}
                          className="w-full"
                          data-testid={`remove-event-product-${index}`}
                        >
                          Remove
                        </Button>
                      </div>
                    </div>
                    
                    <div className="text-sm text-gray-600">
                      Subtotal: ₹{product.total?.toFixed(2) || '0.00'}
                    </div>
                  </div>
                ))}
              </div>

              {/* Payment Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="totalAmount">Total Amount (₹)</Label>
                  <Input
                    id="totalAmount"
                    type="number"
                    value={eventForm.total_amount}
                    onChange={(e) => setEventForm({...eventForm, total_amount: parseFloat(e.target.value) || 0})}
                    data-testid="event-total-amount-input"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="advanceAmount">Advance Amount (₹)</Label>
                  <Input
                    id="advanceAmount"
                    type="number"
                    value={eventForm.advance_amount}
                    onChange={(e) => setEventForm({...eventForm, advance_amount: parseFloat(e.target.value) || 0})}
                    data-testid="event-advance-amount-input"
                  />
                </div>
              </div>

              {/* Additional Info */}
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="setupRequired"
                    checked={eventForm.setup_required}
                    onCheckedChange={(checked) => setEventForm({...eventForm, setup_required: checked})}
                    data-testid="event-setup-required-checkbox"
                  />
                  <Label htmlFor="setupRequired">Setup service required</Label>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="deliveryInstructions">Delivery Instructions</Label>
                  <Textarea
                    id="deliveryInstructions"
                    value={eventForm.delivery_instructions}
                    onChange={(e) => setEventForm({...eventForm, delivery_instructions: e.target.value})}
                    placeholder="Specific delivery instructions..."
                    data-testid="event-delivery-instructions-input"
                  />
                </div>
              </div>

              {/* Total Summary */}
              {eventForm.total_amount > 0 && (
                <div className="border-t pt-4">
                  <div className="space-y-2 text-right bg-gray-50 p-4 rounded-lg">
                    <div className="flex justify-between">
                      <span>Total Amount:</span>
                      <span className="font-medium">₹{eventForm.total_amount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Advance Amount:</span>
                      <span className="font-medium">₹{eventForm.advance_amount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between font-bold text-lg border-t pt-2">
                      <span>Balance Due:</span>
                      <span className="text-red-600">₹{(eventForm.total_amount - eventForm.advance_amount).toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="flex space-x-2 pt-4">
                <Button 
                  type="submit" 
                  className="flex-1 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
                  disabled={eventForm.create_new_customer 
                    ? (!eventForm.new_customer_name || !eventForm.new_customer_mobile || !eventForm.new_customer_address)
                    : !eventForm.customer_id
                  }
                  data-testid="save-event-order-btn"
                >
                  Create Event Order
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowCreateDialog(false)}
                  data-testid="cancel-event-order-btn"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and Filter */}
      <Card className="shadow-soft">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input 
                placeholder="Search by event name, customer, or venue..." 
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                data-testid="event-search-input"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-40" data-testid="event-status-filter">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  {eventStatuses.map(status => (
                    <SelectItem key={status} value={status}>
                      {status.charAt(0).toUpperCase() + status.slice(1).replace('_', ' ')}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-40" data-testid="event-type-filter">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {eventTypes.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Event Stats */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Events</p>
                <p className="text-2xl font-bold text-purple-600" data-testid="total-events-stat">
                  {totalEvents}
                </p>
              </div>
              <PartyPopper className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Upcoming Events</p>
                <p className="text-2xl font-bold text-blue-600" data-testid="upcoming-events-stat">
                  {upcomingEvents}
                </p>
              </div>
              <Clock className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Completed Events</p>
                <p className="text-2xl font-bold text-green-600" data-testid="completed-events-stat">
                  {completedEvents}
                </p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Event Collection</p>
                <p className="text-2xl font-bold text-orange-600" data-testid="event-collection-stat">
                  ₹{totalCollection.toFixed(2)}
                </p>
              </div>
              <IndianRupee className="w-8 h-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Advance Forfeited</p>
                <p className="text-2xl font-bold text-red-600" data-testid="advance-forfeited-stat">
                  ₹{advanceForfeitedCollection.toFixed(2)}
                </p>
              </div>
              <XCircle className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Event List */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle>Event Orders</CardTitle>
          <CardDescription>
            {filteredEvents.length} event order(s) found
          </CardDescription>
        </CardHeader>
        
        <CardContent className="p-0">
          {filteredEvents.length === 0 ? (
            <div className="text-center py-12" data-testid="no-events-message">
              <PartyPopper className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No event orders found</h3>
              <p className="text-gray-600 mb-4">Create your first event order to get started.</p>
              <Button 
                onClick={() => setShowCreateDialog(true)}
                className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700"
                data-testid="create-first-event-btn"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Event Order
              </Button>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {filteredEvents.map((event) => {
                const eventTypeInfo = getEventTypeInfo(event.event_type);
                const Icon = eventTypeInfo.icon;
                
                return (
                  <div key={event.id} className="p-6 hover:bg-gray-50 transition-colors" data-testid={`event-item-${event.id}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex-1 flex items-start space-x-4">
                        <div className={`w-12 h-12 rounded-lg ${eventTypeInfo.color} flex items-center justify-center`}>
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="text-lg font-semibold text-gray-900" data-testid={`event-name-${event.id}`}>
                              {event.event_name}
                            </h3>
                            
                            <Badge className={getStatusBadge(event.event_status)}>
                              {event.event_status.charAt(0).toUpperCase() + event.event_status.slice(1).replace('_', ' ')}
                            </Badge>
                            
                            <Badge className={getPaymentStatusBadge(event.payment_status)}>
                              {event.payment_status.replace('_', ' ').charAt(0).toUpperCase() + event.payment_status.replace('_', ' ').slice(1)}
                            </Badge>
                            
                            <Badge variant="outline" className="bg-gray-50">
                              {eventTypeInfo.label}
                            </Badge>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm text-gray-600">
                            <div className="flex items-center space-x-2">
                              <CalendarIcon className="w-4 h-4" />
                              <span data-testid={`event-date-${event.id}`}>
                                {format(new Date(event.event_date), "MMM dd, yyyy")} at {event.event_time}
                              </span>
                            </div>
                            
                            <div className="flex items-center space-x-2">
                              <Package className="w-4 h-4" />
                              <span data-testid={`event-jars-${event.id}`}>
                                {event.total_jars_required || event.jars_to_deliver || 0} jars required
                              </span>
                            </div>
                            
                            <div className="flex items-center space-x-2">
                              <IndianRupee className="w-4 h-4" />
                              <span className="font-medium text-green-600" data-testid={`event-amount-${event.id}`}>
                                ₹{((event.advance_amount || 0) + (event.last_payment_amount || 0)).toFixed(2)} collected
                              </span>
                              <span className="text-xs text-gray-500">
                                / ₹{event.total_amount.toFixed(2)}
                              </span>
                            </div>
                            
                            <div className="flex items-center space-x-2">
                              <span className="text-gray-500" data-testid={`event-customer-${event.id}`}>
                                {event.customer_name}
                              </span>
                            </div>
                          </div>
                          
                          <div className="mt-2 flex items-center space-x-2 text-sm text-gray-600">
                            <MapPin className="w-4 h-4" />
                            <span className="truncate" data-testid={`event-venue-${event.id}`}>
                              {event.venue_address}
                            </span>
                          </div>

                          {event.delivery_boy_name && (
                            <div className="mt-2 flex items-center space-x-2 text-sm text-gray-600">
                              <UserCheck className="w-4 h-4" />
                              <span data-testid={`event-delivery-boy-${event.id}`}>
                                Assigned to: {event.delivery_boy_name}
                              </span>
                              {event.vehicle_number && (
                                <Badge variant="outline" className="bg-blue-50 text-blue-700">
                                  Vehicle: {event.vehicle_number}
                                </Badge>
                              )}
                            </div>
                          )}

                          {/* Collection Status Information */}
                          {event.payment_status && (
                            <div className="mt-2 flex items-center space-x-2">
                              <IndianRupee className="w-4 h-4" />
                              <Badge variant="outline" className={
                                event.payment_status === 'fully_paid' || event.payment_status === 'full_payment'
                                  ? 'bg-green-50 text-green-700' 
                                  : event.payment_status === 'advance_paid' || event.payment_status === 'partial_payment'
                                    ? 'bg-yellow-50 text-yellow-700'
                                    : 'bg-gray-50 text-gray-700'
                              }>
                                {event.payment_status === 'fully_paid' || event.payment_status === 'full_payment'
                                  ? `Full Collection: ₹${((event.advance_amount || 0) + (event.last_payment_amount || 0)).toFixed(2)}`
                                  : event.payment_status === 'advance_paid' || event.payment_status === 'partial_payment'
                                    ? `Partial Collection: ₹${((event.advance_amount || 0) + (event.last_payment_amount || 0)).toFixed(2)}`
                                    : `Advance Collection: ₹${(event.advance_amount || 0).toFixed(2)}`
                                }
                              </Badge>
                            </div>
                          )}
                          
                          {event.balance_amount > 0 && 
                           event.payment_status !== 'fully_paid' && 
                           event.payment_status !== 'full_payment' && (
                            <div className="mt-2">
                              <Badge variant="outline" className="bg-red-50 text-red-700">
                                Balance Due: ₹{event.balance_amount.toFixed(2)}
                              </Badge>
                            </div>
                          )}

                          {/* Missing Empty Jars Information */}
                          {event.event_status === 'completed' && event.missing_empty_jars > 0 && (
                            <div className="mt-2">
                              <Badge variant="outline" className="bg-orange-50 text-orange-700">
                                Missing Empty Jars: {event.missing_empty_jars}
                              </Badge>
                            </div>
                          )}

                          {/* Empty Jars Collection Summary for Completed Events */}
                          {event.event_status === 'completed' && event.jars_delivered > 0 && (
                            <div className="mt-2 flex items-center space-x-2 text-xs text-gray-600">
                              <ArrowUpCircle className="w-3 h-3" />
                              <span>
                                {event.empty_jars_collected || 0}/{event.jars_delivered} empty jars collected
                              </span>
                            </div>
                          )}

                          {/* Cancelled Event Information */}
                          {event.event_status === 'cancelled' && (
                            <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded-lg">
                              <div className="flex items-center space-x-2 text-sm text-red-700 font-medium">
                                <X className="w-4 h-4" />
                                <span>Event Cancelled</span>
                              </div>
                              {event.advance_amount > 0 && (
                                <div className="mt-2 text-xs text-red-600">
                                  Advance payment ₹{event.advance_amount} forfeited (non-refundable)
                                </div>
                              )}
                              {event.cancellation_reason && (
                                <div className="mt-1 text-xs text-gray-600">
                                  Reason: {event.cancellation_reason}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2 ml-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => viewEventDetails(event)}
                          className="hover:bg-blue-50 hover:text-blue-600"
                          data-testid={`view-event-${event.id}`}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        
                        {/* Edit Button - Show only for incomplete and confirmed events */}
                        {(() => {
                          // Show edit button only for incomplete and confirmed events
                          const editableStatuses = ['incomplete', 'confirmed'];
                          const canEdit = editableStatuses.includes(event.event_status);
                          
                          return canEdit && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => openEditDialog(event)}
                              className="hover:bg-green-50 hover:text-green-600"
                              data-testid={`edit-event-${event.id}`}
                            >
                              <Edit3 className="w-4 h-4" />
                            </Button>
                          );
                        })()}
                        
                        {/* Cancel Button - Only show for pending, confirmed, or in_progress events */}
                        {['pending', 'confirmed', 'in_progress'].includes(event.event_status) && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleCancelEvent(event)}
                            className="hover:bg-red-50 hover:text-red-600"
                            data-testid={`cancel-event-${event.id}`}
                            title="Cancel Event (Advance Non-Refundable)"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        )}
                        
                        {/* Assign Delivery Boy Button - Only for Admin/Manager */}
                        {(user?.role === 'admin' || user?.role === 'manager') && 
                         event.event_status === 'confirmed' && !event.delivery_boy_id && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => openAssignDeliveryDialog(event)}
                            className="hover:bg-purple-50 hover:text-purple-600"
                            data-testid={`assign-delivery-${event.id}`}
                            title="Assign Delivery Boy"
                          >
                            <UserCheck className="w-4 h-4" />
                          </Button>
                        )}

                        {/* Reassign Delivery Boy Button - Only for Admin/Manager */}
                        {(user?.role === 'admin' || user?.role === 'manager') &&
                         event.event_status === 'in_progress' && event.delivery_boy_id && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => openDeliveryExecutionDialog(event)}
                            className="hover:bg-orange-50 hover:text-orange-600"
                            data-testid={`execute-delivery-${event.id}`}
                            title="Execute Delivery"
                          >
                            <Truck className="w-4 h-4" />
                          </Button>
                        )}

                        {event.event_status === 'confirmed' && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleCompleteEvent(event.id)}
                            className="hover:bg-green-50 hover:text-green-600"
                            data-testid={`complete-event-${event.id}`}
                          >
                            <CheckCircle className="w-4 h-4" />
                          </Button>
                        )}
                        
                        {/* Delete Button - Hide for completed and cancelled events */}
                        {!['completed', 'cancelled'].includes(event.event_status) && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDeleteEvent(event.id, event.event_name)}
                            className="hover:bg-red-50 hover:text-red-600"
                            data-testid={`delete-event-${event.id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Event Details Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Event Order Details</DialogTitle>
            <DialogDescription>
              Complete event order information
            </DialogDescription>
          </DialogHeader>
          
          {selectedEvent && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">Event Name:</span>
                  <p>{selectedEvent.event_name}</p>
                </div>
                <div>
                  <span className="font-medium">Event Type:</span>
                  <p>{getEventTypeInfo(selectedEvent.event_type).label}</p>
                </div>
                <div>
                  <span className="font-medium">Date & Time:</span>
                  <p>{format(new Date(selectedEvent.event_date), "PPP")} at {selectedEvent.event_time}</p>
                </div>
                <div>
                  <span className="font-medium">Delivery Quantity:</span>
                  <p>{selectedEvent.total_jars_required || selectedEvent.jars_to_deliver || 0} water jars required</p>
                </div>
                <div>
                  <span className="font-medium">Customer:</span>
                  <p>{selectedEvent.customer_name}</p>
                </div>
                <div>
                  <span className="font-medium">Mobile:</span>
                  <p>{selectedEvent.customer_mobile}</p>
                </div>
              </div>
              
              <div>
                <span className="font-medium">Venue Address:</span>
                <p className="text-gray-600 mt-1">{selectedEvent.venue_address}</p>
              </div>
              
              <div>
                <h4 className="font-medium mb-3">Products:</h4>
                <div className="space-y-2">
                  {selectedEvent.products.map((product, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium">{product.product_name}</p>
                        <p className="text-sm text-gray-600">Qty: {product.quantity} × ₹{product.price}</p>
                      </div>
                      <p className="font-medium">₹{product.total.toFixed(2)}</p>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="border-t pt-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Total Amount:</span>
                    <span>₹{selectedEvent.total_amount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Advance Paid:</span>
                    <span>₹{selectedEvent.advance_amount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-lg border-t pt-2">
                    <span>Balance Due:</span>
                    <span className="text-red-600">₹{selectedEvent.balance_amount.toFixed(2)}</span>
                  </div>
                </div>
              </div>
              
              {selectedEvent.setup_required && (
                <div className="bg-blue-50 p-3 rounded-lg">
                  <p className="text-blue-800 font-medium">Setup Service Required</p>
                </div>
              )}
              
              {selectedEvent.special_requirements && (
                <div>
                  <span className="font-medium">Special Requirements:</span>
                  <p className="text-gray-600 mt-1">{selectedEvent.special_requirements}</p>
                </div>
              )}
              
              {selectedEvent.delivery_instructions && (
                <div>
                  <span className="font-medium">Delivery Instructions:</span>
                  <p className="text-gray-600 mt-1">{selectedEvent.delivery_instructions}</p>
                </div>
              )}
              
              <Button 
                onClick={() => setShowDetailsDialog(false)}
                className="w-full"
                data-testid="close-event-details-btn"
              >
                Close
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delivery Boy Assignment Dialog */}
      <Dialog open={showAssignDeliveryDialog} onOpenChange={setShowAssignDeliveryDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Assign Delivery Boy</DialogTitle>
            <DialogDescription>
              Assign a delivery boy for {selectedEvent?.event_name}
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleAssignDeliveryBoy} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="deliveryBoy">Select Delivery Boy</Label>
              <Select 
                value={deliveryAssignmentForm.delivery_boy_id} 
                onValueChange={handleDeliveryBoySelection}
                required
              >
                <SelectTrigger data-testid="delivery-boy-select">
                  <SelectValue placeholder="Choose delivery boy" />
                </SelectTrigger>
                <SelectContent>
                  {deliveryBoys.map(boy => (
                    <SelectItem key={boy.id} value={boy.id}>
                      {boy.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="deliveryDate">Delivery Date</Label>
                <Input
                  type="date"
                  value={deliveryAssignmentForm.delivery_date.toISOString().split('T')[0]}
                  onChange={(e) => setDeliveryAssignmentForm({
                    ...deliveryAssignmentForm,
                    delivery_date: new Date(e.target.value)
                  })}
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="deliveryTime">Delivery Time</Label>
                <Input
                  type="time"
                  value={deliveryAssignmentForm.delivery_time}
                  onChange={(e) => setDeliveryAssignmentForm({
                    ...deliveryAssignmentForm,
                    delivery_time: e.target.value
                  })}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="vehicleNumber">Vehicle Number (Optional)</Label>
              <Input
                value={deliveryAssignmentForm.vehicle_number}
                onChange={(e) => setDeliveryAssignmentForm({
                  ...deliveryAssignmentForm,
                  vehicle_number: e.target.value
                })}
                placeholder="e.g. KA-01-AB-1234"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="specialInstructions">Special Instructions</Label>
              <Textarea
                value={deliveryAssignmentForm.special_instructions}
                onChange={(e) => setDeliveryAssignmentForm({
                  ...deliveryAssignmentForm,
                  special_instructions: e.target.value
                })}
                placeholder="Any special delivery instructions..."
                rows={3}
              />
            </div>

            <div className="flex space-x-2">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowAssignDeliveryDialog(false)}
                className="w-full"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                <UserCheck className="w-4 h-4 mr-2" />
                Assign Delivery Boy
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delivery Execution Dialog */}
      <Dialog open={showDeliveryExecutionDialog} onOpenChange={setShowDeliveryExecutionDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Execute Delivery</DialogTitle>
            <DialogDescription>
              Complete delivery for {selectedEvent?.event_name}
            </DialogDescription>
          </DialogHeader>
          
          {/* Customer Balance Information */}
          {deliveryExecutionForm.customer_balance > 0 && (
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
              <div className="flex items-center space-x-2">
                <IndianRupee className="w-5 h-5 text-orange-600" />
                <div>
                  <p className="text-sm font-medium text-orange-800">Customer Balance Due</p>
                  <p className="text-lg font-bold text-orange-600">₹{deliveryExecutionForm.customer_balance.toFixed(2)}</p>
                </div>
              </div>
              <p className="text-xs text-orange-600 mt-1">
                You can collect partial payment or no payment and still complete delivery
              </p>
            </div>
          )}
          
          <form onSubmit={handleExecuteDelivery} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="jarsDelivered">Jars Delivered</Label>
                <Input
                  type="number"
                  min="1"
                  value={deliveryExecutionForm.jars_delivered}
                  onChange={(e) => {
                    const newJarsDelivered = e.target.value;
                    setDeliveryExecutionForm({
                      ...deliveryExecutionForm,
                      jars_delivered: newJarsDelivered,
                      empty_jars_collected: newJarsDelivered // Automatically update empty jars to match delivered jars
                    });
                  }}
                  placeholder="Enter number of jars delivered"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="emptyJarsCollected">Empty Jars Collected</Label>
                <div className="relative">
                  <Input
                    type="number"
                    min="0"
                    max={deliveryExecutionForm.jars_delivered || undefined}
                    value={deliveryExecutionForm.empty_jars_collected}
                    onChange={(e) => {
                      const value = parseInt(e.target.value) || 0;
                      const maxJars = parseInt(deliveryExecutionForm.jars_delivered) || 0;
                      // Prevent entering more than delivered jars
                      const validValue = Math.min(value, maxJars);
                      setDeliveryExecutionForm({
                        ...deliveryExecutionForm,
                        empty_jars_collected: validValue.toString()
                      });
                    }}
                    onFocus={() => {
                      // Auto-fill with delivered jar count on focus
                      if (!deliveryExecutionForm.empty_jars_collected && deliveryExecutionForm.jars_delivered) {
                        setDeliveryExecutionForm({
                          ...deliveryExecutionForm,
                          empty_jars_collected: deliveryExecutionForm.jars_delivered
                        });
                      }
                    }}
                    placeholder={`Max: ${deliveryExecutionForm.jars_delivered || 0} jars`}
                  />
                  {deliveryExecutionForm.jars_delivered && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      className="absolute right-1 top-1 h-6 px-2 text-xs"
                      onClick={() => {
                        setDeliveryExecutionForm({
                          ...deliveryExecutionForm,
                          empty_jars_collected: deliveryExecutionForm.jars_delivered
                        });
                      }}
                    >
                      Max
                    </Button>
                  )}
                </div>
                {deliveryExecutionForm.jars_delivered && deliveryExecutionForm.empty_jars_collected && (
                  parseInt(deliveryExecutionForm.jars_delivered) > parseInt(deliveryExecutionForm.empty_jars_collected) && (
                    <p className="text-xs text-red-600">
                      Missing: {parseInt(deliveryExecutionForm.jars_delivered) - parseInt(deliveryExecutionForm.empty_jars_collected)} empty jars
                    </p>
                  )
                )}
                {deliveryExecutionForm.jars_delivered && deliveryExecutionForm.empty_jars_collected && (
                  parseInt(deliveryExecutionForm.empty_jars_collected) > parseInt(deliveryExecutionForm.jars_delivered) && (
                    <p className="text-xs text-red-600">
                      Error: Cannot collect more empty jars than delivered!
                    </p>
                  )
                )}
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="setupCompleted"
                checked={deliveryExecutionForm.setup_completed}
                onCheckedChange={(checked) => setDeliveryExecutionForm({
                  ...deliveryExecutionForm,
                  setup_completed: checked
                })}
              />
              <Label htmlFor="setupCompleted">Setup Completed</Label>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="paymentReceived">
                  Payment Received (₹) 
                  <span className="text-xs text-gray-500 ml-1">(Optional)</span>
                </Label>
                <Input
                  type="number"
                  min="0"
                  max={deliveryExecutionForm.customer_balance > 0 ? deliveryExecutionForm.customer_balance : undefined}
                  step="0.01"
                  value={deliveryExecutionForm.payment_received}
                  onChange={(e) => setDeliveryExecutionForm({
                    ...deliveryExecutionForm,
                    payment_received: e.target.value
                  })}
                  placeholder={deliveryExecutionForm.customer_balance > 0 ? `Max: ₹${deliveryExecutionForm.customer_balance}` : "0.00"}
                />
                {deliveryExecutionForm.payment_received && deliveryExecutionForm.customer_balance > 0 && (
                  <p className="text-xs text-gray-600">
                    Remaining Balance: ₹{Math.max(0, deliveryExecutionForm.customer_balance - parseFloat(deliveryExecutionForm.payment_received || 0)).toFixed(2)}
                  </p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="paymentMode">Payment Mode</Label>
                <Select 
                  value={deliveryExecutionForm.payment_mode} 
                  onValueChange={(value) => setDeliveryExecutionForm({
                    ...deliveryExecutionForm,
                    payment_mode: value
                  })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cash">Cash</SelectItem>
                    <SelectItem value="upi">UPI</SelectItem>
                    <SelectItem value="online">Online Transfer</SelectItem>
                    <SelectItem value="cheque">Cheque</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="deliveryNotes">Delivery Notes</Label>
              <Textarea
                value={deliveryExecutionForm.delivery_notes}
                onChange={(e) => setDeliveryExecutionForm({
                  ...deliveryExecutionForm,
                  delivery_notes: e.target.value
                })}
                placeholder="Any delivery notes or customer feedback..."
                rows={3}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="customerSignature"
                checked={deliveryExecutionForm.customer_signature}
                onCheckedChange={(checked) => setDeliveryExecutionForm({
                  ...deliveryExecutionForm,
                  customer_signature: checked
                })}
              />
              <Label htmlFor="customerSignature">Customer Signature Received</Label>
            </div>

            <div className="flex space-x-2">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowDeliveryExecutionDialog(false)}
                className="w-full"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="w-full bg-orange-600 hover:bg-orange-700"
              >
                <Package className="w-4 h-4 mr-2" />
                Complete Delivery
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Event Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Edit3 className="w-5 h-5" />
              <span>Edit Event Order</span>
            </DialogTitle>
            <DialogDescription>
              Update event order details. Only incomplete and confirmed events can be edited.
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleUpdateEvent} className="space-y-6">
            {/* Basic Event Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="eventName">Event Name *</Label>
                <Input
                  value={eventForm.event_name}
                  onChange={(e) => setEventForm({...eventForm, event_name: e.target.value})}
                  placeholder="e.g. Birthday Party"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="eventType">Event Type *</Label>
                <Select 
                  value={eventForm.event_type} 
                  onValueChange={(value) => setEventForm({...eventForm, event_type: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select event type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="birthday">🎂 Birthday Party</SelectItem>
                    <SelectItem value="wedding">💒 Wedding</SelectItem>
                    <SelectItem value="corporate">🏢 Corporate Event</SelectItem>
                    <SelectItem value="festival">🎊 Festival</SelectItem>
                    <SelectItem value="anniversary">💕 Anniversary</SelectItem>
                    <SelectItem value="business">💼 Business Meeting</SelectItem>
                    <SelectItem value="other">⭐ Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Customer Selection */}
            <div className="space-y-2">
              <Label htmlFor="customer">Customer *</Label>
              <Select 
                value={eventForm.customer_id} 
                onValueChange={(value) => setEventForm({...eventForm, customer_id: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select customer" />
                </SelectTrigger>
                <SelectContent>
                  {customers.map((customer) => (
                    <SelectItem key={customer.id} value={customer.id}>
                      {customer.name} - {customer.mobile}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Date and Time */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Event Date *</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !eventForm.event_date && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {eventForm.event_date ? format(eventForm.event_date, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={eventForm.event_date}
                      onSelect={(date) => setEventForm({...eventForm, event_date: date})}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="space-y-2">
                <Label htmlFor="eventTime">Event Time *</Label>
                <Input
                  type="time"
                  value={eventForm.event_time}
                  onChange={(e) => setEventForm({...eventForm, event_time: e.target.value})}
                  required
                />
              </div>
            </div>

            {/* Venue and Guest Count */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="venue">Venue *</Label>
                <Input
                  value={eventForm.venue}
                  onChange={(e) => setEventForm({...eventForm, venue: e.target.value})}
                  placeholder="Event venue address"
                  required
                />
              </div>

            </div>

            {/* Products Selection */}
            <div className="space-y-3">
              <Label>Products & Services *</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-48 overflow-y-auto border rounded-lg p-3">
                {products.map((product) => (
                  <div key={product.id} className="flex items-center space-x-2 p-2 hover:bg-gray-50 rounded">
                    <Checkbox
                      checked={eventForm.products.some(p => p.product_id === product.id)}
                      onCheckedChange={(checked) => handleProductSelection(product.id, checked)}
                    />
                    <div className="flex-1">
                      <p className="font-medium text-sm">{product.name}</p>
                      <p className="text-xs text-gray-600">₹{product.price}</p>
                    </div>
                    {eventForm.products.some(p => p.product_id === product.id) && (
                      <div className="flex items-center space-x-1">
                        <Input
                          type="number"
                          min="1"
                          value={eventForm.products.find(p => p.product_id === product.id)?.quantity || 1}
                          onChange={(e) => handleQuantityChange(product.id, parseInt(e.target.value))}
                          className="w-16 h-8 text-xs"
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Pricing Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="advanceAmount">Advance Amount *</Label>
                <div className="relative">
                  <IndianRupee className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    type="number"
                    min="0"
                    step="0.01"
                    value={eventForm.advance_amount}
                    onChange={(e) => setEventForm({...eventForm, advance_amount: parseFloat(e.target.value) || 0})}
                    placeholder="0.00"
                    className="pl-10"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="totalAmount">Total Amount</Label>
                <div className="relative">
                  <IndianRupee className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    type="number"
                    value={eventForm.total_amount}
                    className="pl-10 bg-gray-50"
                    readOnly
                  />
                </div>
              </div>
            </div>

            {/* Additional Options */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  checked={eventForm.setup_required}
                  onCheckedChange={(checked) => setEventForm({...eventForm, setup_required: checked})}
                />
                <Label>Setup Required</Label>
              </div>

              <div className="space-y-2">
                <Label htmlFor="deliveryInstructions">Delivery Instructions</Label>
                <Textarea
                  value={eventForm.delivery_instructions}
                  onChange={(e) => setEventForm({...eventForm, delivery_instructions: e.target.value})}
                  placeholder="Any special delivery instructions..."
                  rows={3}
                />
              </div>
            </div>

            {/* Form Actions */}
            <div className="flex space-x-3 pt-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowEditDialog(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="flex-1 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
              >
                <Edit3 className="w-4 h-4 mr-2" />
                Update Event Order
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default EventOrderManagement;