import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../App';
import axios from 'axios';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { 
  Plus, 
  Search, 
  IndianRupee, 
  TrendingDown, 
  Calendar as CalendarIcon,
  Filter,
  Edit3,
  Trash2,
  Fuel,
  Users,
  Wrench,
  Building,
  Truck,
  Zap,
  MoreHorizontal
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

function ExpenseManagement() {
  const { API } = useContext(AuthContext);
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [showExpenseDialog, setShowExpenseDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [selectedExpense, setSelectedExpense] = useState(null);
  
  const [expenseForm, setExpenseForm] = useState({
    title: '',
    category: 'fuel',
    amount: 0,
    description: '',
    expense_date: new Date()
  });

  const expenseCategories = [
    { value: 'fuel', label: 'Fuel & Transport', icon: Fuel, color: 'bg-orange-500' },
    { value: 'salary', label: 'Salary & Wages', icon: Users, color: 'bg-blue-500' },
    { value: 'maintenance', label: 'Maintenance', icon: Wrench, color: 'bg-green-500' },
    { value: 'office', label: 'Office Expenses', icon: Building, color: 'bg-purple-500' },
    { value: 'transport', label: 'Transport', icon: Truck, color: 'bg-red-500' },
    { value: 'utilities', label: 'Utilities', icon: Zap, color: 'bg-yellow-500' },
    { value: 'other', label: 'Other', icon: MoreHorizontal, color: 'bg-gray-500' }
  ];

  const fetchExpenses = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API}/expenses`, {
        headers: {
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        }
      });
      setExpenses([...response.data]);
    } catch (error) {
      console.error('Error fetching expenses:', error);
      toast.error('Failed to load expenses');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchExpenses();
  }, []);

  const handleCreateExpense = async (e) => {
    e.preventDefault();
    try {
      const expenseData = {
        ...expenseForm,
        expense_date: expenseForm.expense_date.toISOString()
      };
      
      await axios.post(`${API}/expenses`, expenseData);
      toast.success('Expense added successfully!');
      setShowExpenseDialog(false);
      resetForm();
      fetchExpenses();
    } catch (error) {
      console.error('Error adding expense:', error);
      toast.error('Failed to add expense');
    }
  };

  const handleUpdateExpense = async (e) => {
    e.preventDefault();
    try {
      const updateData = {
        ...expenseForm,
        expense_date: expenseForm.expense_date.toISOString()
      };
      
      await axios.put(`${API}/expenses/${selectedExpense.id}`, updateData);
      toast.success('Expense updated successfully!');
      setShowEditDialog(false);
      setSelectedExpense(null);
      resetForm();
      fetchExpenses();
    } catch (error) {
      console.error('Error updating expense:', error);
      toast.error('Failed to update expense');
    }
  };

  const handleDeleteExpense = async (expenseId, expenseTitle) => {
    if (window.confirm(`Are you sure you want to delete expense: ${expenseTitle}?`)) {
      try {
        await axios.delete(`${API}/expenses/${expenseId}`);
        toast.success('Expense deleted successfully!');
        fetchExpenses();
      } catch (error) {
        console.error('Error deleting expense:', error);
        toast.error('Failed to delete expense');
      }
    }
  };

  const openEditDialog = (expense) => {
    setSelectedExpense(expense);
    setExpenseForm({
      title: expense.title,
      category: expense.category,
      amount: expense.amount,
      description: expense.description || '',
      expense_date: new Date(expense.expense_date)
    });
    setShowEditDialog(true);
  };

  const resetForm = () => {
    setExpenseForm({
      title: '',
      category: 'fuel',
      amount: 0,
      description: '',
      expense_date: new Date()
    });
  };

  const filteredExpenses = expenses.filter(expense => {
    const matchesSearch = 
      expense.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      expense.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = filterCategory === 'all' || expense.category === filterCategory;
    
    return matchesSearch && matchesCategory;
  });

  const getCategoryInfo = (category) => {
    return expenseCategories.find(cat => cat.value === category) || expenseCategories.find(cat => cat.value === 'other');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const todaysExpenses = expenses.filter(expense => {
    const expenseDate = new Date(expense.expense_date);
    const today = new Date();
    return expenseDate.toDateString() === today.toDateString();
  });

  const thisMonthExpenses = expenses.filter(expense => {
    const expenseDate = new Date(expense.expense_date);
    const now = new Date();
    return expenseDate.getMonth() === now.getMonth() && expenseDate.getFullYear() === now.getFullYear();
  });

  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const todaysTotal = todaysExpenses.reduce((sum, expense) => sum + expense.amount, 0);
  const monthlyTotal = thisMonthExpenses.reduce((sum, expense) => sum + expense.amount, 0);

  // Category breakdown
  const categoryBreakdown = expenseCategories.map(category => ({
    ...category,
    total: expenses.filter(e => e.category === category.value).reduce((sum, e) => sum + e.amount, 0)
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900" data-testid="expense-management-title">
            Expense Management
          </h1>
          <p className="text-gray-600 mt-1">
            Track business expenses and manage financial outflows
          </p>
        </div>
        
        <Dialog open={showExpenseDialog} onOpenChange={setShowExpenseDialog}>
          <DialogTrigger asChild>
            <Button 
              className="bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700 transition-all duration-200"
              data-testid="add-expense-btn"
              onClick={resetForm}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Expense
            </Button>
          </DialogTrigger>
          
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Expense</DialogTitle>
              <DialogDescription>
                Record a new business expense
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleCreateExpense} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Expense Title</Label>
                <Input
                  id="title"
                  value={expenseForm.title}
                  onChange={(e) => setExpenseForm({...expenseForm, title: e.target.value})}
                  placeholder="Enter expense title"
                  required
                  data-testid="expense-title-input"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select 
                  value={expenseForm.category} 
                  onValueChange={(value) => setExpenseForm({...expenseForm, category: value})}
                >
                  <SelectTrigger data-testid="expense-category-select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {expenseCategories.map(category => {
                      const Icon = category.icon;
                      return (
                        <SelectItem key={category.value} value={category.value}>
                          <div className="flex items-center gap-2">
                            <div className={`w-4 h-4 rounded ${category.color} flex items-center justify-center`}>
                              <Icon className="w-2.5 h-2.5 text-white" />
                            </div>
                            {category.label}
                          </div>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="amount">Amount (₹)</Label>
                <Input
                  id="amount"
                  type="number"
                  value={expenseForm.amount}
                  onChange={(e) => setExpenseForm({...expenseForm, amount: parseFloat(e.target.value) || 0})}
                  required
                  data-testid="expense-amount-input"
                />
              </div>
              
              <div className="space-y-2">
                <Label>Expense Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !expenseForm.expense_date && "text-muted-foreground"
                      )}
                      data-testid="expense-date-picker"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {expenseForm.expense_date ? format(expenseForm.expense_date, "PPP") : <span>Pick a date</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={expenseForm.expense_date}
                      onSelect={(date) => setExpenseForm({...expenseForm, expense_date: date})}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">Description (Optional)</Label>
                <Textarea
                  id="description"
                  value={expenseForm.description}
                  onChange={(e) => setExpenseForm({...expenseForm, description: e.target.value})}
                  placeholder="Enter expense description..."
                  data-testid="expense-description-input"
                />
              </div>
              
              <div className="flex space-x-2 pt-4">
                <Button 
                  type="submit" 
                  className="flex-1 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
                  data-testid="save-expense-btn"
                >
                  Add Expense
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowExpenseDialog(false)}
                  data-testid="cancel-expense-btn"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and Filter */}
      <Card className="shadow-soft">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input 
                placeholder="Search expenses by title or description..." 
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                data-testid="expense-search-input"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-40" data-testid="expense-category-filter">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {expenseCategories.map(category => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Expense Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Today's Expenses</p>
                <p className="text-2xl font-bold text-red-600" data-testid="todays-expenses-stat">
                  ₹{todaysTotal.toFixed(2)}
                </p>
              </div>
              <TrendingDown className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">This Month</p>
                <p className="text-2xl font-bold text-orange-600" data-testid="monthly-expenses-stat">
                  ₹{monthlyTotal.toFixed(2)}
                </p>
              </div>
              <IndianRupee className="w-8 h-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Expenses</p>
                <p className="text-2xl font-bold text-purple-600" data-testid="total-expenses-stat">
                  ₹{totalExpenses.toFixed(2)}
                </p>
              </div>
              <IndianRupee className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Expense Entries</p>
                <p className="text-2xl font-bold text-blue-600" data-testid="expense-entries-stat">
                  {expenses.length}
                </p>
              </div>
              <TrendingDown className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Category Breakdown */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle>Expense Categories</CardTitle>
          <CardDescription>Breakdown by category</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {categoryBreakdown.filter(cat => cat.total > 0).map(category => {
              const Icon = category.icon;
              return (
                <div key={category.value} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <div className={`w-10 h-10 rounded-lg ${category.color} flex items-center justify-center`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{category.label}</p>
                    <p className="text-lg font-bold text-gray-700">₹{category.total.toFixed(2)}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Expense List */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle>Expense History</CardTitle>
          <CardDescription>
            {filteredExpenses.length} expense(s) found
          </CardDescription>
        </CardHeader>
        
        <CardContent className="p-0">
          {filteredExpenses.length === 0 ? (
            <div className="text-center py-12" data-testid="no-expenses-message">
              <TrendingDown className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No expenses found</h3>
              <p className="text-gray-600 mb-4">Start by adding your first expense.</p>
              <Button 
                onClick={() => setShowExpenseDialog(true)}
                className="bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700"
                data-testid="add-first-expense-btn"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Expense
              </Button>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {filteredExpenses.map((expense) => {
                const categoryInfo = getCategoryInfo(expense.category);
                const Icon = categoryInfo.icon;
                
                return (
                  <div key={expense.id} className="p-6 hover:bg-gray-50 transition-colors" data-testid={`expense-item-${expense.id}`}>
                    <div className="flex items-center justify-between">
                      <div className="flex-1 flex items-start space-x-4">
                        <div className={`w-12 h-12 rounded-lg ${categoryInfo.color} flex items-center justify-center`}>
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="text-lg font-semibold text-gray-900" data-testid={`expense-title-${expense.id}`}>
                              {expense.title}
                            </h3>
                            <Badge variant="outline" className="bg-gray-50">
                              {categoryInfo.label}
                            </Badge>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                            <div className="flex items-center space-x-2">
                              <IndianRupee className="w-4 h-4" />
                              <span className="font-medium text-red-600 text-lg" data-testid={`expense-amount-${expense.id}`}>
                                ₹{expense.amount.toFixed(2)}
                              </span>
                            </div>
                            
                            <div className="flex items-center space-x-2">
                              <CalendarIcon className="w-4 h-4" />
                              <span data-testid={`expense-date-${expense.id}`}>
                                {format(new Date(expense.expense_date), "MMM dd, yyyy")}
                              </span>
                            </div>
                          </div>
                          
                          {expense.description && (
                            <div className="mt-2">
                              <p className="text-sm text-gray-600" data-testid={`expense-description-${expense.id}`}>
                                {expense.description}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2 ml-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openEditDialog(expense)}
                          className="hover:bg-blue-50 hover:text-blue-600"
                          data-testid={`edit-expense-${expense.id}`}
                        >
                          <Edit3 className="w-4 h-4" />
                        </Button>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteExpense(expense.id, expense.title)}
                          className="hover:bg-red-50 hover:text-red-600"
                          data-testid={`delete-expense-${expense.id}`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Expense Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Expense</DialogTitle>
            <DialogDescription>
              Update expense information
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleUpdateExpense} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="editTitle">Expense Title</Label>
              <Input
                id="editTitle"
                value={expenseForm.title}
                onChange={(e) => setExpenseForm({...expenseForm, title: e.target.value})}
                required
                data-testid="edit-expense-title-input"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="editCategory">Category</Label>
              <Select 
                value={expenseForm.category} 
                onValueChange={(value) => setExpenseForm({...expenseForm, category: value})}
              >
                <SelectTrigger data-testid="edit-expense-category-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {expenseCategories.map(category => {
                    const Icon = category.icon;
                    return (
                      <SelectItem key={category.value} value={category.value}>
                        <div className="flex items-center gap-2">
                          <div className={`w-4 h-4 rounded ${category.color} flex items-center justify-center`}>
                            <Icon className="w-2.5 h-2.5 text-white" />
                          </div>
                          {category.label}
                        </div>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="editAmount">Amount (₹)</Label>
              <Input
                id="editAmount"
                type="number"
                value={expenseForm.amount}
                onChange={(e) => setExpenseForm({...expenseForm, amount: parseFloat(e.target.value) || 0})}
                required
                data-testid="edit-expense-amount-input"
              />
            </div>
            
            <div className="space-y-2">
              <Label>Expense Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !expenseForm.expense_date && "text-muted-foreground"
                    )}
                    data-testid="edit-expense-date-picker"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {expenseForm.expense_date ? format(expenseForm.expense_date, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={expenseForm.expense_date}
                    onSelect={(date) => setExpenseForm({...expenseForm, expense_date: date})}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="editDescription">Description</Label>
              <Textarea
                id="editDescription"
                value={expenseForm.description}
                onChange={(e) => setExpenseForm({...expenseForm, description: e.target.value})}
                data-testid="edit-expense-description-input"
              />
            </div>
            
            <div className="flex space-x-2 pt-4">
              <Button 
                type="submit" 
                className="flex-1 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
                data-testid="update-expense-btn"
              >
                Update Expense
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowEditDialog(false)}
                data-testid="cancel-edit-expense-btn"
              >
                Cancel
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default ExpenseManagement;