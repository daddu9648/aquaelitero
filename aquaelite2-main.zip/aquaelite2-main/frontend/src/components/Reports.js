import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../App';
import axios from 'axios';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { 
  FileText, 
  Download, 
  Calendar as CalendarIcon,
  TrendingUp,
  IndianRupee,
  Package,
  Users,
  Eye,
  Archive,
  Search,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import * as XLSX from 'xlsx';

function Reports() {
  const { API } = useContext(AuthContext);
  const [reportData, setReportData] = useState({
    daily: { 
      orders: 0, 
      revenue: 0, 
      expenses: 0, 
      profit: 0,
      jars_delivered: 0,
      empty_jars_collected: 0,
      missing_jars: 0,
      damaged_jars: 0
    },
    monthly: { 
      orders: 0, 
      revenue: 0, 
      expenses: 0, 
      profit: 0,
      jars_delivered: 0,
      empty_jars_collected: 0,
      missing_jars: 0,
      damaged_jars: 0
    }
  });
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [reportType, setReportType] = useState('daily');
  const [loading, setLoading] = useState(true);
  // Customer Balance Reports removed as requested
  const [showCustomerDetails, setShowCustomerDetails] = useState(false);
  const [customers, setCustomers] = useState([]);
  
  // Event Order Reports State
  const [eventOrderReports, setEventOrderReports] = useState({
    daily_reports: [],
    total_stats: {}
  });
  const [eventReportLoading, setEventReportLoading] = useState(false);
  const [eventStartDate, setEventStartDate] = useState(() => {
    const date = new Date();
    date.setDate(date.getDate() - 30); // Last 30 days
    return date;
  });
  const [eventEndDate, setEventEndDate] = useState(new Date());
  const [eventStatus, setEventStatus] = useState('all');

  // Customer Management Reports State
  const [customerReports, setCustomerReports] = useState({
    daily_reports: [],
    total_stats: {}
  });
  const [customerReportLoading, setCustomerReportLoading] = useState(false);
  const [customerStartDate, setCustomerStartDate] = useState(() => {
    const date = new Date();
    date.setDate(1); // First day of current month
    return date;
  });
  const [customerEndDate, setCustomerEndDate] = useState(new Date());
  const [customerReportType, setCustomerReportType] = useState('all'); // all, deliveries, payments, empty_jars
  
  // Additional state for new report sections
  const [customerManagementReports, setCustomerManagementReports] = useState({
    daily_reports: [],
    total_stats: {}
  });
  const [customerReportDate, setCustomerReportDate] = useState(new Date());

  // Financial Summary State
  const [financialSummary, setFinancialSummary] = useState({
    summary: {}
  });
  const [financialSummaryLoading, setFinancialSummaryLoading] = useState(false);
  const [summaryStartDate, setSummaryStartDate] = useState(() => {
    const date = new Date();
    date.setDate(date.getDate() - 30);
    return date;
  });
  const [summaryEndDate, setSummaryEndDate] = useState(new Date());

  // Archived Events Reports State
  const [archivedEventsData, setArchivedEventsData] = useState(null);
  const [archiveFilters, setArchiveFilters] = useState({
    month: 'all',
    year: 'all'
  });

  // Payment Reconciliation Reports State
  const [paymentReconReports, setPaymentReconReports] = useState({
    payments: [],
    summary: {}
  });
  const [paymentReconLoading, setPaymentReconLoading] = useState(false);
  const [paymentReconStartDate, setPaymentReconStartDate] = useState(() => {
    const date = new Date();
    date.setDate(date.getDate() - 30); // Last 30 days
    return date;
  });
  const [paymentReconEndDate, setPaymentReconEndDate] = useState(new Date());
  const [paymentReconStatus, setPaymentReconStatus] = useState('all');

  // Expense Reports State
  const [expenseReports, setExpenseReports] = useState({
    expenses: [],
    summary: {}
  });
  const [expenseReportLoading, setExpenseReportLoading] = useState(false);
  const [expenseStartDate, setExpenseStartDate] = useState(() => {
    const date = new Date();
    date.setDate(date.getDate() - 30); // Last 30 days
    return date;
  });
  const [expenseEndDate, setExpenseEndDate] = useState(new Date());
  const [expenseCategory, setExpenseCategory] = useState('all');

  const fetchReportData = async (signal) => {
    try {
      setLoading(true);
      // For now, using dashboard stats - can be enhanced later
      const response = await axios.get(`${API}/dashboard/stats`, { 
        signal,
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      });
      const stats = response.data;
      
      setReportData({
        daily: {
          orders: stats.total_orders_today || 0,
          revenue: stats.total_revenue_today || 0,
          expenses: stats.total_expenses_today || 0,
          profit: stats.profit_today || 0,
          jars_delivered: stats.jars_delivered_today || 0,
          empty_jars_collected: stats.empty_jars_collected_today || 0,
          missing_jars: stats.missing_jars_today || 0,
          damaged_jars: stats.damaged_jars_today || 0
        },
        monthly: {
          orders: (stats.total_orders_today || 0) * 30, // Mock monthly data
          revenue: (stats.total_revenue_today || 0) * 30,
          expenses: (stats.total_expenses_today || 0) * 30,
          profit: (stats.profit_today || 0) * 30,
          jars_delivered: (stats.jars_delivered_today || 0) * 30,
          empty_jars_collected: (stats.empty_jars_collected_today || 0) * 30,
          missing_jars: (stats.missing_jars_today || 0) * 30,
          damaged_jars: (stats.damaged_jars_today || 0) * 30
        }
      });
    } catch (error) {
      if (error.name !== 'AbortError') {
        console.error('Error fetching report data:', error);
        // Set default empty data instead of showing error
        setReportData({
          daily: {
            orders: 0, revenue: 0, expenses: 0, profit: 0,
            jars_delivered: 0, empty_jars_collected: 0, missing_jars: 0, damaged_jars: 0
          },
          monthly: {
            orders: 0, revenue: 0, expenses: 0, profit: 0,
            jars_delivered: 0, empty_jars_collected: 0, missing_jars: 0, damaged_jars: 0
          }
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const fetchCustomerManagementReports = async (signal) => {
    try {
      // Create a proper date range - start from 7 days ago to selected date
      const endDate = new Date(customerReportDate);
      endDate.setHours(23, 59, 59, 999); // End of selected day
      
      const startDate = new Date(customerReportDate);
      startDate.setDate(startDate.getDate() - 6); // 7 days total (including selected day)
      startDate.setHours(0, 0, 0, 0); // Start of day
      
      const params = new URLSearchParams({
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString()
      });
      
      if (customerReportType !== 'all') {
        params.append('type', customerReportType);
      }
      
      const response = await axios.get(`${API}/reports/customer-management?${params}`, { 
        signal,
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      });
      setCustomerManagementReports(response.data);
    } catch (error) {
      if (error.name !== 'AbortError') {
        console.error('Error fetching customer management reports:', error);
        // Set empty data instead of showing error
        setCustomerManagementReports({
          daily_reports: [],
          total_stats: {
            total_deliveries: 0,
            total_payments: 0,
            active_customers: 0
          }
        });
      }
    }
  };

  const fetchCustomers = async () => {
    try {
      const response = await axios.get(`${API}/customers`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      });
      setCustomers(response.data);
    } catch (error) {
      console.error('Error fetching customers:', error);
      // Set empty array instead of showing error
      setCustomers([]);
    }
  };

  const fetchFinancialSummary = async () => {
    setFinancialSummaryLoading(true);
    try {
      const params = new URLSearchParams({
        start_date: summaryStartDate.toISOString(),
        end_date: summaryEndDate.toISOString()
      });
      
      const response = await axios.get(`${API}/reports/financial-summary?${params}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      });
      setFinancialSummary(response.data);
    } catch (error) {
      console.error('Error fetching financial summary:', error);
      toast.error('Failed to fetch financial summary');
      setFinancialSummary({ summary: {} });
    } finally {
      setFinancialSummaryLoading(false);
    }
  };

  const fetchPaymentReconReports = async () => {
    setPaymentReconLoading(true);
    try {
      const params = new URLSearchParams({
        start_date: paymentReconStartDate.toISOString(),
        end_date: paymentReconEndDate.toISOString(),
        status: paymentReconStatus
      });
      
      const response = await axios.get(`${API}/reports/payment-reconciliation?${params}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      });
      setPaymentReconReports(response.data);
    } catch (error) {
      console.error('Error fetching payment reconciliation reports:', error);
      toast.error('Failed to fetch payment reconciliation reports');
      setPaymentReconReports({
        payments: [],
        summary: {}
      });
    } finally {
      setPaymentReconLoading(false);
    }
  };

  const fetchExpenseReports = async () => {
    setExpenseReportLoading(true);
    try {
      const params = new URLSearchParams({
        start_date: expenseStartDate.toISOString(),
        end_date: expenseEndDate.toISOString(),
        category: expenseCategory
      });
      
      const response = await axios.get(`${API}/reports/expenses?${params}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      });
      setExpenseReports(response.data);
    } catch (error) {
      console.error('Error fetching expense reports:', error);
      toast.error('Failed to fetch expense reports');
      setExpenseReports({
        expenses: [],
        summary: {}
      });
    } finally {
      setExpenseReportLoading(false);
    }
  };

  useEffect(() => {
    const abortController = new AbortController();
    const signal = abortController.signal;
    
    fetchReportData(signal);
    fetchCustomerManagementReports(signal);
    fetchCustomers();
    
    return () => {
      abortController.abort();
    };
  }, [selectedDate, reportType, customerReportDate, customerReportType]);

  // useEffect for financial summary
  useEffect(() => {
    fetchFinancialSummary();
  }, [summaryStartDate, summaryEndDate]);

  // Separate useEffect for event order reports
  useEffect(() => {
    const abortController = new AbortController();
    const signal = abortController.signal;
    
    fetchEventOrderReports(signal);
    
    return () => {
      abortController.abort();
    };
  }, [eventStartDate, eventEndDate, eventStatus]);

  // Separate useEffect for customer reports  
  useEffect(() => {
    const abortController = new AbortController();
    const signal = abortController.signal;
    
    fetchCustomerReports(signal);
    
    return () => {
      abortController.abort();
    };
  }, [customerStartDate, customerEndDate, customerReportType]);

  const fetchEventOrderReports = async (signal) => {
    setEventReportLoading(true);
    try {
      const params = new URLSearchParams({
        start_date: eventStartDate.toISOString(),
        end_date: eventEndDate.toISOString()
      });
      
      if (eventStatus !== 'all') {
        params.append('status', eventStatus);
      }
      
      const response = await axios.get(`${API}/reports/event-orders?${params}`, { 
        signal,
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      });
      setEventOrderReports(response.data);
    } catch (error) {
      if (error.name !== 'AbortError') {
        console.error('Error fetching event order reports:', error);
        // Set empty data instead of showing error
        setEventOrderReports({
          daily_reports: [],
          total_stats: {
            total_events: 0,
            total_revenue: 0,
            completed_events: 0,
            cancelled_events: 0
          }
        });
      }
    } finally {
      setEventReportLoading(false);
    }
  };

  const fetchCustomerReports = async (signal) => {
    setCustomerReportLoading(true);
    try {
      const params = new URLSearchParams({
        start_date: customerStartDate.toISOString(),
        end_date: customerEndDate.toISOString()
      });
      
      if (customerReportType !== 'all') {
        params.append('type', customerReportType);
      }
      
      const response = await axios.get(`${API}/reports/customer-management?${params}`, { 
        signal,
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      });
      setCustomerReports(response.data);
    } catch (error) {
      if (error.name !== 'AbortError') {
        console.error('Error fetching customer reports:', error);
        // Set empty data instead of showing error
        setCustomerReports({
          daily_reports: [],
          total_stats: {
            total_deliveries: 0,
            total_payments: 0,
            active_customers: 0
          }
        });
      }
    } finally {
      setCustomerReportLoading(false);
    }
  };

  const handleCustomerReportExport = async (format) => {
    try {
      setCustomerReportLoading(true);
      const params = new URLSearchParams({
        start_date: customerStartDate.toISOString(),
        end_date: customerEndDate.toISOString(),
        format: format
      });
      
      if (customerReportType !== 'all') {
        params.append('type', customerReportType);
      }
      
      const response = await axios.get(`${API}/reports/customer-management/export?${params}`, {
        responseType: 'blob'
      });
      
      const filename = format === 'excel'
        ? `customer_management_report_${customerStartDate.toISOString().split('T')[0]}_${customerEndDate.toISOString().split('T')[0]}.xlsx`
        : `customer_management_report_${customerStartDate.toISOString().split('T')[0]}_${customerEndDate.toISOString().split('T')[0]}.pdf`;
      
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      
      toast.success(`Customer management ${format.toUpperCase()} report downloaded!`);
    } catch (error) {
      console.error('Error downloading customer report:', error);
      toast.error(`Failed to download ${format} report`);
    } finally {
      setCustomerReportLoading(false);
    }
  };

  // handleCustomerBalanceDownload function removed as requested

  const handleCustomerManagementExport = async (format) => {
    try {
      // Create a proper date range - start from 7 days ago to selected date
      const endDate = new Date(customerReportDate);
      endDate.setHours(23, 59, 59, 999); // End of selected day
      
      const startDate = new Date(customerReportDate);
      startDate.setDate(startDate.getDate() - 6); // 7 days total (including selected day)
      startDate.setHours(0, 0, 0, 0); // Start of day
      
      const params = new URLSearchParams({
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
        format: format
      });
      
      if (customerReportType !== 'all') {
        params.append('type', customerReportType);
      }
      
      const response = await axios.get(`${API}/reports/customer-management/export?${params}`, {
        responseType: 'blob'
      });
      
      const filename = format === 'excel'
        ? `customer_management_report_${customerReportDate.toISOString().split('T')[0]}.xlsx`
        : `customer_management_report_${customerReportDate.toISOString().split('T')[0]}.pdf`;
      
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      
      toast.success(`Customer management ${format.toUpperCase()} report downloaded!`);
    } catch (error) {
      console.error('Error downloading customer management report:', error);
      toast.error(`Failed to download ${format} report`);
    }
  };

  const handleDownloadPDF = () => {
    window.print();
    toast.success('PDF report ready!');
  };

  const handleDownloadExcel = () => {
    const data = [
      ['AquaElite Report', reportType.toUpperCase()],
      ['Date', format(selectedDate, 'PPP')],
      [''],
      ['Metric', 'Value'],
      ['Orders', currentReport.orders],
      ['Revenue', currentReport.revenue],
      ['Expenses', currentReport.expenses],
      ['Profit', currentReport.profit],
      ['Jars Delivered', currentReport.jars_delivered || 0],
      ['Empty Jars Collected', currentReport.empty_jars_collected || 0],
      ['Missing Jars', currentReport.missing_jars || 0]
    ];
    
    const ws = XLSX.utils.aoa_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Report');
    XLSX.writeFile(wb, `AquaElite-${reportType}-${format(selectedDate, 'yyyy-MM-dd')}.xlsx`);
    toast.success('Excel report downloaded!');
  };

  // fetchCustomerBalanceReports function removed as requested

  // handlePrintCustomerReport and handleDownloadCustomerExcel functions removed as requested

  const handleEventReportExport = async (format) => {
    try {
      const params = new URLSearchParams({
        format: format,
        start_date: eventStartDate.toISOString(),
        end_date: eventEndDate.toISOString()
      });
      
      if (eventStatus !== 'all') {
        params.append('status', eventStatus);
      }
      
      const response = await fetch(`${API}/reports/event-orders/export?${params}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (!response.ok) throw new Error('Export failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      
      const filename = format === 'excel' 
        ? `event_orders_${eventStartDate.toISOString().split('T')[0]}_${eventEndDate.toISOString().split('T')[0]}.xlsx`
        : `event_orders_${eventStartDate.toISOString().split('T')[0]}_${eventEndDate.toISOString().split('T')[0]}.pdf`;
      
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      toast.success(`${format.toUpperCase()} report downloaded successfully`);
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export report');
    }
  };

  const handleFinancialSummaryExport = async (format) => {
    try {
      const params = new URLSearchParams({
        format: format,
        start_date: summaryStartDate.toISOString(),
        end_date: summaryEndDate.toISOString()
      });
      
      const response = await fetch(`${API}/reports/financial-summary/export?${params}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (!response.ok) throw new Error('Export failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      
      const filename = format === 'excel' 
        ? `financial_summary_${summaryStartDate.toISOString().split('T')[0]}_${summaryEndDate.toISOString().split('T')[0]}.xlsx`
        : `financial_summary_${summaryStartDate.toISOString().split('T')[0]}_${summaryEndDate.toISOString().split('T')[0]}.pdf`;
      
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      toast.success(`${format.toUpperCase()} report downloaded successfully`);
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export report');
    }
  };

  const handlePaymentReconExport = async (format) => {
    try {
      const params = new URLSearchParams({
        format: format,
        start_date: paymentReconStartDate.toISOString(),
        end_date: paymentReconEndDate.toISOString(),
        status: paymentReconStatus
      });
      
      const response = await fetch(`${API}/reports/payment-reconciliation/export?${params}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (!response.ok) throw new Error('Export failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      
      const filename = format === 'excel' 
        ? `payment_reconciliation_${paymentReconStartDate.toISOString().split('T')[0]}_${paymentReconEndDate.toISOString().split('T')[0]}.xlsx`
        : `payment_reconciliation_${paymentReconStartDate.toISOString().split('T')[0]}_${paymentReconEndDate.toISOString().split('T')[0]}.pdf`;
      
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      toast.success(`${format.toUpperCase()} payment reconciliation report downloaded successfully`);
    } catch (error) {
      console.error('Payment recon export error:', error);
      toast.error('Failed to export payment reconciliation report');
    }
  };

  const handleExpenseExport = async (format) => {
    try {
      const params = new URLSearchParams({
        format: format,
        start_date: expenseStartDate.toISOString(),
        end_date: expenseEndDate.toISOString(),
        category: expenseCategory
      });
      
      const response = await fetch(`${API}/reports/expenses/export?${params}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (!response.ok) throw new Error('Export failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      
      const filename = format === 'excel' 
        ? `expenses_${expenseStartDate.toISOString().split('T')[0]}_${expenseEndDate.toISOString().split('T')[0]}.xlsx`
        : `expenses_${expenseStartDate.toISOString().split('T')[0]}_${expenseEndDate.toISOString().split('T')[0]}.pdf`;
      
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      toast.success(`${format.toUpperCase()} expense report downloaded successfully`);
    } catch (error) {
      console.error('Expense export error:', error);
      toast.error('Failed to export expense report');
    }
  };

  const fetchArchivedEventsReport = async () => {
    try {
      const params = new URLSearchParams();
      if (archiveFilters.month && archiveFilters.month !== 'all') params.append('month', archiveFilters.month);
      if (archiveFilters.year && archiveFilters.year !== 'all') params.append('year', archiveFilters.year);
      
      const response = await axios.get(`${API}/reports/archived-events?${params}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      });
      setArchivedEventsData(response.data);
      toast.success('Archived events report loaded successfully');
    } catch (error) {
      console.error('Error fetching archived events:', error);
      toast.error('Failed to load archived events report');
      setArchivedEventsData({
        summary: {
          total_events: 0,
          completed_events: 0,
          cancelled_events: 0,
          completion_rate: 0
        },
        events: []
      });
    }
  };

  const handleArchivedEventsExport = async (format) => {
    try {
      const params = new URLSearchParams({
        format: format
      });
      if (archiveFilters.month && archiveFilters.month !== 'all') params.append('month', archiveFilters.month);
      if (archiveFilters.year && archiveFilters.year !== 'all') params.append('year', archiveFilters.year);
      
      const response = await fetch(`${API}/reports/archived-events/export?${params}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (!response.ok) throw new Error('Export failed');
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      
      const filename = format === 'excel' 
        ? `archived_events_${archiveFilters.month || 'all'}_${archiveFilters.year || 'all'}.xlsx`
        : `archived_events_${archiveFilters.month || 'all'}_${archiveFilters.year || 'all'}.pdf`;
      
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      toast.success(`${format.toUpperCase()} archived events report downloaded successfully`);
    } catch (error) {
      console.error('Archived events export error:', error);
      toast.error('Failed to export archived events report');
    }
  };

  const handleManualArchive = async () => {
    try {
      const response = await axios.post(`${API}/event-orders/archive`, {}, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      });
      toast.success('Manual archive process completed successfully');
      // Refresh the archived events data
      fetchArchivedEventsReport();
    } catch (error) {
      console.error('Manual archive error:', error);
      toast.error('Failed to complete manual archive process');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const currentReport = reportData[reportType];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-gray-200 pb-4">
        <h1 className="text-3xl font-bold text-gray-900" data-testid="reports-title">
          📊 Reports & Analytics
        </h1>
        <p className="text-gray-600 mt-1">
          Generate and download comprehensive business reports
        </p>
      </div>

      {/* Available Reports List */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-800">Available Reports</h2>
          <p className="text-sm text-gray-600">Select a report type to generate and download</p>
        </div>
        
        <div className="divide-y divide-gray-200">
          {/* Daily/Monthly Business Reports */}
          <div className="px-6 py-5 hover:bg-gray-50 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <TrendingUp className="w-8 h-8 text-blue-600 bg-blue-100 p-1.5 rounded-lg" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-medium text-gray-900">Daily & Monthly Business Reports</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Comprehensive business analytics including orders, revenue, expenses, and jar tracking
                  </p>
                  <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                    <span className="flex items-center">
                      <Package className="w-3 h-3 mr-1" />
                      Orders: {currentReport.orders}
                    </span>
                    <span className="flex items-center">
                      <IndianRupee className="w-3 h-3 mr-1" />
                      Revenue: ₹{currentReport.revenue.toFixed(2)}
                    </span>
                    <span className="flex items-center">
                      <Users className="w-3 h-3 mr-1" />
                      Profit: ₹{currentReport.profit.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="flex items-center space-x-2 mb-2 sm:mb-0">
                  <Select value={reportType} onValueChange={setReportType}>
                    <SelectTrigger className="w-24" data-testid="report-type-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" size="sm">
                        <CalendarIcon className="w-4 h-4 mr-1" />
                        {format(selectedDate, "MMM dd")}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={selectedDate}
                        onSelect={setSelectedDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div className="flex space-x-1">
                  <Button 
                    onClick={handleDownloadPDF}
                    className="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 text-xs"
                    size="sm"
                  >
                    <FileText className="w-3 h-3 mr-1" />
                    PDF
                  </Button>
                  <Button 
                    onClick={handleDownloadExcel}
                    className="bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 text-xs"
                    size="sm"
                  >
                    <Download className="w-3 h-3 mr-1" />
                    Excel
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Customer Balance Reports section removed as requested */}

          {/* Customer Management Reports */}
          <div className="px-6 py-5 hover:bg-gray-50 transition-colors">
            <div className="flex items-center justify-between">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <Package className="w-8 h-8 text-orange-600 bg-orange-100 p-1.5 rounded-lg" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-medium text-gray-900">Customer Management Reports</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Comprehensive customer activity including deliveries, payments, and jar collections
                  </p>
                  <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                    <span className="flex items-center">
                      <Package className="w-3 h-3 mr-1" />
                      Deliveries: {customerManagementReports.total_stats?.total_deliveries || 0}
                    </span>
                    <span className="flex items-center">
                      <IndianRupee className="w-3 h-3 mr-1" />
                      Payments: ₹{customerManagementReports.total_stats?.total_payments?.toFixed(2) || '0.00'}
                    </span>
                    <span className="flex items-center">
                      <Users className="w-3 h-3 mr-1" />
                      Active: {customerManagementReports.total_stats?.active_customers || 0}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 mt-3">
                    <Select value={customerReportType} onValueChange={setCustomerReportType}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" size="sm">
                          <CalendarIcon className="w-4 h-4 mr-1" />
                          {format(customerReportDate, "MMM dd")}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={customerReportDate}
                          onSelect={setCustomerReportDate}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <Button 
                      onClick={() => setShowCustomerDetails(!showCustomerDetails)}
                      variant="outline"
                      size="sm"
                      className="ml-2"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      {showCustomerDetails ? 'Hide' : 'View'} Details
                    </Button>
                  </div>
                </div>
              </div>
              <div className="flex space-x-1">
                <Button 
                  onClick={() => handleCustomerManagementExport('pdf')}
                  className="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 text-xs"
                  size="sm"
                >
                  <FileText className="w-3 h-3 mr-1" />
                  PDF
                </Button>
                <Button 
                  onClick={() => handleCustomerManagementExport('excel')}
                  className="bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 text-xs"
                  size="sm"
                >
                  <Download className="w-3 h-3 mr-1" />
                  Excel
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Report Controls */}
      <Card className="shadow-soft">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium">Report Type:</label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger className="w-32" data-testid="report-type-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium">Date:</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-48 justify-start text-left font-normal",
                      !selectedDate && "text-muted-foreground"
                    )}
                    data-testid="report-date-picker"
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {selectedDate ? format(selectedDate, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Report Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Orders</p>
                <p className="text-2xl font-bold text-blue-600" data-testid="report-orders-stat">
                  {currentReport.orders}
                </p>
              </div>
              <Package className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Revenue</p>
                <p className="text-2xl font-bold text-green-600" data-testid="report-revenue-stat">
                  ₹{currentReport.revenue.toFixed(2)}
                </p>
              </div>
              <IndianRupee className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Expenses</p>
                <p className="text-2xl font-bold text-red-600" data-testid="report-expenses-stat">
                  ₹{currentReport.expenses.toFixed(2)}
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Profit</p>
                <p className={`text-2xl font-bold ${currentReport.profit >= 0 ? 'text-green-600' : 'text-red-600'}`} data-testid="report-profit-stat">
                  ₹{currentReport.profit.toFixed(2)}
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Report Details */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle>
            {reportType.charAt(0).toUpperCase() + reportType.slice(1)} Report Details
          </CardTitle>
          <CardDescription>
            Detailed breakdown for {format(selectedDate, "PPP")}
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="space-y-2">
                <h4 className="font-medium text-gray-900">Financial Summary</h4>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span>Total Revenue:</span>
                    <span className="font-medium text-green-600">₹{currentReport.revenue.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Expenses:</span>
                    <span className="font-medium text-red-600">₹{currentReport.expenses.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between border-t pt-1">
                    <span className="font-medium">Net Profit:</span>
                    <span className={`font-bold ${currentReport.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      ₹{currentReport.profit.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium text-gray-900">Operations Summary</h4>
                <div className="space-y-1">
                  <div className="flex justify-between">
                    <span>Total Orders:</span>
                    <span className="font-medium">{currentReport.orders}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Profit Margin:</span>
                    <span className="font-medium">
                      {currentReport.revenue > 0 ? ((currentReport.profit / currentReport.revenue) * 100).toFixed(1) : 0}%
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="text-center pt-4 border-t">
              <p className="text-sm text-gray-600">
                Report generated on {format(new Date(), 'PPP')} by AquaElite System
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Customer Balance Reports section removed as requested */}

      {/* Event Order Reports */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Package className="w-5 h-5" />
            <span>Event Order Reports</span>
          </CardTitle>
          <CardDescription>
            Download monthly/date-wise event order reports in PDF or Excel format
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <div className="space-y-6">
            {/* Controls */}
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
              <div className="flex flex-wrap gap-4 items-center">
                <div className="flex items-center space-x-2">
                  <label className="text-sm font-medium">From:</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-40">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {format(eventStartDate, "MMM dd, yyyy")}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={eventStartDate}
                        onSelect={(date) => {
                          setEventStartDate(date);
                          // Auto-refresh data when date changes
                          setTimeout(fetchEventOrderReports, 100);
                        }}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="flex items-center space-x-2">
                  <label className="text-sm font-medium">To:</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-40">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {format(eventEndDate, "MMM dd, yyyy")}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={eventEndDate}
                        onSelect={(date) => {
                          setEventEndDate(date);
                          // Auto-refresh data when date changes
                          setTimeout(fetchEventOrderReports, 100);
                        }}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="flex items-center space-x-2">
                  <label className="text-sm font-medium">Status:</label>
                  <Select value={eventStatus} onValueChange={(value) => {
                    setEventStatus(value);
                    setTimeout(fetchEventOrderReports, 100);
                  }}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="cancelled">Cancelled</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex space-x-4">
                <Button
                  onClick={() => handleEventReportExport('pdf')}
                  disabled={eventReportLoading}
                  className="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 text-xs"
                  size="sm"
                >
                  <FileText className="w-3 h-3 mr-1" />
                  PDF
                </Button>
                
                <Button 
                  onClick={() => handleEventReportExport('excel')}
                  disabled={eventReportLoading}
                  className="bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 text-xs"
                  size="sm"
                >
                  <Download className="w-3 h-3 mr-1" />
                  Excel
                </Button>
              </div>
            </div>

            {/* Summary Stats - Preview of Report Data */}
            <div className="bg-gray-50 p-6 rounded-lg">
              <h4 className="font-semibold mb-4 text-center text-gray-700">Report Preview - Selected Date Range</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div className="bg-white p-4 rounded-lg shadow-sm text-center border-l-4 border-blue-500">
                  <p className="text-3xl font-bold text-blue-600">
                    {eventOrderReports.total_stats?.total_events || 0}
                  </p>
                  <p className="text-sm text-gray-600 font-medium">Total Events</p>
                </div>
                
                <div className="bg-white p-4 rounded-lg shadow-sm text-center border-l-4 border-green-500">
                  <p className="text-3xl font-bold text-green-600">
                    ₹{eventOrderReports.total_stats?.total_revenue?.toFixed(2) || '0.00'}
                  </p>
                  <p className="text-sm text-gray-600 font-medium">Total Revenue</p>
                </div>
                
                <div className="bg-white p-4 rounded-lg shadow-sm text-center border-l-4 border-red-500">
                  <p className="text-3xl font-bold text-red-600">
                    {eventOrderReports.total_stats?.cancelled_events || 0}
                  </p>
                  <p className="text-sm text-gray-600 font-medium">Cancelled Events</p>
                </div>
                
                <div className="bg-white p-4 rounded-lg shadow-sm text-center border-l-4 border-purple-500">
                  <p className="text-3xl font-bold text-purple-600">
                    {eventOrderReports.total_stats?.completed_events || 0}
                  </p>
                  <p className="text-sm text-gray-600 font-medium">Completed Events</p>
                </div>
              </div>
            </div>

            {/* Simple Export Message */}
            <div className="text-center py-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <div className="flex items-center justify-center mb-4">
                  <FileText className="w-12 h-12 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Export Event Order Reports
                </h3>
                <p className="text-gray-600 mb-4">
                  Select date range and status, then download your complete event order report in PDF or Excel format.
                </p>
                <div className="text-sm text-gray-500">
                  Reports include all event details, revenue summary, and daily breakdowns for the selected period.
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Customer Management Reports */}
      <Card className="w-full shadow-lg">
        <CardHeader className="bg-gradient-to-r from-purple-50 to-indigo-50 border-b border-purple-100">
          <CardTitle className="flex items-center space-x-3">
            <Users className="w-6 h-6 text-purple-600" />
            <span>Customer Management Reports</span>
          </CardTitle>
          <CardDescription>
            Download daily/monthly customer activity reports in PDF or Excel format
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          <div className="space-y-6">
            {/* Date Range and Filters */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {/* Start Date */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Start Date</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {customerStartDate ? format(customerStartDate, "PPP") : "Pick start date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={customerStartDate}
                      onSelect={(date) => {
                        if (date) {
                          setCustomerStartDate(date);
                          setTimeout(fetchCustomerReports, 100);
                        }
                      }}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* End Date */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">End Date</label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {customerEndDate ? format(customerEndDate, "PPP") : "Pick end date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={customerEndDate}
                      onSelect={(date) => {
                        if (date) {
                          setCustomerEndDate(date);
                          setTimeout(fetchCustomerReports, 100);
                        }
                      }}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Report Type Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Report Type</label>
                <Select 
                  value={customerReportType} 
                  onValueChange={(value) => {
                    setCustomerReportType(value);
                    setTimeout(fetchCustomerReports, 100);
                  }}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Activities</SelectItem>
                    <SelectItem value="deliveries">Deliveries Only</SelectItem>
                    <SelectItem value="payments">Payments Only</SelectItem>
                    <SelectItem value="empty_jars">Empty Jars Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Download Buttons */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Download Reports</label>
                <div className="flex space-x-4">
                  <Button
                    onClick={() => handleCustomerReportExport('pdf')}
                    disabled={customerReportLoading}
                    className="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 text-xs"
                    size="sm"
                  >
                    <FileText className="w-3 h-3 mr-1" />
                    PDF
                  </Button>
                  <Button
                    onClick={() => handleCustomerReportExport('excel')}
                    disabled={customerReportLoading}
                    className="bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 text-xs"
                    size="sm"
                  >
                    <Download className="w-3 h-3 mr-1" />
                    Excel
                  </Button>
                </div>
              </div>
            </div>

            {/* Summary Stats - Preview of Customer Report Data */}
            <div className="bg-gray-50 p-6 rounded-lg">
              <h4 className="font-semibold mb-4 text-center text-gray-700">Customer Activity Preview - Selected Date Range</h4>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="bg-white p-4 rounded-lg shadow-sm text-center border-l-4 border-purple-500">
                  <p className="text-2xl font-bold text-purple-600">
                    {customerReports.total_stats?.total_deliveries || 0}
                  </p>
                  <p className="text-xs text-gray-600 font-medium">Total Deliveries</p>
                </div>
                
                <div className="bg-white p-4 rounded-lg shadow-sm text-center border-l-4 border-green-500">
                  <p className="text-2xl font-bold text-green-600">
                    ₹{customerReports.total_stats?.total_payments?.toFixed(2) || '0.00'}
                  </p>
                  <p className="text-xs text-gray-600 font-medium">Total Payments</p>
                </div>
                
                <div className="bg-white p-4 rounded-lg shadow-sm text-center border-l-4 border-orange-500">
                  <p className="text-2xl font-bold text-orange-600">
                    {customerReports.total_stats?.total_jars_collected || 0}
                  </p>
                  <p className="text-xs text-gray-600 font-medium">Jars Collected</p>
                </div>
                
                <div className="bg-white p-4 rounded-lg shadow-sm text-center border-l-4 border-red-500">
                  <p className="text-2xl font-bold text-red-600">
                    {customerReports.total_stats?.uncollected_empty_jars || 0}
                  </p>
                  <p className="text-xs text-gray-600 font-medium">Uncollected Jars</p>
                </div>
                
                <div className="bg-white p-4 rounded-lg shadow-sm text-center border-l-4 border-blue-500">
                  <p className="text-2xl font-bold text-blue-600">
                    {customerReports.total_stats?.active_customers || 0}
                  </p>
                  <p className="text-xs text-gray-600 font-medium">Active Customers</p>
                </div>
              </div>
            </div>

            {/* Simple Export Message */}
            <div className="text-center py-6">
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-6">
                <div className="flex items-center justify-center mb-4">
                  <Users className="w-12 h-12 text-purple-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Export Customer Management Reports
                </h3>
                <p className="text-gray-600 mb-4">
                  Select date range and activity type, then download your complete customer activity report in PDF or Excel format.
                </p>
                <div className="text-sm text-gray-500">
                  Reports include customer details, delivery history, payment records, empty jar collections, and customer-wise uncollected empty jar list for the selected period.
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Customer Management Details View */}
      {showCustomerDetails && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 mt-4">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-800 flex items-center">
              <Users className="w-5 h-5 mr-2 text-blue-600" />
              Customer Management Activities
            </h3>
            <p className="text-sm text-gray-600 mt-1">
              View and manage recent customer activities from Regular Customer Management
            </p>
          </div>

          <div className="p-6">
            {/* Activity Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-gradient-to-r from-blue-50 to-blue-100 border border-blue-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-blue-800">Recent Deliveries</p>
                    <p className="text-2xl font-bold text-blue-600">
                      {customerManagementReports.total_stats?.total_deliveries || 0}
                    </p>
                  </div>
                  <Package className="w-8 h-8 text-blue-500" />
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-green-50 to-green-100 border border-green-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-green-800">Payments Collected</p>
                    <p className="text-2xl font-bold text-green-600">
                      ₹{(customerManagementReports.total_stats?.total_payments || 0).toFixed(2)}
                    </p>
                  </div>
                  <IndianRupee className="w-8 h-8 text-green-500" />
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-orange-50 to-orange-100 border border-orange-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-orange-800">Empty Jars Collected</p>
                    <p className="text-2xl font-bold text-orange-600">
                      {customerManagementReports.total_stats?.total_jars_collected || 0}
                    </p>
                  </div>
                  <Package className="w-8 h-8 text-orange-500" />
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-purple-50 to-purple-100 border border-purple-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-purple-800">Jars Delivered</p>
                    <p className="text-2xl font-bold text-purple-600">
                      {customerManagementReports.total_stats?.total_jars_delivered || 0}
                    </p>
                  </div>
                  <Package className="w-8 h-8 text-purple-500" />
                </div>
              </div>
            </div>

            {/* Simple Total Jars Delivered count is shown in the statistics cards above */}

            {/* Customer List with Recent Activities */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-md font-semibold text-gray-800">Customer Activity Summary</h4>
                <Button 
                  onClick={() => {
                    fetchCustomers();
                    fetchCustomerManagementReports();
                  }}
                  variant="outline"
                  size="sm"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Refresh Data
                </Button>
              </div>
              
              {customers.length > 0 ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
                  {customers.slice(0, 12).map((customer) => (
                    <div key={customer.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h5 className="font-medium text-gray-900">{customer.name}</h5>
                          <p className="text-sm text-gray-600">{customer.mobile}</p>
                          <p className="text-xs text-gray-500 truncate">{customer.address}</p>
                        </div>
                        <div className={`w-3 h-3 rounded-full ${
                          customer.cash_balance > 100 ? 'bg-red-500' :
                          customer.cash_balance > 0 || customer.empty_jars_balance > 0 ? 'bg-yellow-500' :
                          'bg-green-500'
                        }`} title={
                          customer.cash_balance > 100 ? 'High Balance Due' :
                          customer.cash_balance > 0 || customer.empty_jars_balance > 0 ? 'Pending Items' :
                          'All Clear'
                        }></div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-gray-600">Cash Balance:</span>
                          <span className={`text-xs font-medium ${
                            customer.cash_balance > 0 ? 'text-red-600' : 'text-green-600'
                          }`}>
                            ₹{customer.cash_balance.toFixed(2)}
                          </span>
                        </div>
                        
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-gray-600">Empty Jars:</span>
                          <span className={`text-xs font-medium ${
                            customer.empty_jars_balance > 0 ? 'text-orange-600' : 'text-green-600'
                          }`}>
                            {customer.empty_jars_balance} jars
                          </span>
                        </div>
                      </div>
                      
                      <div className="mt-3 pt-3 border-t border-gray-200">
                        <div className="flex space-x-2">
                          <Button 
                            onClick={() => window.open('/order-book', '_blank')}
                            size="sm"
                            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-xs py-1"
                          >
                            Quick Delivery
                          </Button>
                          <Button 
                            onClick={() => window.open('/order-book', '_blank')}
                            size="sm"
                            className="flex-1 bg-green-600 hover:bg-green-700 text-white text-xs py-1"
                          >
                            Collect Payment
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">No customer data available</p>
                  <Button 
                    onClick={fetchCustomers}
                    variant="outline"
                    className="mt-2"
                  >
                    Load Customers
                  </Button>
                </div>
              )}
              
              {customers.length > 12 && (
                <div className="text-center pt-4 border-t border-gray-200">
                  <p className="text-sm text-gray-600 mb-2">
                    Showing 12 of {customers.length} customers
                  </p>
                  <Button 
                    onClick={() => window.open('/order-book', '_blank')}
                    variant="outline"
                  >
                    View All in Customer Management
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Financial Summary Report */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center">
            <TrendingUp className="w-6 h-6 text-green-600 mr-2" />
            <h2 className="text-2xl font-bold text-gray-800">Financial Summary Report</h2>
          </div>
          <Button 
            onClick={fetchFinancialSummary}
            disabled={financialSummaryLoading}
            variant="outline"
          >
            {financialSummaryLoading ? 'Loading...' : 'Refresh Data'}
          </Button>
        </div>

        {/* Date Range Filters */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div>
            <Label>Start Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant={"outline"}
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !summaryStartDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {summaryStartDate ? format(summaryStartDate, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={summaryStartDate}
                  onSelect={setSummaryStartDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div>
            <Label>End Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant={"outline"}
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !summaryEndDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {summaryEndDate ? format(summaryEndDate, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={summaryEndDate}
                  onSelect={setSummaryEndDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex items-end gap-2">
            <Button 
              onClick={() => handleFinancialSummaryExport('pdf')} 
              className="bg-red-600 hover:bg-red-700 text-white flex-1"
            >
              <FileText className="w-4 h-4 mr-2" />
              PDF
            </Button>
            <Button 
              onClick={() => handleFinancialSummaryExport('excel')} 
              className="bg-green-600 hover:bg-green-700 text-white flex-1"
            >
              <Download className="w-4 h-4 mr-2" />
              Excel
            </Button>
          </div>
        </div>

        {/* Summary Stats */}
        {financialSummary.summary && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-lg border border-green-200">
              <h3 className="text-sm font-semibold text-green-800 mb-2">Event Collections</h3>
              <p className="text-3xl font-bold text-green-600">
                ₹{financialSummary.summary?.event_collections?.amount?.toFixed(2) || '0.00'}
              </p>
              <p className="text-sm text-green-700 mt-1">
                {financialSummary.summary?.event_collections?.count || 0} events
              </p>
            </div>

            <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-6 rounded-lg border border-orange-200">
              <h3 className="text-sm font-semibold text-orange-800 mb-2">Advance Forfeited</h3>
              <p className="text-3xl font-bold text-orange-600">
                ₹{financialSummary.summary?.advance_forfeited?.amount?.toFixed(2) || '0.00'}
              </p>
              <p className="text-sm text-orange-700 mt-1">
                {financialSummary.summary?.advance_forfeited?.count || 0} cancelled events
              </p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-lg border border-blue-200">
              <h3 className="text-sm font-semibold text-blue-800 mb-2">Regular Collections</h3>
              <p className="text-3xl font-bold text-blue-600">
                ₹{financialSummary.summary?.regular_collections?.amount?.toFixed(2) || '0.00'}
              </p>
              <p className="text-sm text-blue-700 mt-1">
                {financialSummary.summary?.regular_collections?.count || 0} transactions
              </p>
            </div>

            <div className="bg-gradient-to-br from-red-50 to-red-100 p-6 rounded-lg border border-red-200">
              <h3 className="text-sm font-semibold text-red-800 mb-2">Total Expenses</h3>
              <p className="text-3xl font-bold text-red-600">
                ₹{financialSummary.summary?.expenses?.amount?.toFixed(2) || '0.00'}
              </p>
              <p className="text-sm text-red-700 mt-1">
                {financialSummary.summary?.expenses?.count || 0} expenses
              </p>
            </div>
          </div>
        )}

        {/* Profit Summary */}
        {financialSummary.summary && (
          <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <p className="text-sm text-gray-600">Total Collections</p>
                <p className="text-2xl font-bold text-gray-900">
                  ₹{financialSummary.summary?.total_collections?.toFixed(2) || '0.00'}
                </p>
              </div>
              
              <div>
                <p className="text-sm text-gray-600">Net Profit</p>
                <p className={`text-2xl font-bold ${
                  (financialSummary.summary?.net_profit || 0) >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  ₹{financialSummary.summary?.net_profit?.toFixed(2) || '0.00'}
                </p>
              </div>

              <div>
                <p className="text-sm text-gray-600">Profit Margin</p>
                <p className={`text-2xl font-bold ${
                  (financialSummary.summary?.profit_margin || 0) >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {financialSummary.summary?.profit_margin?.toFixed(2) || '0.00'}%
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Archived Event Orders Reports */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold text-purple-600">Archived Event Orders Reports</CardTitle>
          <CardDescription>
            View and download reports for completed and cancelled event orders archived monthly
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Archive Filters */}
            <div className="flex space-x-4">
              <div className="flex-1">
                <Label>Archive Month</Label>
                <Select value={archiveFilters.month} onValueChange={(value) => setArchiveFilters({...archiveFilters, month: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select month" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Months</SelectItem>
                    <SelectItem value="2025-10">October 2025</SelectItem>
                    <SelectItem value="2025-09">September 2025</SelectItem>
                    <SelectItem value="2025-08">August 2025</SelectItem>
                    <SelectItem value="2025-07">July 2025</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1">
                <Label>Archive Year</Label>
                <Select value={archiveFilters.year} onValueChange={(value) => setArchiveFilters({...archiveFilters, year: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select year" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Years</SelectItem>
                    <SelectItem value="2025">2025</SelectItem>
                    <SelectItem value="2024">2024</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1">
                <Label>&nbsp;</Label>
                <Button 
                  onClick={fetchArchivedEventsReport}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  <Search className="w-4 h-4 mr-2" />
                  Load Archive Report
                </Button>
              </div>
            </div>

            {/* Archive Statistics */}
            {archivedEventsData && (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-purple-50 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-purple-700">Total Events</p>
                      <p className="text-2xl font-bold text-purple-600">{archivedEventsData.summary.total_events}</p>
                    </div>
                    <Archive className="w-8 h-8 text-purple-500" />
                  </div>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-green-700">Completed</p>
                      <p className="text-2xl font-bold text-green-600">{archivedEventsData.summary.completed_events}</p>
                    </div>
                    <CheckCircle className="w-8 h-8 text-green-500" />
                  </div>
                </div>
                <div className="bg-red-50 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-red-700">Cancelled</p>
                      <p className="text-2xl font-bold text-red-600">{archivedEventsData.summary.cancelled_events}</p>
                    </div>
                    <XCircle className="w-8 h-8 text-red-500" />
                  </div>
                </div>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-blue-700">Completion Rate</p>
                      <p className="text-2xl font-bold text-blue-600">{archivedEventsData.summary.completion_rate}%</p>
                    </div>
                    <TrendingUp className="w-8 h-8 text-blue-500" />
                  </div>
                </div>
              </div>
            )}

            {/* Export Buttons */}
            <div className="flex space-x-3">
              <Button 
                onClick={() => handleArchivedEventsExport('pdf')}
                disabled={!archivedEventsData}
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                <FileText className="w-4 h-4 mr-2" />
                PDF
              </Button>
              <Button 
                onClick={() => handleArchivedEventsExport('excel')}
                disabled={!archivedEventsData}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                <Download className="w-4 h-4 mr-2" />
                Excel
              </Button>
              <Button 
                onClick={handleManualArchive}
                className="bg-orange-600 hover:bg-orange-700 text-white"
              >
                <Archive className="w-4 h-4 mr-2" />
                Manual Archive
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Payment Reconciliation Reports */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center">
            <CheckCircle className="w-6 h-6 text-blue-600 mr-2" />
            <h2 className="text-2xl font-bold text-gray-800">Payment Reconciliation Reports</h2>
          </div>
          <Button 
              onClick={fetchPaymentReconReports}
              disabled={paymentReconLoading}
              variant="outline"
            >
              {paymentReconLoading ? 'Loading...' : 'Refresh Data'}
            </Button>
          </div>

          {/* Date Range and Status Filter */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div>
              <Label>Start Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !paymentReconStartDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {paymentReconStartDate ? format(paymentReconStartDate, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={paymentReconStartDate}
                    onSelect={setPaymentReconStartDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div>
              <Label>End Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !paymentReconEndDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {paymentReconEndDate ? format(paymentReconEndDate, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={paymentReconEndDate}
                    onSelect={setPaymentReconEndDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div>
              <Label>Status</Label>
              <Select value={paymentReconStatus} onValueChange={setPaymentReconStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="received_by_admin">Received by Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end gap-2">
              <Button 
                onClick={() => handlePaymentReconExport('pdf')} 
                className="bg-red-600 hover:bg-red-700 text-white flex-1"
              >
                <FileText className="w-4 h-4 mr-2" />
                PDF
              </Button>
              <Button 
                onClick={() => handlePaymentReconExport('excel')} 
                className="bg-green-600 hover:bg-green-700 text-white flex-1"
              >
                <Download className="w-4 h-4 mr-2" />
                Excel
              </Button>
            </div>
          </div>

          {/* Summary Stats */}
          {paymentReconReports.summary && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Total Payments</p>
                <p className="text-2xl font-bold text-blue-600">
                  {paymentReconReports.summary.total_payments || 0}
                </p>
                <p className="text-sm text-gray-500">
                  ₹{paymentReconReports.summary.total_amount?.toFixed(2) || '0.00'}
                </p>
              </div>
              
              <div className="bg-yellow-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Pending</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {paymentReconReports.summary.pending_count || 0}
                </p>
                <p className="text-sm text-gray-500">
                  ₹{paymentReconReports.summary.pending_amount?.toFixed(2) || '0.00'}
                </p>
              </div>
              
              <div className="bg-green-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Received</p>
                <p className="text-2xl font-bold text-green-600">
                  {paymentReconReports.summary.received_count || 0}
                </p>
                <p className="text-sm text-gray-500">
                  ₹{paymentReconReports.summary.received_amount?.toFixed(2) || '0.00'}
                </p>
              </div>

              <div className="bg-purple-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Payment Types</p>
                <p className="text-2xl font-bold text-purple-600">
                  {Object.keys(paymentReconReports.summary.payment_types || {}).length}
                </p>
                <p className="text-sm text-gray-500">Categories</p>
              </div>
            </div>
          )}

          {/* Recent Payments Preview */}
          {paymentReconReports.payments && paymentReconReports.payments.length > 0 && (
            <div className="mt-4">
              <h3 className="font-semibold mb-3">Recent Payment Entries (Top 10)</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full border-collapse border border-gray-300">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="border border-gray-300 px-4 py-2 text-left">Date</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">Customer</th>
                      <th className="border border-gray-300 px-4 py-2 text-right">Amount</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">Type</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">Status</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">Collected By</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paymentReconReports.payments.slice(0, 10).map((payment, idx) => (
                      <tr key={idx} className="hover:bg-gray-50">
                        <td className="border border-gray-300 px-4 py-2">
                          {payment.collected_at ? new Date(payment.collected_at).toLocaleDateString() : 'N/A'}
                        </td>
                        <td className="border border-gray-300 px-4 py-2">{payment.customer_name}</td>
                        <td className="border border-gray-300 px-4 py-2 text-right font-semibold">
                          ₹{payment.amount?.toFixed(2)}
                        </td>
                        <td className="border border-gray-300 px-4 py-2">{payment.payment_type}</td>
                        <td className="border border-gray-300 px-4 py-2">
                          <span className={`px-2 py-1 rounded text-xs ${
                            payment.reconciliation_status === 'received_by_admin' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-yellow-100 text-yellow-800'
                          }`}>
                            {payment.reconciliation_status}
                          </span>
                        </td>
                        <td className="border border-gray-300 px-4 py-2">{payment.collected_by_name}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="text-sm text-gray-600 mt-2">
                Showing {Math.min(10, paymentReconReports.payments.length)} of {paymentReconReports.payments.length} payments. Download full report for complete data.
              </p>
            </div>
          )}
      </div>

      {/* Expense Reports */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center">
            <IndianRupee className="w-6 h-6 text-red-600 mr-2" />
            <h2 className="text-2xl font-bold text-gray-800">Expense Entry-wise Reports</h2>
          </div>
          <Button 
            onClick={fetchExpenseReports}
            disabled={expenseReportLoading}
            variant="outline"
          >
            {expenseReportLoading ? 'Loading...' : 'Refresh Data'}
          </Button>
        </div>

          {/* Date Range and Category Filter */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div>
              <Label>Start Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !expenseStartDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {expenseStartDate ? format(expenseStartDate, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={expenseStartDate}
                    onSelect={setExpenseStartDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div>
              <Label>End Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !expenseEndDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {expenseEndDate ? format(expenseEndDate, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={expenseEndDate}
                    onSelect={setExpenseEndDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div>
              <Label>Category</Label>
              <Select value={expenseCategory} onValueChange={setExpenseCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="fuel">Fuel</SelectItem>
                  <SelectItem value="salary">Salary</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="office">Office</SelectItem>
                  <SelectItem value="transport">Transport</SelectItem>
                  <SelectItem value="utilities">Utilities</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="repair">Repair</SelectItem>
                  <SelectItem value="insurance">Insurance</SelectItem>
                  <SelectItem value="miscellaneous">Miscellaneous</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end gap-2">
              <Button 
                onClick={() => handleExpenseExport('pdf')} 
                className="bg-red-600 hover:bg-red-700 text-white flex-1"
              >
                <FileText className="w-4 h-4 mr-2" />
                PDF
              </Button>
              <Button 
                onClick={() => handleExpenseExport('excel')} 
                className="bg-green-600 hover:bg-green-700 text-white flex-1"
              >
                <Download className="w-4 h-4 mr-2" />
                Excel
              </Button>
            </div>
          </div>

          {/* Summary Stats */}
          {expenseReports.summary && (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-red-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Total Expenses</p>
                <p className="text-2xl font-bold text-red-600">
                  {expenseReports.summary.total_expenses || 0}
                </p>
                <p className="text-sm text-gray-500">
                  ₹{expenseReports.summary.total_amount?.toFixed(2) || '0.00'}
                </p>
              </div>
              
              <div className="bg-orange-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Categories</p>
                <p className="text-2xl font-bold text-orange-600">
                  {Object.keys(expenseReports.summary.categories || {}).length}
                </p>
                <p className="text-sm text-gray-500">Different types</p>
              </div>

              <div className="bg-purple-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600">Top Category</p>
                <p className="text-xl font-bold text-purple-600">
                  {Object.entries(expenseReports.summary.categories || {})
                    .sort((a, b) => b[1].amount - a[1].amount)[0]?.[0]?.toUpperCase() || 'N/A'}
                </p>
                <p className="text-sm text-gray-500">
                  ₹{Object.entries(expenseReports.summary.categories || {})
                    .sort((a, b) => b[1].amount - a[1].amount)[0]?.[1]?.amount?.toFixed(2) || '0.00'}
                </p>
              </div>
            </div>
          )}

          {/* Category Breakdown */}
          {expenseReports.summary && expenseReports.summary.categories && Object.keys(expenseReports.summary.categories).length > 0 && (
            <div className="mb-6">
              <h3 className="font-semibold mb-3">Category Breakdown</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {Object.entries(expenseReports.summary.categories).map(([category, stats]) => (
                  <div key={category} className="bg-gray-50 p-3 rounded border">
                    <p className="text-sm font-semibold text-gray-700 capitalize">{category}</p>
                    <p className="text-lg font-bold text-gray-900">₹{stats.amount.toFixed(2)}</p>
                    <p className="text-xs text-gray-500">{stats.count} entries</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recent Expenses Preview */}
          {expenseReports.expenses && expenseReports.expenses.length > 0 && (
            <div className="mt-4">
              <h3 className="font-semibold mb-3">Recent Expense Entries (Top 10)</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full border-collapse border border-gray-300">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="border border-gray-300 px-4 py-2 text-left">Date</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">Title</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">Category</th>
                      <th className="border border-gray-300 px-4 py-2 text-right">Amount</th>
                      <th className="border border-gray-300 px-4 py-2 text-left">Created By</th>
                    </tr>
                  </thead>
                  <tbody>
                    {expenseReports.expenses.slice(0, 10).map((expense, idx) => (
                      <tr key={idx} className="hover:bg-gray-50">
                        <td className="border border-gray-300 px-4 py-2">
                          {expense.expense_date ? new Date(expense.expense_date).toLocaleDateString() : 'N/A'}
                        </td>
                        <td className="border border-gray-300 px-4 py-2">{expense.title}</td>
                        <td className="border border-gray-300 px-4 py-2 capitalize">{expense.category}</td>
                        <td className="border border-gray-300 px-4 py-2 text-right font-semibold">
                          ₹{expense.amount?.toFixed(2)}
                        </td>
                        <td className="border border-gray-300 px-4 py-2">{expense.created_by}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="text-sm text-gray-600 mt-2">
                Showing {Math.min(10, expenseReports.expenses.length)} of {expenseReports.expenses.length} expenses. Download full report for complete data.
              </p>
            </div>
          )}
        </div>
      </div>
  );
}

export default Reports;