import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../App';
import axios from 'axios';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { 
  Plus, 
  Search, 
  FileText, 
  Download, 
  Send, 
  Eye,
  Edit3,
  Trash2,
  Calendar,
  User,
  IndianRupee,
  Filter,
  AlertCircle,
  CheckCircle,
  Clock,
  Mail,
  PartyPopper
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

function InvoiceManagement() {
  const { API, user } = useContext(AuthContext);
  const [invoices, setInvoices] = useState([]);
  const [orders, setOrders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showInvoiceDialog, setShowInvoiceDialog] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [adminDetails, setAdminDetails] = useState(null);
  
  // New states for event and monthly invoices
  const [showEventInvoiceDialog, setShowEventInvoiceDialog] = useState(false);
  const [showMonthlyInvoiceDialog, setShowMonthlyInvoiceDialog] = useState(false);
  const [eligibleEvents, setEligibleEvents] = useState([]);
  const [monthlyDueCustomers, setMonthlyDueCustomers] = useState([]);
  const [monthlyInvoiceForm, setMonthlyInvoiceForm] = useState({
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear(),
    minimum_due: 100
  });
  
  const [invoiceForm, setInvoiceForm] = useState({
    order_id: '',
    customer_id: '',
    items: [],
    subtotal: 0,
    tax_rate: 18,
    discount_amount: 0,
    due_days: 30,
    payment_terms: 'Net 30',
    notes: ''
  });

  const invoiceStatuses = ['draft', 'sent', 'paid', 'overdue', 'cancelled'];
  const paymentTerms = ['Net 30', 'Net 15', 'Due on Receipt', 'Net 45', 'Net 60'];

  const fetchAdminDetails = async () => {
    try {
      // Fetch current logged-in user's details if admin/manager
      const response = await axios.get(`${API}/users`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      // Find admin or manager
      const admin = response.data.find(u => u.role === 'admin' || u.role === 'manager');
      if (admin) {
        setAdminDetails(admin);
      }
    } catch (error) {
      console.error('Error fetching admin details:', error);
    }
  };

  const fetchData = async () => {
    try {
      setLoading(true);
      const [invoicesRes, ordersRes, customersRes] = await Promise.all([
        axios.get(`${API}/invoices`, {
          headers: {
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
          }
        }),
        axios.get(`${API}/orders`, {
          headers: {
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
          }
        }),
        axios.get(`${API}/customers`, {
          headers: {
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
          }
        })
      ]);
      
      setInvoices([...invoicesRes.data]);
      setOrders([...ordersRes.data]);
      setCustomers([...customersRes.data]);
      
      // Fetch admin details for invoice
      await fetchAdminDetails();
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load invoices');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleCreateInvoice = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${API}/invoices`, invoiceForm);
      toast.success('Invoice created successfully!');
      setShowCreateDialog(false);
      resetForm();
      fetchData();
    } catch (error) {
      console.error('Error creating invoice:', error);
      toast.error('Failed to create invoice');
    }
  };

  const handleUpdateInvoiceStatus = async (invoiceId, status) => {
    try {
      await axios.put(`${API}/invoices/${invoiceId}`, { status });
      toast.success('Invoice status updated!');
      fetchData();
    } catch (error) {
      console.error('Error updating invoice:', error);
      toast.error('Failed to update invoice');
    }
  };

  const handleSendInvoice = async (invoiceId) => {
    try {
      await axios.post(`${API}/invoices/${invoiceId}/send`);
      toast.success('Invoice sent successfully!');
      fetchData();
    } catch (error) {
      console.error('Error sending invoice:', error);
      toast.error('Failed to send invoice');
    }
  };

  const handleDeleteInvoice = async (invoiceId, invoiceNumber) => {
    if (window.confirm(`Are you sure you want to delete invoice: ${invoiceNumber}?`)) {
      try {
        await axios.delete(`${API}/invoices/${invoiceId}`);
        toast.success('Invoice deleted successfully!');
        fetchData();
      } catch (error) {
        console.error('Error deleting invoice:', error);
        toast.error('Failed to delete invoice');
      }
    }
  };

  // Fetch eligible events for invoicing
  const fetchEligibleEvents = async () => {
    try {
      const response = await axios.get(`${API}/event-orders/invoice-eligible`);
      setEligibleEvents(response.data);
    } catch (error) {
      console.error('Error fetching eligible events:', error);
      toast.error('Failed to load eligible events');
    }
  };

  // Fetch monthly due customers
  const fetchMonthlyDueCustomers = async () => {
    try {
      const response = await axios.get(`${API}/customers/monthly-due?minimum_due=${monthlyInvoiceForm.minimum_due}`);
      setMonthlyDueCustomers(response.data);
    } catch (error) {
      console.error('Error fetching monthly due customers:', error);
      toast.error('Failed to load monthly due customers');
    }
  };

  // Create event order invoice
  const handleCreateEventInvoice = async (eventId) => {
    try {
      const response = await axios.post(`${API}/invoices/event-order/${eventId}`);
      toast.success('Event order invoice created successfully!');
      setShowEventInvoiceDialog(false);
      fetchData();
      fetchEligibleEvents(); // Refresh eligible events
    } catch (error) {
      console.error('Error creating event invoice:', error);
      toast.error(error.response?.data?.detail || 'Failed to create event invoice');
    }
  };

  // Create monthly due invoices
  const handleCreateMonthlyInvoices = async () => {
    try {
      const response = await axios.post(`${API}/invoices/monthly-due`, monthlyInvoiceForm);
      toast.success(`${response.data.invoices_created} monthly invoices created successfully!`);
      setShowMonthlyInvoiceDialog(false);
      fetchData();
    } catch (error) {
      console.error('Error creating monthly invoices:', error);
      toast.error(error.response?.data?.detail || 'Failed to create monthly invoices');
    }
  };

  const handleOrderSelection = (orderId) => {
    const order = orders.find(o => o.id === orderId);
    if (order) {
      const items = order.products.map(product => ({
        name: product.product_name,
        quantity: product.quantity,
        price: product.price,
        total: product.quantity * product.price
      }));
      
      setInvoiceForm({
        ...invoiceForm,
        order_id: orderId,
        customer_id: order.customer_id,
        items: items,
        subtotal: order.total_amount
      });
    }
  };

  const resetForm = () => {
    setInvoiceForm({
      order_id: '',
      customer_id: '',
      items: [],
      subtotal: 0,
      tax_rate: 18,
      discount_amount: 0,
      due_days: 30,
      payment_terms: 'Net 30',
      notes: ''
    });
  };

  const viewInvoice = (invoice) => {
    setSelectedInvoice(invoice);
    setShowInvoiceDialog(true);
  };

  const generatePDF = (invoice) => {
    try {
      // Validate invoice data
      if (!invoice || !invoice.invoice_number) {
        toast.error('Invalid invoice data');
        return;
      }

      // Create a printable invoice
      const printWindow = window.open('', '_blank');
      
      if (!printWindow) {
        toast.error('Please allow pop-ups to download invoice');
        return;
      }

      const invoiceHTML = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Invoice ${invoice.invoice_number}</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 15px; font-size: 14px; }
          .header { text-align: center; margin-bottom: 15px; }
          .company-info { text-align: center; margin-bottom: 15px; }
          .invoice-details { display: flex; justify-content: space-between; margin-bottom: 15px; }
          .customer-info { margin-bottom: 15px; }
          .items-table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
          .items-table th, .items-table td { border: 1px solid #ddd; padding: 12px; text-align: left; }
          .items-table th { background-color: #f5f5f5; font-weight: bold; }
          .main-item { background-color: #f8f9ff !important; font-weight: bold; }
          .detail-item { font-size: 12px; color: #666; background-color: #fafafa; }
          .jar-highlight { background-color: #e7f3ff; border-left: 3px solid #2563eb; }
          .payment-status { margin-top: 20px; padding: 15px; border-radius: 8px; text-align: center; }
          .status-paid { background-color: #d4edda; border: 2px solid #28a745; color: #155724; }
          .status-pending { background-color: #fff3cd; border: 2px solid #ffc107; color: #856404; }
          .status-overdue { background-color: #f8d7da; border: 2px solid #dc3545; color: #721c24; }
          .status-draft { background-color: #e9ecef; border: 2px solid #6c757d; color: #495057; }
          .signature-section { page-break-inside: avoid; margin-top: 50px; }
          .signature-line { border-bottom: 2px solid #333; height: 60px; }
          .terms-conditions { background-color: #f8f9fa; border-left: 4px solid #007bff; padding: 15px; }
          .total-section { text-align: right; }
          .footer { margin-top: 10px; text-align: center; font-size: 10px; color: #666; }
        </style>
      </head>
      <body>
        <div class="company-info">
          <h1 style="color: #007bff; margin: 0 0 3px 0; font-size: 24px;">AquaElite</h1>
          <p style="font-size: 12px; color: #666; margin: 2px 0;">Premium Water Delivery System</p>
          <p style="font-size: 10px; color: #888; margin: 1px 0;">
            📞 ${adminDetails?.mobile || '+91-XXXXXXXXXX'} | 📧 ${adminDetails?.email || 'info@aquaelite.com'}${adminDetails?.gst_number ? ' | GST: ' + adminDetails.gst_number : ''}
          </p>
        </div>
        
        <div class="header">
          <h2>INVOICE</h2>
        </div>
        
        <div class="invoice-details">
          <div>
            <strong>Invoice Number:</strong> ${invoice.invoice_number}<br>
            <strong>Issue Date:</strong> ${format(new Date(invoice.issue_date), 'MMM dd, yyyy')}<br>
            <strong>Due Date:</strong> ${format(new Date(invoice.due_date), 'MMM dd, yyyy')}<br>
          </div>
          <div>
            <strong>Status:</strong> ${invoice.status.toUpperCase()}<br>
            <strong>Payment Status:</strong> ${
              (() => {
                const totalAmount = adminDetails?.gst_number ? invoice.total_amount : (invoice.subtotal - invoice.discount_amount);
                const amountPaid = invoice.amount_paid || 0;
                
                if (amountPaid >= totalAmount && totalAmount > 0) {
                  return '<span style="color: #28a745; font-weight: bold;">PAID</span>';
                } else if (amountPaid > 0 && amountPaid < totalAmount) {
                  return '<span style="color: #ffc107; font-weight: bold;">PARTIALLY PAID (₹' + amountPaid.toFixed(2) + ' / ₹' + totalAmount.toFixed(2) + ')</span>';
                } else {
                  return '<span style="color: #dc3545; font-weight: bold;">UNPAID</span>';
                }
              })()
            }<br>
            <strong>Payment Terms:</strong> ${invoice.payment_terms}<br>
          </div>
        </div>
        
        <div class="customer-info">
          <h3>Bill To:</h3>
          <p>
            <strong>${invoice.customer_name}</strong><br>
            ${invoice.customer_address || 'Address not provided'}<br>
            ${invoice.customer_mobile ? `Mobile: ${invoice.customer_mobile}` : 'Mobile not provided'}
          </p>
          <!-- Event invoice header removed as requested -->
          ${invoice.invoice_type === 'monthly_due' ? `
            <div style="margin-top: 15px; padding: 10px; background-color: #fff7ed; border-left: 4px solid #f97316;">
              <strong>Monthly Due Invoice</strong><br>
              Invoice Period: ${invoice.issue_month ? new Date(0, invoice.issue_month - 1).toLocaleString('default', { month: 'long' }) : ''} ${invoice.issue_year || ''}
            </div>
          ` : ''}
        </div>
        
        <table class="items-table">
          <thead>
            <tr>
              <th>Item</th>
              <th>Quantity</th>
              <th>Price</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            ${invoice.items.map(item => {
              const isMainItem = (item.quantity || 0) > 0;
              const isDetailItem = (item.quantity || 0) === 0 && item.description && item.description.includes('•');
              const mainStyle = isMainItem ? 'font-weight: bold; background-color: #f9f9f9;' : '';
              const detailStyle = isDetailItem ? 'font-size: 13px; color: #666;' : '';
              const tdStyle = isDetailItem ? 'padding-left: 20px; font-style: italic;' : '';
              const amountStyle = isMainItem ? 'font-weight: bold; color: #16a34a;' : '';
              
              return '<tr style="' + mainStyle + detailStyle + '">' +
                       '<td style="' + tdStyle + '">' + (item.description || item.name || 'Item') + '</td>' +
                       '<td style="text-align: center;">' + (item.quantity > 0 ? item.quantity + ' jars' : '-') + '</td>' +
                       '<td style="text-align: right;">' + (item.unit_price > 0 ? '₹' + (item.unit_price || item.price || 0).toFixed(2) : '-') + '</td>' +
                       '<td style="text-align: right; ' + amountStyle + '">' + (item.amount > 0 ? '₹' + (item.amount || item.total || 0).toFixed(2) : '-') + '</td>' +
                     '</tr>';
            }).join('')}
          </tbody>
        </table>
        
        <div class="total-section">
          <p><strong>Subtotal:</strong> ₹${invoice.subtotal.toFixed(2)}</p>
          ${(invoice.tax_rate > 0 && adminDetails?.gst_number) ? `<p><strong>GST (${invoice.tax_rate}%):</strong> ₹${invoice.tax_amount.toFixed(2)}</p>` : ''}
          ${invoice.discount_amount > 0 ? `<p><strong>Discount:</strong> -₹${invoice.discount_amount.toFixed(2)}</p>` : ''}
          <h3><strong>Total Amount:</strong> ₹${(adminDetails?.gst_number ? invoice.total_amount : (invoice.subtotal - invoice.discount_amount)).toFixed(2)}</h3>
          
          <!-- Payment status removed for cleaner single-page invoice -->
        </div>
        
        ${invoice.notes ? `<div style="margin-top: 30px;"><strong>Notes:</strong><br>${invoice.notes}</div>` : ''}
        
        <!-- Signature Section - Compact for single page -->
        <div class="signature-section" style="margin-top: 20px; margin-bottom: 10px;">
          <div style="display: flex; justify-content: space-between; align-items: flex-end;">
            <!-- Terms and Conditions - Left Side -->
            <div style="width: 60%; font-size: 11px;">
              <p style="margin: 0 0 5px 0; font-weight: bold; color: #007bff;">Terms & Conditions:</p>
              <p style="margin: 1px 0; line-height: 1.3;">• Payment due within ${invoice.payment_terms || '30 days'}</p>
              <p style="margin: 1px 0; line-height: 1.3;">• Late payment may incur charges</p>
              <p style="margin: 1px 0; line-height: 1.3;">• Empty jars must be returned in good condition</p>
            </div>
            
            <!-- Authorized Signature - Right Side -->
            <div style="width: 35%; text-align: center;">
              <div style="border-bottom: 2px solid #333; width: 100%; height: 40px; margin-bottom: 8px;"></div>
              <p style="margin: 3px 0; font-weight: bold; font-size: 12px;">Authorized Signature</p>
              <p style="margin: 1px 0; font-size: 10px; color: #666;">AquaElite Water Delivery</p>
            </div>
          </div>
        </div>
        
        <div class="footer">
          <p style="margin: 5px 0;">Thank you for your business! | Generated on ${format(new Date(), 'MMM dd, yyyy')}</p>
        </div>
      </body>
      </html>
    `;
    
      printWindow.document.write(invoiceHTML);
      printWindow.document.close();
      
      // Wait a moment for the document to load, then print
      setTimeout(() => {
        printWindow.print();
      }, 500);
      
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast.error('Failed to generate invoice PDF. Please try again.');
    }
  };

  const filteredInvoices = invoices.filter(invoice => {
    const matchesSearch = 
      invoice.invoice_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      invoice.customer_name.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === 'all' || invoice.status === filterStatus;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status) => {
    const variants = {
      draft: 'bg-gray-100 text-gray-800',
      sent: 'bg-blue-100 text-blue-800',
      paid: 'bg-green-100 text-green-800',
      overdue: 'bg-red-100 text-red-800',
      cancelled: 'bg-red-100 text-red-800'
    };
    
    return variants[status] || 'bg-gray-100 text-gray-800';
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'draft': return <Edit3 className="w-4 h-4" />;
      case 'sent': return <Mail className="w-4 h-4" />;
      case 'paid': return <CheckCircle className="w-4 h-4" />;
      case 'overdue': return <AlertCircle className="w-4 h-4" />;
      case 'cancelled': return <AlertCircle className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const totalInvoices = invoices.length;
  const totalAmount = invoices.reduce((sum, inv) => sum + inv.total_amount, 0);
  const pendingInvoices = invoices.filter(inv => ['draft', 'sent'].includes(inv.status)).length;
  const overdueInvoices = invoices.filter(inv => inv.status === 'overdue' || 
    (inv.status !== 'paid' && new Date(inv.due_date) < new Date())).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900" data-testid="invoice-management-title">
            Invoice Management
          </h1>
          <p className="text-gray-600 mt-1">
            Create, manage, and track invoices for your water delivery business
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Event Order Invoice Button */}
          <Dialog open={showEventInvoiceDialog} onOpenChange={setShowEventInvoiceDialog}>
            <DialogTrigger asChild>
              <Button 
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                onClick={fetchEligibleEvents}
              >
                <PartyPopper className="w-4 h-4 mr-2" />
                Event Invoices
              </Button>
            </DialogTrigger>
          </Dialog>

          {/* Monthly Due Invoice Button */}
          <Dialog open={showMonthlyInvoiceDialog} onOpenChange={setShowMonthlyInvoiceDialog}>
            <DialogTrigger asChild>
              <Button 
                className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700"
                onClick={fetchMonthlyDueCustomers}
              >
                <Calendar className="w-4 h-4 mr-2" />
                Monthly Due
              </Button>
            </DialogTrigger>
          </Dialog>

          {/* Regular Invoice Button */}
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button 
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                data-testid="create-invoice-btn"
                onClick={resetForm}
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Invoice
              </Button>
            </DialogTrigger>
          </Dialog>
        </div>

        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <div style={{ display: 'none' }}></div>
          </DialogTrigger>
          
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Invoice</DialogTitle>
              <DialogDescription>
                Generate an invoice from an existing order
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleCreateInvoice} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="order">Select Order</Label>
                <Select 
                  value={invoiceForm.order_id} 
                  onValueChange={handleOrderSelection}
                >
                  <SelectTrigger data-testid="invoice-order-select">
                    <SelectValue placeholder="Select order to invoice" />
                  </SelectTrigger>
                  <SelectContent>
                    {orders.map(order => (
                      <SelectItem key={order.id} value={order.id}>
                        #{order.id.slice(-8)} - {order.customer_name} - ₹{order.total_amount}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {invoiceForm.items.length > 0 && (
                <div className="space-y-2">
                  <Label>Invoice Items</Label>
                  <div className="border rounded-lg p-4 bg-gray-50">
                    {invoiceForm.items.map((item, index) => (
                      <div key={index} className="flex justify-between items-center py-2 border-b last:border-b-0">
                        <div>
                          <span className="font-medium">{item.name}</span>
                          <span className="text-sm text-gray-600 ml-2">x{item.quantity}</span>
                        </div>
                        <span className="font-medium">₹{item.total.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="taxRate">GST Rate (%)</Label>
                  <Input
                    id="taxRate"
                    type="number"
                    value={invoiceForm.tax_rate}
                    onChange={(e) => setInvoiceForm({...invoiceForm, tax_rate: parseFloat(e.target.value) || 0})}
                    data-testid="invoice-tax-rate-input"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="discount">Discount Amount (₹)</Label>
                  <Input
                    id="discount"
                    type="number"
                    value={invoiceForm.discount_amount}
                    onChange={(e) => setInvoiceForm({...invoiceForm, discount_amount: parseFloat(e.target.value) || 0})}
                    data-testid="invoice-discount-input"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dueDays">Due Days</Label>
                  <Input
                    id="dueDays"
                    type="number"
                    value={invoiceForm.due_days}
                    onChange={(e) => setInvoiceForm({...invoiceForm, due_days: parseInt(e.target.value) || 30})}
                    data-testid="invoice-due-days-input"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="paymentTerms">Payment Terms</Label>
                  <Select 
                    value={invoiceForm.payment_terms} 
                    onValueChange={(value) => setInvoiceForm({...invoiceForm, payment_terms: value})}
                  >
                    <SelectTrigger data-testid="invoice-payment-terms-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {paymentTerms.map(term => (
                        <SelectItem key={term} value={term}>{term}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="notes">Notes (Optional)</Label>
                <Textarea
                  id="notes"
                  value={invoiceForm.notes}
                  onChange={(e) => setInvoiceForm({...invoiceForm, notes: e.target.value})}
                  placeholder="Additional notes or terms..."
                  data-testid="invoice-notes-input"
                />
              </div>

              {invoiceForm.subtotal > 0 && (
                <div className="border-t pt-4">
                  <div className="space-y-2 text-right">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>₹{invoiceForm.subtotal.toFixed(2)}</span>
                    </div>
                    {invoiceForm.tax_rate > 0 && (
                      <div className="flex justify-between">
                        <span>GST ({invoiceForm.tax_rate}%):</span>
                        <span>₹{(invoiceForm.subtotal * invoiceForm.tax_rate / 100).toFixed(2)}</span>
                      </div>
                    )}
                    {invoiceForm.discount_amount > 0 && (
                      <div className="flex justify-between">
                        <span>Discount:</span>
                        <span>-₹{invoiceForm.discount_amount.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between font-bold text-lg border-t pt-2">
                      <span>Total:</span>
                      <span>₹{(invoiceForm.subtotal + (invoiceForm.subtotal * invoiceForm.tax_rate / 100) - invoiceForm.discount_amount).toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="flex space-x-2 pt-4">
                <Button 
                  type="submit" 
                  className="flex-1 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
                  disabled={!invoiceForm.order_id}
                  data-testid="save-invoice-btn"
                >
                  Create Invoice
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowCreateDialog(false)}
                  data-testid="cancel-invoice-btn"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and Filter */}
      <Card className="shadow-soft">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input 
                placeholder="Search by invoice number or customer name..." 
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                data-testid="invoice-search-input"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-40" data-testid="invoice-status-filter">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  {invoiceStatuses.map(status => (
                    <SelectItem key={status} value={status}>
                      {status.charAt(0).toUpperCase() + status.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Invoice Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Invoices</p>
                <p className="text-2xl font-bold text-blue-600" data-testid="total-invoices-stat">
                  {totalInvoices}
                </p>
              </div>
              <FileText className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Amount</p>
                <p className="text-2xl font-bold text-green-600" data-testid="total-invoice-amount-stat">
                  ₹{totalAmount.toFixed(2)}
                </p>
              </div>
              <IndianRupee className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending</p>
                <p className="text-2xl font-bold text-yellow-600" data-testid="pending-invoices-stat">
                  {pendingInvoices}
                </p>
              </div>
              <Clock className="w-8 h-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Overdue</p>
                <p className="text-2xl font-bold text-red-600" data-testid="overdue-invoices-stat">
                  {overdueInvoices}
                </p>
              </div>
              <AlertCircle className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Invoice List */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle>Invoice List</CardTitle>
          <CardDescription>
            {filteredInvoices.length} invoice(s) found
          </CardDescription>
        </CardHeader>
        
        <CardContent className="p-0">
          {filteredInvoices.length === 0 ? (
            <div className="text-center py-12" data-testid="no-invoices-message">
              <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No invoices found</h3>
              <p className="text-gray-600 mb-4">Create your first invoice to get started.</p>
              <Button 
                onClick={() => setShowCreateDialog(true)}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
                data-testid="create-first-invoice-btn"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Invoice
              </Button>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {filteredInvoices.map((invoice) => (
                <div key={invoice.id} className="p-6 hover:bg-gray-50 transition-colors" data-testid={`invoice-item-${invoice.id}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-3">
                        <h3 className="text-lg font-semibold text-gray-900" data-testid={`invoice-number-${invoice.id}`}>
                          {invoice.invoice_number}
                        </h3>
                        
                        {/* Payment Status Badge */}
                        <Badge className={
                          invoice.status === 'paid' ? 'bg-green-100 text-green-800 border-green-300' :
                          invoice.status === 'sent' || invoice.status === 'overdue' ? 'bg-red-100 text-red-800 border-red-300' :
                          'bg-yellow-100 text-yellow-800 border-yellow-300'
                        }>
                          <div className="flex items-center space-x-1">
                            {invoice.status === 'paid' ? <CheckCircle className="w-3 h-3" /> :
                             (invoice.status === 'sent' || invoice.status === 'overdue') ? <AlertCircle className="w-3 h-3" /> :
                             <Clock className="w-3 h-3" />}
                            <span>
                              {invoice.status === 'paid' ? 'Fully Paid' :
                               (invoice.status === 'sent' || invoice.status === 'overdue') ? 'Unpaid' :
                               'Draft'}
                            </span>
                          </div>
                        </Badge>
                        
                        {/* Invoice Type Badge */}
                        {invoice.invoice_type && (
                          <Badge 
                            variant="outline"
                            className={
                              invoice.invoice_type === 'event_order' ? 'bg-purple-100 text-purple-800 border-purple-200' :
                              invoice.invoice_type === 'monthly_due' ? 'bg-orange-100 text-orange-800 border-orange-200' :
                              'bg-gray-100 text-gray-800 border-gray-200'
                            }
                          >
                            {invoice.invoice_type === 'event_order' ? 'Event Order' :
                             invoice.invoice_type === 'monthly_due' ? 'Monthly Due' :
                             'Regular'}
                          </Badge>
                        )}
                        
                        <div className="text-lg font-bold text-green-600" data-testid={`invoice-amount-${invoice.id}`}>
                          ₹{invoice.total_amount.toFixed(2)}
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm text-gray-600">
                        <div className="flex items-center space-x-2">
                          <User className="w-4 h-4" />
                          <span data-testid={`invoice-customer-${invoice.id}`}>{invoice.customer_name}</span>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <Calendar className="w-4 h-4" />
                          <span data-testid={`invoice-issue-date-${invoice.id}`}>
                            Issue: {format(new Date(invoice.issue_date), "MMM dd, yyyy")}
                          </span>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <Calendar className="w-4 h-4" />
                          <span className={new Date(invoice.due_date) < new Date() && invoice.status !== 'paid' ? 'text-red-600 font-medium' : ''} data-testid={`invoice-due-date-${invoice.id}`}>
                            Due: {format(new Date(invoice.due_date), "MMM dd, yyyy")}
                          </span>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <span className="text-gray-500">Items: {invoice.items.length}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => viewInvoice(invoice)}
                        className="hover:bg-blue-50 hover:text-blue-600"
                        data-testid={`view-invoice-${invoice.id}`}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => generatePDF(invoice)}
                        className="hover:bg-green-50 hover:text-green-600"
                        data-testid={`download-invoice-${invoice.id}`}
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                      
                      {invoice.status === 'draft' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleSendInvoice(invoice.id)}
                          className="hover:bg-purple-50 hover:text-purple-600"
                          data-testid={`send-invoice-${invoice.id}`}
                        >
                          <Send className="w-4 h-4" />
                        </Button>
                      )}
                      
                      {['draft', 'sent'].includes(invoice.status) && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleUpdateInvoiceStatus(invoice.id, 'paid')}
                          className="hover:bg-green-50 hover:text-green-600"
                          data-testid={`mark-paid-invoice-${invoice.id}`}
                        >
                          <CheckCircle className="w-4 h-4" />
                        </Button>
                      )}
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteInvoice(invoice.id, invoice.invoice_number)}
                        className="hover:bg-red-50 hover:text-red-600"
                        data-testid={`delete-invoice-${invoice.id}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Invoice Details Dialog */}
      <Dialog open={showInvoiceDialog} onOpenChange={setShowInvoiceDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Invoice Details</DialogTitle>
            <DialogDescription>
              Complete invoice information and preview
            </DialogDescription>
          </DialogHeader>
          
          {selectedInvoice && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">Invoice Number:</span>
                  <p>{selectedInvoice.invoice_number}</p>
                </div>
                <div>
                  <span className="font-medium">Payment Status:</span>
                  <div className={`mt-2 p-3 rounded-lg text-center font-bold ${
                    selectedInvoice.status === 'paid' ? 'bg-green-100 text-green-800 border border-green-300' :
                    selectedInvoice.status === 'sent' || selectedInvoice.status === 'overdue' ? 'bg-red-100 text-red-800 border border-red-300' :
                    selectedInvoice.status === 'cancelled' ? 'bg-gray-100 text-gray-800 border border-gray-300' :
                    'bg-yellow-100 text-yellow-800 border border-yellow-300'
                  }`}>
                    {selectedInvoice.status === 'paid' ? '✅ Fully Paid' :
                     selectedInvoice.status === 'sent' ? '❌ Unpaid' :
                     selectedInvoice.status === 'overdue' ? '⚠️ Unpaid (Overdue)' :
                     selectedInvoice.status === 'cancelled' ? '❌ Cancelled' :
                     '📝 Draft'}
                  </div>
                </div>
                <div>
                  <span className="font-medium">Customer:</span>
                  <p>{selectedInvoice.customer_name}</p>
                </div>
                <div>
                  <span className="font-medium">Payment Terms:</span>
                  <p>{selectedInvoice.payment_terms}</p>
                </div>
                <div>
                  <span className="font-medium">Issue Date:</span>
                  <p>{format(new Date(selectedInvoice.issue_date), "PPP")}</p>
                </div>
                <div>
                  <span className="font-medium">Due Date:</span>
                  <p>{format(new Date(selectedInvoice.due_date), "PPP")}</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-3">Invoice Items:</h4>
                <div className="space-y-2">
                  {selectedInvoice.items.map((item, index) => {
                    const isMainItem = (item.quantity || 0) > 0;
                    const isDetailItem = (item.quantity || 0) === 0;
                    
                    return (
                      <div 
                        key={index} 
                        className={`p-3 rounded-lg ${
                          isMainItem ? 'bg-blue-50 border-l-4 border-blue-500' : 
                          isDetailItem ? 'bg-gray-50 ml-4 border-l-2 border-gray-300' : 
                          'bg-gray-50'
                        }`}
                      >
                        {isMainItem ? (
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <p className="font-semibold text-blue-900">{item.description || item.name}</p>
                              <div className="mt-2 space-y-1">
                                <p className="text-sm text-blue-700">
                                  <strong>Jars Delivered:</strong> {item.quantity} jars
                                </p>
                                <p className="text-sm text-blue-700">
                                  <strong>Rate per Jar:</strong> ₹{(item.unit_price || item.price || 0).toFixed(2)}
                                </p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-xl font-bold text-green-600">
                                ₹{(item.amount || item.total || 0).toFixed(2)}
                              </p>
                            </div>
                          </div>
                        ) : isDetailItem ? (
                          <p className="text-sm text-gray-600 italic">
                            {item.description || item.name}
                          </p>
                        ) : (
                          <div className="flex justify-between items-center">
                            <div>
                              <p className="font-medium">{item.description || item.name}</p>
                              {(item.quantity || 0) > 0 && (
                                <p className="text-sm text-gray-600">
                                  Qty: {item.quantity} × ₹{(item.unit_price || item.price || 0).toFixed(2)}
                                </p>
                              )}
                            </div>
                            <p className="font-medium">
                              ₹{(item.amount || item.total || 0).toFixed(2)}
                            </p>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
              
              <div className="border-t pt-4">
                <div className="space-y-2 text-right">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>₹{selectedInvoice.subtotal.toFixed(2)}</span>
                  </div>
                  {selectedInvoice.tax_rate > 0 && adminDetails?.gst_number && (
                    <div className="flex justify-between">
                      <span>GST ({selectedInvoice.tax_rate}%):</span>
                      <span>₹{selectedInvoice.tax_amount.toFixed(2)}</span>
                    </div>
                  )}
                  {selectedInvoice.discount_amount > 0 && (
                    <div className="flex justify-between">
                      <span>Discount:</span>
                      <span>-₹{selectedInvoice.discount_amount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold text-lg border-t pt-2">
                    <span>Total Amount:</span>
                    <span className="text-green-600">₹{(adminDetails?.gst_number ? selectedInvoice.total_amount : (selectedInvoice.subtotal - selectedInvoice.discount_amount)).toFixed(2)}</span>
                  </div>
                </div>
              </div>
              
              {selectedInvoice.notes && (
                <div>
                  <span className="font-medium">Notes:</span>
                  <p className="text-gray-600 mt-1">{selectedInvoice.notes}</p>
                </div>
              )}
              
              <div className="flex space-x-2 pt-4">
                <Button 
                  onClick={() => generatePDF(selectedInvoice)}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
                  data-testid="download-invoice-pdf-btn"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download PDF
                </Button>
                <Button 
                  onClick={() => setShowInvoiceDialog(false)}
                  variant="outline"
                  data-testid="close-invoice-dialog-btn"
                >
                  Close
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Event Order Invoice Dialog */}
      <Dialog open={showEventInvoiceDialog} onOpenChange={setShowEventInvoiceDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <PartyPopper className="w-6 h-6 text-purple-600" />
              <span>Create Event Order Invoices</span>
            </DialogTitle>
            <DialogDescription>
              Select event orders to generate invoices. Only completed events without existing invoices are shown.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {eligibleEvents.length === 0 ? (
              <div className="text-center py-8">
                <PartyPopper className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No eligible event orders found for invoicing</p>
                <p className="text-sm text-gray-500">
                  Event orders must be completed to generate invoices
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {eligibleEvents.map((event) => (
                  <div key={event.id} className="border rounded-lg p-4 hover:bg-gray-50">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{event.event_name}</h3>
                        <p className="text-gray-600">{event.customer_name}</p>
                        <div className="mt-2 space-y-1">
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <span>Date: {event.event_date}</span>
                            <span>Venue: {event.venue_address}</span>
                          </div>
                          <div className="flex items-center space-x-4 text-sm">
                            <Badge variant="outline" className="bg-purple-100 text-purple-800">
                              {event.event_status}
                            </Badge>
                            <span className="text-gray-600">
                              Jars: {event.total_jars_delivered || event.water_jars}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-bold text-green-600">
                          ₹{(event.total_amount || 0).toFixed(2)}
                        </p>
                        <Button 
                          onClick={() => handleCreateEventInvoice(event.id)}
                          className="mt-2 bg-purple-600 hover:bg-purple-700"
                          size="sm"
                        >
                          <FileText className="w-4 h-4 mr-2" />
                          Create Invoice
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Monthly Due Invoice Dialog */}
      <Dialog open={showMonthlyInvoiceDialog} onOpenChange={setShowMonthlyInvoiceDialog}>
        <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Calendar className="w-6 h-6 text-orange-600" />
              <span>Create Monthly Due Invoices</span>
            </DialogTitle>
            <DialogDescription>
              Generate invoices for customers with outstanding monthly dues. Configure the parameters below.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* Monthly Invoice Configuration */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Invoice Configuration</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label>Month</Label>
                    <Select 
                      value={monthlyInvoiceForm.month.toString()} 
                      onValueChange={(value) => setMonthlyInvoiceForm({
                        ...monthlyInvoiceForm, 
                        month: parseInt(value)
                      })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({length: 12}, (_, i) => (
                          <SelectItem key={i+1} value={(i+1).toString()}>
                            {new Date(0, i).toLocaleString('default', { month: 'long' })}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label>Year</Label>
                    <Select 
                      value={monthlyInvoiceForm.year.toString()} 
                      onValueChange={(value) => setMonthlyInvoiceForm({
                        ...monthlyInvoiceForm, 
                        year: parseInt(value)
                      })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({length: 3}, (_, i) => {
                          const year = new Date().getFullYear() - 1 + i;
                          return (
                            <SelectItem key={year} value={year.toString()}>
                              {year}
                            </SelectItem>
                          );
                        })}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label>Minimum Due Amount (₹)</Label>
                    <Input
                      type="number"
                      min="0"
                      value={monthlyInvoiceForm.minimum_due}
                      onChange={(e) => setMonthlyInvoiceForm({
                        ...monthlyInvoiceForm, 
                        minimum_due: parseFloat(e.target.value) || 0
                      })}
                      placeholder="100"
                    />
                  </div>
                </div>
                
                <div className="flex space-x-3 mt-4">
                  <Button 
                    onClick={fetchMonthlyDueCustomers} 
                    variant="outline"
                    className="flex-1"
                  >
                    <Search className="w-4 h-4 mr-2" />
                    Search Customers
                  </Button>
                  
                  {monthlyDueCustomers.customers && monthlyDueCustomers.customers.length > 0 && (
                    <Button 
                      onClick={handleCreateMonthlyInvoices}
                      className="flex-1 bg-orange-600 hover:bg-orange-700"
                    >
                      <FileText className="w-4 h-4 mr-2" />
                      Create All Invoices ({monthlyDueCustomers.customers.length})
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Monthly Due Customers Summary */}
            {monthlyDueCustomers.summary && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Customers Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-600">Total Customers</p>
                      <p className="text-2xl font-bold text-blue-600">
                        {monthlyDueCustomers.summary.total_customers}
                      </p>
                    </div>
                    <div className="bg-orange-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-600">Total Due Amount</p>
                      <p className="text-2xl font-bold text-orange-600">
                        ₹{monthlyDueCustomers.summary.total_due_amount.toFixed(2)}
                      </p>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <p className="text-sm text-gray-600">Average Due</p>
                      <p className="text-2xl font-bold text-green-600">
                        ₹{(monthlyDueCustomers.summary.total_due_amount / Math.max(1, monthlyDueCustomers.summary.total_customers)).toFixed(2)}
                      </p>
                    </div>
                  </div>
                  
                  {/* Customers List */}
                  {monthlyDueCustomers.customers && monthlyDueCustomers.customers.length > 0 && (
                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      <h4 className="font-medium text-gray-900">Customers with Outstanding Dues:</h4>
                      {monthlyDueCustomers.customers.slice(0, 10).map((customer) => (
                        <div key={customer.id} className="flex justify-between items-center p-3 bg-gray-50 rounded">
                          <div>
                            <p className="font-medium">{customer.name}</p>
                            <p className="text-sm text-gray-600">{customer.mobile}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-orange-600">₹{customer.cash_balance.toFixed(2)}</p>
                            <p className="text-xs text-gray-500">{customer.empty_jars_balance} empty jars</p>
                          </div>
                        </div>
                      ))}
                      {monthlyDueCustomers.customers.length > 10 && (
                        <p className="text-sm text-gray-500 text-center">
                          ... and {monthlyDueCustomers.customers.length - 10} more customers
                        </p>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default InvoiceManagement;