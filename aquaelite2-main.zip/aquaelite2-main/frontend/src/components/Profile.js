import React, { useState, useContext } from 'react';
import { AuthContext } from '../App';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { 
  User, 
  Mail, 
  Phone, 
  Shield, 
  Truck,
  Edit3,
  Save,
  Camera,
  Trash2,
  Upload
} from 'lucide-react';
import { toast } from 'sonner';

function Profile() {
  const { user, API } = useContext(AuthContext);
  const [editing, setEditing] = useState(false);
  const [photoUploading, setPhotoUploading] = useState(false);
  const [previewPhoto, setPreviewPhoto] = useState(null);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    mobile: user?.mobile || '',
    gst_number: user?.gst_number || ''
  });

  const getRoleIcon = (role) => {
    switch (role) {
      case 'admin': return <Shield className="w-4 h-4" />;
      case 'delivery_boy': return <Truck className="w-4 h-4" />;
      default: return <User className="w-4 h-4" />;
    }
  };

  const getRoleLabel = (role) => {
    switch (role) {
      case 'admin': return 'Administrator';
      case 'delivery_boy': return 'Delivery Boy';
      default: return 'User';
    }
  };

  const getInitials = (name) => {
    return name?.split(' ').map(word => word.charAt(0)).join('').toUpperCase().slice(0, 2) || 'U';
  };

  const handleSave = async () => {
    try {
      const response = await fetch(`${API}/profile`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(formData)
      });
      
      if (!response.ok) {
        throw new Error('Failed to update profile');
      }
      
      const updatedUser = await response.json();
      
      // Update localStorage with new user data
      localStorage.setItem('user', JSON.stringify(updatedUser));
      
      // Refresh page to update context
      window.location.reload();
      
      toast.success('Profile updated successfully!');
      setEditing(false);
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error('Failed to update profile. Please try again.');
    }
  };

  const handlePhotoUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      toast.error('Invalid file type. Please upload JPEG, PNG, or WebP images only.');
      return;
    }

    // Validate file size (5MB max)
    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) {
      toast.error('File size too large. Maximum size allowed is 5MB.');
      return;
    }

    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreviewPhoto(e.target.result);
    };
    reader.readAsDataURL(file);

    // Upload file
    setPhotoUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch(`${API}/profile/upload-photo`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: formData
      });

      if (!response.ok) {
        throw new Error('Failed to upload photo');
      }

      const result = await response.json();
      
      // Update user data in localStorage and context
      const updatedUser = { ...user, profile_photo: result.photo_url };
      localStorage.setItem('user', JSON.stringify(updatedUser));
      
      toast.success('Profile photo updated successfully!');
      
      // Refresh page to update context
      setTimeout(() => {
        window.location.reload();
      }, 1000);
      
    } catch (error) {
      console.error('Error uploading photo:', error);
      toast.error('Failed to upload photo. Please try again.');
      setPreviewPhoto(null);
    } finally {
      setPhotoUploading(false);
    }
  };

  const handleDeletePhoto = async () => {
    if (!user?.profile_photo) return;

    try {
      const response = await fetch(`${API}/profile/delete-photo`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });

      if (!response.ok) {
        throw new Error('Failed to delete photo');
      }

      // Update user data in localStorage and context
      const updatedUser = { ...user, profile_photo: null };
      localStorage.setItem('user', JSON.stringify(updatedUser));
      
      toast.success('Profile photo deleted successfully!');
      setPreviewPhoto(null);
      
      // Refresh page to update context
      setTimeout(() => {
        window.location.reload();
      }, 1000);
      
    } catch (error) {
      console.error('Error deleting photo:', error);
      toast.error('Failed to delete photo. Please try again.');
    }
  };

  const getProfilePhotoUrl = () => {
    if (previewPhoto) return previewPhoto;
    if (user?.profile_photo) {
      // For production environment, use the same base URL as API
      const baseUrl = API.replace('/api', '');
      return `${baseUrl}${user.profile_photo}`;
    }
    return null;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900" data-testid="profile-title">
          Profile
        </h1>
        <p className="text-gray-600 mt-1">
          Manage your account information and preferences
        </p>
      </div>

      {/* Profile Info */}
      <Card className="shadow-soft">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Personal Information</CardTitle>
            <Button
              variant="outline"
              onClick={() => setEditing(!editing)}
              data-testid="edit-profile-btn"
            >
              <Edit3 className="w-4 h-4 mr-2" />
              {editing ? 'Cancel' : 'Edit'}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-6 mb-6">
            {/* Profile Photo Section */}
            <div className="relative">
              <div className="w-20 h-20 rounded-full overflow-hidden bg-gradient-to-r from-blue-600 to-cyan-600 flex items-center justify-center">
                {getProfilePhotoUrl() ? (
                  <img
                    src={getProfilePhotoUrl()}
                    alt="Profile"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span className="text-white text-2xl font-semibold">
                    {getInitials(user?.name)}
                  </span>
                )}
              </div>
              
              {/* Photo Upload/Change Button */}
              <div className="absolute -bottom-1 -right-1">
                <div className="relative">
                  <input
                    type="file"
                    id="photo-upload"
                    accept="image/jpeg,image/jpg,image/png,image/webp"
                    onChange={handlePhotoUpload}
                    className="hidden"
                    disabled={photoUploading}
                  />
                  <label
                    htmlFor="photo-upload"
                    className="flex items-center justify-center w-8 h-8 bg-white border-2 border-gray-300 rounded-full cursor-pointer hover:bg-gray-50 shadow-sm"
                    title="Change profile photo"
                  >
                    {photoUploading ? (
                      <div className="w-3 h-3 border border-gray-400 border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <Camera className="w-3 h-3 text-gray-600" />
                    )}
                  </label>
                </div>
              </div>
            </div>
            
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">{user?.name}</h3>
                  <div className="flex items-center space-x-2 mt-1">
                    {getRoleIcon(user?.role)}
                    <Badge className="bg-blue-100 text-blue-800">
                      {getRoleLabel(user?.role)}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">
                    Member since {new Date(user?.created_at).toLocaleDateString()}
                  </p>
                </div>
                
                {/* Delete Photo Button */}
                {(user?.profile_photo || previewPhoto) && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleDeletePhoto}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    title="Delete profile photo"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
              </div>
              
              {/* Photo Upload Instructions */}
              <div className="mt-3 text-xs text-gray-500">
                <p>Click the camera icon to upload a photo</p>
                <p>Supported: JPG, PNG, WebP (max 5MB)</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label>Full Name</Label>
                {editing ? (
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    data-testid="profile-name-input"
                  />
                ) : (
                  <div className="flex items-center space-x-2 mt-1">
                    <User className="w-4 h-4 text-gray-400" />
                    <span>{user?.name}</span>
                  </div>
                )}
              </div>
              
              <div>
                <Label>Email Address (Optional)</Label>
                {editing ? (
                  <Input
                    type="email"
                    value={formData.email || ''}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    placeholder="Enter email address (optional)"
                    data-testid="profile-email-input"
                  />
                ) : (
                  <div className="flex items-center space-x-2 mt-1">
                    <Mail className="w-4 h-4 text-gray-400" />
                    <span>{user?.email || 'Not provided'}</span>
                  </div>
                )}
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <Label>Mobile Number</Label>
                {editing ? (
                  <Input
                    value={formData.mobile}
                    onChange={(e) => setFormData({...formData, mobile: e.target.value})}
                    data-testid="profile-mobile-input"
                  />
                ) : (
                  <div className="flex items-center space-x-2 mt-1">
                    <Phone className="w-4 h-4 text-gray-400" />
                    <span>{user?.mobile}</span>
                  </div>
                )}
              </div>
              
              <div>
                <Label>GST Number (Optional)</Label>
                {editing ? (
                  <Input
                    value={formData.gst_number}
                    onChange={(e) => setFormData({...formData, gst_number: e.target.value})}
                    placeholder="Enter GST number (e.g., 29ABCDE1234F1Z5)"
                    data-testid="profile-gst-input"
                  />
                ) : (
                  <div className="flex items-center space-x-2 mt-1">
                    <span className="text-gray-600">{user?.gst_number || 'Not provided'}</span>
                  </div>
                )}
              </div>
              
              <div>
                <Label>Role</Label>
                <div className="flex items-center space-x-2 mt-1">
                  {getRoleIcon(user?.role)}
                  <span>{getRoleLabel(user?.role)}</span>
                  <Badge variant="outline">Read Only</Badge>
                </div>
              </div>
            </div>
          </div>
          
          {editing && (
            <div className="flex space-x-2 mt-6 pt-4 border-t">
              <Button 
                onClick={handleSave}
                className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
                data-testid="save-profile-btn"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default Profile;