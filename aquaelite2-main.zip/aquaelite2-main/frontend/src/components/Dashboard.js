import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../App';
import axios from 'axios';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Users, 
  ShoppingCart, 
  Package, 
  IndianRupee,
  TrendingUp,
  TrendingDown,
  Clock,
  CheckCircle,
  Plus,
  RefreshCw,
  Receipt,
  AlertCircle,
  PartyPopper,
  Droplets,
  ArrowDownCircle,
  ArrowUpCircle,
  Banknote,
  Calendar,
  X
} from 'lucide-react';
import { toast } from 'sonner';

function Dashboard() {
  const { API } = useContext(AuthContext);
  const [stats, setStats] = useState({
    total_customers: 0,
    total_jars_delivered_today: 0,
    total_revenue_today: 0,
    pending_orders: 0,
    total_expenses_today: 0,
    outstanding_payments: 0,
    profit_today: 0,
    total_invoices: 0,
    pending_invoices: 0,
    overdue_invoices: 0,
    total_event_orders: 0,
    upcoming_events: 0,
    event_revenue_month: 0,
    event_jars_delivered_today: 0,
    event_empty_jars_collected_today: 0,
    event_revenue_today: 0,
    completed_events_today: 0,
    completed_events_month: 0,
    cancelled_events_today: 0,
    cancelled_events_month: 0,
    advance_forfeited_today: 0,
    advance_forfeited_month: 0
  });
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchDashboardStats = async () => {
    try {
      setRefreshing(true);
      const response = await axios.get(`${API}/dashboard/stats`);
      setStats(response.data);
    } catch (error) {
      console.error('Error fetching dashboard stats:', error);
      toast.error('Failed to load dashboard stats');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchDashboardStats();
  }, []);

  const handleRefresh = () => {
    fetchDashboardStats();
  };

  const statCards = [
    {
      title: 'Total Customers',
      value: stats.total_customers,
      icon: Users,
      color: 'bg-blue-500',
      gradient: 'from-blue-400 to-blue-600',
      change: null,
      testId: 'total-customers-card'
    },
    {
      title: 'Jars Delivered',
      value: stats.total_jars_delivered_today,
      icon: Package,
      color: 'bg-purple-500',
      gradient: 'from-purple-400 to-purple-600',
      change: null,
      testId: 'jars-delivered-card'
    },
    {
      title: 'Today\'s Revenue',
      value: `₹${stats.total_revenue_today.toFixed(2)}`,
      icon: IndianRupee,
      color: 'bg-green-500',
      gradient: 'from-green-400 to-green-600',
      change: null,
      testId: 'todays-revenue-card'
    },
    {
      title: 'Today\'s Expenses',
      value: `₹${stats.total_expenses_today.toFixed(2)}`,
      icon: TrendingDown,
      color: 'bg-red-500',
      gradient: 'from-red-400 to-red-600',
      change: null,
      testId: 'todays-expenses-card'
    },
    {
      title: 'Outstanding Payments',
      value: `₹${stats.outstanding_payments.toFixed(2)}`,
      icon: Clock,
      color: 'bg-yellow-500',
      gradient: 'from-yellow-400 to-yellow-600',
      change: null,
      testId: 'outstanding-payments-card'
    },
    {
      title: 'Today\'s Profit',
      value: `₹${stats.profit_today.toFixed(2)}`,
      icon: TrendingUp,
      color: 'bg-purple-500',
      gradient: 'from-purple-400 to-purple-600',
      change: null,
      testId: 'todays-profit-card'
    }
  ];

  // Event Order Statistics Cards
  const eventStatCards = [
    {
      title: 'Event Jars Delivered Today',
      value: stats.event_jars_delivered_today,
      icon: Droplets,
      color: 'bg-cyan-500',
      gradient: 'from-cyan-400 to-cyan-600',
      description: 'Jars delivered in events today',
      testId: 'event-jars-delivered-card'
    },
    {
      title: 'Empty Jars Collected Today',
      value: stats.event_empty_jars_collected_today,
      icon: ArrowUpCircle,
      color: 'bg-orange-500',
      gradient: 'from-orange-400 to-orange-600',
      description: 'Empty jars collected from events',
      testId: 'event-empty-jars-card'
    },
    {
      title: 'Event Revenue Today',
      value: `₹${stats.event_revenue_today.toFixed(2)}`,
      icon: Banknote,
      color: 'bg-emerald-500',
      gradient: 'from-emerald-400 to-emerald-600',
      description: 'Revenue generated from events today',
      testId: 'event-revenue-today-card'
    },
    {
      title: 'Events Completed Today',
      value: stats.completed_events_today,
      icon: CheckCircle,
      color: 'bg-green-500',
      gradient: 'from-green-400 to-green-600',
      description: 'Total events completed today',
      testId: 'completed-events-today-card'
    },
    {
      title: 'Events Completed This Month',
      value: stats.completed_events_month,
      icon: Calendar,
      color: 'bg-indigo-500',
      gradient: 'from-indigo-400 to-indigo-600',
      description: 'Total events completed this month',
      testId: 'completed-events-month-card'
    },
    {
      title: 'Event Revenue This Month',
      value: `₹${stats.event_revenue_month.toFixed(2)}`,
      icon: IndianRupee,
      color: 'bg-violet-500',
      gradient: 'from-violet-400 to-violet-600',
      description: 'Total revenue generated from events this month',
      testId: 'event-revenue-month-card'
    },
    {
      title: 'Events Cancelled Today',
      value: stats.cancelled_events_today || 0,
      icon: X,
      color: 'bg-red-500',
      gradient: 'from-red-400 to-red-600',
      description: 'Events cancelled today',
      testId: 'cancelled-events-today-card'
    },
    {
      title: 'Advance Forfeited Today',
      value: `₹${(stats.advance_forfeited_today || 0).toFixed(2)}`,
      icon: AlertCircle,
      color: 'bg-red-600',
      gradient: 'from-red-500 to-red-700',
      description: 'Non-refundable advance from cancellations today',
      testId: 'advance-forfeited-today-card'
    },
    {
      title: 'Events Cancelled This Month',
      value: stats.cancelled_events_month || 0,
      icon: X,
      color: 'bg-gray-500',
      gradient: 'from-gray-400 to-gray-600',
      description: 'Total events cancelled this month',
      testId: 'cancelled-events-month-card'
    },
    {
      title: 'Advance Forfeited This Month',
      value: `₹${(stats.advance_forfeited_month || 0).toFixed(2)}`,
      icon: AlertCircle,
      color: 'bg-gray-600',
      gradient: 'from-gray-500 to-gray-700',
      description: 'Total advance forfeited from cancellations this month',
      testId: 'advance-forfeited-month-card'
    }
  ];

  const quickActions = [
    {
      title: 'Add New Customer',
      description: 'Register a new customer',
      icon: Users,
      color: 'bg-blue-500 hover:bg-blue-600',
      href: '/customers',
      testId: 'add-customer-btn'
    },
    {
      title: 'Create Order',
      description: 'Place a new water delivery order',
      icon: Plus,
      color: 'bg-green-500 hover:bg-green-600',
      href: '/orders',
      testId: 'create-order-btn'
    },
    {
      title: 'Record Payment',
      description: 'Record customer payment',
      icon: IndianRupee,
      color: 'bg-teal-500 hover:bg-teal-600',
      href: '/payments',
      testId: 'record-payment-btn'
    },
    {
      title: 'Add Expense',
      description: 'Track business expenses',
      icon: TrendingDown,
      color: 'bg-red-500 hover:bg-red-600',
      href: '/expenses',
      testId: 'add-expense-btn'
    },
    {
      title: 'Create Invoice',
      description: 'Generate customer invoice',
      icon: Receipt,
      color: 'bg-indigo-500 hover:bg-indigo-600',
      href: '/invoices',
      testId: 'create-invoice-btn'
    },
    {
      title: 'Event Order',
      description: 'Bulk orders for events',
      icon: PartyPopper,
      color: 'bg-pink-500 hover:bg-pink-600',
      href: '/events',
      testId: 'create-event-order-btn'
    },
    {
      title: 'Manage Products',
      description: 'Update inventory and pricing',
      icon: Package,
      color: 'bg-purple-500 hover:bg-purple-600',
      href: '/products',
      testId: 'manage-products-btn'
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900" data-testid="dashboard-title">
            Dashboard
          </h1>
          <p className="text-gray-600 mt-1">
            Welcome back! Here's what's happening with your premium water delivery business today.
          </p>
        </div>
        
        <Button 
          onClick={handleRefresh} 
          disabled={refreshing}
          variant="outline"
          className="transition-all duration-200 hover:bg-gray-50"
          data-testid="refresh-stats-btn"
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="relative overflow-hidden shadow-soft hover:shadow-medium transition-all duration-200 card-hover" data-testid={stat.testId}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600 mb-1">
                      {stat.title}
                    </p>
                    <p className="text-2xl font-bold text-gray-900" data-testid={`${stat.testId}-value`}>
                      {stat.value}
                    </p>
                    {stat.change && (
                      <div className="flex items-center mt-2">
                        <TrendingUp className="w-3 h-3 text-green-500 mr-1" />
                        <span className="text-xs text-green-600">{stat.change}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className={`p-3 rounded-full bg-gradient-to-r ${stat.gradient}`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Event Order Statistics Section */}
      <div className="mt-8">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
            <PartyPopper className="w-6 h-6 text-pink-500" />
            <span>Event Order Analytics</span>
          </h2>
          <p className="text-gray-600 mt-1">
            Detailed statistics for event orders delivery and payment collection
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {eventStatCards.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index} className="relative overflow-hidden shadow-soft hover:shadow-medium transition-all duration-200 card-hover" data-testid={stat.testId}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-600 mb-1">
                        {stat.title}
                      </p>
                      <p className="text-2xl font-bold text-gray-900 mb-1" data-testid={`${stat.testId}-value`}>
                        {stat.value}
                      </p>
                      <p className="text-xs text-gray-500">
                        {stat.description}
                      </p>
                    </div>
                    
                    <div className={`p-3 rounded-full bg-gradient-to-r ${stat.gradient} flex-shrink-0 ml-4`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Order Status Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="shadow-soft" data-testid="order-status-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Clock className="w-5 h-5 text-orange-500" />
              <span>Order Status</span>
            </CardTitle>
            <CardDescription>
              Current order processing status
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg border border-yellow-200">
              <div className="flex items-center space-x-3">
                <Clock className="w-4 h-4 text-yellow-600" />
                <span className="text-sm font-medium text-yellow-800">Pending Orders</span>
              </div>
              <span className="text-lg font-bold text-yellow-800" data-testid="pending-orders-count">
                {stats.pending_orders}
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="shadow-soft" data-testid="quick-actions-card">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>
              Frequently used operations
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {quickActions.map((action, index) => {
              const Icon = action.icon;
              return (
                <Button
                  key={index}
                  variant="ghost"
                  className="w-full justify-start p-4 h-auto hover:bg-gray-50 transition-all duration-200"
                  onClick={() => window.location.href = action.href}
                  data-testid={action.testId}
                >
                  <div className={`p-2 rounded-lg ${action.color} mr-3`}>
                    <Icon className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-gray-900">{action.title}</p>
                    <p className="text-xs text-gray-500">{action.description}</p>
                  </div>
                </Button>
              );
            })}
          </CardContent>
        </Card>
      </div>

      {/* Additional Info */}
      <Card className="shadow-soft" data-testid="system-info-card">
        <CardHeader>
          <CardTitle>System Information</CardTitle>
          <CardDescription>
            Application status and information
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div>
              <span className="text-gray-600">Last Updated:</span>
              <p className="font-medium">{new Date().toLocaleString()}</p>
            </div>
            <div>
              <span className="text-gray-600">System Status:</span>
              <div className="flex items-center mt-1">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                <span className="font-medium text-green-600">Operational</span>
              </div>
            </div>
            <div>
              <span className="text-gray-600">Version:</span>
              <p className="font-medium">AquaElite v1.0.0</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default Dashboard;