import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../App';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel,
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Menu, 
  Bell, 
  Search, 
  User, 
  Settings, 
  LogOut,
  Shield,
  Truck
} from 'lucide-react';
import { Input } from '@/components/ui/input';

function Header({ user, onMenuClick }) {
  const { logout, API } = useContext(AuthContext);
  const navigate = useNavigate();

  const getProfilePhotoUrl = () => {
    if (user?.profile_photo) {
      return `${API.replace('/api', '')}${user.profile_photo}`;
    }
    return null;
  };
  
  const getRoleIcon = (role) => {
    switch (role) {
      case 'admin':
        return <Shield className="w-4 h-4" />;
      case 'delivery_boy':
        return <Truck className="w-4 h-4" />;
      default:
        return <User className="w-4 h-4" />;
    }
  };
  
  const getRoleLabel = (role) => {
    switch (role) {
      case 'admin':
        return 'Administrator';
      case 'delivery_boy':
        return 'Delivery Boy';
      case 'customer':
        return 'Customer';
      default:
        return 'User';
    }
  };
  
  const getInitials = (name) => {
    return name
      .split(' ')
      .map(word => word.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-3 sm:px-4 md:px-6">
      {/* Left section */}
      <div className="flex items-center space-x-2 sm:space-x-4">
        {/* Mobile menu button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={onMenuClick}
          className="lg:hidden"
          data-testid="mobile-menu-btn"
        >
          <Menu className="w-5 h-5" />
        </Button>
        
        {/* Search bar */}
        <div className="relative hidden md:block">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input 
            placeholder="Search customers, orders..." 
            className="pl-10 w-64 focus-ring"
            data-testid="search-input"
          />
        </div>
      </div>
      
      {/* Right section */}
      <div className="flex items-center space-x-2 sm:space-x-4">
        {/* Notifications */}
        <Button
          variant="ghost"
          size="sm"
          className="relative"
          data-testid="notifications-btn"
        >
          <Bell className="w-5 h-5" />
          {/* Notification dot */}
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full text-xs flex items-center justify-center">
            <span className="w-1.5 h-1.5 bg-white rounded-full"></span>
          </span>
        </Button>
        
        {/* User dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="p-0 h-auto" data-testid="user-menu-btn">
              <div className="flex items-center space-x-3">
                <Avatar className="w-8 h-8">
                  <AvatarImage src={getProfilePhotoUrl()} alt={user?.name} />
                  <AvatarFallback className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white text-sm">
                    {user?.name ? getInitials(user.name) : 'U'}
                  </AvatarFallback>
                </Avatar>
                
                <div className="hidden md:block text-left">
                  <p className="text-sm font-medium text-gray-900">{user?.name}</p>
                  <div className="flex items-center space-x-1">
                    {getRoleIcon(user?.role)}
                    <p className="text-xs text-gray-500">{getRoleLabel(user?.role)}</p>
                  </div>
                </div>
              </div>
            </Button>
          </DropdownMenuTrigger>
          
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>
              <div className="flex flex-col space-y-1">
                <p className="text-sm font-medium">{user?.name}</p>
                <p className="text-xs text-gray-500">{user?.email}</p>
                <div className="flex items-center space-x-1 mt-1">
                  {getRoleIcon(user?.role)}
                  <span className="text-xs text-gray-500">{getRoleLabel(user?.role)}</span>
                </div>
              </div>
            </DropdownMenuLabel>
            
            <DropdownMenuSeparator />
            
            <DropdownMenuItem 
              className="cursor-pointer" 
              data-testid="profile-menu-item"
              onClick={() => navigate('/profile')}
            >
              <User className="w-4 h-4 mr-2" />
              Profile
            </DropdownMenuItem>
            
            <DropdownMenuItem 
              className="cursor-pointer" 
              data-testid="settings-menu-item"
              onClick={() => navigate('/settings')}
            >
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </DropdownMenuItem>
            
            <DropdownMenuSeparator />
            
            <DropdownMenuItem 
              className="cursor-pointer text-red-600 focus:text-red-600" 
              onClick={logout}
              data-testid="logout-menu-item"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sign out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}

export default Header;