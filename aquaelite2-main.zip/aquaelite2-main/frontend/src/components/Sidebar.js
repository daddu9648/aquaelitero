import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  ShoppingCart, 
  Package, 
  FileText,
  Settings,
  X,
  Droplets,
  TrendingDown,
  Receipt,
  PartyPopper,
  User,
  UserCog,
  Users2,
  BookOpen
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const Sidebar = ({ isOpen, onClose }) => {
  const location = useLocation();
  
  const menuItems = [
    {
      title: 'Dashboard',
      icon: LayoutDashboard,
      path: '/',
      active: location.pathname === '/'
    },
    {
      title: 'Profile',
      icon: User,
      path: '/profile',
      active: location.pathname === '/profile'
    },
    {
      title: 'User Management',
      icon: UserCog,
      path: '/users',
      active: location.pathname === '/users'
    },
    {
      title: 'Group Management',
      icon: Users2,
      path: '/groups',
      active: location.pathname === '/groups'
    },
    {
      title: 'Customers',
      icon: Users,
      path: '/customers',
      active: location.pathname === '/customers'
    },
    {
      title: 'Order Book',
      icon: BookOpen,
      path: '/order-book',
      active: location.pathname === '/order-book'
    },
    {
      title: 'Products',
      icon: Package,
      path: '/products',
      active: location.pathname === '/products'
    },
    {
      title: 'Payment Reconciliation',
      icon: Receipt,
      path: '/payment-reconciliation',
      active: location.pathname === '/payment-reconciliation'
    },
    {
      title: 'Expenses',
      icon: TrendingDown,
      path: '/expenses',
      active: location.pathname === '/expenses'
    },
    {
      title: 'Invoices',
      icon: Receipt,
      path: '/invoices',
      active: location.pathname === '/invoices'
    },
    {
      title: 'Events',
      icon: PartyPopper,
      path: '/events',
      active: location.pathname === '/events'
    },
    {
      title: 'Reports',
      icon: FileText,
      path: '/reports',
      active: location.pathname === '/reports'
    },
    {
      title: 'Settings',
      icon: Settings,
      path: '/settings',
      active: location.pathname === '/settings'
    }
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40 bg-black bg-opacity-50 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        {/* Header */}
        <div className="flex items-center justify-between h-16 px-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="flex items-center justify-center w-8 h-8 bg-gradient-to-br from-blue-50 to-cyan-50 shadow-md p-1 border border-blue-200" style={{borderRadius: '50%'}}>
              <img 
                src="/aquaelite-logo.png" 
                alt="AquaElite Logo" 
                className="w-full h-full object-contain"
                style={{borderRadius: '50%'}}
              />
            </div>
            <span className="text-xl font-bold text-gray-900">AquaElite</span>
          </div>
          
          {/* Mobile close button */}
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="lg:hidden"
            data-testid="sidebar-close-btn"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>
        
        {/* Navigation */}
        <nav className="flex-1 px-4 py-6 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={onClose}
                data-testid={`sidebar-${item.title.toLowerCase()}-link`}
                className={cn(
                  "flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                  item.active
                    ? "bg-blue-50 text-blue-700 border-r-2 border-blue-600"
                    : "text-gray-700 hover:bg-gray-50 hover:text-gray-900"
                )}
              >
                <Icon className={cn(
                  "w-5 h-5",
                  item.active ? "text-blue-600" : "text-gray-400"
                )} />
                <span>{item.title}</span>
              </Link>
            );
          })}
        </nav>
        
        {/* Footer */}
        <div className="p-4 border-t border-gray-200">
          <div className="text-xs text-gray-500 text-center">
            <p>Version 1.0.0</p>
            <p className="mt-1">© 2024 AquaElite</p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;