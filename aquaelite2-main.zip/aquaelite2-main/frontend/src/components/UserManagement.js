import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../App';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { 
  Users, 
  UserPlus, 
  Trash2, 
  Shield, 
  Truck, 
  User, 
  Mail, 
  Phone,
  Plus,
  Settings,
  Check,
  X,
  Key
} from 'lucide-react';
import { toast } from 'sonner';

function UserManagement() {
  const { user, API, register } = useContext(AuthContext);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showPermissionDialog, setShowPermissionDialog] = useState(false);
  const [showResetPasswordDialog, setShowResetPasswordDialog] = useState(false);
  const [selectedUserForPermissions, setSelectedUserForPermissions] = useState(null);
  const [selectedUserForPasswordReset, setSelectedUserForPasswordReset] = useState(null);
  const [newPassword, setNewPassword] = useState('');
  const [availablePermissions, setAvailablePermissions] = useState({});
  const [userPermissions, setUserPermissions] = useState([]);
  const [permissionLoading, setPermissionLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    mobile: '',
    password: '',
    role: 'manager'
  });

  // Check if current user is admin
  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    if (isAdmin) {
      fetchUsers();
    }
  }, [isAdmin]);

  const fetchUsers = async () => {
    try {
      const response = await fetch(`${API}/users`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        }
      });
      
      if (response.ok) {
        const usersData = await response.json();
        setUsers([...usersData]);
      } else {
        throw new Error('Failed to fetch users');
      }
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('Failed to load users');
    } finally {
      setLoading(false);
    }
  };

  const handleAddUser = async (e) => {
    e.preventDefault();
    
    try {
      // Clean form data - convert empty email to null
      const cleanedData = {
        ...formData,
        email: formData.email.trim() === '' ? null : formData.email
      };
      
      const result = await register(cleanedData);
      
      if (result.success) {
        toast.success('User added successfully!');
        setShowAddForm(false);
        setFormData({ name: '', email: '', mobile: '', password: '', role: 'delivery_boy' });
        fetchUsers(); // Refresh user list
      } else {
        toast.error(result.error || 'Failed to add user');
      }
    } catch (error) {
      console.error('Error adding user:', error);
      toast.error('Failed to add user');
    }
  };

  const handleDeleteUser = async (userId, userName) => {
    try {
      const response = await fetch(`${API}/users/${userId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        toast.success(`User ${userName} deleted successfully`);
        fetchUsers(); // Refresh user list
      } else {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to delete user');
      }
    } catch (error) {
      console.error('Error deleting user:', error);
      toast.error(error.message || 'Failed to delete user');
    }
  };

  const fetchAvailablePermissions = async () => {
    try {
      const response = await fetch(`${API}/permissions/available`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setAvailablePermissions(data);
      }
    } catch (error) {
      console.error('Error fetching available permissions:', error);
    }
  };

  const handleManagePermissions = async (userItem) => {
    setSelectedUserForPermissions(userItem);
    setPermissionLoading(true);
    setShowPermissionDialog(true);

    try {
      // Fetch available permissions if not loaded
      if (Object.keys(availablePermissions).length === 0) {
        await fetchAvailablePermissions();
      }

      // Fetch user's current permissions
      const response = await fetch(`${API}/users/${userItem.id}/permissions`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setUserPermissions(data.permissions);
      }
    } catch (error) {
      console.error('Error fetching user permissions:', error);
      toast.error('Failed to load user permissions');
    } finally {
      setPermissionLoading(false);
    }
  };

  const handlePermissionToggle = (permissionKey) => {
    setUserPermissions(prev => {
      if (prev.includes(permissionKey)) {
        return prev.filter(p => p !== permissionKey);
      } else {
        return [...prev, permissionKey];
      }
    });
  };

  const handleSavePermissions = async () => {
    if (!selectedUserForPermissions) return;

    setPermissionLoading(true);
    try {
      const response = await fetch(`${API}/users/${selectedUserForPermissions.id}/permissions`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ permissions: userPermissions })
      });
      
      if (response.ok) {
        toast.success('Permissions updated successfully!');
        setShowPermissionDialog(false);
        fetchUsers(); // Refresh user list
      } else {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to update permissions');
      }
    } catch (error) {
      console.error('Error updating permissions:', error);
      toast.error(error.message || 'Failed to update permissions');
    } finally {
      setPermissionLoading(false);
    }
  };

  const handleResetPassword = async () => {
    if (!newPassword || newPassword.length < 6) {
      toast.error('Password must be at least 6 characters long');
      return;
    }

    try {
      const response = await fetch(`${API}/users/${selectedUserForPasswordReset.id}/reset-password`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ new_password: newPassword })
      });

      if (response.ok) {
        const result = await response.json();
        toast.success(result.message || 'Password reset successfully!');
        setShowResetPasswordDialog(false);
        setNewPassword('');
        setSelectedUserForPasswordReset(null);
      } else {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to reset password');
      }
    } catch (error) {
      console.error('Error resetting password:', error);
      toast.error(error.message || 'Failed to reset password');
    }
  };

  const openResetPasswordDialog = (userToReset) => {
    setSelectedUserForPasswordReset(userToReset);
    setNewPassword('');
    setShowResetPasswordDialog(true);
  };

  const getRoleIcon = (role) => {
    switch (role) {
      case 'admin': return <Shield className="w-4 h-4" />;
      case 'manager': return <Users className="w-4 h-4" />;
      case 'employee': return <User className="w-4 h-4" />;
      case 'delivery_boy': return <Truck className="w-4 h-4" />;
      default: return <User className="w-4 h-4" />;
    }
  };

  const getRoleLabel = (role) => {
    switch (role) {
      case 'admin': return 'Administrator';
      case 'manager': return 'Manager';
      case 'employee': return 'Employee';
      case 'delivery_boy': return 'Delivery Boy';
      default: return 'User';
    }
  };

  const getRoleBadgeColor = (role) => {
    switch (role) {
      case 'admin': return 'bg-red-100 text-red-800';
      case 'manager': return 'bg-purple-100 text-purple-800';
      case 'employee': return 'bg-green-100 text-green-800';
      case 'delivery_boy': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getInitials = (name) => {
    return name?.split(' ').map(word => word.charAt(0)).join('').toUpperCase().slice(0, 2) || 'U';
  };

  // Redirect if not admin
  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Shield className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Access Denied</h3>
          <p className="text-gray-600">You don't have permission to access user management.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900" data-testid="user-management-title">
            User Management
          </h1>
          <p className="text-gray-600 mt-1">
            Manage managers and delivery boys
          </p>
        </div>
        
        <Button 
          onClick={() => setShowAddForm(!showAddForm)}
          className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
          data-testid="add-user-btn"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add User
        </Button>
      </div>

      {/* Add User Form */}
      {showAddForm && (
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <UserPlus className="w-5 h-5" />
              <span>Add New User</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddUser} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    required
                    data-testid="user-name-input"
                  />
                </div>
                
                <div>
                  <Label htmlFor="email">Email Address (Optional)</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    placeholder="Enter email address (optional)"
                    data-testid="user-email-input"
                  />
                </div>
                
                <div>
                  <Label htmlFor="mobile">Mobile Number</Label>
                  <Input
                    id="mobile"
                    type="tel"
                    value={formData.mobile}
                    onChange={(e) => setFormData({...formData, mobile: e.target.value})}
                    required
                    data-testid="user-mobile-input"
                  />
                </div>
                
                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                    required
                    data-testid="user-password-input"
                  />
                </div>
                
                <div>
                  <Label htmlFor="role">Role</Label>
                  <Select 
                    value={formData.role} 
                    onValueChange={(value) => setFormData({...formData, role: value})}
                  >
                    <SelectTrigger data-testid="user-role-select">
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="manager">👨‍💼 Manager</SelectItem>
                      <SelectItem value="employee">👥 Employee</SelectItem>
                      <SelectItem value="delivery_boy">🚚 Delivery Boy</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex space-x-2 pt-4">
                <Button 
                  type="submit" 
                  className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
                  data-testid="save-user-btn"
                >
                  Add User
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowAddForm(false)}
                  data-testid="cancel-user-btn"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Users List */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Users className="w-5 h-5" />
            <span>All Users ({users.length})</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {users.length === 0 ? (
            <div className="text-center py-8">
              <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No users found</p>
            </div>
          ) : (
            <div className="space-y-4">
              {users.map((userItem) => (
                <div 
                  key={userItem.id} 
                  className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50"
                >
                  <div className="flex items-center space-x-4">
                    <Avatar className="w-12 h-12">
                      <AvatarFallback className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white">
                        {getInitials(userItem.name)}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div>
                      <div className="flex items-center space-x-3">
                        <h3 className="font-medium text-gray-900">{userItem.name}</h3>
                        <Badge className={getRoleBadgeColor(userItem.role)}>
                          <span className="flex items-center space-x-1">
                            {getRoleIcon(userItem.role)}
                            <span>{getRoleLabel(userItem.role)}</span>
                          </span>
                        </Badge>
                      </div>
                      
                      <div className="flex items-center space-x-4 mt-1 text-sm text-gray-600">
                        {userItem.email && (
                          <div className="flex items-center space-x-1">
                            <Mail className="w-3 h-3" />
                            <span>{userItem.email}</span>
                          </div>
                        )}
                        <div className="flex items-center space-x-1">
                          <Phone className="w-3 h-3" />
                          <span>{userItem.mobile}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    {userItem.id !== user.id && (
                      <>
                        {/* Show permissions button for all users */}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleManagePermissions(userItem)}
                          className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                          data-testid={`manage-permissions-${userItem.id}-btn`}
                          title="Manage Permissions"
                        >
                          <Settings className="w-4 h-4" />
                        </Button>
                        
                        {/* Show reset password button for all users */}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openResetPasswordDialog(userItem)}
                          className="text-green-600 hover:text-green-700 hover:bg-green-50"
                          data-testid={`reset-password-${userItem.id}-btn`}
                          title="Reset Password"
                        >
                          <Shield className="w-4 h-4" />
                        </Button>
                        
                        {/* SECURITY: Hide delete button for admin users */}
                        {userItem.role !== 'admin' && (
                          <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                              data-testid={`delete-user-${userItem.id}-btn`}
                              title="Delete User"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete User</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete {userItem.name}? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction 
                                onClick={() => handleDeleteUser(userItem.id, userItem.name)}
                                className="bg-red-600 hover:bg-red-700"
                                data-testid={`confirm-delete-user-${userItem.id}`}
                              >
                                Delete
                              </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                        )}
                      </>
                    )}
                    
                    {userItem.id === user.id && (
                      <Badge variant="outline" className="text-blue-600">
                        You
                      </Badge>
                    )}
                    
                    {/* Show protected badge for admin users (other than current user) */}
                    {userItem.id !== user.id && userItem.role === 'admin' && (
                      <Badge variant="outline" className="text-green-600 border-green-600">
                        Protected
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Permission Management Dialog */}
      <Dialog open={showPermissionDialog} onOpenChange={setShowPermissionDialog}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Settings className="w-5 h-5" />
              <span>Manage Permissions - {selectedUserForPermissions?.name}</span>
            </DialogTitle>
            <DialogDescription>
              Configure what this user can and cannot do in the system
            </DialogDescription>
          </DialogHeader>

          {permissionLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              <span className="ml-2">Loading permissions...</span>
            </div>
          ) : (
            <div className="space-y-6">
              {availablePermissions && Object.entries(availablePermissions).map(([categoryKey, category]) => (
                <div key={categoryKey} className="border rounded-lg p-4">
                  <h4 className="font-medium text-gray-900 mb-3">{category.label}</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {category.permissions.map((permission) => (
                      <div 
                        key={permission.key}
                        className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50"
                      >
                        <span className="text-sm font-medium text-gray-700">
                          {permission.label}
                        </span>
                        <button
                          onClick={() => handlePermissionToggle(permission.key)}
                          className={`flex items-center justify-center w-6 h-6 rounded ${
                            userPermissions.includes(permission.key)
                              ? 'bg-green-500 text-white'
                              : 'bg-gray-200 text-gray-400'
                          }`}
                        >
                          {userPermissions.includes(permission.key) ? (
                            <Check className="w-4 h-4" />
                          ) : (
                            <X className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              ))}

              {/* Admin Override Option */}
              {selectedUserForPermissions?.role === 'admin' && (
                <div className="border border-red-200 rounded-lg p-4 bg-red-50">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-red-900">Administrator Access</h4>
                      <p className="text-sm text-red-700">
                        Grants full access to all features (overrides individual permissions)
                      </p>
                    </div>
                    <button
                      onClick={() => handlePermissionToggle('admin.*')}
                      className={`flex items-center justify-center w-6 h-6 rounded ${
                        userPermissions.includes('admin.*')
                          ? 'bg-red-500 text-white'
                          : 'bg-gray-200 text-gray-400'
                      }`}
                    >
                      {userPermissions.includes('admin.*') ? (
                        <Check className="w-4 h-4" />
                      ) : (
                        <X className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
              )}

              {/* Permission Summary */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h5 className="font-medium text-blue-900 mb-2">
                  Active Permissions ({userPermissions.length})
                </h5>
                <div className="flex flex-wrap gap-2">
                  {userPermissions.length > 0 ? (
                    userPermissions.map((perm) => (
                      <span 
                        key={perm}
                        className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded"
                      >
                        {perm}
                      </span>
                    ))
                  ) : (
                    <span className="text-blue-700 text-sm">No permissions assigned</span>
                  )}
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowPermissionDialog(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSavePermissions}
              disabled={permissionLoading}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {permissionLoading ? 'Saving...' : 'Save Permissions'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reset Password Dialog */}
      <Dialog open={showResetPasswordDialog} onOpenChange={setShowResetPasswordDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Reset Password</DialogTitle>
            <DialogDescription>
              Reset password for: <strong>{selectedUserForPasswordReset?.name}</strong>
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="newPassword">New Password</Label>
              <Input
                id="newPassword"
                type="password"
                placeholder="Enter new password (min 6 characters)"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="mt-1"
              />
              <p className="text-xs text-gray-500 mt-1">
                Password must be at least 6 characters long
              </p>
            </div>
            
            {selectedUserForPasswordReset && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-md p-3">
                <p className="text-sm text-yellow-800">
                  <strong>Note:</strong> After reset, inform the user about their new password via call or WhatsApp.
                </p>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowResetPasswordDialog(false);
                setNewPassword('');
                setSelectedUserForPasswordReset(null);
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={handleResetPassword}
              className="bg-green-600 hover:bg-green-700"
              disabled={!newPassword || newPassword.length < 6}
            >
              Reset Password
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default UserManagement;