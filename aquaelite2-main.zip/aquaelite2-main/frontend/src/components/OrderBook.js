import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../App';
import axios from 'axios';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  BookOpen,
  Truck, 
  Package,
  IndianRupee,
  Clock,
  CheckCircle,
  ArrowUpCircle,
  ArrowDownCircle,
  Zap,
  Users,
  PartyPopper,
  Calendar,
  MapPin,
  Filter,
  RefreshCw,
  Search,
  Banknote,
  Plus,
  X
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

function OrderBook() {
  const { API, user } = useContext(AuthContext);
  const [activeTab, setActiveTab] = useState('customers');
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterDate, setFilterDate] = useState('all');

  // Data states
  const [regularOrders, setRegularOrders] = useState([]);
  const [eventOrders, setEventOrders] = useState([]);
  const [deliveryBoyOrders, setDeliveryBoyOrders] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [deliveryBoys, setDeliveryBoys] = useState([]);
  const [scheduledDeliveries, setScheduledDeliveries] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);

  // Dialog states for customer management
  const [showQuickDeliveryDialog, setShowQuickDeliveryDialog] = useState(false);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showEmptyJarDialog, setShowEmptyJarDialog] = useState(false);

  // Form states for customer operations
  const [quickDeliveryForm, setQuickDeliveryForm] = useState({
    customer_id: '',
    jars_delivered: '',
    delivery_notes: '',
    payment_amount: '',
    payment_mode: 'cash',
    delivery_date: new Date().toISOString().split('T')[0], // Today's date
    delivery_time_slot: 'morning', // morning, afternoon, evening
    is_scheduled: false // immediate or scheduled delivery
  });

  const [paymentForm, setPaymentForm] = useState({
    customer_id: '',
    amount_received: '',
    payment_mode: 'cash',
    payment_notes: ''
  });

  const [emptyJarForm, setEmptyJarForm] = useState({
    customer_id: '',
    jars_collected: '',
    collection_notes: ''
  });

  // Fetch all data
  const fetchData = async () => {
    try {
      setLoading(true);
      const [ordersRes, eventsRes, customersRes, deliveryBoysRes, scheduledRes] = await Promise.all([
        axios.get(`${API}/orders`).catch(() => ({ data: [] })),
        axios.get(`${API}/event-orders`),
        axios.get(`${API}/customers`),
        axios.get(`${API}/delivery-boys`).catch(() => ({ data: [] })),
        axios.get(`${API}/scheduled-deliveries`).catch(() => ({ data: [] }))
      ]);
      
      setRegularOrders(ordersRes.data);
      setEventOrders(eventsRes.data);
      setCustomers(customersRes.data);
      setDeliveryBoys(deliveryBoysRes.data);
      setScheduledDeliveries(scheduledRes.data);

      // Filter delivery boy orders if user is delivery boy
      if (user?.role === 'delivery_boy') {
        const userEvents = eventsRes.data.filter(event => 
          event.delivery_boy_id === user.id
        );
        setDeliveryBoyOrders(userEvents);
      }
    } catch (error) {
      console.error('Error fetching order book data:', error);
      toast.error('Failed to load order book');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Quick Delivery Function for Customers
  const handleCustomerQuickDelivery = async () => {
    try {
      const jarsDelivered = parseInt(quickDeliveryForm.jars_delivered) || 1;
      const paymentAmount = parseFloat(quickDeliveryForm.payment_amount) || 0;
      
      if (!selectedCustomer) {
        toast.error('Please select a customer');
        return;
      }

      const deliveryData = {
        customer_id: selectedCustomer.id,
        customer_name: selectedCustomer.name,
        jars_delivered: jarsDelivered,
        delivery_notes: quickDeliveryForm.delivery_notes,
        delivered_by: user?.id,
        delivered_by_name: user?.name,
        payment_amount: paymentAmount,
        payment_mode: quickDeliveryForm.payment_mode
      };

      if (quickDeliveryForm.is_scheduled) {
        // Schedule delivery for later
        const timeSlotMapping = {
          'morning': '09:00:00',
          'afternoon': '14:00:00', 
          'evening': '18:00:00'
        };

        deliveryData.scheduled_date = quickDeliveryForm.delivery_date;
        deliveryData.scheduled_time_slot = quickDeliveryForm.delivery_time_slot;
        deliveryData.scheduled_time = timeSlotMapping[quickDeliveryForm.delivery_time_slot];
        deliveryData.delivery_status = 'scheduled';
        deliveryData.scheduled_by = user?.id;
        deliveryData.scheduled_by_name = user?.name;
        deliveryData.scheduled_at = new Date().toISOString();

        // Create scheduled delivery
        await axios.post(`${API}/scheduled-deliveries`, deliveryData);
        
        toast.success(`Delivery scheduled for ${selectedCustomer.name} on ${quickDeliveryForm.delivery_date} (${quickDeliveryForm.delivery_time_slot})`);
      } else {
        // Immediate delivery
        deliveryData.delivered_at = new Date().toISOString();
        deliveryData.delivery_status = 'completed';

        // Record immediate delivery
        await axios.post(`${API}/deliveries`, deliveryData);
        
        // Get product price for customer's water type to calculate charge
        const productsRes = await axios.get(`${API}/products`);
        const product = productsRes.data.find(p => p.capacity === selectedCustomer.water_type && p.is_active);
        const pricePerJar = product ? product.price : 25; // Default to 25 if product not found
        const deliveryCharge = jarsDelivered * pricePerJar;
        
        // Add delivery charge to customer's balance (customer owes this amount)
        await axios.post(`${API}/customers/${selectedCustomer.id}/update-balance`, {
          type: 'charge',
          amount: deliveryCharge,
          notes: `Delivery charge for ${jarsDelivered} jars @ ₹${pricePerJar} per jar (Quick Delivery by ${user?.name})`
        });
        
        // Update customer's empty jar balance (add delivered jars to empty jar count)
        await axios.post(`${API}/customers/${selectedCustomer.id}/update-balance`, {
          type: 'empty_jars_add',
          amount: jarsDelivered,
          notes: `${jarsDelivered} jars delivered during quick delivery by ${user?.name}`
        });

        // Update customer balance if payment received
        if (paymentAmount > 0) {
          await axios.post(`${API}/customers/${selectedCustomer.id}/update-balance`, {
            type: 'payment',
            amount: paymentAmount,
            notes: `Payment collected during quick delivery by ${user?.name}`
          });

          // Record payment in payment collection for reporting
          await axios.post(`${API}/customer-payments`, {
            customer_id: selectedCustomer.id,
            customer_name: selectedCustomer.name,
            amount: paymentAmount,
            payment_mode: quickDeliveryForm.payment_mode,
            collected_by: user?.id,
            collected_by_name: user?.name,
            payment_type: 'quick_delivery_payment',
            notes: `Payment collected during quick delivery - ${jarsDelivered} jars delivered`,
            collected_at: new Date().toISOString()
          });
        }

        toast.success(`Quick delivery completed! ${jarsDelivered} jars delivered to ${selectedCustomer.name}. Charge: ₹${deliveryCharge.toFixed(2)}`);
      }

      setShowQuickDeliveryDialog(false);
      setQuickDeliveryForm({ 
        customer_id: '', 
        jars_delivered: '', 
        delivery_notes: '', 
        payment_amount: '', 
        payment_mode: 'cash',
        delivery_date: new Date().toISOString().split('T')[0],
        delivery_time_slot: 'morning',
        is_scheduled: false
      });
      fetchData();
    } catch (error) {
      console.error('Error completing quick delivery:', error);
      toast.error('Failed to complete quick delivery');
    }
  };

  // Quick Delivery Function for Orders
  const handleQuickDelivery = async (order, orderType = 'regular') => {
    try {
      const jarsDelivered = parseInt(quickDeliveryForm.jars_delivered) || 1;
      
      if (!order) {
        toast.error('Please select an order');
        return;
      }

      // Update order status to delivered
      if (orderType === 'event') {
        await axios.put(`${API}/event-orders/${order.id}`, {
          event_status: 'completed',
          jars_delivered: jarsDelivered,
          // Note: empty_jars_collected should be updated separately via Empty Jar Collection button
          delivered_at: new Date().toISOString(),
          delivered_by: user?.id,
          delivered_by_name: user?.name,
          delivery_notes: quickDeliveryForm.delivery_notes,
          delivery_completed_at: new Date().toISOString()
        });
      } else {
        await axios.put(`${API}/orders/${order.id}`, {
          delivery_status: 'delivered',
          delivered_at: new Date().toISOString(),
          delivered_by: user?.id,
          delivered_by_name: user?.name,
          delivery_notes: quickDeliveryForm.delivery_notes
        });
      }

      // Create delivery record
      const deliveryData = {
        customer_id: order.customer_id,
        customer_name: order.customer_name || order.event_name,
        jars_delivered: jarsDelivered,
        delivery_notes: quickDeliveryForm.delivery_notes,
        delivered_by: user?.id,
        delivered_by_name: user?.name,
        delivered_at: new Date().toISOString(),
        order_id: order.id,
        order_type: orderType
      };

      await axios.post(`${API}/deliveries`, deliveryData);

      toast.success(`Quick delivery completed! ${jarsDelivered} jars delivered to ${order.customer_name || order.event_name}`);
      setShowQuickDeliveryDialog(false);
      setQuickDeliveryForm({ jars_delivered: '', delivery_notes: '' });
      fetchData();
    } catch (error) {
      console.error('Error completing quick delivery:', error);
      toast.error('Failed to complete quick delivery');
    }
  };

  // Payment Collection Function for Customers
  const handleCustomerPaymentCollection = async () => {
    try {
      const paymentAmount = parseFloat(paymentForm.amount_received) || 0;
      
      if (paymentAmount <= 0) {
        toast.error('Please enter a valid payment amount');
        return;
      }

      if (!selectedCustomer) {
        toast.error('Please select a customer');
        return;
      }

      if (!user?.id || !user?.name) {
        toast.error('User information not available. Please refresh and try again.');
        return;
      }

      // Update customer balance
      await axios.post(`${API}/customers/${selectedCustomer.id}/update-balance`, {
        type: 'payment',
        amount: paymentAmount,
        notes: paymentForm.payment_notes || `Payment collected by ${user?.name}`
      });

      // Record customer payment
      await axios.post(`${API}/customer-payments`, {
        customer_id: selectedCustomer.id,
        customer_name: selectedCustomer.name,
        amount: paymentAmount,
        payment_mode: paymentForm.payment_mode,
        collected_by: user?.id,
        collected_by_name: user?.name,
        payment_type: 'customer_payment',
        notes: paymentForm.payment_notes,
        collected_at: new Date().toISOString()
      });

      toast.success(`Payment collected successfully! ₹${paymentAmount.toFixed(2)} received from ${selectedCustomer.name}`);
      setShowPaymentDialog(false);
      setPaymentForm({ customer_id: '', amount_received: '', payment_mode: 'cash', payment_notes: '' });
      fetchData(); // Refresh data to show updated payment status
    } catch (error) {
      console.error('Error collecting payment:', error);
      toast.error('Failed to collect payment');
    }
  };

  // Payment Collection Function for Orders
  const handlePaymentCollection = async (order, orderType = 'regular') => {
    try {
      const paymentAmount = parseFloat(paymentForm.amount_received) || 0;
      
      if (paymentAmount <= 0) {
        toast.error('Please enter a valid payment amount');
        return;
      }

      if (orderType === 'event') {
        // Validate payment amount against balance due for event orders
        const balanceDue = order.balance_amount || (order.total_amount - order.advance_amount) || 0;
        
        if (paymentAmount > balanceDue) {
          toast.error(`Payment amount ₹${paymentAmount.toFixed(2)} exceeds balance due ₹${balanceDue.toFixed(2)}`);
          return;
        }
        
        if (balanceDue <= 0) {
          toast.error('No outstanding balance for this event order');
          return;
        }
        // Update event order payment status
        const totalAmount = order.total_amount || 0;
        const advanceAmount = order.advance_amount || 0;
        const previousPayments = order.last_payment_amount || 0;
        const newBalanceAmount = totalAmount - advanceAmount - previousPayments - paymentAmount;
        
        let paymentStatus = 'pending';
        if (newBalanceAmount <= 0) {
          paymentStatus = 'paid';
        } else if (paymentAmount > 0) {
          paymentStatus = 'partial_paid';
        }
        
        await axios.put(`${API}/event-orders/${order.id}`, {
          payment_status: paymentStatus,
          balance_amount: newBalanceAmount,
          last_payment_amount: (previousPayments + paymentAmount),
          last_payment_date: new Date().toISOString(),
          last_payment_mode: paymentForm.payment_mode,
          payment_collected_by: user?.name
        });
      } else {
        // Update regular order payment status
        const totalAmount = order.total_amount || 0;
        let paymentStatus = 'pending';
        if (paymentAmount >= totalAmount) {
          paymentStatus = 'paid';
        } else if (paymentAmount > 0) {
          paymentStatus = 'partial_paid';
        }
        
        await axios.put(`${API}/orders/${order.id}`, {
          payment_status: paymentStatus,
          last_payment_amount: paymentAmount,
          last_payment_date: new Date().toISOString(),
          last_payment_mode: paymentForm.payment_mode,
          payment_collected_by: user?.name
        });
      }

      // Record payment in payments table
      await axios.post(`${API}/customer-payments`, {
        customer_id: order.customer_id,
        customer_name: order.customer_name || order.event_name,
        amount: paymentAmount,
        payment_mode: paymentForm.payment_mode,
        collected_by: user?.id,
        collected_by_name: user?.name,
        payment_type: orderType === 'event' ? 'event_order_payment' : 'quick_delivery_payment',
        notes: paymentForm.payment_notes,
        collected_at: new Date().toISOString(),
        event_id: orderType === 'event' ? order.id : undefined,
        event_name: orderType === 'event' ? order.event_name : undefined,
        order_id: orderType === 'regular' ? order.id : undefined,
        order_type: orderType
      });

      toast.success(`Payment collected successfully! ₹${paymentAmount.toFixed(2)} received from ${order.customer_name || order.event_name}`);
      setShowPaymentDialog(false);
      setPaymentForm({ customer_id: '', amount_received: '', payment_mode: 'cash', payment_notes: '' });
      fetchData();
    } catch (error) {
      console.error('Error collecting payment:', error);
      toast.error('Failed to collect payment');
    }
  };

  // Empty Jar Collection Function for Customers
  const handleCustomerEmptyJarCollection = async () => {
    try {
      const jarsCollected = parseInt(emptyJarForm.jars_collected) || 0;
      
      if (jarsCollected <= 0) {
        toast.error('Please enter valid number of empty jars collected');
        return;
      }

      if (!selectedCustomer) {
        toast.error('Please select a customer');
        return;
      }

      // Update customer empty jar balance
      await axios.post(`${API}/customers/${selectedCustomer.id}/update-balance`, {
        type: 'empty_jar_collection',
        jar_count: jarsCollected,
        notes: emptyJarForm.collection_notes || `Empty jars collected by ${user?.name}`
      });

      // Record the collection
      await axios.post(`${API}/empty-jar-collections`, {
        customer_id: selectedCustomer.id,
        customer_name: selectedCustomer.name,
        jars_collected: jarsCollected,
        collection_notes: emptyJarForm.collection_notes,
        collected_by: user?.id,
        collected_by_name: user?.name,
        collected_at: new Date().toISOString()
      });

      toast.success(`${jarsCollected} empty jars collected from ${selectedCustomer.name}`);
      setShowEmptyJarDialog(false);
      setEmptyJarForm({ customer_id: '', jars_collected: '', collection_notes: '' });
      fetchData();
    } catch (error) {
      console.error('Error collecting empty jars:', error);
      toast.error('Failed to collect empty jars');
    }
  };

  // Empty Jar Collection Function for Orders
  const handleEmptyJarCollection = async (order, orderType = 'regular') => {
    try {
      const jarsCollected = parseInt(emptyJarForm.jars_collected) || 0;
      
      if (jarsCollected <= 0) {
        toast.error('Please enter valid number of empty jars collected');
        return;
      }

      if (orderType === 'event') {
        // Update event order empty jar collection
        await axios.put(`${API}/event-orders/${order.id}`, {
          empty_jars_collected: (order.empty_jars_collected || 0) + jarsCollected,
          updated_at: new Date().toISOString()
        });

        // Update customer empty jar balance
        await axios.post(`${API}/customers/${order.customer_id}/update-balance`, {
          type: 'empty_jar_collection',
          jar_count: jarsCollected,
          notes: emptyJarForm.collection_notes || `Empty jars collected from event: ${order.event_name} by ${user?.name}`
        });

        // Record the collection for event orders
        await axios.post(`${API}/empty-jar-collections`, {
          customer_id: order.customer_id,
          customer_name: order.customer_name,
          event_order_id: order.id,
          event_name: order.event_name,
          jars_collected: jarsCollected,
          collection_notes: emptyJarForm.collection_notes,
          collected_by: user?.id,
          collected_by_name: user?.name,
          collected_at: new Date().toISOString()
        });
      } else {
        // Handle regular order empty jar collection
        await axios.put(`${API}/orders/${order.id}`, {
          empty_jars_collected: jarsCollected,
          collection_completed_at: new Date().toISOString()
        });

        // Update customer empty jar balance
        await axios.post(`${API}/customers/${order.customer_id}/update-balance`, {
          type: 'empty_jar_collection',
          jar_count: jarsCollected,
          notes: emptyJarForm.collection_notes || `Empty jars collected from order by ${user?.name}`
        });

        // Record the collection for regular orders
        await axios.post(`${API}/empty-jar-collections`, {
          customer_id: order.customer_id,
          customer_name: order.customer_name,
          order_id: order.id,
          jars_collected: jarsCollected,
          collection_notes: emptyJarForm.collection_notes,
          collected_by: user?.id,
          collected_by_name: user?.name,
          collected_at: new Date().toISOString()
        });
      }

      toast.success(`${jarsCollected} empty jars collected from ${order.customer_name || order.event_name}`);
      setShowEmptyJarDialog(false);
      setEmptyJarForm({ customer_id: '', jars_collected: '', collection_notes: '' });
      fetchData();
    } catch (error) {
      console.error('Error collecting empty jars:', error);
      toast.error('Failed to collect empty jars');
    }
  };

  // Filter functions
  const filterOrders = (orders, type = 'regular') => {
    return orders.filter(order => {
      const matchesSearch = searchTerm === '' || 
        order.customer_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.event_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.id?.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus = filterStatus === 'all' || 
        (type === 'regular' ? order.delivery_status === filterStatus : order.event_status === filterStatus);

      const matchesDate = filterDate === 'all' || 
        (filterDate === 'today' && isToday(order.created_at || order.event_date)) ||
        (filterDate === 'pending' && (order.delivery_status === 'pending' || order.event_status === 'confirmed'));

      return matchesSearch && matchesStatus && matchesDate;
    });
  };

  const isToday = (dateString) => {
    const today = new Date();
    const date = new Date(dateString);
    return date.toDateString() === today.toDateString();
  };

  // Enhanced search filter function
  const filterCustomersBySearch = (customer) => {
    if (searchTerm === '') return true;
    
    const search = searchTerm.toLowerCase().trim();
    const name = customer.name?.toLowerCase() || '';
    const mobile = customer.mobile || '';
    const address = customer.address?.toLowerCase() || '';
    
    return (
      name.includes(search) ||
      mobile.includes(searchTerm) ||
      mobile.endsWith(searchTerm) || // Search by last digits
      address.includes(search) ||
      // Search by first name or last name separately
      name.split(' ').some(namePart => namePart.startsWith(search))
    );
  };

  // Get customer status based on recent activities
  const getCustomerStatus = (customer) => {
    const hasOutstandingBalance = customer.cash_balance > 0;
    const hasPendingEmptyJars = customer.empty_jars_balance > 0;
    
    // Check if customer has any pending tasks
    const hasPendingTasks = hasOutstandingBalance || hasPendingEmptyJars;
    
    // Determine status based on multiple factors
    if (!hasPendingTasks && customer.cash_balance <= 0) {
      // Green: All completed - no outstanding balance, no empty jars pending
      return { 
        status: 'completed', 
        color: 'bg-green-500', 
        label: 'All Tasks Completed - Ready for next order' 
      };
    } else if (hasPendingTasks && customer.cash_balance > 100) {
      // Red: No recent delivery - high balance suggests no recent service
      return { 
        status: 'no_delivery', 
        color: 'bg-red-500', 
        label: 'No Recent Delivery - Needs Attention' 
      };
    } else {
      // Yellow: Partial completion - some tasks pending
      const pendingTasks = [];
      if (hasOutstandingBalance) pendingTasks.push('Payment Due');
      if (hasPendingEmptyJars) pendingTasks.push('Empty Jars');
      
      return { 
        status: 'partial', 
        color: 'bg-yellow-500', 
        label: `Pending: ${pendingTasks.join(', ')}` 
      };
    }
  };

  // Get status color for orders
  const getStatusColor = (status, type = 'regular') => {
    if (type === 'regular') {
      switch (status) {
        case 'pending': return 'bg-yellow-100 text-yellow-800';
        case 'in_transit': return 'bg-blue-100 text-blue-800';
        case 'delivered': return 'bg-green-100 text-green-800';
        default: return 'bg-gray-100 text-gray-800';
      }
    } else {
      switch (status) {
        case 'confirmed': return 'bg-blue-100 text-blue-800';
        case 'in_progress': return 'bg-yellow-100 text-yellow-800';
        case 'completed': return 'bg-green-100 text-green-800';
        default: return 'bg-gray-100 text-gray-800';
      }
    }
  };

  // Render customer card
  const renderCustomerCard = (customer) => {
    const customerStatus = getCustomerStatus(customer);
    
    return (
      <Card key={customer.id} className="hover:shadow-lg transition-all duration-200">
        <CardContent className="p-4">
          <div className="flex justify-between items-start mb-3">
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-1">
                {/* Status Dot */}
                <div 
                  className={`w-3 h-3 rounded-full ${customerStatus.color}`}
                  title={customerStatus.label}
                ></div>
                <h3 className="font-semibold text-lg text-gray-900">
                  {customer.name}
                </h3>
              </div>
            <p className="text-sm text-gray-600 mb-2">
              📱 {customer.mobile} | 📍 {customer.address?.slice(0, 30)}{customer.address?.length > 30 ? '...' : ''}
            </p>
            <div className="flex items-center space-x-4 text-sm text-gray-600">
              <div className="flex items-center space-x-1">
                <IndianRupee className="w-4 h-4" />
                <span>Balance: ₹{customer.cash_balance?.toFixed(2) || '0.00'}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Package className="w-4 h-4" />
                <span>Empty Jars: {customer.empty_jars_balance || 0}</span>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col space-y-2">
            <Badge className={customer.cash_balance > 0 ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}>
              {customer.cash_balance > 0 ? 'Due' : 'Paid'}
            </Badge>
            {/* Status Badge */}
            <Badge 
              className={
                customerStatus.status === 'completed' ? 'bg-green-100 text-green-800' :
                customerStatus.status === 'partial' ? 'bg-yellow-100 text-yellow-800' :
                'bg-red-100 text-red-800'
              }
              title={customerStatus.label}
            >
              {customerStatus.status === 'completed' ? '✓ Complete' :
               customerStatus.status === 'partial' ? '⚠ Partial' :
               '● Pending'}
            </Badge>
          </div>
        </div>

        {/* Scheduled Delivery Info */}
        {(() => {
          const customerScheduledDeliveries = scheduledDeliveries.filter(delivery => 
            delivery.customer_id === customer.id && delivery.delivery_status === 'scheduled'
          );
          
          if (customerScheduledDeliveries.length > 0) {
            const nextDelivery = customerScheduledDeliveries[0];
            const timeSlotEmojis = {
              'morning': '🌅',
              'afternoon': '☀️', 
              'evening': '🌆'
            };
            
            return (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-blue-800">Scheduled Delivery</p>
                    <p className="text-xs text-blue-600">
                      {format(new Date(nextDelivery.scheduled_date), 'MMM dd, yyyy')} - 
                      {timeSlotEmojis[nextDelivery.scheduled_time_slot]} {nextDelivery.scheduled_time_slot}
                    </p>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Package className="w-4 h-4 text-blue-600" />
                    <span className="text-sm font-medium text-blue-800">{nextDelivery.jars_delivered} jars</span>
                  </div>
                </div>
              </div>
            );
          }
          return null;
        })()}

        {/* Action Buttons */}
        <div className="flex justify-between items-center pt-3 border-t">
          <div className="text-sm text-gray-500">
            Customer since {format(new Date(customer.created_at || Date.now()), 'MMM yyyy')}
          </div>
          
          <div className="flex space-x-2">
            <Button 
              size="sm" 
              variant="outline"
              className="bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
              onClick={() => {
                setSelectedCustomer(customer);
                setSelectedOrder(null); // Clear any selected order
                setQuickDeliveryForm(prev => ({ ...prev, customer_id: customer.id }));
                setShowQuickDeliveryDialog(true);
              }}
            >
              <Truck className="w-4 h-4 mr-1" />
              Quick Delivery
            </Button>
            
            <Button 
              size="sm" 
              variant="outline"
              className="bg-green-50 hover:bg-green-100 text-green-700 border-green-200"
              onClick={() => {
                setSelectedCustomer(customer);
                setSelectedOrder(null); // Clear any selected order
                setPaymentForm(prev => ({ ...prev, customer_id: customer.id }));
                setShowPaymentDialog(true);
              }}
            >
              <Banknote className="w-4 h-4 mr-1" />
              Collect Payment
            </Button>
            
            <Button 
              size="sm" 
              variant="outline"
              className="bg-orange-50 hover:bg-orange-100 text-orange-700 border-orange-200"
              onClick={() => {
                setSelectedCustomer(customer);
                setSelectedOrder(null); // Clear any selected order
                setEmptyJarForm(prev => ({ ...prev, customer_id: customer.id }));
                setShowEmptyJarDialog(true);
              }}
            >
              <ArrowUpCircle className="w-4 h-4 mr-1" />
              Empty Jars
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

  // Render order card
  const renderOrderCard = (order, type = 'regular') => (
    <Card key={order.id} className="hover:shadow-lg transition-all duration-200">
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-3">
          <div className="flex-1">
            <h3 className="font-semibold text-lg text-gray-900 mb-1">
              {type === 'regular' ? order.customer_name : order.event_name}
            </h3>
            <p className="text-sm text-gray-600 mb-2">
              {type === 'regular' ? `Order #${order.id?.slice(-8)}` : `Event #${order.id?.slice(-8)}`}
            </p>
            <div className="flex items-center space-x-4 text-sm text-gray-600">
              {type === 'regular' ? (
                <>
                  <div className="flex items-center space-x-1">
                    <Package className="w-4 h-4" />
                    <span>{order.products?.reduce((sum, p) => sum + p.quantity, 0) || order.quantity || 0} jars</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <IndianRupee className="w-4 h-4" />
                    <span>₹{order.total_amount?.toFixed(2) || '0.00'}</span>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>{format(new Date(order.event_date), 'MMM dd')}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <IndianRupee className="w-4 h-4" />
                    <span>₹{order.total_amount?.toFixed(2) || '0.00'}</span>
                  </div>
                </>
              )}
            </div>
          </div>
          
          <div className="flex flex-col items-end space-y-2">
            <Badge className={getStatusColor(type === 'regular' ? order.delivery_status : order.event_status, type)}>
              {type === 'regular' ? order.delivery_status : order.event_status}
            </Badge>
            
            {type === 'event' && order.delivery_boy_name && (
              <Badge variant="outline" className="text-xs">
                {order.delivery_boy_name}
              </Badge>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-2 mt-3">
          {((type === 'regular' && order.delivery_status !== 'delivered') || 
            (type === 'event' && order.event_status !== 'completed' && order.event_status !== 'cancelled')) && (
            <Button
              size="sm"
              onClick={() => {
                setSelectedOrder({ ...order, type });
                setSelectedCustomer(null); // Clear any selected customer
                const jarsDeliveredCount = type === 'regular' 
                  ? (order.products?.reduce((sum, p) => sum + p.quantity, 0) || order.quantity || 0)
                  : (order.products?.reduce((sum, p) => sum + p.quantity, 0) || order.total_jars_required || 0);
                
                // Ensure exact order quantity - no more, no less
                const exactOrderQuantity = jarsDeliveredCount;
                
                setQuickDeliveryForm({
                  jars_delivered: exactOrderQuantity,
                  empty_jars_collected: exactOrderQuantity, // Auto-fill with same number as delivered jars
                  delivery_notes: '',
                  auto_collect_empty: true,
                  order_quantity: exactOrderQuantity // Store original order quantity for validation
                });
                setShowQuickDeliveryDialog(true);
              }}
              className="bg-green-600 hover:bg-green-700"
            >
              <Zap className="w-4 h-4 mr-1" />
              Quick Delivery
            </Button>
          )}
          
          {/* Hide payment and empty jar collection for cancelled events */}
          {!(type === 'event' && order.event_status === 'cancelled') && (
            <>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  setSelectedOrder({ ...order, type });
                  setSelectedCustomer(null); // Clear any selected customer
                  
                  // Calculate balance amount and pre-fill payment form
                  let balanceAmount = 0;
                  if (type === 'event') {
                    const totalAmount = order.total_amount || 0;
                    const advanceAmount = order.advance_amount || 0;
                    const previousPayments = order.last_payment_amount || 0;
                    balanceAmount = totalAmount - advanceAmount - previousPayments;
                  } else {
                    const totalAmount = order.total_amount || 0;
                    const previousPayments = order.last_payment_amount || 0;
                    balanceAmount = totalAmount - previousPayments;
                  }
                  
                  setPaymentForm({
                    amount_received: balanceAmount > 0 ? balanceAmount.toString() : '',
                    payment_mode: 'cash',
                    payment_notes: '',
                    balance_amount: balanceAmount
                  });
                  setShowPaymentDialog(true);
                }}
                className="hover:bg-blue-50"
              >
                <Banknote className="w-4 h-4 mr-1" />
                Collect Payment
              </Button>
              
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  setSelectedOrder({ ...order, type });
                  setSelectedCustomer(null); // Clear any selected customer
                  const totalJars = order.quantity || order.products?.reduce((sum, p) => sum + p.quantity, 0) || order.total_jars_required || 0;
                  
                  // Ensure exact order quantity for empty jar collection
                  const exactOrderQuantity = totalJars;
                  
                  setEmptyJarForm({
                    jars_collected: exactOrderQuantity.toString(),
                    collection_notes: '',
                    auto_collect_empty: true,
                    order_quantity: exactOrderQuantity // Store original order quantity for validation
                  });
                  setShowEmptyJarDialog(true);
                }}
                className="hover:bg-orange-50"
              >
                <ArrowUpCircle className="w-4 h-4 mr-1" />
                Empty Jars
              </Button>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center space-x-2">
            <BookOpen className="w-8 h-8 text-blue-600" />
            <span>Order Book</span>
          </h1>
          <p className="text-gray-600 mt-1">
            Comprehensive order management with quick delivery and payment collection
          </p>
        </div>
        
        <Button onClick={fetchData} variant="outline" className="hover:bg-gray-50">
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4 items-center bg-gray-50 p-4 rounded-lg">
        <div className="flex items-center space-x-2">
          <Search className="w-4 h-4 text-gray-500" />
          <Input
            placeholder="Search customers by name, mobile, address... (Press Enter for quick delivery)"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && searchTerm.trim()) {
                const filteredCustomers = customers.filter(filterCustomersBySearch);
                
                if (filteredCustomers.length > 0) {
                  // Auto-select first customer for quick delivery
                  const firstCustomer = filteredCustomers[0];
                  setSelectedCustomer(firstCustomer);
                  setSelectedOrder(null); // Clear any selected order
                  setQuickDeliveryForm(prev => ({ ...prev, customer_id: firstCustomer.id }));
                  setShowQuickDeliveryDialog(true);
                }
              }
            }}
            className="w-80"
          />
        </div>
        
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="in_transit">In Transit</SelectItem>
            <SelectItem value="delivered">Delivered</SelectItem>
            <SelectItem value="confirmed">Confirmed</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
          </SelectContent>
        </Select>
        
        <Select value={filterDate} onValueChange={setFilterDate}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="Date" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Order Book Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="customers" className="flex items-center space-x-2">
            <Users className="w-4 h-4" />
            <span>Regular Customer Management</span>
          </TabsTrigger>
          <TabsTrigger value="event" className="flex items-center space-x-2">
            <PartyPopper className="w-4 h-4" />
            <span>Event Orders</span>
          </TabsTrigger>
          {user?.role === 'delivery_boy' && (
            <TabsTrigger value="assigned" className="flex items-center space-x-2">
              <Truck className="w-4 h-4" />
              <span>My Orders</span>
            </TabsTrigger>
          )}
          {user?.role !== 'delivery_boy' && (
            <TabsTrigger value="assigned" className="flex items-center space-x-2">
              <Truck className="w-4 h-4" />
              <span>Delivery View</span>
            </TabsTrigger>
          )}
        </TabsList>

        {/* Regular Customer Management Tab */}
        <TabsContent value="customers" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Regular Customer Management</h2>
            <Badge variant="outline">
              {customers.length} customers
            </Badge>
          </div>

          {/* Quick Delivery Search Section */}
          {searchTerm && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <Zap className="w-5 h-5 text-blue-600" />
                  <h3 className="font-medium text-blue-800">Quick Delivery Search Results</h3>
                  <Badge variant="outline" className="bg-blue-100 text-blue-800">
                    {customers.filter(filterCustomersBySearch).length} found
                  </Badge>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setSearchTerm('')}
                  className="text-blue-600 hover:bg-blue-100"
                >
                  <X className="w-4 h-4 mr-1" />
                  Clear Search
                </Button>
              </div>
              <p className="text-sm text-blue-600 mb-3">
                🚀 Quick Actions: Search by customer name or mobile number for instant delivery processing
              </p>
            </div>
          )}
          
          <div className="grid gap-4">
            {customers.filter(filterCustomersBySearch).map(customer => renderCustomerCard(customer))}
            
            {customers.filter(filterCustomersBySearch).length === 0 && searchTerm !== '' && (
              <Card className="p-8 text-center">
                <Search className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-600 font-medium mb-2">No customers found for "{searchTerm}"</p>
                <p className="text-gray-500 text-sm">
                  Try searching by:
                </p>
                <ul className="text-gray-500 text-sm mt-2 space-y-1">
                  <li>• Full customer name</li>
                  <li>• Mobile number (full or last 4 digits)</li>
                  <li>• Address or area</li>
                </ul>
              </Card>
            )}
            
            {customers.length === 0 && (
              <Card className="p-8 text-center">
                <Users className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-500">No customers found</p>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Event Orders Tab */}
        <TabsContent value="event" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Event Orders</h2>
            <div className="flex items-center space-x-3">
              <Badge variant="outline">
                {filterOrders(eventOrders, 'event').length} events
              </Badge>
              <Button
                onClick={() => {
                  // Navigate to event order creation
                  window.location.href = '/events';
                }}
                className="bg-blue-600 hover:bg-blue-700"
                size="sm"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create New Event
              </Button>
            </div>
          </div>
          
          <div className="grid gap-4">
            {filterOrders(eventOrders, 'event').map(order => renderOrderCard(order, 'event'))}
            {filterOrders(eventOrders, 'event').length === 0 && (
              <Card className="p-8 text-center">
                <PartyPopper className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-500">No event orders found</p>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Delivery Boy / Assigned Orders Tab */}
        <TabsContent value="assigned" className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">
              {user?.role === 'delivery_boy' ? 'My Assigned Orders' : 'Delivery Boy View'}
            </h2>
            <Badge variant="outline">
              {user?.role === 'delivery_boy' 
                ? deliveryBoyOrders.length 
                : filterOrders([...regularOrders, ...eventOrders]).length
              } orders
            </Badge>
          </div>
          
          <div className="grid gap-4">
            {user?.role === 'delivery_boy' ? (
              deliveryBoyOrders.map(order => renderOrderCard(order, order.event_name ? 'event' : 'regular'))
            ) : (
              filterOrders([...regularOrders, ...eventOrders]).map(order => 
                renderOrderCard(order, order.event_name ? 'event' : 'regular')
              )
            )}
            
            {((user?.role === 'delivery_boy' && deliveryBoyOrders.length === 0) ||
              (user?.role !== 'delivery_boy' && filterOrders([...regularOrders, ...eventOrders]).length === 0)) && (
              <Card className="p-8 text-center">
                <Truck className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                <p className="text-gray-500">
                  {user?.role === 'delivery_boy' ? 'No orders assigned to you' : 'No orders found'}
                </p>
              </Card>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Quick Delivery Dialog */}
      <Dialog open={showQuickDeliveryDialog} onOpenChange={setShowQuickDeliveryDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Zap className="w-5 h-5 text-green-600" />
              <span>Quick Delivery</span>
            </DialogTitle>
            <DialogDescription>
              Complete delivery for {selectedCustomer?.name || selectedOrder?.customer_name || selectedOrder?.event_name}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Jars to Deliver {selectedOrder ? '(Order Quantity)' : ''}</Label>
              <Input
                type="number"
                value={quickDeliveryForm.jars_delivered}
                readOnly={!!selectedOrder}
                disabled={!!selectedOrder}
                className={selectedOrder ? "bg-gray-100 cursor-not-allowed" : ""}
                placeholder="Number of jars to deliver"
                min="1"
                onChange={(e) => !selectedOrder && setQuickDeliveryForm({
                  ...quickDeliveryForm,
                  jars_delivered: e.target.value
                })}
              />
              {selectedOrder && (
                <p className="text-xs text-gray-600 flex items-center space-x-1">
                  <span>🔒</span>
                  <span>Delivery quantity is locked to order quantity. Cannot deliver more or less than ordered.</span>
                </p>
              )}
              {!selectedOrder && (
                <p className="text-xs text-gray-600">
                  Enter the number of jars to deliver to the customer.
                </p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label>Payment Received (Optional)</Label>
              <Input
                type="number"
                min="0"
                step="0.01"
                value={quickDeliveryForm.payment_amount}
                onChange={(e) => setQuickDeliveryForm({
                  ...quickDeliveryForm,
                  payment_amount: e.target.value
                })}
                placeholder="Amount received during delivery"
              />
            </div>

            <div className="space-y-2">
              <Label>Payment Mode</Label>
              <Select value={quickDeliveryForm.payment_mode} onValueChange={(value) => setQuickDeliveryForm({
                ...quickDeliveryForm,
                payment_mode: value
              })}>
                <SelectTrigger>
                  <SelectValue placeholder="Payment mode" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="upi">UPI</SelectItem>
                  <SelectItem value="card">Card</SelectItem>
                  <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Delivery Scheduling Options */}
            <div className="space-y-3 border-t pt-4">
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="scheduleDelivery"
                  checked={quickDeliveryForm.is_scheduled}
                  onChange={(e) => setQuickDeliveryForm({
                    ...quickDeliveryForm,
                    is_scheduled: e.target.checked
                  })}
                />
                <Label htmlFor="scheduleDelivery" className="flex items-center space-x-1">
                  <Clock className="w-4 h-4" />
                  <span>Schedule for later</span>
                </Label>
              </div>

              {quickDeliveryForm.is_scheduled && (
                <>
                  <div className="space-y-2">
                    <Label>Delivery Date</Label>
                    <Input
                      type="date"
                      value={quickDeliveryForm.delivery_date}
                      min={new Date().toISOString().split('T')[0]}
                      onChange={(e) => setQuickDeliveryForm({
                        ...quickDeliveryForm,
                        delivery_date: e.target.value
                      })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Delivery Time Slot</Label>
                    <Select value={quickDeliveryForm.delivery_time_slot} onValueChange={(value) => setQuickDeliveryForm({
                      ...quickDeliveryForm,
                      delivery_time_slot: value
                    })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select time slot" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="morning">
                          <div className="flex items-center space-x-2">
                            <span>🌅</span>
                            <div>
                              <div className="font-medium">Morning</div>
                              <div className="text-xs text-gray-500">9:00 AM - 12:00 PM</div>
                            </div>
                          </div>
                        </SelectItem>
                        <SelectItem value="afternoon">
                          <div className="flex items-center space-x-2">
                            <span>☀️</span>
                            <div>
                              <div className="font-medium">Afternoon</div>
                              <div className="text-xs text-gray-500">2:00 PM - 5:00 PM</div>
                            </div>
                          </div>
                        </SelectItem>
                        <SelectItem value="evening">
                          <div className="flex items-center space-x-2">
                            <span>🌆</span>
                            <div>
                              <div className="font-medium">Evening</div>
                              <div className="text-xs text-gray-500">6:00 PM - 8:00 PM</div>
                            </div>
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}
            </div>
            
            <div className="space-y-2">
              <Label>Delivery Notes</Label>
              <Input
                value={quickDeliveryForm.delivery_notes}
                onChange={(e) => setQuickDeliveryForm({
                  ...quickDeliveryForm,
                  delivery_notes: e.target.value
                })}
                placeholder="Optional delivery notes"
              />
            </div>
            
            <div className="flex space-x-2">
              <Button
                variant="outline"
                onClick={() => {
                  setShowQuickDeliveryDialog(false);
                  setSelectedCustomer(null);
                  setSelectedOrder(null);
                }}
                className="w-full relative z-50"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  // Use appropriate handler based on what's selected
                  if (selectedOrder) {
                    handleQuickDelivery(selectedOrder, selectedOrder.type);
                  } else {
                    handleCustomerQuickDelivery();
                  }
                }}
                className={`w-full relative z-50 ${quickDeliveryForm.is_scheduled ? 'bg-blue-600 hover:bg-blue-700' : 'bg-green-600 hover:bg-green-700'}`}
              >
                {quickDeliveryForm.is_scheduled ? (
                  <>
                    <Calendar className="w-4 h-4 mr-2" />
                    Schedule Delivery
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Complete Delivery
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Payment Collection Dialog */}
      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Banknote className="w-5 h-5 text-blue-600" />
              <span>Collect Payment</span>
            </DialogTitle>
            <DialogDescription>
              Collect payment from {selectedCustomer?.name || selectedOrder?.customer_name || selectedOrder?.event_name}
            </DialogDescription>
          </DialogHeader>
          
          {/* Customer Balance Information */}
          {selectedCustomer?.cash_balance > 0 && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-blue-800">Outstanding Balance</p>
                  <p className="text-xl font-bold text-blue-600">₹{selectedCustomer.cash_balance.toFixed(2)}</p>
                </div>
                <IndianRupee className="w-8 h-8 text-blue-500" />
              </div>
              <p className="text-xs text-blue-600 mt-2">
                You can collect full amount or any partial amount
              </p>
            </div>
          )}

          {/* Event Order Balance Information */}
          {selectedOrder && selectedOrder.type === 'event' && (
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-orange-800">Event Order Balance Due</p>
                  <p className="text-xl font-bold text-orange-600">
                    ₹{(selectedOrder.balance_amount || (selectedOrder.total_amount - selectedOrder.advance_amount) || 0).toFixed(2)}
                  </p>
                </div>
                <IndianRupee className="w-8 h-8 text-orange-500" />
              </div>
              <div className="mt-2 text-xs text-orange-700">
                <p><strong>Total Amount:</strong> ₹{(selectedOrder.total_amount || 0).toFixed(2)}</p>
                <p><strong>Advance Paid:</strong> ₹{(selectedOrder.advance_amount || 0).toFixed(2)}</p>
                <p className="flex items-center space-x-1 mt-1">
                  <span>🔒</span>
                  <span>Payment limited to balance due amount only</span>
                </p>
              </div>
            </div>
          )}
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>
                Amount Received (₹)
                {selectedCustomer?.cash_balance > 0 && (
                  <span className="text-xs text-gray-500 ml-2">
                    (Max: ₹{selectedCustomer.cash_balance.toFixed(2)})
                  </span>
                )}
                {selectedOrder && selectedOrder.type === 'event' && (
                  <span className="text-xs text-orange-600 ml-2">
                    (Max: ₹{(selectedOrder.balance_amount || (selectedOrder.total_amount - selectedOrder.advance_amount) || 0).toFixed(2)})
                  </span>
                )}
              </Label>
              <Input
                type="number"
                min="0"
                max={
                  selectedOrder && selectedOrder.type === 'event'
                    ? (selectedOrder.balance_amount || (selectedOrder.total_amount - selectedOrder.advance_amount) || 0)
                    : selectedCustomer?.cash_balance > 0 
                      ? selectedCustomer.cash_balance 
                      : undefined
                }
                step="0.01"
                value={paymentForm.amount_received}
                onChange={(e) => {
                  const inputAmount = parseFloat(e.target.value) || 0;
                  let maxAmount;
                  
                  if (selectedOrder && selectedOrder.type === 'event') {
                    maxAmount = selectedOrder.balance_amount || (selectedOrder.total_amount - selectedOrder.advance_amount) || 0;
                  } else if (selectedCustomer?.cash_balance > 0) {
                    maxAmount = selectedCustomer.cash_balance;
                  }
                  
                  // Prevent amount exceeding maximum
                  if (maxAmount && inputAmount > maxAmount) {
                    toast.error(`Amount cannot exceed ₹${maxAmount.toFixed(2)}`);
                    return;
                  }
                  
                  setPaymentForm({
                    ...paymentForm,
                    amount_received: e.target.value
                  });
                }}
                placeholder={
                  selectedOrder && selectedOrder.type === 'event'
                    ? `Enter amount (up to ₹${(selectedOrder.balance_amount || (selectedOrder.total_amount - selectedOrder.advance_amount) || 0).toFixed(2)})`
                    : selectedCustomer?.cash_balance > 0 
                      ? `Enter amount (up to ₹${selectedCustomer.cash_balance.toFixed(2)})`
                      : "Enter amount received"
                }
              />
              {paymentForm.amount_received && selectedCustomer?.cash_balance > 0 && (
                <p className="text-xs text-gray-600">
                  Remaining balance after payment: ₹{(selectedCustomer.cash_balance - parseFloat(paymentForm.amount_received || 0)).toFixed(2)}
                </p>
              )}
              
              {paymentForm.amount_received && selectedOrder && selectedOrder.type === 'event' && (
                <p className="text-xs text-orange-600">
                  Remaining balance after payment: ₹{((selectedOrder.balance_amount || (selectedOrder.total_amount - selectedOrder.advance_amount) || 0) - parseFloat(paymentForm.amount_received || 0)).toFixed(2)}
                </p>
              )}
              
              {/* Quick Payment Buttons for Event Orders */}
              {selectedOrder && selectedOrder.type === 'event' && (
                <div className="flex space-x-2 mt-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const balanceDue = selectedOrder.balance_amount || (selectedOrder.total_amount - selectedOrder.advance_amount) || 0;
                      setPaymentForm({
                        ...paymentForm,
                        amount_received: balanceDue.toString()
                      });
                    }}
                    className="text-xs px-3 py-1"
                  >
                    Full Balance (₹{(selectedOrder.balance_amount || (selectedOrder.total_amount - selectedOrder.advance_amount) || 0).toFixed(2)})
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const balanceDue = selectedOrder.balance_amount || (selectedOrder.total_amount - selectedOrder.advance_amount) || 0;
                      const halfAmount = balanceDue / 2;
                      setPaymentForm({
                        ...paymentForm,
                        amount_received: halfAmount.toString()
                      });
                    }}
                    className="text-xs px-3 py-1"
                  >
                    Half (₹{((selectedOrder.balance_amount || (selectedOrder.total_amount - selectedOrder.advance_amount) || 0) / 2).toFixed(2)})
                  </Button>
                </div>
              )}
            </div>
            
            <div className="space-y-2">
              <Label>Payment Mode</Label>
              <Select 
                value={paymentForm.payment_mode} 
                onValueChange={(value) => setPaymentForm({
                  ...paymentForm,
                  payment_mode: value
                })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="upi">UPI</SelectItem>
                  <SelectItem value="online">Online Transfer</SelectItem>
                  <SelectItem value="cheque">Cheque</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>Payment Notes</Label>
              <Input
                value={paymentForm.payment_notes}
                onChange={(e) => setPaymentForm({
                  ...paymentForm,
                  payment_notes: e.target.value
                })}
                placeholder="Optional payment notes"
              />
            </div>
            
            <div className="flex space-x-2">
              <Button
                variant="outline"
                onClick={() => {
                  setShowPaymentDialog(false);
                  setSelectedCustomer(null);
                  setSelectedOrder(null);
                }}
                className="w-full relative z-50"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  // Use appropriate handler based on what's selected
                  if (selectedOrder) {
                    handlePaymentCollection(selectedOrder, selectedOrder.type);
                  } else {
                    handleCustomerPaymentCollection();
                  }
                }}
                className="w-full bg-blue-600 hover:bg-blue-700 relative z-50"
              >
                <Banknote className="w-4 h-4 mr-2" />
                Collect Payment
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Empty Jar Collection Dialog */}
      <Dialog open={showEmptyJarDialog} onOpenChange={setShowEmptyJarDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <ArrowUpCircle className="w-5 h-5 text-orange-600" />
              <span>Collect Empty Jars</span>
            </DialogTitle>
            <DialogDescription>
              Record empty jar collection from {selectedCustomer?.name || selectedOrder?.customer_name || selectedOrder?.event_name}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {selectedCustomer?.empty_jars_balance > 0 && (
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-orange-800">Customer's Empty Jars</p>
                    <p className="text-xl font-bold text-orange-600">{selectedCustomer.empty_jars_balance} jars</p>
                  </div>
                  <Package className="w-8 h-8 text-orange-500" />
                </div>
              </div>
            )}
            
            <div className="space-y-2">
              <Label>Empty Jars Collected {selectedOrder ? '(Order Quantity)' : ''}</Label>
              <Input
                type="number"
                value={emptyJarForm.jars_collected}
                readOnly={!!selectedOrder}
                disabled={!!selectedOrder}
                className={selectedOrder ? "bg-gray-100 cursor-not-allowed" : ""}
                placeholder="Number of empty jars collected"
                min="0"
                max={selectedCustomer?.empty_jars_balance}
                onChange={(e) => !selectedOrder && setEmptyJarForm({
                  ...emptyJarForm,
                  jars_collected: e.target.value
                })}
              />
              {selectedOrder && (
                <p className="text-xs text-gray-600 flex items-center space-x-1">
                  <span>🔒</span>
                  <span>Collection quantity is locked to order quantity. Must collect exact number of jars as delivered.</span>
                </p>
              )}
              {!selectedOrder && selectedCustomer && (
                <p className="text-xs text-gray-600">
                  Enter number of empty jars to collect (Max: {selectedCustomer.empty_jars_balance} jars)
                </p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label>Collection Notes</Label>
              <Input
                value={emptyJarForm.collection_notes}
                onChange={(e) => setEmptyJarForm({
                  ...emptyJarForm,
                  collection_notes: e.target.value
                })}
                placeholder="Optional collection notes"
              />
            </div>
            
            <div className="flex space-x-2">
              <Button
                variant="outline"
                onClick={() => {
                  setShowEmptyJarDialog(false);
                  setSelectedCustomer(null);
                  setSelectedOrder(null);
                }}
                className="w-full relative z-50"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  // Use appropriate handler based on what's selected
                  if (selectedOrder) {
                    handleEmptyJarCollection(selectedOrder, selectedOrder.type);
                  } else {
                    handleCustomerEmptyJarCollection();
                  }
                }}
                className="w-full bg-orange-600 hover:bg-orange-700 relative z-50"
              >
                <ArrowUpCircle className="w-4 h-4 mr-2" />
                Collect Empty Jars
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default OrderBook;