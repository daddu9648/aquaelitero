import React, { useState, useContext } from 'react';
import { AuthContext } from '../App';
import axios from 'axios';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { 
  Settings as SettingsIcon, 
  User, 
  Bell, 
  Shield,
  Database,
  Palette,
  Save
} from 'lucide-react';
import { toast } from 'sonner';

function Settings() {
  const { user, API } = useContext(AuthContext);
  const [settings, setSettings] = useState({
    companyName: 'AquaElite',
    notifications: true,
    autoBackup: false,
    darkMode: false
  });
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const handlePasswordReset = async (e) => {
    e.preventDefault();
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    
    try {
      await axios.put(`${API}/auth/change-password`, {
        current_password: passwordForm.currentPassword,
        new_password: passwordForm.newPassword
      });
      toast.success('Password changed successfully!');
      setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (error) {
      toast.error('Failed to change password');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900" data-testid="settings-title">
          Settings
        </h1>
        <p className="text-gray-600 mt-1">
          Manage your application preferences and configuration
        </p>
      </div>

      {/* Company Settings */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <SettingsIcon className="w-5 h-5" />
            <span>Company Settings</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Company Name</Label>
              <Input value={settings.companyName} data-testid="company-name-input" />
            </div>
            <div>
              <Label>Version</Label>
              <Input value="1.0.0" disabled />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* User Settings */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <User className="w-5 h-5" />
            <span>User Preferences</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>Enable Notifications</Label>
            <Switch checked={settings.notifications} data-testid="notifications-switch" />
          </div>
          <div className="flex items-center justify-between">
            <Label>Auto Backup</Label>
            <Switch checked={settings.autoBackup} data-testid="backup-switch" />
          </div>
          <div className="flex items-center justify-between">
            <Label>Dark Mode</Label>
            <Switch checked={settings.darkMode} data-testid="dark-mode-switch" />
          </div>
        </CardContent>
      </Card>

      {/* Password Reset */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="w-5 h-5" />
            <span>Password Reset</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handlePasswordReset} className="space-y-4">
            <Input type="password" placeholder="Current Password" value={passwordForm.currentPassword} onChange={(e) => setPasswordForm({...passwordForm, currentPassword: e.target.value})} data-testid="current-password-input" />
            <Input type="password" placeholder="New Password" value={passwordForm.newPassword} onChange={(e) => setPasswordForm({...passwordForm, newPassword: e.target.value})} data-testid="new-password-input" />
            <Input type="password" placeholder="Confirm Password" value={passwordForm.confirmPassword} onChange={(e) => setPasswordForm({...passwordForm, confirmPassword: e.target.value})} data-testid="confirm-password-input" />
            <Button type="submit" className="w-full bg-red-600 hover:bg-red-700" data-testid="reset-password-btn">Reset Password</Button>
          </form>
        </CardContent>
      </Card>

      <Button className="w-full bg-gradient-to-r from-blue-600 to-cyan-600" data-testid="save-settings-btn">
        Save Settings
      </Button>
    </div>
  );
}

export default Settings;