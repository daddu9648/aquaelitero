import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../App';
import axios from 'axios';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  Users, 
  Phone, 
  MapPin,
  Droplets,
  IndianRupee,
  Filter,
  Power,
  PowerOff
} from 'lucide-react';
import { toast } from 'sonner';

function CustomerManagement() {
  const { API } = useContext(AuthContext);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    mobile: '',
    address: '',
    water_type: '20L',
    bottle_deposit: 0
  });

  const waterTypes = ['20L', '15L', '10L', '5L', '2L', '1L'];

  const fetchCustomers = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API}/customers/all`, {
        headers: {
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        }
      });
      setCustomers([...response.data]);
    } catch (error) {
      console.error('Error fetching customers:', error);
      toast.error('Failed to load customers');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomers();
  }, []);

  const handleAddCustomer = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${API}/customers`, formData);
      toast.success('Customer added successfully!');
      setShowAddDialog(false);
      setFormData({ name: '', mobile: '', address: '', water_type: '20L', bottle_deposit: 0 });
      fetchCustomers();
    } catch (error) {
      console.error('Error adding customer:', error);
      toast.error('Failed to add customer');
    }
  };

  const handleEditCustomer = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`${API}/customers/${selectedCustomer.id}`, formData);
      toast.success('Customer updated successfully!');
      setShowEditDialog(false);
      setSelectedCustomer(null);
      setFormData({ name: '', mobile: '', address: '', water_type: '20L', bottle_deposit: 0 });
      fetchCustomers();
    } catch (error) {
      console.error('Error updating customer:', error);
      toast.error('Failed to update customer');
    }
  };

  const handleDeleteCustomer = async (customerId, customerName, cashBalance = 0, emptyJarsBalance = 0) => {
    // Check if customer has outstanding balance or empty jars
    if (cashBalance > 0) {
      toast.error(`Cannot delete customer with outstanding balance of ₹${cashBalance.toFixed(2)}. Please collect payment first.`);
      return;
    }
    
    if (emptyJarsBalance > 0) {
      toast.error(`Cannot delete customer with ${emptyJarsBalance} empty jars pending. Please collect empty jars first.`);
      return;
    }
    
    if (window.confirm(`Are you sure you want to delete customer: ${customerName}?`)) {
      try {
        await axios.delete(`${API}/customers/${customerId}`);
        toast.success('Customer deleted successfully!');
        fetchCustomers();
      } catch (error) {
        console.error('Error deleting customer:', error);
        toast.error('Failed to delete customer');
      }
    }
  };

  const activateCustomer = async (customerId) => {
    try {
      await axios.put(`${API}/customers/${customerId}/activate`);
      toast.success('Customer activated successfully!');
      fetchCustomers();
    } catch (error) {
      console.error('Error activating customer:', error);
      toast.error('Failed to activate customer');
    }
  };

  const deactivateCustomer = async (customerId) => {
    if (window.confirm('Are you sure you want to deactivate this customer? They will not appear in Order Book.')) {
      try {
        await axios.put(`${API}/customers/${customerId}/deactivate`);
        toast.success('Customer deactivated successfully!');
        fetchCustomers();
      } catch (error) {
        console.error('Error deactivating customer:', error);
        toast.error('Failed to deactivate customer');
      }
    }
  };

  const openEditDialog = (customer) => {
    setSelectedCustomer(customer);
    setFormData({
      name: customer.name,
      mobile: customer.mobile,
      address: customer.address,
      water_type: customer.water_type,
      bottle_deposit: customer.bottle_deposit
    });
    setShowEditDialog(true);
  };

  const filteredCustomers = customers.filter(customer => {
    const matchesSearch = customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         customer.mobile.includes(searchTerm) ||
                         customer.address.toLowerCase().includes(searchTerm.toLowerCase());
    
    let matchesFilter = true;
    if (filterType === 'active') {
      matchesFilter = customer.is_active === true;
    } else if (filterType === 'inactive') {
      matchesFilter = customer.is_active === false;
    } else if (filterType !== 'all') {
      matchesFilter = customer.water_type === filterType;
    }
    
    return matchesSearch && matchesFilter;
  });

  const resetForm = () => {
    setFormData({ name: '', mobile: '', address: '', water_type: '20L', bottle_deposit: 0 });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900" data-testid="customer-management-title">
            Customer Management
          </h1>
          <p className="text-gray-600 mt-1">
            Manage your customer database and track their orders
          </p>
        </div>
        
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button 
              className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 transition-all duration-200"
              data-testid="add-customer-btn"
              onClick={resetForm}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Customer
            </Button>
          </DialogTrigger>
          
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Customer</DialogTitle>
              <DialogDescription>
                Fill in the customer details below
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleAddCustomer} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Enter customer name"
                  required
                  data-testid="customer-name-input"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="mobile">Mobile Number</Label>
                <Input
                  id="mobile"
                  type="tel"
                  value={formData.mobile}
                  onChange={(e) => {
                    const value = e.target.value.replace(/\D/g, ''); // Only digits
                    if (value.length <= 10) {
                      setFormData({...formData, mobile: value});
                    }
                  }}
                  placeholder="Enter 10 digit mobile number"
                  required
                  maxLength={10}
                  pattern="[0-9]{10}"
                  data-testid="customer-mobile-input"
                />
                {formData.mobile && formData.mobile.length !== 10 && (
                  <p className="text-xs text-red-600 mt-1">Mobile number must be exactly 10 digits</p>
                )}
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="address">Address</Label>
                <Textarea
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData({...formData, address: e.target.value})}
                  placeholder="Enter full address"
                  required
                  data-testid="customer-address-input"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="waterType">Water Type</Label>
                <Select 
                  value={formData.water_type} 
                  onValueChange={(value) => setFormData({...formData, water_type: value})}
                >
                  <SelectTrigger data-testid="customer-water-type-select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {waterTypes.map(type => (
                      <SelectItem key={type} value={type}>{type} Jar</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="deposit">Bottle Deposit (₹)</Label>
                <Input
                  id="deposit"
                  type="number"
                  value={formData.bottle_deposit}
                  onChange={(e) => setFormData({...formData, bottle_deposit: parseFloat(e.target.value) || 0})}
                  placeholder="0"
                  data-testid="customer-deposit-input"
                />
              </div>
              
              <div className="flex space-x-2 pt-4">
                <Button 
                  type="submit" 
                  className="flex-1 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
                  data-testid="save-customer-btn"
                >
                  Save Customer
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowAddDialog(false)}
                  data-testid="cancel-customer-btn"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search and Filter */}
      <Card className="shadow-soft">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input 
                placeholder="Search by name, mobile, or address..." 
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                data-testid="customer-search-input"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-400" />
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-40" data-testid="customer-filter-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Customers</SelectItem>
                  <SelectItem value="active">Active Only</SelectItem>
                  <SelectItem value="inactive">Inactive Only</SelectItem>
                  {waterTypes.map(type => (
                    <SelectItem key={type} value={type}>{type} Jar</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Customer Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Customers</p>
                <p className="text-2xl font-bold text-gray-900" data-testid="total-customers-stat">
                  {customers.length}
                </p>
              </div>
              <Users className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Customers</p>
                <p className="text-2xl font-bold text-green-600" data-testid="active-customers-stat">
                  {customers.filter(c => c.is_active).length}
                </p>
              </div>
              <Users className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Deposits</p>
                <p className="text-2xl font-bold text-purple-600" data-testid="total-deposits-stat">
                  ₹{customers.reduce((sum, c) => sum + c.bottle_deposit, 0).toFixed(2)}
                </p>
              </div>
              <IndianRupee className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Customer List */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle>Customer List</CardTitle>
          <CardDescription>
            {filteredCustomers.length} customer(s) found
          </CardDescription>
        </CardHeader>
        
        <CardContent className="p-0">
          {filteredCustomers.length === 0 ? (
            <div className="text-center py-12" data-testid="no-customers-message">
              <Users className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No customers found</h3>
              <p className="text-gray-600 mb-4">Get started by adding your first customer.</p>
              <Button 
                onClick={() => setShowAddDialog(true)}
                className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
                data-testid="add-first-customer-btn"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Customer
              </Button>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {filteredCustomers.map((customer) => (
                <div key={customer.id} className="p-6 hover:bg-gray-50 transition-colors" data-testid={`customer-item-${customer.id}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900" data-testid={`customer-name-${customer.id}`}>
                          {customer.name}
                        </h3>
                        <Badge 
                          variant={customer.is_active ? 'default' : 'secondary'}
                          className={customer.is_active ? 'bg-green-100 text-green-800' : ''}
                        >
                          {customer.is_active ? 'Active' : 'Inactive'}
                        </Badge>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700">
                          <Droplets className="w-3 h-3 mr-1" />
                          {customer.water_type}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
                        <div className="flex items-center space-x-2">
                          <Phone className="w-4 h-4" />
                          <span data-testid={`customer-mobile-${customer.id}`}>{customer.mobile}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <MapPin className="w-4 h-4" />
                          <span className="truncate" data-testid={`customer-address-${customer.id}`}>
                            {customer.address}
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <IndianRupee className="w-4 h-4" />
                          <span data-testid={`customer-deposit-${customer.id}`}>
                            Deposit: ₹{customer.bottle_deposit}
                          </span>
                        </div>
                      </div>
                      
                      {customer.balance_due > 0 && (
                        <div className="mt-2">
                          <Badge variant="destructive">
                            Balance Due: ₹{customer.balance_due}
                          </Badge>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openEditDialog(customer)}
                        className="hover:bg-blue-50 hover:text-blue-600"
                        data-testid={`edit-customer-${customer.id}`}
                      >
                        <Edit3 className="w-4 h-4" />
                      </Button>
                      
                      {customer.is_active ? (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deactivateCustomer(customer.id)}
                          className="hover:bg-yellow-50 hover:text-yellow-600"
                          title="Deactivate Customer"
                          data-testid={`deactivate-customer-${customer.id}`}
                        >
                          <PowerOff className="w-4 h-4" />
                        </Button>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => activateCustomer(customer.id)}
                          className="hover:bg-green-50 hover:text-green-600"
                          title="Activate Customer"
                          data-testid={`activate-customer-${customer.id}`}
                        >
                          <Power className="w-4 h-4" />
                        </Button>
                      )}
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteCustomer(customer.id, customer.name, customer.cash_balance, customer.empty_jars_balance)}
                        disabled={customer.cash_balance > 0 || customer.empty_jars_balance > 0}
                        className={(customer.cash_balance > 0 || customer.empty_jars_balance > 0)
                          ? "opacity-50 cursor-not-allowed" 
                          : "hover:bg-red-50 hover:text-red-600"}
                        title={
                          customer.cash_balance > 0 
                            ? `Cannot delete: Outstanding balance ₹${customer.cash_balance.toFixed(2)}` 
                            : customer.empty_jars_balance > 0
                            ? `Cannot delete: ${customer.empty_jars_balance} empty jars pending`
                            : "Delete customer"
                        }
                        data-testid={`delete-customer-${customer.id}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Customer Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Customer</DialogTitle>
            <DialogDescription>
              Update customer information
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleEditCustomer} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="editName">Full Name</Label>
              <Input
                id="editName"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                required
                data-testid="edit-customer-name-input"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="editMobile">Mobile Number</Label>
              <Input
                id="editMobile"
                type="tel"
                value={formData.mobile}
                onChange={(e) => {
                  const value = e.target.value.replace(/\D/g, ''); // Only digits
                  if (value.length <= 10) {
                    setFormData({...formData, mobile: value});
                  }
                }}
                placeholder="Enter 10 digit mobile number"
                required
                maxLength={10}
                pattern="[0-9]{10}"
                data-testid="edit-customer-mobile-input"
              />
              {formData.mobile && formData.mobile.length !== 10 && (
                <p className="text-xs text-red-600 mt-1">Mobile number must be exactly 10 digits</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="editAddress">Address</Label>
              <Textarea
                id="editAddress"
                value={formData.address}
                onChange={(e) => setFormData({...formData, address: e.target.value})}
                required
                data-testid="edit-customer-address-input"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="editWaterType">Water Type</Label>
              <Select 
                value={formData.water_type} 
                onValueChange={(value) => setFormData({...formData, water_type: value})}
              >
                <SelectTrigger data-testid="edit-customer-water-type-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {waterTypes.map(type => (
                    <SelectItem key={type} value={type}>{type} Jar</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="editDeposit">Bottle Deposit (₹)</Label>
              <Input
                id="editDeposit"
                type="number"
                value={formData.bottle_deposit}
                onChange={(e) => setFormData({...formData, bottle_deposit: parseFloat(e.target.value) || 0})}
                data-testid="edit-customer-deposit-input"
              />
            </div>
            
            <div className="flex space-x-2 pt-4">
              <Button 
                type="submit" 
                className="flex-1 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
                data-testid="update-customer-btn"
              >
                Update Customer
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setShowEditDialog(false)}
                data-testid="cancel-edit-customer-btn"
              >
                Cancel
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default CustomerManagement;