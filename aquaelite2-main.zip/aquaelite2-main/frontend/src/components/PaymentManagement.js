import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../App';
import axios from 'axios';
import { format } from 'date-fns';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { 
  Plus, 
  Search, 
  IndianRupee, 
  CreditCard, 
  Receipt, 
  Calendar,
  User,
  UserCheck,
  Banknote,
  Filter,
  Download,
  Eye
} from 'lucide-react';
import { toast } from 'sonner';

function PaymentManagement() {
  const { API, user } = useContext(AuthContext);
  const [paymentCollections, setPaymentCollections] = useState([]);
  const [customerPayments, setCustomerPayments] = useState([]);
  const [deliveryBoys, setDeliveryBoys] = useState([]);
  const [managers, setManagers] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPaymentType, setFilterPaymentType] = useState('all');
  const [filterRole, setFilterRole] = useState('all');
  const [filterMethod, setFilterMethod] = useState('all');
  const [showCollectionDialog, setShowCollectionDialog] = useState(false);
  const [showCustomerPaymentDialog, setShowCustomerPaymentDialog] = useState(false);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showReceiptDialog, setShowReceiptDialog] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState(null);
  
  const [collectionForm, setCollectionForm] = useState({
    payer_id: '',
    payer_name: '',
    payer_role: '', // delivery_boy, manager, administrator
    amount: '',
    payment_type: 'delivery_collection', // delivery_collection, jar_deposit, penalty, advance
    payment_method: 'cash',
    reference_number: '',
    description: '',
    collected_by: user?.id,
    collected_by_name: user?.name
  });

  const [customerPaymentForm, setCustomerPaymentForm] = useState({
    customer_id: '',
    customer_name: '',
    amount: '',
    payment_type: 'order_payment', // order_payment, balance_payment, advance_payment, jar_deposit
    payment_method: 'cash',
    reference_number: '',
    description: '',
    collected_by: user?.id,
    collected_by_name: user?.name,
    collected_by_staff_id: user?.id, // Staff member who collected the payment
    collected_by_staff_name: user?.name, // Staff member name
    order_id: '' // Optional order reference
  });

  const paymentTypes = [
    { value: 'delivery_collection', label: 'Delivery Collection' },
    { value: 'jar_deposit', label: 'Jar Deposit' },
    { value: 'penalty', label: 'Penalty Payment' },
    { value: 'advance', label: 'Advance Payment' },
    { value: 'other', label: 'Other Payment' }
  ];

  const customerPaymentTypes = [
    { value: 'order_payment', label: 'Order Payment' },
    { value: 'balance_payment', label: 'Balance Payment' },
    { value: 'advance_payment', label: 'Advance Payment' },
    { value: 'jar_deposit', label: 'Jar Deposit' },
    { value: 'other', label: 'Other Payment' }
  ];

  const paymentMethods = [
    { value: 'cash', label: 'Cash', icon: Banknote },
    { value: 'upi', label: 'UPI', icon: CreditCard },
    { value: 'online', label: 'Online Transfer', icon: CreditCard },
    { value: 'cheque', label: 'Cheque', icon: Receipt }
  ];

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Fetch payment collections, customer payments, delivery boys, managers, and customers
      const [collectionsRes, deliveryBoysRes, usersRes, customersRes] = await Promise.all([
        fetchPaymentCollections(),
        axios.get(`${API}/users?role=delivery_boy`).catch(() => ({ data: [] })),
        axios.get(`${API}/users`).catch(() => ({ data: [] })),
        axios.get(`${API}/customers`).catch(() => ({ data: [] }))
      ]);
      
      setDeliveryBoys(deliveryBoysRes.data || []);
      // Filter managers and administrators from users
      const managersAndAdmins = (usersRes.data || []).filter(user => 
        ['manager', 'admin', 'administrator'].includes(user.role)
      );
      setManagers(managersAndAdmins);
      setCustomers(customersRes.data || []);
      
      // Fetch customer payments
      await fetchCustomerPayments();
      
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load payment data');
    } finally {
      setLoading(false);
    }
  };

  const fetchPaymentCollections = async () => {
    try {
      // In a real implementation, this would be a dedicated API
      // For now, we'll use local storage or simulate data
      const savedCollections = JSON.parse(localStorage.getItem('paymentCollections') || '[]');
      setPaymentCollections(savedCollections);
      return { data: savedCollections };
    } catch (error) {
      console.error('Error fetching payment collections:', error);
      return { data: [] };
    }
  };

  const fetchCustomerPayments = async () => {
    try {
      const response = await axios.get(`${API}/customer-payments`);
      setCustomerPayments(response.data);
      return response;
    } catch (error) {
      console.error('Error fetching customer payments:', error);
      return { data: [] };
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleCollectPayment = async () => {
    try {
      // Validation
      if (!collectionForm.payer_id || !collectionForm.amount || parseFloat(collectionForm.amount) <= 0) {
        toast.error('Please select payer and enter valid amount');
        return;
      }

      const paymentCollection = {
        id: Date.now().toString(),
        ...collectionForm,
        amount: parseFloat(collectionForm.amount),
        collection_date: new Date().toISOString(),
        status: 'completed'
      };

      // Save to local storage (in production, this would be API call)
      const existingCollections = JSON.parse(localStorage.getItem('paymentCollections') || '[]');
      const updatedCollections = [paymentCollection, ...existingCollections];
      localStorage.setItem('paymentCollections', JSON.stringify(updatedCollections));
      
      setPaymentCollections(updatedCollections);
      
      toast.success(`Payment of ₹${collectionForm.amount} collected from ${collectionForm.payer_name}!`);
      
      // Reset form and close dialog
      setShowCollectionDialog(false);
      setCollectionForm({
        payer_id: '',
        payer_name: '',
        payer_role: '',
        amount: '',
        payment_type: 'delivery_collection',
        payment_method: 'cash',
        reference_number: '',
        description: '',
        collected_by: user?.id,
        collected_by_name: user?.name
      });
      
    } catch (error) {
      console.error('Error collecting payment:', error);
      toast.error('Failed to record payment collection');
    }
  };

  const handlePayerSelection = (payerId) => {
    // Find payer in delivery boys or managers
    const payer = [...deliveryBoys, ...managers].find(person => person.id === payerId);
    if (payer) {
      setCollectionForm({
        ...collectionForm,
        payer_id: payerId,
        payer_name: payer.name,
        payer_role: payer.role
      });
    }
  };

  const handleCustomerSelection = (customerId) => {
    // Find customer
    const customer = customers.find(c => c.id === customerId);
    if (customer) {
      setCustomerPaymentForm({
        ...customerPaymentForm,
        customer_id: customerId,
        customer_name: customer.name
      });
    }
  };

  const handleCustomerPaymentCollection = async () => {
    try {
      // Validation
      if (!customerPaymentForm.customer_id || !customerPaymentForm.amount || parseFloat(customerPaymentForm.amount) <= 0) {
        toast.error('Please select customer and enter valid amount');
        return;
      }

      const customerPayment = {
        id: Date.now().toString(),
        ...customerPaymentForm,
        amount: parseFloat(customerPaymentForm.amount),
        collection_date: new Date().toISOString(),
        status: 'completed',
        payer_type: 'customer'
      };

      // Save to local storage (in production, this would be API call)
      const existingCustomerPayments = JSON.parse(localStorage.getItem('customerPayments') || '[]');
      const updatedCustomerPayments = [customerPayment, ...existingCustomerPayments];
      localStorage.setItem('customerPayments', JSON.stringify(updatedCustomerPayments));
      
      setCustomerPayments(updatedCustomerPayments);

      // Update customer balance
      try {
        await axios.put(`${API}/customers/${customerPaymentForm.customer_id}/balance`, {
          amount_received: parseFloat(customerPaymentForm.amount),
          payment_mode: customerPaymentForm.payment_method,
          notes: `Payment collected by ${user?.name} on ${new Date().toLocaleDateString()}`
        });
      } catch (error) {
        console.warn('Could not update customer balance:', error);
      }
      
      toast.success(`Payment of ₹${customerPaymentForm.amount} collected from ${customerPaymentForm.customer_name}!`);
      
      // Reset form and close dialog
      setShowCustomerPaymentDialog(false);
      setCustomerPaymentForm({
        customer_id: '',
        customer_name: '',
        amount: '',
        payment_type: 'order_payment',
        payment_method: 'cash',
        reference_number: '',
        description: '',
        collected_by: user?.id,
        collected_by_name: user?.name,
        collected_by_staff_id: user?.id,
        collected_by_staff_name: user?.name,
        order_id: ''
      });
      
    } catch (error) {
      console.error('Error collecting customer payment:', error);
      toast.error('Failed to record customer payment collection');
    }
  };

  const getFilteredCollections = () => {
    return paymentCollections.filter(collection => {
      const matchesSearch = collection.payer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           collection.reference_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           collection.description.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesPaymentType = filterPaymentType === 'all' || collection.payment_type === filterPaymentType;
      const matchesRole = filterRole === 'all' || collection.payer_role === filterRole;
      
      return matchesSearch && matchesPaymentType && matchesRole;
    });
  };

  const getTotalCollections = () => {
    return paymentCollections.reduce((sum, collection) => sum + collection.amount, 0);
  };

  const getTodayCollections = () => {
    const today = new Date().toDateString();
    return paymentCollections.filter(collection => 
      new Date(collection.collection_date).toDateString() === today
    );
  };

  const getCollectionsByRole = (role) => {
    return paymentCollections.filter(collection => collection.payer_role === role);
  };

  // Add missing computed values for the stats
  const todaysPayments = getTodayCollections();
  const totalTodaysRevenue = todaysPayments.reduce((sum, payment) => sum + payment.amount, 0);
  const pendingOrdersAmount = 0; // This would come from orders API in real implementation
  const totalRevenue = getTotalCollections();
  
  // Add filtered payments for the payment list
  const filteredPayments = getFilteredCollections();

  const exportCollections = () => {
    const collections = getFilteredCollections();
    const csv = convertCollectionsToCSV(collections);
    downloadCSV(csv, `payment-collections-${new Date().toISOString().split('T')[0]}.csv`);
    toast.success('Payment collections exported successfully!');
  };

  const convertCollectionsToCSV = (collections) => {
    const headers = [
      'Date', 'Payer Name', 'Role', 'Amount', 'Payment Type', 'Payment Method', 
      'Reference Number', 'Description', 'Collected By'
    ];
    
    const rows = collections.map(collection => [
      new Date(collection.collection_date).toLocaleDateString(),
      collection.payer_name,
      collection.payer_role,
      `₹${collection.amount}`,
      collection.payment_type.replace('_', ' '),
      collection.payment_method.toUpperCase(),
      collection.reference_number || 'N/A',
      collection.description || 'N/A',
      collection.collected_by_name
    ]);
    
    return [headers, ...rows].map(row => row.join(',')).join('\n');
  };

  const downloadCSV = (csv, filename) => {
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('hidden', '');
    a.setAttribute('href', url);
    a.setAttribute('download', filename);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const showReceipt = (payment) => {
    setSelectedPayment(payment);
    setShowReceiptDialog(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p>Loading payment collections...</p>
        </div>
      </div>
    );
  }

  const todaysCollections = getTodayCollections();
  const totalCollected = getTotalCollections();
  const deliveryBoyCollections = getCollectionsByRole('delivery_boy');
  const managerCollections = getCollectionsByRole('manager');
  
  // Customer payment stats
  const todaysCustomerPayments = customerPayments.filter(payment => 
    new Date(payment.collection_date).toDateString() === new Date().toDateString()
  );
  const totalCustomerPayments = customerPayments.reduce((sum, payment) => sum + payment.amount, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900" data-testid="payment-collection-title">
            Payment Collection Management
          </h1>
          <p className="text-gray-600 mt-1">
            Collect payments from delivery boys, managers, and administrators
          </p>
        </div>
        
        <div className="flex gap-3">
          <Button 
            onClick={exportCollections}
            variant="outline"
            className="border-green-600 text-green-600 hover:bg-green-50"
          >
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
          
          <Button 
            onClick={() => setShowCustomerPaymentDialog(true)}
            className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            data-testid="collect-customer-payment-btn"
          >
            <User className="w-4 h-4 mr-2" />
            Customer Payment
          </Button>
          
          <Button 
            onClick={() => setShowCollectionDialog(true)}
            className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
            data-testid="collect-staff-payment-btn"
          >
            <UserCheck className="w-4 h-4 mr-2" />
            Staff Payment
          </Button>
        </div>
      </div>
      
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="shadow-soft bg-gradient-to-r from-green-50 to-teal-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-700">Total Collections</p>
                <p className="text-3xl font-bold text-green-900">₹{totalCollected + totalCustomerPayments}</p>
                <p className="text-xs text-green-600">Staff: ₹{totalCollected} | Customer: ₹{totalCustomerPayments}</p>
              </div>
              <IndianRupee className="w-12 h-12 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft bg-gradient-to-r from-blue-50 to-cyan-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-700">Today's Collections</p>
                <p className="text-3xl font-bold text-blue-900">₹{todaysCollections.reduce((sum, c) => sum + c.amount, 0)}</p>
              </div>
              <Calendar className="w-12 h-12 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft bg-gradient-to-r from-purple-50 to-indigo-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-purple-700">Delivery Boy Payments</p>
                <p className="text-3xl font-bold text-purple-900">₹{deliveryBoyCollections.reduce((sum, c) => sum + c.amount, 0)}</p>
              </div>
              <UserCheck className="w-12 h-12 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft bg-gradient-to-r from-orange-50 to-red-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-orange-700">Manager Payments</p>
                <p className="text-3xl font-bold text-orange-900">₹{managerCollections.reduce((sum, c) => sum + c.amount, 0)}</p>
              </div>
              <User className="w-12 h-12 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Search and Filter Controls */}
      <Card className="shadow-soft">
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search by payer name, reference number, or description..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <Select value={filterPaymentType} onValueChange={setFilterPaymentType}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Payment Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Payment Types</SelectItem>
                {paymentTypes.map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={filterRole} onValueChange={setFilterRole}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Role Filter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                <SelectItem value="delivery_boy">Delivery Boys</SelectItem>
                <SelectItem value="manager">Managers</SelectItem>
                <SelectItem value="admin">Administrators</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Payment Collection Dialog */}
      <Dialog open={showCollectionDialog} onOpenChange={setShowCollectionDialog} modal={true}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto z-50">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <IndianRupee className="w-5 h-5 text-green-600" />
              <span>Collect Payment</span>
            </DialogTitle>
            <DialogDescription>
              Record payment collection from delivery boy, manager, or administrator
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Payer Selection */}
            <div className="space-y-2">
              <Label>Select Payer</Label>
              <Select value={collectionForm.payer_id} onValueChange={handlePayerSelection}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose person making payment" />
                </SelectTrigger>
                <SelectContent>
                  <optgroup label="Delivery Boys">
                    {deliveryBoys.map(boy => (
                      <SelectItem key={boy.id} value={boy.id}>
                        {boy.name} - {boy.assigned_area || 'No area'}
                      </SelectItem>
                    ))}
                  </optgroup>
                  <optgroup label="Managers & Administrators">
                    {managers.map(manager => (
                      <SelectItem key={manager.id} value={manager.id}>
                        {manager.name} - {manager.role.toUpperCase()}
                      </SelectItem>
                    ))}
                  </optgroup>
                </SelectContent>
              </Select>
            </div>

            {/* Payment Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="amount">Amount (₹)</Label>
                <Input
                  id="amount"
                  type="number"
                  min="1"
                  step="0.01"
                  value={collectionForm.amount}
                  onChange={(e) => setCollectionForm({...collectionForm, amount: e.target.value})}
                  placeholder="Enter amount"
                />
              </div>
              
              <div className="space-y-2">
                <Label>Payment Type</Label>
                <Select 
                  value={collectionForm.payment_type} 
                  onValueChange={(value) => setCollectionForm({...collectionForm, payment_type: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentTypes.map(type => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Payment Method</Label>
                <Select 
                  value={collectionForm.payment_method} 
                  onValueChange={(value) => setCollectionForm({...collectionForm, payment_method: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentMethods.map(method => (
                      <SelectItem key={method.value} value={method.value}>
                        <div className="flex items-center space-x-2">
                          <method.icon className="w-4 h-4" />
                          <span>{method.label}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="reference">Reference Number (Optional)</Label>
                <Input
                  id="reference"
                  value={collectionForm.reference_number}
                  onChange={(e) => setCollectionForm({...collectionForm, reference_number: e.target.value})}
                  placeholder="Transaction ID, Receipt No."
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description/Notes</Label>
              <Textarea
                id="description"
                rows={3}
                value={collectionForm.description}
                onChange={(e) => setCollectionForm({...collectionForm, description: e.target.value})}
                placeholder="Reason for payment, additional notes..."
              />
            </div>

            {/* Collection Summary */}
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <h4 className="font-medium text-green-900 mb-2">Collection Summary</h4>
              <div className="space-y-1 text-sm text-green-800">
                <p><strong>Payer:</strong> {collectionForm.payer_name || 'Not selected'}</p>
                <p><strong>Role:</strong> {collectionForm.payer_role || 'N/A'}</p>
                <p><strong>Amount:</strong> ₹{collectionForm.amount || '0'}</p>
                <p><strong>Type:</strong> {paymentTypes.find(t => t.value === collectionForm.payment_type)?.label || 'Delivery Collection'}</p>
                <p><strong>Method:</strong> {paymentMethods.find(m => m.value === collectionForm.payment_method)?.label || 'Cash'}</p>
                <p><strong>Collected By:</strong> {user?.name}</p>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCollectionDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleCollectPayment}
              className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
              disabled={!collectionForm.payer_id || !collectionForm.amount}
            >
              <Receipt className="w-4 h-4 mr-2" />
              Collect Payment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Customer Payment Collection Dialog */}
      <Dialog open={showCustomerPaymentDialog} onOpenChange={setShowCustomerPaymentDialog} modal={true}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto z-50">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <User className="w-5 h-5 text-blue-600" />
              <span>Collect Customer Payment</span>
            </DialogTitle>
            <DialogDescription>
              Record payment collection from customer
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Customer Selection */}
            <div className="space-y-2">
              <Label>Select Customer</Label>
              <Select value={customerPaymentForm.customer_id} onValueChange={handleCustomerSelection}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose customer making payment" />
                </SelectTrigger>
                <SelectContent>
                  {customers.map(customer => (
                    <SelectItem key={customer.id} value={customer.id}>
                      <div className="flex flex-col">
                        <span className="font-medium">{customer.name}</span>
                        <span className="text-xs text-gray-500">{customer.mobile} | {customer.address}</span>
                        {customer.cash_balance > 0 && (
                          <span className="text-xs text-red-600">Balance Due: ₹{customer.cash_balance}</span>
                        )}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Payment Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="customer-amount">Amount (₹)</Label>
                <Input
                  id="customer-amount"
                  type="number"
                  min="1"
                  step="0.01"
                  value={customerPaymentForm.amount}
                  onChange={(e) => setCustomerPaymentForm({...customerPaymentForm, amount: e.target.value})}
                  placeholder="Enter amount received"
                />
              </div>
              
              <div className="space-y-2">
                <Label>Payment Type</Label>
                <Select 
                  value={customerPaymentForm.payment_type} 
                  onValueChange={(value) => setCustomerPaymentForm({...customerPaymentForm, payment_type: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {customerPaymentTypes.map(type => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Payment Method</Label>
                <Select 
                  value={customerPaymentForm.payment_method} 
                  onValueChange={(value) => setCustomerPaymentForm({...customerPaymentForm, payment_method: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {paymentMethods.map(method => (
                      <SelectItem key={method.value} value={method.value}>
                        <div className="flex items-center space-x-2">
                          <method.icon className="w-4 h-4" />
                          <span>{method.label}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="customer-reference">Reference Number (Optional)</Label>
                <Input
                  id="customer-reference"
                  value={customerPaymentForm.reference_number}
                  onChange={(e) => setCustomerPaymentForm({...customerPaymentForm, reference_number: e.target.value})}
                  placeholder="Receipt No., Transaction ID"
                />
              </div>
            </div>

            {/* Staff Selection for who collected the payment */}
            <div className="space-y-2">
              <Label>Payment Collected By (Staff Member)</Label>
              <Select 
                value={customerPaymentForm.collected_by_staff_id} 
                onValueChange={(value) => {
                  const staff = [...deliveryBoys, ...managers].find(s => s.id === value);
                  setCustomerPaymentForm({
                    ...customerPaymentForm, 
                    collected_by_staff_id: value,
                    collected_by_staff_name: staff?.name || ''
                  });
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select staff member who collected payment" />
                </SelectTrigger>
                <SelectContent>
                  <optgroup label="Current User">
                    <SelectItem value={user?.id}>
                      {user?.name} - {user?.role.toUpperCase()} (You)
                    </SelectItem>
                  </optgroup>
                  <optgroup label="Delivery Boys">
                    {deliveryBoys.filter(boy => boy.id !== user?.id).map(boy => (
                      <SelectItem key={boy.id} value={boy.id}>
                        {boy.name} - {boy.assigned_area || 'No area assigned'}
                      </SelectItem>
                    ))}
                  </optgroup>
                  <optgroup label="Managers & Administrators">
                    {managers.filter(manager => manager.id !== user?.id).map(manager => (
                      <SelectItem key={manager.id} value={manager.id}>
                        {manager.name} - {manager.role.toUpperCase()}
                      </SelectItem>
                    ))}
                  </optgroup>
                </SelectContent>
              </Select>
            </div>

            {/* Staff Selection */}
            <div className="space-y-2">
              <Label>Collected By (Staff Member)</Label>
              <Select 
                value={customerPaymentForm.collected_by_staff_id} 
                onValueChange={(value) => {
                  const staff = [...deliveryBoys, ...managers].find(s => s.id === value);
                  setCustomerPaymentForm({
                    ...customerPaymentForm, 
                    collected_by_staff_id: value,
                    collected_by_staff_name: staff?.name || ''
                  });
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select staff member who collected payment" />
                </SelectTrigger>
                <SelectContent>
                  <optgroup label="Delivery Boys">
                    {deliveryBoys.map(boy => (
                      <SelectItem key={boy.id} value={boy.id}>
                        {boy.name} - {boy.assigned_area || 'No area'}
                      </SelectItem>
                    ))}
                  </optgroup>
                  <optgroup label="Managers & Administrators">
                    {managers.map(manager => (
                      <SelectItem key={manager.id} value={manager.id}>
                        {manager.name} - {manager.role.toUpperCase()}
                      </SelectItem>
                    ))}
                  </optgroup>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="customer-description">Payment Description/Notes</Label>
              <Textarea
                id="customer-description"
                rows={3}
                value={customerPaymentForm.description}
                onChange={(e) => setCustomerPaymentForm({...customerPaymentForm, description: e.target.value})}
                placeholder="Order payment, balance clearance, advance payment, etc..."
              />
            </div>

            {/* Customer Info & Summary */}
            {customerPaymentForm.customer_name && (
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h4 className="font-medium text-blue-900 mb-2">Payment Collection Summary</h4>
                <div className="space-y-1 text-sm text-blue-800">
                  <p><strong>Customer:</strong> {customerPaymentForm.customer_name}</p>
                  <p><strong>Amount:</strong> ₹{customerPaymentForm.amount || '0'}</p>
                  <p><strong>Payment Type:</strong> {customerPaymentTypes.find(t => t.value === customerPaymentForm.payment_type)?.label || 'Order Payment'}</p>
                  <p><strong>Payment Method:</strong> {paymentMethods.find(m => m.value === customerPaymentForm.payment_method)?.label || 'Cash'}</p>
                  <p><strong>Collected By:</strong> {customerPaymentForm.collected_by_staff_name || user?.name} 
                    {customerPaymentForm.collected_by_staff_id ? 
                      ` (${[...deliveryBoys, ...managers].find(s => s.id === customerPaymentForm.collected_by_staff_id)?.role.toUpperCase() || 'STAFF'})` : 
                      ` (${user?.role.toUpperCase()})`
                    }
                  </p>
                  <p><strong>Collection Date:</strong> {new Date().toLocaleDateString()}</p>
                </div>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCustomerPaymentDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleCustomerPaymentCollection}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
              disabled={!customerPaymentForm.customer_id || !customerPaymentForm.amount}
            >
              <Receipt className="w-4 h-4 mr-2" />
              Collect Payment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Duplicate section removed */}

      {/* Payment Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Today's Payments</p>
                <p className="text-2xl font-bold text-green-600" data-testid="todays-payments-stat">
                  {todaysPayments.length}
                </p>
              </div>
              <Receipt className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Today's Revenue</p>
                <p className="text-2xl font-bold text-blue-600" data-testid="todays-revenue-stat">
                  ₹{totalTodaysRevenue.toFixed(2)}
                </p>
              </div>
              <IndianRupee className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Outstanding Amount</p>
                <p className="text-2xl font-bold text-red-600" data-testid="outstanding-amount-stat">
                  ₹{pendingOrdersAmount.toFixed(2)}
                </p>
              </div>
              <CreditCard className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="shadow-soft">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Revenue</p>
                <p className="text-2xl font-bold text-purple-600" data-testid="total-revenue-stat">
                  ₹{totalRevenue.toFixed(2)}
                </p>
              </div>
              <IndianRupee className="w-8 h-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payment List */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle>Payment History</CardTitle>
          <CardDescription>
            {filteredPayments.length} payment(s) found
          </CardDescription>
        </CardHeader>
        
        <CardContent className="p-0">
          {filteredPayments.length === 0 ? (
            <div className="text-center py-12" data-testid="no-payments-message">
              <Receipt className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No payments found</h3>
              <p className="text-gray-600 mb-4">Start by recording your first payment.</p>
              <Button 
                onClick={() => setShowPaymentDialog(true)}
                className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
                data-testid="record-first-payment-btn"
              >
                <Plus className="w-4 h-4 mr-2" />
                Record Payment
              </Button>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {filteredPayments.map((payment) => (
                <div key={payment.id} className="p-6 hover:bg-gray-50 transition-colors" data-testid={`payment-item-${payment.id}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-3">
                        <h3 className="text-lg font-semibold text-gray-900" data-testid={`payment-receipt-${payment.id}`}>
                          {payment.receipt_number}
                        </h3>
                        
                        <Badge 
                          className="bg-green-100 text-green-800"
                        >
                          {payment.payment_method.toUpperCase()}
                        </Badge>
                        
                        <div className="text-lg font-bold text-green-600" data-testid={`payment-amount-${payment.id}`}>
                          ₹{payment.amount.toFixed(2)}
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm text-gray-600">
                        <div className="flex items-center space-x-2">
                          <User className="w-4 h-4" />
                          <span data-testid={`payment-customer-${payment.id}`}>{payment.customer_name}</span>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <Calendar className="w-4 h-4" />
                          <span data-testid={`payment-date-${payment.id}`}>
                            {format(new Date(payment.payment_date), "MMM dd, yyyy")}
                          </span>
                        </div>
                        
                        {payment.transaction_id && (
                          <div className="flex items-center space-x-2">
                            <CreditCard className="w-4 h-4" />
                            <span className="font-mono text-xs" data-testid={`payment-transaction-${payment.id}`}>
                              {payment.transaction_id}
                            </span>
                          </div>
                        )}
                        
                        <div className="flex items-center space-x-2">
                          <span className="text-gray-500">Order: #{payment.order_id.slice(-8)}</span>
                        </div>
                      </div>
                      
                      {payment.notes && (
                        <div className="mt-2">
                          <p className="text-sm text-gray-600">
                            <span className="font-medium">Notes:</span> {payment.notes}
                          </p>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => showReceipt(payment)}
                        className="hover:bg-blue-50 hover:text-blue-600"
                        data-testid={`view-receipt-${payment.id}`}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => showReceipt(payment)}
                        className="hover:bg-green-50 hover:text-green-600"
                        data-testid={`download-receipt-${payment.id}`}
                      >
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Receipt Dialog */}
      <Dialog open={showReceiptDialog} onOpenChange={setShowReceiptDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Payment Receipt</DialogTitle>
          </DialogHeader>
          
          {selectedPayment && (
            <div className="space-y-4 border rounded-lg p-4 bg-gray-50">
              <div className="text-center border-b pb-4">
                <h3 className="font-bold text-lg">WaterKard</h3>
                <p className="text-sm text-gray-600">Payment Receipt</p>
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="font-medium">Receipt No:</span>
                  <span>{selectedPayment.receipt_number}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Date:</span>
                  <span>{format(new Date(selectedPayment.payment_date), "MMM dd, yyyy")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Customer:</span>
                  <span>{selectedPayment.customer_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Order ID:</span>
                  <span>#{selectedPayment.order_id.slice(-8)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Payment Method:</span>
                  <span>{selectedPayment.payment_method.toUpperCase()}</span>
                </div>
                {selectedPayment.transaction_id && (
                  <div className="flex justify-between">
                    <span className="font-medium">Transaction ID:</span>
                    <span className="font-mono text-xs">{selectedPayment.transaction_id}</span>
                  </div>
                )}
                <div className="flex justify-between border-t pt-2 font-bold text-lg">
                  <span>Amount Paid:</span>
                  <span>₹{selectedPayment.amount.toFixed(2)}</span>
                </div>
              </div>
              
              <div className="text-center text-xs text-gray-500 border-t pt-4">
                <p>Thank you for your business!</p>
                <p>AquaElite - Premium Water Delivery System</p>
              </div>
            </div>
          )}
          
          <Button 
            onClick={() => setShowReceiptDialog(false)}
            className="w-full"
            data-testid="close-receipt-btn"
          >
            Close
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default PaymentManagement;