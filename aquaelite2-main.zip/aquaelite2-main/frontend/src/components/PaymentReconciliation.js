import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../App';
import axios from 'axios';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  IndianRupee,
  CheckCircle,
  Clock,
  Users,
  Receipt,
  TrendingUp,
  AlertCircle,
  RefreshCw
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

function PaymentReconciliation() {
  const { API, user } = useContext(AuthContext);
  const [loading, setLoading] = useState(true);
  const [pendingPayments, setPendingPayments] = useState([]);
  const [reconciliationSummary, setReconciliationSummary] = useState(null);
  const [showReceiveDialog, setShowReceiveDialog] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState(null);
  const [reconciliationNotes, setReconciliationNotes] = useState('');

  // Fetch all data
  const fetchData = async () => {
    try {
      setLoading(true);
      const [pendingRes, summaryRes] = await Promise.all([
        axios.get(`${API}/payments/pending-reconciliation`),
        axios.get(`${API}/payments/reconciliation-summary`)
      ]);
      
      setPendingPayments(pendingRes.data);
      setReconciliationSummary(summaryRes.data);
    } catch (error) {
      console.error('Error fetching reconciliation data:', error);
      toast.error('Failed to load payment reconciliation data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Handle admin receiving payment
  const handleReceivePayment = async () => {
    try {
      if (!selectedPayment) return;

      await axios.post(`${API}/payments/${selectedPayment.id}/receive`, {
        notes: reconciliationNotes
      });

      toast.success(`Payment of ₹${selectedPayment.amount} received from ${selectedPayment.collected_by_name}`);
      setShowReceiveDialog(false);
      setReconciliationNotes('');
      setSelectedPayment(null);
      fetchData(); // Refresh data
    } catch (error) {
      console.error('Error receiving payment:', error);
      toast.error('Failed to receive payment');
    }
  };

  const openReceiveDialog = (payment) => {
    setSelectedPayment(payment);
    setShowReceiveDialog(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4" />
          <p>Loading payment reconciliation data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Payment Reconciliation</h1>
          <p className="text-gray-600">Manage payments collected by delivery boys and managers</p>
        </div>
        <Button onClick={fetchData} variant="outline" className="flex items-center space-x-2">
          <RefreshCw className="w-4 h-4" />
          <span>Refresh</span>
        </Button>
      </div>

      {/* Summary Cards */}
      {reconciliationSummary && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-orange-50 border-orange-200">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2 text-orange-800">
                <Clock className="w-5 h-5" />
                <span>Pending Reconciliation</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-orange-600">
                ₹{reconciliationSummary.totals.total_pending_amount.toFixed(2)}
              </p>
              <p className="text-sm text-orange-600">
                {pendingPayments.length} payments pending
              </p>
            </CardContent>
          </Card>

          <Card className="bg-green-50 border-green-200">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2 text-green-800">
                <CheckCircle className="w-5 h-5" />
                <span>Received by Admin</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-green-600">
                ₹{reconciliationSummary.totals.total_received_amount.toFixed(2)}
              </p>
              <p className="text-sm text-green-600">Successfully reconciled</p>
            </CardContent>
          </Card>

          <Card className="bg-blue-50 border-blue-200">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2 text-blue-800">
                <TrendingUp className="w-5 h-5" />
                <span>Total Collections</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-blue-600">
                ₹{reconciliationSummary.totals.total_amount.toFixed(2)}
              </p>
              <p className="text-sm text-blue-600">All time collections</p>
            </CardContent>
          </Card>
        </div>
      )}

      <Tabs defaultValue="pending" className="w-full">
        <TabsList>
          <TabsTrigger value="pending">Pending Reconciliation</TabsTrigger>
          <TabsTrigger value="summary">Collector Summary</TabsTrigger>
        </TabsList>

        {/* Pending Payments Tab */}
        <TabsContent value="pending" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="w-5 h-5 text-orange-600" />
                <span>Payments Pending Admin Approval</span>
              </CardTitle>
              <CardDescription>
                These payments have been collected by delivery boys/managers but not yet received by admin
              </CardDescription>
            </CardHeader>
            <CardContent>
              {pendingPayments.length === 0 ? (
                <div className="text-center py-8">
                  <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                  <p className="text-gray-600">All payments have been reconciled!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {pendingPayments.map((payment) => (
                    <div key={payment.id} className="border rounded-lg p-4 flex justify-between items-center">
                      <div className="flex-1">
                        <div className="flex items-center space-x-4">
                          <div>
                            <p className="font-semibold">{payment.customer_name}</p>
                            {payment.event_name && (
                              <p className="text-sm font-medium text-purple-600">
                                Event: {payment.event_name}
                              </p>
                            )}
                            <p className="text-sm text-gray-600">
                              Collected by: {payment.collected_by_name}
                            </p>
                            <p className="text-xs text-gray-500">
                              {format(new Date(payment.collected_at), 'dd MMM yyyy, hh:mm a')}
                            </p>
                          </div>
                        </div>
                        <div className="mt-2">
                          <Badge variant="outline" className="mr-2">
                            {payment.payment_mode}
                          </Badge>
                          <Badge 
                            variant="outline"
                            className={
                              payment.payment_type === 'event_order_payment' ? 'bg-purple-100 text-purple-800' :
                              payment.payment_type === 'quick_delivery_payment' ? 'bg-blue-100 text-blue-800' :
                              'bg-gray-100 text-gray-800'
                            }
                          >
                            {payment.payment_type === 'event_order_payment' ? 'Event Order' :
                             payment.payment_type === 'quick_delivery_payment' ? 'Quick Delivery' :
                             payment.payment_type === 'customer_payment' ? 'Regular Payment' :
                             payment.payment_type}
                          </Badge>
                        </div>
                        {payment.notes && (
                          <p className="text-sm text-gray-600 mt-2">
                            <strong>Notes:</strong> {payment.notes}
                          </p>
                        )}
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-bold text-orange-600">
                          ₹{payment.amount.toFixed(2)}
                        </p>
                        <Button 
                          onClick={() => openReceiveDialog(payment)}
                          className="mt-2 bg-green-600 hover:bg-green-700"
                          size="sm"
                        >
                          <Receipt className="w-4 h-4 mr-2" />
                          Receive Payment
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Collector Summary Tab */}
        <TabsContent value="summary" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Users className="w-5 h-5 text-blue-600" />
                <span>Payment Collection Summary by Collector</span>
              </CardTitle>
              <CardDescription>
                Overview of payments collected by each team member
              </CardDescription>
            </CardHeader>
            <CardContent>
              {reconciliationSummary && reconciliationSummary.collectors.length === 0 ? (
                <div className="text-center py-8">
                  <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">No payment collections found</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {reconciliationSummary?.collectors.map((collector) => (
                    <div key={collector.collector_id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h3 className="font-semibold text-lg">{collector.collector_name}</h3>
                          <p className="text-sm text-gray-600">
                            Total Collections: {collector.total_count} payments
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-xl font-bold">₹{collector.total_amount.toFixed(2)}</p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div className="bg-orange-50 p-3 rounded">
                          <div className="flex items-center space-x-2 mb-1">
                            <Clock className="w-4 h-4 text-orange-600" />
                            <span className="text-sm font-medium text-orange-800">Pending</span>
                          </div>
                          <p className="text-lg font-bold text-orange-600">
                            ₹{collector.pending_amount.toFixed(2)}
                          </p>
                          <p className="text-xs text-orange-600">
                            {collector.pending_count} payments
                          </p>
                        </div>
                        
                        <div className="bg-green-50 p-3 rounded">
                          <div className="flex items-center space-x-2 mb-1">
                            <CheckCircle className="w-4 h-4 text-green-600" />
                            <span className="text-sm font-medium text-green-800">Received</span>
                          </div>
                          <p className="text-lg font-bold text-green-600">
                            ₹{collector.received_amount.toFixed(2)}
                          </p>
                          <p className="text-xs text-green-600">
                            {collector.received_count} payments
                          </p>
                        </div>
                      </div>
                      
                      {/* Payment Types Breakdown */}
                      {collector.payment_types && Object.keys(collector.payment_types).length > 0 && (
                        <div className="mt-3 pt-3 border-t">
                          <p className="text-sm font-medium text-gray-700 mb-2">Payment Types:</p>
                          <div className="flex flex-wrap gap-2">
                            {Object.entries(collector.payment_types).map(([type, data]) => (
                              <Badge 
                                key={type}
                                variant="outline" 
                                className={`text-xs ${
                                  type === 'event_order_payment' ? 'bg-purple-100 text-purple-800 border-purple-200' :
                                  type === 'quick_delivery_payment' ? 'bg-blue-100 text-blue-800 border-blue-200' :
                                  'bg-gray-100 text-gray-800 border-gray-200'
                                }`}
                              >
                                {type === 'event_order_payment' ? 'Events' :
                                 type === 'quick_delivery_payment' ? 'Quick Del.' :
                                 type === 'customer_payment' ? 'Regular' : type}: 
                                ₹{data.amount.toFixed(0)} ({data.count})
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Receive Payment Dialog */}
      <Dialog open={showReceiveDialog} onOpenChange={setShowReceiveDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Receipt className="w-5 h-5 text-green-600" />
              <span>Receive Payment</span>
            </DialogTitle>
            <DialogDescription>
              Confirm receiving payment from {selectedPayment?.collected_by_name}
            </DialogDescription>
          </DialogHeader>
          
          {selectedPayment && (
            <div className="space-y-4">
              {/* Payment Details */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Customer:</span>
                    <span className="font-medium">{selectedPayment.customer_name}</span>
                  </div>
                  {selectedPayment.event_name && (
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Event:</span>
                      <span className="font-medium text-purple-600">{selectedPayment.event_name}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Payment Type:</span>
                    <span className={`font-medium ${
                      selectedPayment.payment_type === 'event_order_payment' ? 'text-purple-600' :
                      selectedPayment.payment_type === 'quick_delivery_payment' ? 'text-blue-600' :
                      'text-gray-600'
                    }`}>
                      {selectedPayment.payment_type === 'event_order_payment' ? 'Event Order Payment' :
                       selectedPayment.payment_type === 'quick_delivery_payment' ? 'Quick Delivery Payment' :
                       selectedPayment.payment_type === 'customer_payment' ? 'Regular Payment' :
                       selectedPayment.payment_type}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Amount:</span>
                    <span className="font-bold text-green-600">₹{selectedPayment.amount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Payment Mode:</span>
                    <span className="font-medium">{selectedPayment.payment_mode}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Collected by:</span>
                    <span className="font-medium">{selectedPayment.collected_by_name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Collected at:</span>
                    <span className="font-medium">
                      {format(new Date(selectedPayment.collected_at), 'dd MMM yyyy, hh:mm a')}
                    </span>
                  </div>
                </div>
              </div>

              {/* Reconciliation Notes */}
              <div className="space-y-2">
                <Label>Admin Notes (Optional)</Label>
                <Textarea
                  value={reconciliationNotes}
                  onChange={(e) => setReconciliationNotes(e.target.value)}
                  placeholder="Add any notes about receiving this payment..."
                  rows="3"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex space-x-3">
                <Button
                  variant="outline"
                  onClick={() => setShowReceiveDialog(false)}
                  className="w-full"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleReceivePayment}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  <Receipt className="w-4 h-4 mr-2" />
                  Confirm Receipt
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default PaymentReconciliation;