import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../App';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { 
  Users2, 
  Plus, 
  Edit, 
  Trash2, 
  User, 
  Building, 
  Crown,
  Percent,
  UserPlus,
  UserMinus
} from 'lucide-react';
import { toast } from 'sonner';

function GroupManagement() {
  const { user, API } = useContext(AuthContext);
  const [groups, setGroups] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingGroup, setEditingGroup] = useState(null);
  const [selectedGroup, setSelectedGroup] = useState(null);
  const [showCustomerAssignment, setShowCustomerAssignment] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'Individual',
    discount_percentage: 0
  });

  // Check if current user is admin
  const isAdmin = user?.role === 'admin';

  useEffect(() => {
    if (isAdmin) {
      fetchGroups();
      fetchCustomers();
    }
  }, [isAdmin]);

  const fetchGroups = async () => {
    try {
      const response = await fetch(`${API}/customer-groups`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        const groupsData = await response.json();
        setGroups(groupsData);
      } else {
        throw new Error('Failed to fetch groups');
      }
    } catch (error) {
      console.error('Error fetching groups:', error);
      toast.error('Failed to load groups');
    } finally {
      setLoading(false);
    }
  };

  const fetchCustomers = async () => {
    try {
      const response = await fetch(`${API}/customers`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        const customersData = await response.json();
        setCustomers(customersData);
      }
    } catch (error) {
      console.error('Error fetching customers:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const url = editingGroup ? `${API}/customer-groups/${editingGroup.id}` : `${API}/customer-groups`;
      const method = editingGroup ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(formData)
      });
      
      if (response.ok) {
        toast.success(editingGroup ? 'Group updated successfully!' : 'Group created successfully!');
        setShowAddForm(false);
        setEditingGroup(null);
        setFormData({ name: '', description: '', category: 'Individual', discount_percentage: 0 });
        fetchGroups();
      } else {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to save group');
      }
    } catch (error) {
      console.error('Error saving group:', error);
      toast.error(error.message || 'Failed to save group');
    }
  };

  const handleEdit = (group) => {
    setFormData({
      name: group.name,
      description: group.description || '',
      category: group.category,
      discount_percentage: group.discount_percentage
    });
    setEditingGroup(group);
    setShowAddForm(true);
  };

  const handleDelete = async (groupId) => {
    try {
      const response = await fetch(`${API}/customer-groups/${groupId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        toast.success('Group deleted successfully');
        fetchGroups();
      } else {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to delete group');
      }
    } catch (error) {
      console.error('Error deleting group:', error);
      toast.error(error.message || 'Failed to delete group');
    }
  };

  const handleAssignCustomer = async (customerId, groupId) => {
    try {
      const response = await fetch(`${API}/customer-groups/${groupId}/add-customer/${customerId}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (response.ok) {
        toast.success('Customer assigned to group successfully');
        fetchCustomers();
      } else {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to assign customer');
      }
    } catch (error) {
      console.error('Error assigning customer:', error);
      toast.error(error.message || 'Failed to assign customer');
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'Corporate': return <Building className="w-4 h-4" />;
      case 'VIP': return <Crown className="w-4 h-4" />;
      default: return <User className="w-4 h-4" />;
    }
  };

  const getCategoryColor = (category) => {
    switch (category) {
      case 'Corporate': return 'bg-blue-100 text-blue-800';
      case 'VIP': return 'bg-yellow-100 text-yellow-800';
      case 'Individual': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCustomersInGroup = (groupId) => {
    return customers.filter(customer => customer.group_id === groupId);
  };

  const getUnassignedCustomers = () => {
    return customers.filter(customer => !customer.group_id);
  };

  // Redirect if not admin
  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Users2 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Access Denied</h3>
          <p className="text-gray-600">You don't have permission to access group management.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900" data-testid="group-management-title">
            Group Management
          </h1>
          <p className="text-gray-600 mt-1">
            Manage customer groups and categories
          </p>
        </div>
        
        <Button 
          onClick={() => {
            setFormData({ name: '', description: '', category: 'Individual', discount_percentage: 0 });
            setEditingGroup(null);
            setShowAddForm(true);
          }}
          className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
          data-testid="add-group-btn"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Group
        </Button>
      </div>

      {/* Add/Edit Group Dialog */}
      <Dialog open={showAddForm} onOpenChange={setShowAddForm}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>
              {editingGroup ? 'Edit Group' : 'Add New Group'}
            </DialogTitle>
            <DialogDescription>
              Create customer groups to organize and manage pricing.
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name">Group Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                required
                data-testid="group-name-input"
              />
            </div>
            
            <div>
              <Label htmlFor="category">Category</Label>
              <Select value={formData.category} onValueChange={(value) => setFormData({...formData, category: value})}>
                <SelectTrigger data-testid="group-category-select">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Individual">Individual</SelectItem>
                  <SelectItem value="Corporate">Corporate</SelectItem>
                  <SelectItem value="VIP">VIP</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="discount">Discount Percentage</Label>
              <Input
                id="discount"
                type="number"
                min="0"
                max="100"
                step="0.1"
                value={formData.discount_percentage}
                onChange={(e) => setFormData({...formData, discount_percentage: parseFloat(e.target.value) || 0})}
                data-testid="group-discount-input"
              />
            </div>
            
            <div>
              <Label htmlFor="description">Description (Optional)</Label>
              <textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="Enter group description"
                className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                data-testid="group-description-input"
              />
            </div>
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setShowAddForm(false)}>
                Cancel
              </Button>
              <Button type="submit" data-testid="save-group-btn">
                {editingGroup ? 'Update' : 'Create'} Group
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Groups List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {groups.map((group) => {
          const customersInGroup = getCustomersInGroup(group.id);
          
          return (
            <Card key={group.id} className="shadow-soft hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg flex items-center space-x-2">
                    {getCategoryIcon(group.category)}
                    <span>{group.name}</span>
                  </CardTitle>
                  <Badge className={getCategoryColor(group.category)}>
                    {group.category}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {group.description && (
                  <p className="text-sm text-gray-600">{group.description}</p>
                )}
                
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center space-x-1">
                    <Users2 className="w-4 h-4 text-gray-400" />
                    <span>{customersInGroup.length} customers</span>
                  </div>
                  
                  {group.discount_percentage > 0 && (
                    <div className="flex items-center space-x-1 text-green-600">
                      <Percent className="w-4 h-4" />
                      <span>{group.discount_percentage}% discount</span>
                    </div>
                  )}
                </div>
                
                <div className="flex space-x-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(group)}
                    data-testid={`edit-group-${group.id}-btn`}
                  >
                    <Edit className="w-3 h-3" />
                  </Button>
                  
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" data-testid={`manage-customers-${group.id}-btn`}>
                        <UserPlus className="w-3 h-3" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Manage Customers - {group.name}</DialogTitle>
                        <DialogDescription>
                          Add or remove customers from this group
                        </DialogDescription>
                      </DialogHeader>
                      
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-medium mb-2">Customers in Group ({customersInGroup.length})</h4>
                          <div className="max-h-32 overflow-y-auto space-y-1">
                            {customersInGroup.map((customer) => (
                              <div key={customer.id} className="flex items-center justify-between p-2 border rounded">
                                <span className="text-sm">{customer.name}</span>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleAssignCustomer(customer.id, null)}
                                >
                                  <UserMinus className="w-3 h-3" />
                                </Button>
                              </div>
                            ))}
                            {customersInGroup.length === 0 && (
                              <p className="text-sm text-gray-500">No customers in this group</p>
                            )}
                          </div>
                        </div>
                        
                        <div>
                          <h4 className="font-medium mb-2">Unassigned Customers ({getUnassignedCustomers().length})</h4>
                          <div className="max-h-32 overflow-y-auto space-y-1">
                            {getUnassignedCustomers().map((customer) => (
                              <div key={customer.id} className="flex items-center justify-between p-2 border rounded">
                                <span className="text-sm">{customer.name}</span>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleAssignCustomer(customer.id, group.id)}
                                >
                                  <UserPlus className="w-3 h-3" />
                                </Button>
                              </div>
                            ))}
                            {getUnassignedCustomers().length === 0 && (
                              <p className="text-sm text-gray-500">All customers are assigned</p>
                            )}
                          </div>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                  
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-red-600 hover:text-red-700"
                        data-testid={`delete-group-${group.id}-btn`}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Group</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to delete "{group.name}"? 
                          {customersInGroup.length > 0 && (
                            <span className="block mt-1 text-red-600">
                              This group has {customersInGroup.length} customers assigned. 
                              Please reassign them first.
                            </span>
                          )}
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction 
                          onClick={() => handleDelete(group.id)}
                          className="bg-red-600 hover:bg-red-700"
                          disabled={customersInGroup.length > 0}
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>
          );
        })}
        
        {groups.length === 0 && (
          <div className="col-span-full text-center py-12">
            <Users2 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Groups Found</h3>
            <p className="text-gray-600">Create your first customer group to get started.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default GroupManagement;