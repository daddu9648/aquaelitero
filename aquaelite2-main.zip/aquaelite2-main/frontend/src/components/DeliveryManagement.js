import React, { useState, useEffect, useContext } from 'react';
import { AuthContext } from '../App';
import axios from 'axios';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { 
  Truck, 
  MapPin, 
  Calendar,
  User,
  Phone,
  Package,
  ArrowDownCircle,
  ArrowUpCircle,
  CheckCircle,
  IndianRupee,
  FileText,
  Search,
  Filter,
  PackageCheck,
  PackageOpen,
  CreditCard,
  Banknote,
  Clock,
  Navigation,
  AlertTriangle,
  UserCheck
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

function DeliveryManagement() {
  const { API, user } = useContext(AuthContext);
  const [customers, setCustomers] = useState([]);
  const [customerGroups, setCustomerGroups] = useState([]);
  const [eventOrders, setEventOrders] = useState([]);
  const [deliveryBoys, setDeliveryBoys] = useState([]);
  const [loadedJars, setLoadedJars] = useState([]);
  const [deliveries, setDeliveries] = useState([]);
  const [reports, setReports] = useState({ daily: [], monthly: [] });
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [customerBalance, setCustomerBalance] = useState(0);
  const [loadingData, setLoadingData] = useState({});
  const [showLoadingDialog, setShowLoadingDialog] = useState(false);
  const [unloadingData, setUnloadingData] = useState({});
  const [showUnloadingDialog, setShowUnloadingDialog] = useState(false);
  const [showDeliveryDialog, setShowDeliveryDialog] = useState(false);
  const [showSimpleDeliveryDialog, setShowSimpleDeliveryDialog] = useState(false);
  const [showReportDialog, setShowReportDialog] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [reportType, setReportType] = useState('daily');
  
  const [deliveryData, setDeliveryData] = useState({
    customer_id: '',
    customer_name: '',
    jars_delivered: 0,
    empty_jars_collected: false,
    empty_jars_count: 0,
    payment_received: 0,
    payment_mode: 'cash',
    payment_status: 'pending',
    delivery_notes: ''
  });

  const [simpleDeliveryForm, setSimpleDeliveryForm] = useState({
    customer_id: '',
    customer_name: '',
    customer_address: '',
    customer_group_id: 'none',
    customer_group_name: '',
    event_id: 'none',
    event_name: '',
    delivery_boy_id: '',
    delivery_boy_name: '',
    jars_delivered: '',
    empty_jars_collected: false,
    empty_jars_count: '',
    payment_received: '',
    payment_mode: 'cash',
    payment_status: 'pending',
    delivery_notes: '',
    vehicle_number: ''
  });

  // New delivery functions for customer-centric delivery
  const openCustomerDeliveryDialog = (customer) => {
    setSelectedCustomer(customer);
    
    // Find loaded jars for this customer
    const customerJars = loadedJars.filter(jar => jar.customer_id === customer.id);
    const totalJarsLoaded = customerJars.reduce((sum, jar) => sum + jar.jars_loaded, 0);
    
    if (totalJarsLoaded === 0) {
      toast.error('No loaded jars found for this customer');
      return;
    }
    
    setDeliveryData({
      customer_id: customer.id,
      customer_name: customer.name,
      jars_delivered: totalJarsLoaded, // Default to all loaded jars
      empty_jars_collected: false,
      empty_jars_count: 0,
      payment_received: 0,
      payment_mode: 'cash',
      payment_status: 'pending',
      delivery_notes: ''
    });
    
    setShowDeliveryDialog(true);
  };

  const handleCustomerDeliveryComplete = async () => {
    try {
      if (deliveryData.jars_delivered <= 0) {
        toast.error('Please enter valid jar count for delivery');
        return;
      }

      // Create delivery record
      const deliveryRecord = {
        customer_id: deliveryData.customer_id,
        customer_name: deliveryData.customer_name,
        jars_delivered: deliveryData.jars_delivered,
        empty_jars_collected: deliveryData.empty_jars_collected,
        empty_jars_count: deliveryData.empty_jars_collected ? deliveryData.empty_jars_count : 0,
        payment_received: deliveryData.payment_received,
        payment_mode: deliveryData.payment_mode,
        payment_status: deliveryData.payment_received > 0 ? 'paid' : 'pending',
        delivery_notes: deliveryData.delivery_notes,
        delivery_date: new Date().toISOString(),
        delivery_status: 'completed'
      };

      // Save delivery record to local state for immediate display
      setDeliveries(prev => [deliveryRecord, ...prev]);
      
      // Update customer balance if payment received
      if (deliveryData.payment_received > 0) {
        try {
          await axios.put(`${API}/customers/${deliveryData.customer_id}/balance`, {
            amount_received: deliveryData.payment_received,
            payment_mode: deliveryData.payment_mode,
            notes: `Payment received during delivery on ${new Date().toLocaleDateString()}`
          });
        } catch (error) {
          console.warn('Could not update customer balance:', error);
        }
      }
      
      toast.success(`Delivery completed! ${deliveryData.jars_delivered} jars delivered to ${deliveryData.customer_name}`);
      setShowDeliveryDialog(false);
      setSelectedCustomer(null);
      fetchData(); // Refresh data
      
    } catch (error) {
      console.error('Error completing delivery:', error);
      toast.error('Failed to complete delivery');
    }
  };

  const handleCustomerSelectionForSimpleDelivery = (customerId) => {
    const customer = customers.find(c => c.id === customerId);
    if (customer) {
      setSimpleDeliveryForm({
        ...simpleDeliveryForm,
        customer_id: customerId,
        customer_name: customer.name,
        customer_address: customer.address,
        customer_group_id: customer.group_id || 'none',
        customer_group_name: customer.group_id ? 
          customerGroups.find(g => g.id === customer.group_id)?.name || '' : ''
      });
    }
  };

  const handleGroupSelection = (groupId) => {
    const group = customerGroups.find(g => g.id === groupId);
    setSimpleDeliveryForm({
      ...simpleDeliveryForm,
      customer_group_id: groupId,
      customer_group_name: groupId === 'none' ? '' : (group ? group.name : '')
    });
  };

  const handleEventSelection = (eventId) => {
    const event = eventOrders.find(e => e.id === eventId);
    setSimpleDeliveryForm({
      ...simpleDeliveryForm,
      event_id: eventId,
      event_name: eventId === 'none' ? '' : (event ? event.event_name : '')
    });
  };

  const handleDeliveryBoySelection = (deliveryBoyId) => {
    const deliveryBoy = deliveryBoys.find(db => db.id === deliveryBoyId);
    setSimpleDeliveryForm({
      ...simpleDeliveryForm,
      delivery_boy_id: deliveryBoyId,
      delivery_boy_name: deliveryBoy ? deliveryBoy.name : ''
    });
  };

  const handleSimpleDeliveryComplete = async () => {
    try {
      // Validation
      if (!simpleDeliveryForm.customer_id) {
        toast.error('Please select a customer');
        return;
      }
      if (!simpleDeliveryForm.jars_delivered || parseInt(simpleDeliveryForm.jars_delivered) <= 0) {
        toast.error('Please enter valid number of jars delivered');
        return;
      }
      if (!simpleDeliveryForm.delivery_boy_id) {
        toast.error('Please assign a delivery boy');
        return;
      }

      // Create delivery record
      const deliveryRecord = {
        id: Date.now().toString(),
        customer_id: simpleDeliveryForm.customer_id,
        customer_name: simpleDeliveryForm.customer_name,
        customer_address: simpleDeliveryForm.customer_address,
        customer_group_id: simpleDeliveryForm.customer_group_id,
        customer_group_name: simpleDeliveryForm.customer_group_name,
        event_id: simpleDeliveryForm.event_id,
        event_name: simpleDeliveryForm.event_name,
        delivery_boy_id: simpleDeliveryForm.delivery_boy_id,
        delivery_boy_name: simpleDeliveryForm.delivery_boy_name,
        jars_delivered: parseInt(simpleDeliveryForm.jars_delivered),
        empty_jars_collected: simpleDeliveryForm.empty_jars_collected,
        empty_jars_count: simpleDeliveryForm.empty_jars_collected ? parseInt(simpleDeliveryForm.empty_jars_count) || 0 : 0,
        payment_received: parseFloat(simpleDeliveryForm.payment_received) || 0,
        payment_mode: simpleDeliveryForm.payment_mode,
        payment_status: parseFloat(simpleDeliveryForm.payment_received) > 0 ? 'paid' : 'pending',
        delivery_notes: simpleDeliveryForm.delivery_notes,
        vehicle_number: simpleDeliveryForm.vehicle_number,
        delivery_date: new Date().toISOString(),
        delivery_status: 'completed',
        delivered_by: user?.name || 'Unknown',
        created_by: user?.name || 'Unknown'
      };

      // Save delivery record (in production, this would be API call)
      const existingDeliveries = JSON.parse(localStorage.getItem('simpleDeliveries') || '[]');
      const updatedDeliveries = [deliveryRecord, ...existingDeliveries];
      localStorage.setItem('simpleDeliveries', JSON.stringify(updatedDeliveries));
      
      setDeliveries(prev => [deliveryRecord, ...prev]);

      // Update customer balance if payment received
      if (parseFloat(simpleDeliveryForm.payment_received) > 0) {
        try {
          await axios.put(`${API}/customers/${simpleDeliveryForm.customer_id}/balance`, {
            amount_received: parseFloat(simpleDeliveryForm.payment_received),
            payment_mode: simpleDeliveryForm.payment_mode,
            notes: `Payment received during delivery by ${user?.name} on ${new Date().toLocaleDateString()}`
          });
        } catch (error) {
          console.warn('Could not update customer balance:', error);
        }
      }
      
      toast.success(`Delivery completed! ${simpleDeliveryForm.jars_delivered} jars delivered to ${simpleDeliveryForm.customer_name}`);
      
      // Reset form and close dialog
      setShowSimpleDeliveryDialog(false);
      resetSimpleDeliveryForm();
      
    } catch (error) {
      console.error('Error completing simple delivery:', error);
      toast.error('Failed to complete delivery');
    }
  };

  const resetSimpleDeliveryForm = () => {
    setSimpleDeliveryForm({
      customer_id: '',
      customer_name: '',
      customer_address: '',
      customer_group_id: 'none',
      customer_group_name: '',
      event_id: 'none',
      event_name: '',
      delivery_boy_id: '',
      delivery_boy_name: '',
      jars_delivered: '',
      empty_jars_collected: false,
      empty_jars_count: '',
      payment_received: '',
      payment_mode: 'cash',
      payment_status: 'pending',
      delivery_notes: '',
      vehicle_number: ''
    });
  };
  const generateDeliveryReport = () => {
    setShowReportDialog(true);
  };

  const exportDeliveryReport = () => {
    const reportData = reportType === 'daily' ? reports.daily : reports.monthly;
    
    if (reportData.length === 0) {
      toast.error('No delivery data available for export');
      return;
    }
    
    const csv = convertDeliveriesToCSV(reportData);
    downloadCSVFile(csv, `delivery-report-${reportType}-${new Date().toISOString().split('T')[0]}.csv`);
    toast.success('Report exported successfully!');
  };

  const convertDeliveriesToCSV = (data) => {
    const headers = [
      'Date', 
      'Customer Name', 
      'Jars Delivered', 
      'Empty Jars Collected', 
      'Payment Received', 
      'Payment Mode',
      'Payment Status',
      'Notes'
    ];
    
    const rows = data.map(delivery => [
      new Date(delivery.unloading_completed_at || delivery.updated_at || delivery.delivery_date).toLocaleDateString(),
      delivery.customer_name || 'Unknown',
      delivery.jars_delivered || 0,
      delivery.empty_jars_count || 0,
      delivery.payment_received ? `₹${delivery.payment_received}` : '₹0',
      delivery.payment_mode || 'cash',
      delivery.payment_status || 'pending',
      delivery.delivery_notes || delivery.customer_notes || ''
    ]);
    
    return [headers, ...rows].map(row => row.join(',')).join('\n');
  };

  const downloadCSVFile = (csv, filename) => {
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('hidden', '');
    a.setAttribute('href', url);
    a.setAttribute('download', filename);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  // Filter functions
  const filteredCustomersForDelivery = customers.filter(customer => {
    const hasLoadedJars = loadedJars.some(jar => jar.customer_id === customer.id);
    const matchesSearch = customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          customer.mobile.includes(searchTerm) ||
                          customer.address.toLowerCase().includes(searchTerm.toLowerCase());
    
    return hasLoadedJars && matchesSearch;
  });

  const getCustomerLoadedJars = (customerId) => {
    const customerJars = loadedJars.filter(jar => jar.customer_id === customerId);
    return customerJars.reduce((sum, jar) => sum + jar.jars_loaded, 0);
  };

  const getTodayDeliveryStats = () => {
    const today = new Date().toDateString();
    const todayDeliveries = deliveries.filter(d => 
      new Date(d.delivery_date || d.updated_at).toDateString() === today
    );
    
    return {
      totalDeliveries: todayDeliveries.length,
      totalJarsDelivered: todayDeliveries.reduce((sum, d) => sum + (d.jars_delivered || 0), 0),
      totalPaymentCollected: todayDeliveries.reduce((sum, d) => sum + (d.payment_received || 0), 0),
      totalEmptyJars: todayDeliveries.reduce((sum, d) => sum + (d.empty_jars_count || 0), 0)
    };
  };
  
  const [deliveryForm, setDeliveryForm] = useState({
    filled_jars_delivered: 0,
    empty_jars_collected: 0,
    missing_jars: 0,
    damaged_jars: 0,
    payment_collected: 0,
    balance_adjustment: 0,
    balance_adjustment_type: 'payment', // payment or charge
    customer_notes: '',
    missing_jar_reason: ''
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      // Fetch all required data
      const [customersRes, groupsRes, eventsRes, deliveryBoysRes] = await Promise.all([
        axios.get(`${API}/customers`).catch(() => ({ data: [] })),
        axios.get(`${API}/customer-groups`).catch(() => ({ data: [] })),
        axios.get(`${API}/event-orders`).catch(() => ({ data: [] })),
        axios.get(`${API}/users?role=delivery_boy`).catch(() => ({ data: [] }))
      ]);
      
      setCustomers(customersRes.data || []);
      setCustomerGroups(groupsRes.data || []);
      setEventOrders(eventsRes.data || []);
      setDeliveryBoys(deliveryBoysRes.data || []);
      
      // Fetch loaded jars (from loading entries or orders with loaded jars)
      await fetchLoadedJars();
      
      // Fetch delivery history
      await fetchDeliveries();
      
      // Fetch reports
      await fetchReports();
      
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Error loading data');
    } finally {
      setLoading(false);
    }
  };

  const fetchLoadedJars = async () => {
    try {
      // Get orders with loaded jars (in_transit status)
      const ordersRes = await axios.get(`${API}/orders`);
      const loadedOrders = ordersRes.data.filter(order => 
        order.delivery_status === 'in_transit' && order.products_loaded
      );
      
      // Transform to loaded jars format
      const jarsData = loadedOrders.map(order => ({
        id: order.id,
        customer_id: order.customer_id,
        customer_name: order.customer_name,
        jars_loaded: order.products_loaded.reduce((sum, p) => sum + (p.quantity_loaded || 0), 0),
        vehicle_number: order.vehicle_number,
        loaded_date: order.loading_completed_at,
        products: order.products_loaded
      }));
      
      setLoadedJars(jarsData);
    } catch (error) {
      console.error('Error fetching loaded jars:', error);
      setLoadedJars([]);
    }
  };

  const fetchDeliveries = async () => {
    try {
      // In a real implementation, this would be a separate deliveries endpoint
      // For now, we'll use delivered orders
      const ordersRes = await axios.get(`${API}/orders`);
      const deliveredOrders = ordersRes.data.filter(order => 
        order.delivery_status === 'delivered'
      );
      setDeliveries(deliveredOrders);
    } catch (error) {
      console.error('Error fetching deliveries:', error);
      setDeliveries([]);
    }
  };

  const fetchReports = async () => {
    try {
      const today = new Date();
      const startOfDay = new Date(today.setHours(0, 0, 0, 0));
      const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
      
      // Daily report
      const dailyDeliveries = deliveries.filter(delivery => 
        new Date(delivery.unloading_completed_at || delivery.updated_at) >= startOfDay
      );
      
      // Monthly report  
      const monthlyDeliveries = deliveries.filter(delivery =>
        new Date(delivery.unloading_completed_at || delivery.updated_at) >= startOfMonth
      );
      
      setReports({
        daily: dailyDeliveries,
        monthly: monthlyDeliveries
      });
    } catch (error) {
      console.error('Error generating reports:', error);
    }
  };

  const getCustomerById = (customerId) => {
    return customers.find(customer => customer.id === customerId);
  };

  const handleStartDelivery = async (order) => {
    setSelectedOrder(order);
    
    // Get customer balance
    const customer = getCustomerById(order.customer_id);
    setCustomerBalance(customer?.balance_due || 0);
    
    setDeliveryForm({
      filled_jars_delivered: order.products.reduce((sum, p) => sum + p.quantity, 0),
      empty_jars_collected: 0,
      payment_collected: order.payment_mode === 'cash' ? order.total_amount : 0,
      balance_adjustment: 0,
      balance_adjustment_type: 'payment',
      customer_notes: ''
    });
    setShowDeliveryDialog(true);
  };

  const handleCompleteDelivery = async (e) => {
    e.preventDefault();
    try {
      // Update order status
      await axios.put(`${API}/orders/${selectedOrder.id}`, {
        delivery_status: 'delivered',
        payment_status: deliveryForm.payment_collected > 0 ? 'paid' : selectedOrder.payment_status
      });

      // Record payment if collected
      if (deliveryForm.payment_collected > 0) {
        await axios.post(`${API}/payments`, {
          order_id: selectedOrder.id,
          customer_id: selectedOrder.customer_id,
          amount: deliveryForm.payment_collected,
          payment_method: 'cash',
          notes: `Payment collected during delivery. ${deliveryForm.customer_notes}`
        });
      }

      // Update customer balance if there's a balance adjustment
      if (deliveryForm.balance_adjustment > 0) {
        await axios.post(`${API}/customers/${selectedOrder.customer_id}/update-balance`, {
          amount: deliveryForm.balance_adjustment,
          type: deliveryForm.balance_adjustment_type,
          notes: `Balance ${deliveryForm.balance_adjustment_type} during delivery. ${deliveryForm.customer_notes}`
        });
      }

      toast.success('Delivery completed successfully!');
      setShowDeliveryDialog(false);
      setSelectedOrder(null);
      fetchData();
    } catch (error) {
      console.error('Error completing delivery:', error);
      toast.error('Failed to complete delivery');
    }
  };

  // Loading Operations
  const handleStartLoading = (order) => {
    setSelectedOrder(order);
    setLoadingData({
      loading_location: 'Main Warehouse',
      vehicle_number: '',
      products_loaded: order.products.map(p => ({...p, loaded_quantity: p.quantity}))
    });
    setShowLoadingDialog(true);
  };

  const handleCompleteLoading = async (order) => {
    try {
      await axios.post(`${API}/orders/${order.id}/complete-loading`);
      toast.success('Loading completed! Order is now in transit.');
      fetchData();
    } catch (error) {
      console.error('Error completing loading:', error);
      toast.error('Failed to complete loading');
    }
  };

  const handleStartUnloading = (order) => {
    setSelectedOrder(order);
    setUnloadingData({
      empty_jars_collected: 0,
      customer_notes: ''
    });
    setShowUnloadingDialog(true);
  };

  const handleSubmitLoading = async () => {
    try {
      await axios.post(`${API}/orders/${selectedOrder.id}/start-loading`, loadingData);
      toast.success('Loading started successfully!');
      setShowLoadingDialog(false);
      fetchData();
    } catch (error) {
      console.error('Error starting loading:', error);
      toast.error('Failed to start loading');
    }
  };

  const handleCompleteUnloading = async () => {
    try {
      await axios.post(`${API}/orders/${selectedOrder.id}/complete-unloading`, unloadingData);
      toast.success('Delivery completed successfully!');
      setShowUnloadingDialog(false);
      fetchData();
    } catch (error) {
      console.error('Error completing unloading:', error);
      toast.error('Failed to complete delivery');
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending': return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'loading': return <PackageOpen className="w-4 h-4 text-blue-500" />;
      case 'in_transit': return <Navigation className="w-4 h-4 text-purple-500" />;
      case 'unloading': return <PackageCheck className="w-4 h-4 text-orange-500" />;
      case 'delivered': return <CheckCircle className="w-4 h-4 text-green-500" />;
      default: return <AlertTriangle className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'pending': return 'Pending';
      case 'loading': return 'Loading';
      case 'in_transit': return 'In Transit';
      case 'unloading': return 'Unloading';
      case 'delivered': return 'Delivered';
      default: return 'Unknown';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'loading': return 'bg-blue-100 text-blue-800';
      case 'in_transit': return 'bg-purple-100 text-purple-800';
      case 'unloading': return 'bg-orange-100 text-orange-800';
      case 'delivered': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const todayStats = getTodayDeliveryStats();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading delivery operations...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900" data-testid="delivery-management-title">
            Delivery Operations
          </h1>
          <p className="text-gray-600 mt-1">
            Select customers, deliver loaded jars, collect empty jars & payments
          </p>
        </div>
        <div className="flex gap-3">
          <Button onClick={generateDeliveryReport} className="bg-blue-600 hover:bg-blue-700">
            <FileText className="w-4 h-4 mr-2" />
            View Reports
          </Button>
          
          <Button 
            onClick={() => setShowSimpleDeliveryDialog(true)}
            className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
            data-testid="simple-delivery-btn"
          >
            <PackageCheck className="w-4 h-4 mr-2" />
            Quick Delivery
          </Button>
        </div>
      </div>

      {/* Today's Delivery Summary */}
      <Card className="shadow-soft bg-gradient-to-r from-blue-50 to-cyan-50">
        <CardContent className="p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Today's Delivery Summary</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
            <div className="bg-white rounded-lg p-4">
              <Truck className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600">{todayStats.totalDeliveries}</p>
              <p className="text-sm text-gray-600">Deliveries Made</p>
            </div>
            <div className="bg-white rounded-lg p-4">
              <Package className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">{todayStats.totalJarsDelivered}</p>
              <p className="text-sm text-gray-600">Jars Delivered</p>
            </div>
            <div className="bg-white rounded-lg p-4">
              <ArrowDownCircle className="w-8 h-8 text-orange-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600">{todayStats.totalEmptyJars}</p>
              <p className="text-sm text-gray-600">Empty Jars Collected</p>
            </div>
            <div className="bg-white rounded-lg p-4">
              <IndianRupee className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600">₹{todayStats.totalPaymentCollected}</p>
              <p className="text-sm text-gray-600">Payment Collected</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Customer Search and Filter */}
      <Card className="shadow-soft">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input 
                placeholder="Search customers by name, mobile, or address..." 
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="text-sm text-gray-600 flex items-center">
              <Filter className="w-4 h-4 mr-2" />
              Showing customers with loaded jars: {filteredCustomersForDelivery.length}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Customers with Loaded Jars */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Truck className="w-5 h-5 text-blue-600" />
            <span>Customers Ready for Delivery</span>
          </CardTitle>
          <CardDescription>
            Select customers who have loaded jars for delivery
          </CardDescription>
        </CardHeader>
        
        <CardContent className="p-0">
          {filteredCustomersForDelivery.length === 0 ? (
            <div className="text-center py-12" data-testid="no-customers-message">
              <Package className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No customers with loaded jars</h3>
              <p className="text-gray-600">Load jars first or check if customers have pending deliveries.</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {filteredCustomersForDelivery.map((customer) => (
                <div key={customer.id} className="p-6 hover:bg-gray-50 transition-colors" data-testid={`customer-item-${customer.id}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                          <User className="w-5 h-5 text-green-600" />
                        </div>
                        
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900" data-testid={`customer-name-${customer.id}`}>
                            {customer.name}
                          </h3>
                          <p className="text-sm text-gray-600">{customer.mobile}</p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm text-gray-600 mb-4">
                        <div className="flex items-center space-x-2">
                          <MapPin className="w-4 h-4" />
                          <span className="truncate">{customer.address}</span>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <Package className="w-4 h-4" />
                          <span className="font-medium">{getCustomerLoadedJars(customer.id)} jars loaded</span>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <IndianRupee className="w-4 h-4" />
                          <span className="text-red-600">₹{customer.cash_balance || 0} balance</span>
                        </div>
                      </div>

                      {/* Loaded Jars Details */}
                      {loadedJars
                        .filter(jar => jar.customer_id === customer.id)
                        .map((jar, index) => (
                          <div key={index} className="bg-blue-50 rounded-lg p-3 mb-3">
                            <h4 className="font-medium text-sm text-blue-700 mb-2">Loaded Jars:</h4>
                            <div className="space-y-1">
                              <div className="flex justify-between text-sm">
                                <span>Vehicle: {jar.vehicle_number}</span>
                                <span className="font-medium">{jar.jars_loaded} jars</span>
                              </div>
                              {jar.loaded_date && (
                                <div className="text-xs text-blue-600">
                                  Loaded: {new Date(jar.loaded_date).toLocaleDateString()}
                                </div>
                              )}
                            </div>
                          </div>
                        ))}

                      {/* Customer Balance Info */}
                      {customer.cash_balance !== 0 && (
                        <div className={`p-3 rounded-lg ${customer.cash_balance > 0 ? 'bg-red-50 border border-red-200' : 'bg-green-50 border border-green-200'}`}>
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Customer Balance:</span>
                            <span className={`font-bold ${customer.cash_balance > 0 ? 'text-red-700' : 'text-green-700'}`}>
                              ₹{Math.abs(customer.cash_balance).toFixed(2)} {customer.cash_balance > 0 ? '(Due)' : '(Credit)'}
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="ml-4 space-y-2">
                      {/* Delivery Action Button */}
                      <Button 
                        onClick={() => openCustomerDeliveryDialog(customer)}
                        className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 w-full"
                        data-testid={`start-delivery-${customer.id}`}
                      >
                        <Truck className="w-4 h-4 mr-2" />
                        Start Delivery
                      </Button>
                      
                      <div className="text-xs text-gray-500 text-center">
                        {getCustomerLoadedJars(customer.id)} jars ready
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Customer Delivery Dialog */}
      <Dialog open={showDeliveryDialog} onOpenChange={setShowDeliveryDialog} modal={true}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto z-50">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Truck className="w-5 h-5 text-green-600" />
              <span>Complete Customer Delivery</span>
            </DialogTitle>
            <DialogDescription>
              Deliver loaded jars, collect empty jars, and process payment
            </DialogDescription>
          </DialogHeader>
          
          {selectedCustomer && (
            <div className="space-y-6">
              {/* Customer Info */}
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="font-semibold text-green-900 mb-2">
                  Delivery for {selectedCustomer.name}
                </h3>
                <div className="text-sm text-green-700 space-y-1">
                  <p><strong>Mobile:</strong> {selectedCustomer.mobile}</p>
                  <p><strong>Address:</strong> {selectedCustomer.address}</p>
                  <p><strong>Loaded Jars:</strong> {getCustomerLoadedJars(selectedCustomer.id)} jars ready</p>
                  {selectedCustomer.cash_balance !== 0 && (
                    <p><strong>Balance:</strong> ₹{selectedCustomer.cash_balance} {selectedCustomer.cash_balance > 0 ? '(Due)' : '(Credit)'}</p>
                  )}
                </div>
              </div>

              {/* Jar Delivery Section */}
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900 flex items-center">
                  <Package className="w-5 h-5 text-blue-500 mr-2" />
                  Jar Delivery
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Jars to Deliver</Label>
                    <Input
                      type="number"
                      min="0"
                      max={getCustomerLoadedJars(selectedCustomer.id)}
                      value={deliveryData.jars_delivered}
                      onChange={(e) => setDeliveryData({
                        ...deliveryData, 
                        jars_delivered: parseInt(e.target.value) || 0
                      })}
                      placeholder="Number of jars to deliver"
                    />
                  </div>
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <p className="text-sm text-blue-700">
                      <strong>Available:</strong> {getCustomerLoadedJars(selectedCustomer.id)} jars
                    </p>
                  </div>
                </div>
              </div>

              {/* Empty Jar Collection */}
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900 flex items-center">
                  <ArrowDownCircle className="w-5 h-5 text-orange-500 mr-2" />
                  Empty Jar Collection
                </h4>
                
                <div className="space-y-3">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <input
                        type="radio"
                        id="collect-yes"
                        name="empty-jars"
                        checked={deliveryData.empty_jars_collected === true}
                        onChange={() => setDeliveryData({
                          ...deliveryData, 
                          empty_jars_collected: true
                        })}
                      />
                      <Label htmlFor="collect-yes">Yes, collect empty jars</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <input
                        type="radio"
                        id="collect-no"
                        name="empty-jars"
                        checked={deliveryData.empty_jars_collected === false}
                        onChange={() => setDeliveryData({
                          ...deliveryData, 
                          empty_jars_collected: false,
                          empty_jars_count: 0
                        })}
                      />
                      <Label htmlFor="collect-no">No empty jars</Label>
                    </div>
                  </div>

                  {deliveryData.empty_jars_collected && (
                    <div className="space-y-2">
                      <Label>Number of Empty Jars Collected</Label>
                      <Input
                        type="number"
                        min="0"
                        value={deliveryData.empty_jars_count}
                        onChange={(e) => setDeliveryData({
                          ...deliveryData,
                          empty_jars_count: parseInt(e.target.value) || 0
                        })}
                        placeholder="Count of empty jars"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Payment Section */}
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900 flex items-center">
                  <IndianRupee className="w-5 h-5 text-purple-500 mr-2" />
                  Payment Collection
                </h4>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Payment Received (₹)</Label>
                    <Input
                      type="number"
                      min="0"
                      step="0.01"
                      value={deliveryData.payment_received}
                      onChange={(e) => setDeliveryData({
                        ...deliveryData,
                        payment_received: parseFloat(e.target.value) || 0,
                        payment_status: parseFloat(e.target.value) > 0 ? 'paid' : 'pending'
                      })}
                      placeholder="Amount received"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Payment Mode</Label>
                    <Select 
                      value={deliveryData.payment_mode} 
                      onValueChange={(value) => setDeliveryData({...deliveryData, payment_mode: value})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cash">Cash</SelectItem>
                        <SelectItem value="upi">UPI</SelectItem>
                        <SelectItem value="online">Online Transfer</SelectItem>
                        <SelectItem value="cheque">Cheque</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Payment Status</Label>
                  <Select 
                    value={deliveryData.payment_status} 
                    onValueChange={(value) => setDeliveryData({...deliveryData, payment_status: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="paid">Paid</SelectItem>
                      <SelectItem value="partial">Partial</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Delivery Notes */}
              <div className="space-y-2">
                <Label>Delivery Notes (Optional)</Label>
                <Textarea
                  rows={3}
                  value={deliveryData.delivery_notes}
                  onChange={(e) => setDeliveryData({...deliveryData, delivery_notes: e.target.value})}
                  placeholder="Any observations, customer feedback, or special notes..."
                />
              </div>

              {/* Summary */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-3">Delivery Summary</h4>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="space-y-1">
                    <p><strong>Customer:</strong> {deliveryData.customer_name}</p>
                    <p><strong>Jars Delivered:</strong> {deliveryData.jars_delivered}</p>
                    <p><strong>Empty Jars:</strong> {deliveryData.empty_jars_collected ? deliveryData.empty_jars_count : 'None'}</p>
                  </div>
                  <div className="space-y-1">
                    <p><strong>Payment:</strong> ₹{deliveryData.payment_received}</p>
                    <p><strong>Mode:</strong> {deliveryData.payment_mode.toUpperCase()}</p>
                    <p><strong>Status:</strong> {deliveryData.payment_status.toUpperCase()}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowDeliveryDialog(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleCustomerDeliveryComplete}
              className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
              disabled={!selectedCustomer || deliveryData.jars_delivered === 0}
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Complete Delivery
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reports Dialog */}
      <Dialog open={showReportDialog} onOpenChange={setShowReportDialog}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <FileText className="w-5 h-5 text-blue-600" />
              <span>Delivery Reports</span>
            </DialogTitle>
            <DialogDescription>
              View and export daily/monthly delivery reports
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            {/* Report Type Selection */}
            <div className="flex items-center space-x-4">
              <Label>Report Type:</Label>
              <div className="flex space-x-2">
                <Button
                  variant={reportType === 'daily' ? 'default' : 'outline'}
                  onClick={() => setReportType('daily')}
                  size="sm"
                >
                  Daily Report
                </Button>
                <Button
                  variant={reportType === 'monthly' ? 'default' : 'outline'}
                  onClick={() => setReportType('monthly')}
                  size="sm"
                >
                  Monthly Report
                </Button>
              </div>
              <Button
                onClick={exportDeliveryReport}
                className="ml-auto"
                size="sm"
              >
                <FileText className="w-4 h-4 mr-2" />
                Export CSV
              </Button>
            </div>

            {/* Report Summary */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card className="p-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-blue-600">
                    {reportType === 'daily' ? reports.daily.length : reports.monthly.length}
                  </p>
                  <p className="text-sm text-gray-600">Total Deliveries</p>
                </div>
              </Card>
              <Card className="p-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-green-600">
                    {(reportType === 'daily' ? reports.daily : reports.monthly)
                      .reduce((sum, d) => sum + (d.jars_delivered || 0), 0)}
                  </p>
                  <p className="text-sm text-gray-600">Jars Delivered</p>
                </div>
              </Card>
              <Card className="p-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-orange-600">
                    {(reportType === 'daily' ? reports.daily : reports.monthly)
                      .reduce((sum, d) => sum + (d.empty_jars_count || 0), 0)}
                  </p>
                  <p className="text-sm text-gray-600">Empty Jars</p>
                </div>
              </Card>
              <Card className="p-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-purple-600">
                    ₹{(reportType === 'daily' ? reports.daily : reports.monthly)
                      .reduce((sum, d) => sum + (d.payment_received || 0), 0)}
                  </p>
                  <p className="text-sm text-gray-600">Payment Collected</p>
                </div>
              </Card>
            </div>

            {/* Report Table */}
            <div className="border rounded-lg overflow-hidden">
              <div className="bg-gray-50 p-3 font-medium text-sm border-b">
                {reportType === 'daily' ? 'Today\'s' : 'This Month\'s'} Delivery Records
              </div>
              <div className="max-h-64 overflow-y-auto">
                {(reportType === 'daily' ? reports.daily : reports.monthly).length === 0 ? (
                  <div className="p-8 text-center text-gray-500">
                    No delivery records found for {reportType} report
                  </div>
                ) : (
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left p-2">Date</th>
                        <th className="text-left p-2">Customer</th>
                        <th className="text-left p-2">Jars</th>
                        <th className="text-left p-2">Empty Jars</th>
                        <th className="text-left p-2">Payment</th>
                        <th className="text-left p-2">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(reportType === 'daily' ? reports.daily : reports.monthly)
                        .slice(0, 50) // Limit to 50 records for display
                        .map((delivery, index) => (
                          <tr key={index} className="border-t hover:bg-gray-50">
                            <td className="p-2">
                              {new Date(delivery.delivery_date || delivery.updated_at).toLocaleDateString()}
                            </td>
                            <td className="p-2">{delivery.customer_name || 'Unknown'}</td>
                            <td className="p-2">{delivery.jars_delivered || 0}</td>
                            <td className="p-2">{delivery.empty_jars_count || 0}</td>
                            <td className="p-2">₹{delivery.payment_received || 0}</td>
                            <td className="p-2">
                              <Badge 
                                className={delivery.payment_status === 'paid' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}
                              >
                                {delivery.payment_status || 'pending'}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReportDialog(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Loading Dialog */}
      <Dialog open={showLoadingDialog} onOpenChange={setShowLoadingDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <PackageOpen className="w-5 h-5" />
              <span>Start Loading</span>
            </DialogTitle>
            <DialogDescription>
              Record loading details and vehicle information
            </DialogDescription>
          </DialogHeader>
          
          {selectedOrder && (
            <div className="space-y-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-semibold text-blue-900 mb-2">Loading for {selectedOrder.customer_name}</h3>
                <p className="text-sm text-blue-700">Order #{selectedOrder.id.slice(-8)} • ₹{selectedOrder.total_amount}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="loading-location">Loading Location</Label>
                  <Input
                    id="loading-location"
                    value={loadingData.loading_location}
                    onChange={(e) => setLoadingData({...loadingData, loading_location: e.target.value})}
                    placeholder="e.g., Main Warehouse"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="vehicle-number">Vehicle Number</Label>
                  <Input
                    id="vehicle-number"
                    value={loadingData.vehicle_number}
                    onChange={(e) => setLoadingData({...loadingData, vehicle_number: e.target.value})}
                    placeholder="e.g., MH12AB1234"
                  />
                </div>
              </div>

              <div className="space-y-3">
                <Label>Products to Load</Label>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {loadingData.products_loaded.map((product, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <span className="font-medium">{product.product_name}</span>
                        <p className="text-sm text-gray-600">Ordered: {product.quantity} units</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Label>Load:</Label>
                        <Input
                          type="number"
                          className="w-20"
                          min="0"
                          max={product.quantity}
                          value={product.loaded_quantity}
                          onChange={(e) => {
                            const updatedProducts = [...loadingData.products_loaded];
                            updatedProducts[index].loaded_quantity = parseInt(e.target.value) || 0;
                            setLoadingData({...loadingData, products_loaded: updatedProducts});
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex space-x-2 pt-4">
                <Button 
                  onClick={handleSubmitLoading}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
                >
                  <PackageOpen className="w-4 h-4 mr-2" />
                  Start Loading
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setShowLoadingDialog(false)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Unloading Dialog */}
      <Dialog open={showUnloadingDialog} onOpenChange={setShowUnloadingDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <ArrowDownCircle className="w-5 h-5" />
              <span>Start Unloading</span>
            </DialogTitle>
            <DialogDescription>
              Record unloading details and empty jar collection
            </DialogDescription>
          </DialogHeader>
          
          {selectedOrder && (
            <div className="space-y-6">
              <div className="bg-orange-50 p-4 rounded-lg">
                <h3 className="font-semibold text-orange-900 mb-2">Unloading for {selectedOrder.customer_name}</h3>
                <p className="text-sm text-orange-700">Order #{selectedOrder.id.slice(-8)} • ₹{selectedOrder.total_amount}</p>
                <div className="mt-2 text-sm">
                  <p>Address: {getCustomerById(selectedOrder.customer_id)?.address || 'Not available'}</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="empty-jars">Empty Jars to Collect</Label>
                  <Input
                    id="empty-jars"
                    type="number"
                    min="0"
                    value={unloadingData.empty_jars_collected}
                    onChange={(e) => setUnloadingData({...unloadingData, empty_jars_collected: parseInt(e.target.value) || 0})}
                    placeholder="Number of empty jars collected"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="customer-notes-unload">Customer Notes (Optional)</Label>
                  <textarea
                    id="customer-notes-unload"
                    className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    value={unloadingData.customer_notes}
                    onChange={(e) => setUnloadingData({...unloadingData, customer_notes: e.target.value})}
                    placeholder="Any special instructions or observations..."
                  />
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-2">Delivery Summary</h4>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Products to deliver:</span>
                    <span className="font-medium">{selectedOrder.products.reduce((sum, p) => sum + p.quantity, 0)} jars</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Empty jars to collect:</span>
                    <span className="font-medium">{unloadingData.empty_jars_collected}</span>
                  </div>
                </div>
              </div>

              <div className="flex space-x-2 pt-4">
                <Button 
                  onClick={handleCompleteUnloading}
                  className="flex-1 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Complete Delivery
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setShowUnloadingDialog(false)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Simple Delivery Dialog */}
      <Dialog open={showSimpleDeliveryDialog} onOpenChange={setShowSimpleDeliveryDialog} modal={true}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto z-50">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <PackageCheck className="w-5 h-5 text-green-600" />
              <span>Quick Delivery Entry</span>
            </DialogTitle>
            <DialogDescription>
              Simple delivery form - select customer, enter delivery details, collect payment
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Customer Selection */}
            <div className="space-y-2">
              <Label>Select Customer *</Label>
              <Select value={simpleDeliveryForm.customer_id} onValueChange={handleCustomerSelectionForSimpleDelivery}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose customer for delivery" />
                </SelectTrigger>
                <SelectContent>
                  {customers.map(customer => (
                    <SelectItem key={customer.id} value={customer.id}>
                      <div className="flex flex-col">
                        <span className="font-medium">{customer.name}</span>
                        <span className="text-xs text-gray-500">{customer.mobile} | {customer.address}</span>
                        {customer.cash_balance > 0 && (
                          <span className="text-xs text-red-600">Balance Due: ₹{customer.cash_balance}</span>
                        )}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Selected Customer Info */}
            {simpleDeliveryForm.customer_name && (
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h4 className="font-medium text-blue-900 mb-1">Selected Customer</h4>
                <p className="text-sm text-blue-800"><strong>{simpleDeliveryForm.customer_name}</strong></p>
                <p className="text-xs text-blue-600">{simpleDeliveryForm.customer_address}</p>
                {simpleDeliveryForm.customer_group_name && (
                  <p className="text-xs text-green-600">Group: {simpleDeliveryForm.customer_group_name}</p>
                )}
              </div>
            )}

            {/* Assignments Section */}
            <div className="space-y-4">
              <h4 className="font-medium text-gray-900 flex items-center">
                <UserCheck className="w-5 h-5 text-purple-500 mr-2" />
                Assignments & Delivery Boy
              </h4>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Customer Group Assignment */}
                <div className="space-y-2">
                  <Label>Customer Group (Optional)</Label>
                  <Select value={simpleDeliveryForm.customer_group_id} onValueChange={handleGroupSelection}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select group" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No Group</SelectItem>
                      {customerGroups.map(group => (
                        <SelectItem key={group.id} value={group.id}>
                          <div className="flex flex-col">
                            <span className="font-medium">{group.name}</span>
                            <span className="text-xs text-gray-500">
                              {group.discount_percentage}% discount
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Event Assignment */}
                <div className="space-y-2">
                  <Label>Event Order (Optional)</Label>
                  <Select value={simpleDeliveryForm.event_id} onValueChange={handleEventSelection}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select event" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No Event</SelectItem>
                      {eventOrders.map(event => (
                        <SelectItem key={event.id} value={event.id}>
                          <div className="flex flex-col">
                            <span className="font-medium">{event.event_name}</span>
                            <span className="text-xs text-gray-500">
                              {new Date(event.event_date).toLocaleDateString()}
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Delivery Boy Assignment */}
                <div className="space-y-2">
                  <Label>Delivery Boy *</Label>
                  <Select value={simpleDeliveryForm.delivery_boy_id} onValueChange={handleDeliveryBoySelection}>
                    <SelectTrigger>
                      <SelectValue placeholder="Assign delivery boy" />
                    </SelectTrigger>
                    <SelectContent>
                      {deliveryBoys.map(boy => (
                        <SelectItem key={boy.id} value={boy.id}>
                          <div className="flex flex-col">
                            <span className="font-medium">{boy.name}</span>
                            <span className="text-xs text-gray-500">
                              {boy.assigned_area || 'No area assigned'}
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Delivery Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="jars-delivered">Jars Delivered *</Label>
                <Input
                  id="jars-delivered"
                  type="number"
                  min="1"
                  value={simpleDeliveryForm.jars_delivered}
                  onChange={(e) => setSimpleDeliveryForm({...simpleDeliveryForm, jars_delivered: e.target.value})}
                  placeholder="Number of jars delivered"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="vehicle-no">Vehicle Number (Optional)</Label>
                <Input
                  id="vehicle-no"
                  value={simpleDeliveryForm.vehicle_number}
                  onChange={(e) => setSimpleDeliveryForm({...simpleDeliveryForm, vehicle_number: e.target.value})}
                  placeholder="e.g., MH12AB1234"
                />
              </div>
            </div>

            {/* Empty Jar Collection */}
            <div className="space-y-4">
              <h4 className="font-medium text-gray-900 flex items-center">
                <ArrowDownCircle className="w-5 h-5 text-orange-500 mr-2" />
                Empty Jar Collection
              </h4>
              
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="empty-yes"
                    name="empty-jars"
                    checked={simpleDeliveryForm.empty_jars_collected === true}
                    onChange={() => setSimpleDeliveryForm({
                      ...simpleDeliveryForm, 
                      empty_jars_collected: true
                    })}
                  />
                  <Label htmlFor="empty-yes">Yes, collected empty jars</Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <input
                    type="radio"
                    id="empty-no"
                    name="empty-jars"
                    checked={simpleDeliveryForm.empty_jars_collected === false}
                    onChange={() => setSimpleDeliveryForm({
                      ...simpleDeliveryForm, 
                      empty_jars_collected: false,
                      empty_jars_count: ''
                    })}
                  />
                  <Label htmlFor="empty-no">No empty jars</Label>
                </div>
              </div>

              {simpleDeliveryForm.empty_jars_collected && (
                <div className="space-y-2">
                  <Label htmlFor="empty-count">Number of Empty Jars Collected</Label>
                  <Input
                    id="empty-count"
                    type="number"
                    min="0"
                    value={simpleDeliveryForm.empty_jars_count}
                    onChange={(e) => setSimpleDeliveryForm({
                      ...simpleDeliveryForm,
                      empty_jars_count: e.target.value
                    })}
                    placeholder="Count of empty jars"
                  />
                </div>
              )}
            </div>

            {/* Payment Collection */}
            <div className="space-y-4">
              <h4 className="font-medium text-gray-900 flex items-center">
                <IndianRupee className="w-5 h-5 text-green-500 mr-2" />
                Payment Collection
              </h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="payment-amount">Payment Received (₹)</Label>
                  <Input
                    id="payment-amount"
                    type="number"
                    min="0"
                    step="0.01"
                    value={simpleDeliveryForm.payment_received}
                    onChange={(e) => setSimpleDeliveryForm({
                      ...simpleDeliveryForm,
                      payment_received: e.target.value
                    })}
                    placeholder="Amount received"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Payment Mode</Label>
                  <Select 
                    value={simpleDeliveryForm.payment_mode} 
                    onValueChange={(value) => setSimpleDeliveryForm({...simpleDeliveryForm, payment_mode: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cash">
                        <div className="flex items-center space-x-2">
                          <Banknote className="w-4 h-4" />
                          <span>Cash</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="upi">
                        <div className="flex items-center space-x-2">
                          <CreditCard className="w-4 h-4" />
                          <span>UPI</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="online">
                        <div className="flex items-center space-x-2">
                          <CreditCard className="w-4 h-4" />
                          <span>Online Transfer</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="cheque">
                        <div className="flex items-center space-x-2">
                          <CreditCard className="w-4 h-4" />
                          <span>Cheque</span>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Delivery Notes */}
            <div className="space-y-2">
              <Label htmlFor="delivery-notes">Delivery Notes (Optional)</Label>
              <Textarea
                id="delivery-notes"
                rows={3}
                value={simpleDeliveryForm.delivery_notes}
                onChange={(e) => setSimpleDeliveryForm({...simpleDeliveryForm, delivery_notes: e.target.value})}
                placeholder="Any observations, customer feedback, delivery issues..."
              />
            </div>

            {/* Delivery Summary */}
            {simpleDeliveryForm.customer_name && (
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <h4 className="font-medium text-green-900 mb-3">Delivery Summary</h4>
                <div className="grid grid-cols-2 gap-4 text-sm text-green-800">
                  <div className="space-y-1">
                    <p><strong>Customer:</strong> {simpleDeliveryForm.customer_name}</p>
                    <p><strong>Jars Delivered:</strong> {simpleDeliveryForm.jars_delivered || '0'}</p>
                    <p><strong>Empty Jars:</strong> {simpleDeliveryForm.empty_jars_collected ? simpleDeliveryForm.empty_jars_count || '0' : 'None'}</p>
                    <p><strong>Delivery Boy:</strong> {simpleDeliveryForm.delivery_boy_name || 'Not assigned'}</p>
                  </div>
                  <div className="space-y-1">
                    <p><strong>Payment:</strong> ₹{simpleDeliveryForm.payment_received || '0'}</p>
                    <p><strong>Mode:</strong> {simpleDeliveryForm.payment_mode.toUpperCase()}</p>
                    <p><strong>Vehicle:</strong> {simpleDeliveryForm.vehicle_number || 'Not specified'}</p>
                    {simpleDeliveryForm.customer_group_name && (
                      <p><strong>Group:</strong> {simpleDeliveryForm.customer_group_name}</p>
                    )}
                    {simpleDeliveryForm.event_name && (
                      <p><strong>Event:</strong> {simpleDeliveryForm.event_name}</p>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => {
                setShowSimpleDeliveryDialog(false);
                resetSimpleDeliveryForm();
              }}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSimpleDeliveryComplete}
              className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
              disabled={!simpleDeliveryForm.customer_id || !simpleDeliveryForm.jars_delivered || !simpleDeliveryForm.delivery_boy_id}
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Complete Delivery
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default DeliveryManagement;