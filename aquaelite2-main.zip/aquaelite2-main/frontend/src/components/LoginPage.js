import React, { useState, useContext } from 'react';
import { AuthContext } from '../App';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Droplets, Truck, Shield } from 'lucide-react';

function LoginPage() {
  const { login, register } = useContext(AuthContext);
  const [activeTab, setActiveTab] = useState('login');
  const [loading, setLoading] = useState(false);
  
  // Login form state
  const [loginData, setLoginData] = useState({
    email: '',
    mobile: '',
    password: ''
  });
  
  // Login type toggle
  const [loginType, setLoginType] = useState('email'); // 'email' or 'mobile'
  
  // Register form state
  const [registerData, setRegisterData] = useState({
    name: '',
    email: '',
    mobile: '',
    password: '',
    confirmPassword: '',
    role: 'admin'
  });

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    // Prepare login credentials based on login type
    const credentials = {
      password: loginData.password
    };
    
    if (loginType === 'email') {
      credentials.email = loginData.email;
    } else {
      credentials.mobile = loginData.mobile;
    }
    
    const result = await login(credentials);
    setLoading(false);
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    
    if (registerData.password !== registerData.confirmPassword) {
      alert('Passwords do not match');
      return;
    }
    
    setLoading(true);
    
    const { confirmPassword, ...userData } = registerData;
    const result = await register(userData);
    
    if (result.success) {
      setActiveTab('login');
      setRegisterData({
        name: '',
        email: '',
        mobile: '',
        password: '',
        confirmPassword: '',
        role: 'admin'
      });
    }
    
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-cyan-50 px-4">
      <div className="w-full max-w-md">
        {/* Logo & Brand */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center w-20 h-20 mb-4 mx-auto bg-gradient-to-br from-blue-50 to-cyan-50 shadow-lg p-3 border-2 border-blue-200" style={{borderRadius: '50%'}}>
            <img 
              src="/aquaelite-logo.png" 
              alt="AquaElite Logo" 
              className="w-full h-full object-contain"
              style={{borderRadius: '50%'}}
            />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">AquaElite</h1>
          <p className="text-gray-600">Premium Water Delivery System</p>
        </div>

        <Card className="shadow-xl border-0">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl text-center">Welcome Back</CardTitle>
            <CardDescription className="text-center">
              Sign in to your account or create a new one
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">Sign In</TabsTrigger>
                <TabsTrigger value="register">Sign Up</TabsTrigger>
              </TabsList>
              
              {/* Login Form */}
              <TabsContent value="login" className="space-y-4">
                <form onSubmit={handleLogin} className="space-y-4">
                  {/* Login Type Toggle */}
                  <div className="space-y-3">
                    <Label>Login With</Label>
                    <div className="flex space-x-2">
                      <Button
                        type="button"
                        variant={loginType === 'email' ? 'default' : 'outline'}
                        onClick={() => setLoginType('email')}
                        className="flex-1"
                      >
                        📧 Email
                      </Button>
                      <Button
                        type="button"
                        variant={loginType === 'mobile' ? 'default' : 'outline'}
                        onClick={() => setLoginType('mobile')}
                        className="flex-1"
                      >
                        📱 Mobile
                      </Button>
                    </div>
                  </div>
                  
                  {/* Email Input */}
                  {loginType === 'email' && (
                    <div className="space-y-2">
                      <Label htmlFor="loginEmail">Email Address</Label>
                      <Input
                        id="loginEmail"
                        type="email"
                        placeholder="admin@waterkard.com"
                        value={loginData.email}
                        onChange={(e) => setLoginData({...loginData, email: e.target.value})}
                        required
                        data-testid="login-email-input"
                        className="focus-ring"
                      />
                    </div>
                  )}
                  
                  {/* Mobile Input */}
                  {loginType === 'mobile' && (
                    <div className="space-y-2">
                      <Label htmlFor="loginMobile">Mobile Number</Label>
                      <Input
                        id="loginMobile"
                        type="tel"
                        placeholder="+91 98765 43210"
                        value={loginData.mobile}
                        onChange={(e) => setLoginData({...loginData, mobile: e.target.value})}
                        required
                        data-testid="login-mobile-input"
                        className="focus-ring"
                      />
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    <Label htmlFor="loginPassword">Password</Label>
                    <Input
                      id="loginPassword"
                      type="password"
                      placeholder="Enter your password"
                      value={loginData.password}
                      onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                      required
                      data-testid="login-password-input"
                      className="focus-ring"
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 transition-all duration-200"
                    disabled={loading}
                    data-testid="login-submit-btn"
                  >
                    {loading ? 'Signing in...' : 'Sign In'}
                  </Button>
                </form>
              </TabsContent>
              
              {/* Register Form */}
              <TabsContent value="register" className="space-y-4">
                <form onSubmit={handleRegister} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="registerName">Full Name</Label>
                    <Input
                      id="registerName"
                      type="text"
                      placeholder="John Doe"
                      value={registerData.name}
                      onChange={(e) => setRegisterData({...registerData, name: e.target.value})}
                      required
                      data-testid="register-name-input"
                      className="focus-ring"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="registerEmail">Email</Label>
                    <Input
                      id="registerEmail"
                      type="email"
                      placeholder="john@example.com"
                      value={registerData.email}
                      onChange={(e) => setRegisterData({...registerData, email: e.target.value})}
                      required
                      data-testid="register-email-input"
                      className="focus-ring"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="registerMobile">Mobile Number</Label>
                    <Input
                      id="registerMobile"
                      type="tel"
                      placeholder="+91 9876543210"
                      value={registerData.mobile}
                      onChange={(e) => setRegisterData({...registerData, mobile: e.target.value})}
                      required
                      data-testid="register-mobile-input"
                      className="focus-ring"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="registerRole">Role</Label>
                    <Select 
                      value={registerData.role} 
                      onValueChange={(value) => setRegisterData({...registerData, role: value})}
                    >
                      <SelectTrigger data-testid="register-role-select">
                        <SelectValue placeholder="Select role" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="admin">
                          <div className="flex items-center gap-2">
                            <Shield className="w-4 h-4" />
                            Admin
                          </div>
                        </SelectItem>
                        <SelectItem value="delivery_boy">
                          <div className="flex items-center gap-2">
                            <Truck className="w-4 h-4" />
                            Delivery Boy
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="registerPassword">Password</Label>
                    <Input
                      id="registerPassword"
                      type="password"
                      placeholder="Create a password"
                      value={registerData.password}
                      onChange={(e) => setRegisterData({...registerData, password: e.target.value})}
                      required
                      data-testid="register-password-input"
                      className="focus-ring"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm Password</Label>
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="Confirm your password"
                      value={registerData.confirmPassword}
                      onChange={(e) => setRegisterData({...registerData, confirmPassword: e.target.value})}
                      required
                      data-testid="register-confirm-password-input"
                      className="focus-ring"
                    />
                  </div>
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700 transition-all duration-200"
                    disabled={loading}
                    data-testid="register-submit-btn"
                  >
                    {loading ? 'Creating account...' : 'Create Account'}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        
        {/* Footer */}
        <div className="text-center mt-6 text-sm text-gray-600">
          <p>© 2024 AquaElite. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;