import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import axios from 'axios';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';

// Import components
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import CustomerManagement from './components/CustomerManagement';
import OrderManagement from './components/OrderManagement';
import ProductManagement from './components/ProductManagement';
import PaymentReconciliation from './components/PaymentReconciliation';
import ExpenseManagement from './components/ExpenseManagement';
import InvoiceManagement from './components/InvoiceManagement';
import EventOrderManagement from './components/EventOrderManagement';
import DeliveryManagement from './components/DeliveryManagement';
import Reports from './components/Reports';
import Settings from './components/Settings';
import Profile from './components/Profile';
import UserManagement from './components/UserManagement';
import GroupManagement from './components/GroupManagement';
import LoadingUnloading from './components/LoadingUnloading';
import OrderBook from './components/OrderBook';
import Sidebar from './components/Sidebar';
import Header from './components/Header';

// API Configuration
const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Axios interceptor for auth token
axios.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Axios interceptor for handling auth errors
axios.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth context
export const AuthContext = React.createContext();

// Protected Route component
function ProtectedRoute({ children }) {
  const token = localStorage.getItem('token');
  return token ? children : <Navigate to="/login" />;
}

// Main Layout component
function MainLayout({ children, user }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          user={user} 
          onMenuClick={() => setSidebarOpen(true)}
        />
        
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 p-2 sm:p-4 md:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user is logged in on app start
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    
    if (token && userData) {
      try {
        setUser(JSON.parse(userData));
      } catch (error) {
        console.error('Error parsing user data:', error);
        localStorage.removeItem('token');
        localStorage.removeItem('user');
      }
    }
    
    setLoading(false);
  }, []);

  const login = async (credentials) => {
    try {
      const response = await axios.post(`${API}/auth/login`, credentials);
      
      const { access_token, user: userData } = response.data;
      
      localStorage.setItem('token', access_token);
      localStorage.setItem('user', JSON.stringify(userData));
      setUser(userData);
      
      toast.success('Login successful!');
      return { success: true };
    } catch (error) {
      console.error('Login error:', error);
      const message = error.response?.data?.detail || 'Login failed';
      toast.error(message);
      return { success: false, error: message };
    }
  };

  const register = async (userData) => {
    try {
      const response = await axios.post(`${API}/auth/register`, userData);
      toast.success('Registration successful! Please login.');
      return { success: true, data: response.data };
    } catch (error) {
      console.error('Registration error:', error);
      const message = error.response?.data?.detail || 'Registration failed';
      toast.error(message);
      return { success: false, error: message };
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
    toast.success('Logged out successfully');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ user, login, register, logout, API }}>
      <div className="App min-h-screen">
        <BrowserRouter>
          <Routes>
            <Route 
              path="/login" 
              element={localStorage.getItem('token') ? <Navigate to="/" /> : <LoginPage />} 
            />
            
            <Route path="/" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <Dashboard />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="/customers" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <CustomerManagement />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="/orders" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <OrderManagement />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="/order-book" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <OrderBook />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="/products" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <ProductManagement />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="/payment-reconciliation" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <PaymentReconciliation />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="/expenses" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <ExpenseManagement />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="/invoices" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <InvoiceManagement />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="/events" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <EventOrderManagement />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="/delivery" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <DeliveryManagement />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="/reports" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <Reports />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="/settings" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <Settings />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="/profile" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <Profile />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="/users" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <UserManagement />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="/groups" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <GroupManagement />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="/loading-unloading" element={
              <ProtectedRoute>
                <MainLayout user={user}>
                  <LoadingUnloading />
                </MainLayout>
              </ProtectedRoute>
            } />
            
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </BrowserRouter>
        
        <Toaster position="top-right" richColors />
      </div>
    </AuthContext.Provider>
  );
}

export default App;