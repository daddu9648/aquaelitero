#!/usr/bin/env python3

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from backend_test import WaterKardAPITester

def main():
    tester = WaterKardAPITester()
    
    # Test authentication first
    if not tester.test_authentication():
        print("\n❌ Authentication failed - stopping tests")
        return 1
    
    # Run only permission management test
    tester.test_permission_management()
    
    # Print results
    print("\n" + "="*60)
    print("PERMISSION MANAGEMENT TEST RESULTS")
    print("="*60)
    print(f"Total tests run: {tester.tests_run}")
    print(f"Tests passed: {tester.tests_passed}")
    print(f"Tests failed: {tester.tests_run - tester.tests_passed}")
    print(f"Success rate: {(tester.tests_passed/tester.tests_run)*100:.1f}%")
    
    if tester.tests_passed == tester.tests_run:
        print("🎉 All permission management tests passed!")
    else:
        print("⚠️  Some tests failed - check logs above")

if __name__ == "__main__":
    main()