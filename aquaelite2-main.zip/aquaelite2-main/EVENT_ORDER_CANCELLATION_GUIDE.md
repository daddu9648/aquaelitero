# Event Order Cancellation - Complete Guide

## ✅ Functionality Status: ALREADY IMPLEMENTED

Event order cancellation functionality is **fully implemented and working** in the AquaElite application.

---

## 🎯 How to Cancel an Event Order

### Step 1: Navigate to Event Order Management
- Go to **Event Order Management** page from the sidebar
- You'll see the list of all event orders

### Step 2: Find the Cancel Button
The **Cancel Button** (❌ icon) appears for events with these statuses:
- ✅ Pending
- ✅ Confirmed  
- ✅ In-Progress

**Note**: Cancel button is **NOT shown** for:
- ❌ Completed events
- ❌ Already cancelled events

### Step 3: Click Cancel Button
- Click the **❌ Cancel** button for the event you want to cancel
- A confirmation dialog will appear

### Step 4: Confirm Cancellation
The confirmation dialog shows:
```
Are you sure you want to cancel "[Event Name]"?

⚠️ IMPORTANT: Advance payment of ₹[amount] will be NON-REFUNDABLE 
and will be retained by the company.

This action cannot be undone.
```

- Click **OK** to confirm cancellation
- Click **Cancel** to abort

---

## 📊 What Happens When Event is Cancelled?

### 1. Event Status Update
- **event_status** → changed to `cancelled`
- **cancelled_at** → current timestamp
- **cancelled_by** → admin/user ID who cancelled
- **cancelled_by_name** → name of canceller

### 2. Advance Forfeiture
- **advance_forfeited** → set to `true`
- **refund_amount** → set to `0` (no refund)
- Advance amount is retained by company (non-refundable)

### 3. Financial Impact
The cancelled event's advance is tracked separately:

**Event Order Management Page**:
- "Event Collection" stat: ₹0 (not counted)
- "Advance Forfeited" stat: ₹[advance_amount] (shown separately in red card)

**Financial Summary Report**:
- Regular collections: Does not include forfeited advance
- Advance Forfeited: Shows total forfeited amount separately
- Total collections: Includes forfeited advances

### 4. UI Indicators
After cancellation, the event card shows:
- 🚫 **Red "Cancelled" badge**
- 📝 **Cancellation details**:
  - Cancelled at: [date/time]
  - Cancelled by: [name]
  - Advance forfeited: ₹[amount]

---

## 🔧 Technical Implementation

### Backend Endpoint
```
PUT /api/event-orders/{event_id}
```

**Request Body** (for cancellation):
```json
{
  "event_status": "cancelled",
  "cancellation_reason": "Customer requested cancellation",
  "cancelled_at": "2025-01-15T10:30:00Z",
  "cancelled_by": "user-id",
  "cancelled_by_name": "Admin Name",
  "advance_forfeited": true,
  "refund_amount": 0
}
```

### Frontend Function
```javascript
handleCancelEvent(event)
```

**Location**: `/app/frontend/src/components/EventOrderManagement.js` (line 224-265)

---

## 📋 Business Rules

### When Can Events Be Cancelled?
✅ **Can Cancel**:
- Events with status: pending, confirmed, in_progress
- Before event is completed
- By users with proper permissions

❌ **Cannot Cancel**:
- Events with status: completed
- Already cancelled events

### Advance Payment Rules
- **100% Non-Refundable**: All advance payments are forfeited
- **Company Retains**: Advance amount kept by company
- **Tracked Separately**: Shows in "Advance Forfeited" stats
- **Not in Regular Collection**: Does not count towards event collection

---

## 📈 Reporting & Analytics

### Stats Display

**Event Order Management**:
- Total Events: All events count (including cancelled)
- Event Collection: Excludes forfeited advances
- **Advance Forfeited**: Shows total forfeited (red card)

**Financial Summary Report**:
- Event Collections: Completed event payments
- **Advance Forfeited**: Separate line item
- Total Collections: Sum of all (includes forfeited)

### Archived Events Report
- Cancelled events are archived monthly
- Shows in Archived Events Report with cancellation details
- Maintains full history

---

## 🎨 UI Elements

### Cancel Button
- **Icon**: ❌ (X icon)
- **Color**: Red on hover
- **Tooltip**: "Cancel Event (Advance Non-Refundable)"
- **Location**: Event card action buttons

### Cancelled Event Badge
- **Color**: Red background
- **Text**: "Cancelled"
- **Additional Info**: Shows cancellation date and user

---

## 🚀 Usage Examples

### Example 1: Cancel Confirmed Event
1. Customer calls to cancel wedding event (confirmed)
2. Admin opens Event Order Management
3. Finds the event card
4. Clicks ❌ Cancel button
5. Confirms cancellation in dialog
6. Advance ₹10,000 is forfeited
7. Event shows as cancelled with red badge

### Example 2: Check Forfeited Advances
1. Go to Event Order Management
2. Look at "Advance Forfeited" card (red)
3. Shows total: ₹25,000 from 3 cancelled events
4. Or go to Financial Summary Report
5. "Advance Forfeited" line shows same amount

---

## 🔐 Permissions Required

To cancel event orders, user needs:
- **Permission**: `event_orders.edit`
- **Role**: Admin or Manager
- **Access**: Event Order Management page

---

## 💡 Tips & Best Practices

1. **Always Confirm**: Double-check event details before cancelling
2. **Document Reason**: Note why event was cancelled (for records)
3. **Inform Customer**: Tell customer about non-refundable advance
4. **Check Stats**: Monitor "Advance Forfeited" regularly
5. **Monthly Reports**: Review cancelled events in archived reports

---

## ⚠️ Important Notes

- **Irreversible**: Cancellation cannot be undone
- **No Refunds**: Advance payments are always forfeited
- **Financial Tracking**: Forfeited advances tracked separately
- **History Maintained**: All cancellation details preserved
- **Monthly Archival**: Cancelled events archived at month-end

---

## 📞 Need Help?

If you encounter any issues:
1. Check event status (must be pending/confirmed/in_progress)
2. Verify user permissions
3. Check console for error messages
4. Contact support with event details

---

**Last Updated**: January 2025  
**Version**: 1.0  
**Status**: ✅ Fully Operational
