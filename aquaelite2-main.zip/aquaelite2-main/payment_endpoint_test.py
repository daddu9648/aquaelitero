import requests
import json
from datetime import datetime

def test_payment_endpoints():
    """Test both payment endpoints to identify the routing conflict"""
    
    base_url = "https://jar-system.preview.emergentagent.com"
    api_url = f"{base_url}/api"
    
    # Login first
    login_data = {"email": "testadmin@waterkard.com", "password": "admin123"}
    login_response = requests.post(f"{api_url}/auth/login", json=login_data)
    
    if login_response.status_code != 200:
        print("❌ Login failed")
        return
    
    token = login_response.json()['access_token']
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {token}'
    }
    
    print("🔍 Testing Payment Endpoint Routing Conflict")
    print("="*50)
    
    # Create a test customer first
    customer_data = {
        "name": "Test Customer",
        "mobile": "+91 9999999999",
        "address": "Test Address",
        "water_type": "20L",
        "bottle_deposit": 100.0
    }
    
    customer_response = requests.post(f"{api_url}/customers", json=customer_data, headers=headers)
    if customer_response.status_code != 200:
        print("❌ Failed to create test customer")
        return
    
    customer_id = customer_response.json()['id']
    print(f"✅ Created test customer: {customer_id}")
    
    # Test 1: Try the frontend format (should work with second endpoint)
    print("\n--- Test 1: Frontend Format (Customer Payment Collection) ---")
    frontend_payment_data = {
        "customer_id": customer_id,
        "customer_name": "Test Customer",
        "amount": 150.0,
        "payment_mode": "cash",
        "collected_by": "test-user-id",
        "collected_by_name": "Test Admin",
        "payment_type": "customer_payment",
        "notes": "Regular payment collection",
        "collected_at": datetime.now().isoformat()
    }
    
    response = requests.post(f"{api_url}/payments", json=frontend_payment_data, headers=headers)
    print(f"Status: {response.status_code}")
    print(f"Response: {response.json()}")
    
    # Test 2: Try the first endpoint format (PaymentCreate model)
    print("\n--- Test 2: PaymentCreate Format (Order Payment) ---")
    order_payment_data = {
        "order_id": "dummy-order-id",
        "customer_id": customer_id,
        "amount": 100.0,
        "payment_method": "cash",
        "notes": "Order payment"
    }
    
    response = requests.post(f"{api_url}/payments", json=order_payment_data, headers=headers)
    print(f"Status: {response.status_code}")
    print(f"Response: {response.json()}")
    
    # Test 3: Check which endpoint is actually being called by examining the error
    print("\n--- Test 3: Endpoint Identification ---")
    minimal_data = {"test": "data"}
    
    response = requests.post(f"{api_url}/payments", json=minimal_data, headers=headers)
    print(f"Status: {response.status_code}")
    error_response = response.json()
    print(f"Error Response: {error_response}")
    
    # Analyze the error to determine which endpoint is being called
    if 'detail' in error_response and isinstance(error_response['detail'], list):
        missing_fields = [item['loc'][-1] for item in error_response['detail'] if item['type'] == 'missing']
        print(f"Missing fields: {missing_fields}")
        
        if 'order_id' in missing_fields and 'payment_method' in missing_fields:
            print("🔍 ANALYSIS: First endpoint (PaymentCreate model) is being called")
            print("   This endpoint expects: order_id, customer_id, amount, payment_method")
        elif 'customer_name' in missing_fields:
            print("🔍 ANALYSIS: Second endpoint (dict-based) is being called")
            print("   This endpoint expects: customer_id, customer_name, amount, collected_by, collected_by_name, collected_at")
    
    # Cleanup
    requests.delete(f"{api_url}/customers/{customer_id}", headers=headers)
    print(f"\n✅ Cleaned up test customer: {customer_id}")

if __name__ == "__main__":
    test_payment_endpoints()