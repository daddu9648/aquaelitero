#!/usr/bin/env python3
"""
Focused test for the fixed invoice download/print functionality for event invoices.
This script tests the specific fixes mentioned in the review request.
"""

import requests
import sys
import json
from datetime import datetime, timedelta

class InvoiceFixTester:
    def __init__(self, base_url="https://jar-system.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.token = None
        self.user_data = None
        self.tests_run = 0
        self.tests_passed = 0

    def run_test(self, name, method, endpoint, expected_status, data=None, headers=None):
        """Run a single API test"""
        url = f"{self.api_url}/{endpoint}"
        test_headers = {'Content-Type': 'application/json'}
        
        if self.token:
            test_headers['Authorization'] = f'Bearer {self.token}'
        
        if headers:
            test_headers.update(headers)

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=test_headers, timeout=30)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=test_headers, timeout=30)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=test_headers, timeout=30)
            elif method == 'DELETE':
                response = requests.delete(url, headers=test_headers, timeout=30)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    if isinstance(response_data, dict) and len(str(response_data)) < 500:
                        print(f"   Response: {response_data}")
                    elif isinstance(response_data, list):
                        print(f"   Response: List with {len(response_data)} items")
                    return success, response_data
                except:
                    return success, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {error_data}")
                except:
                    print(f"   Error: {response.text}")
                return False, {}

        except requests.exceptions.Timeout:
            print(f"❌ Failed - Request timeout (30s)")
            return False, {}
        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def authenticate(self):
        """Authenticate with the API"""
        print("\n" + "="*50)
        print("AUTHENTICATION")
        print("="*50)
        
        # Try different admin credentials
        admin_credentials = [
            {"email": "testadmin@waterkard.com", "password": "admin123"},
            {"email": "admin2@waterkard.com", "password": "admin123"},
            {"email": "admin@waterkard.com", "password": "admin123"}
        ]
        
        for i, login_data in enumerate(admin_credentials):
            print(f"   Trying admin credentials {i+1}: {login_data}")
            
            success, response = self.run_test(
                f"Admin Login Attempt {i+1}",
                "POST",
                "auth/login",
                200,
                data=login_data
            )
            
            if success and 'access_token' in response:
                self.token = response['access_token']
                self.user_data = response.get('user', {})
                print(f"   ✅ Authentication successful!")
                print(f"   User: {self.user_data.get('name', 'Unknown')} ({self.user_data.get('role', 'Unknown')})")
                return True
        
        print("❌ Authentication failed - cannot proceed with tests")
        return False

    def test_invoice_fixes(self):
        """Test the fixed invoice download/print functionality for event invoices"""
        print("\n" + "="*70)
        print("TESTING FIXED INVOICE DOWNLOAD/PRINT FUNCTIONALITY")
        print("="*70)
        
        # Store created IDs for cleanup
        created_customer_id = None
        created_event_order_id = None
        created_invoice_id = None
        
        try:
            # Test 1: Create test customer with complete address and mobile
            print("\n--- Test 1: Create Customer with Enhanced Data ---")
            customer_data = {
                "name": "Rajesh Kumar Sharma",
                "mobile": "+91 9876543210",
                "address": "123 Business Park, Sector 18, Noida, Uttar Pradesh - 201301",
                "water_type": "20L",
                "bottle_deposit": 200.0
            }
            
            success, response = self.run_test(
                "Create Customer with Complete Details",
                "POST",
                "customers",
                200,
                data=customer_data
            )
            
            if success and 'id' in response:
                created_customer_id = response['id']
                print(f"   ✅ Customer created with ID: {created_customer_id}")
                print(f"   Customer address: {response.get('address', 'Missing')}")
                print(f"   Customer mobile: {response.get('mobile', 'Missing')}")
            else:
                print("❌ Failed to create test customer - cannot proceed")
                return False
            
            # Test 2: Create completed event order
            print("\n--- Test 2: Create Event Order for Invoice ---")
            event_order_data = {
                "event_name": "Corporate Annual Conference 2024",
                "event_type": "corporate",
                "customer_id": created_customer_id,
                "event_date": (datetime.now() + timedelta(days=1)).isoformat(),
                "event_time": "09:00 AM",
                "venue_address": "Grand Ballroom, Hotel Taj Palace, New Delhi - 110021",
                "guest_count": 150,
                "products": [
                    {
                        "product_id": "water-20l-premium",
                        "product_name": "Premium Water 20L",
                        "quantity": 25,
                        "price": 30.0,
                        "total": 750.0
                    },
                    {
                        "product_id": "water-1l-bottles",
                        "product_name": "Bottled Water 1L",
                        "quantity": 100,
                        "price": 15.0,
                        "total": 1500.0
                    }
                ],
                "total_amount": 2250.0,
                "advance_amount": 500.0,
                "special_requirements": "Chilled water required, setup by 8:30 AM",
                "setup_required": True
            }
            
            success, response = self.run_test(
                "Create Event Order",
                "POST",
                "event-orders",
                200,
                data=event_order_data
            )
            
            if success and 'id' in response:
                created_event_order_id = response['id']
                print(f"   ✅ Event order created with ID: {created_event_order_id}")
                
                # Mark event as completed
                update_data = {
                    "event_status": "completed",
                    "delivery_status": "completed",
                    "jars_delivered": 25,
                    "empty_jars_collected": 20,
                    "delivery_completed_at": datetime.now().isoformat()
                }
                
                success, response = self.run_test(
                    "Mark Event Order as Completed",
                    "PUT",
                    f"event-orders/{created_event_order_id}",
                    200,
                    data=update_data
                )
                
                if success:
                    print("   ✅ Event order marked as completed")
            else:
                print("❌ Failed to create event order - cannot proceed")
                return False
            
            # Test 3: Create invoice with enhanced customer fields
            print("\n--- Test 3: Create Event Invoice with Enhanced Customer Fields ---")
            
            success, response = self.run_test(
                "Create Event Order Invoice",
                "POST",
                f"invoices/event-order/{created_event_order_id}",
                200
            )
            
            if success and 'id' in response:
                created_invoice_id = response['id']
                print(f"   ✅ Event invoice created successfully!")
                print(f"   Invoice ID: {created_invoice_id}")
                print(f"   Invoice Number: {response.get('invoice_number', 'Unknown')}")
                print(f"   Invoice Type: {response.get('invoice_type', 'Unknown')}")
                print(f"   Total Amount: ₹{response.get('total_amount', 0)}")
                
                # Test Fix 1: Verify enhanced customer fields
                print("\n   🔍 TESTING FIX 1: Enhanced Customer Fields")
                customer_address = response.get('customer_address')
                customer_mobile = response.get('customer_mobile')
                
                fix1_passed = True
                if customer_address:
                    print(f"   ✅ Customer address included: {customer_address}")
                else:
                    print("   ❌ CRITICAL: Customer address missing from invoice")
                    fix1_passed = False
                
                if customer_mobile:
                    print(f"   ✅ Customer mobile included: {customer_mobile}")
                else:
                    print("   ❌ CRITICAL: Customer mobile missing from invoice")
                    fix1_passed = False
                
                # Test Fix 2: Verify item field mapping
                print("\n   🔍 TESTING FIX 2: Item Field Mapping")
                items = response.get('items', [])
                fix2_passed = True
                
                if items:
                    print(f"   Found {len(items)} items in invoice")
                    
                    for i, item in enumerate(items):
                        print(f"   Item {i+1}:")
                        
                        # Check for correct field names for PDF generation
                        description = item.get('description') or item.get('name')
                        quantity = item.get('quantity', 0)
                        unit_price = item.get('unit_price') or item.get('price')
                        amount = item.get('amount') or item.get('total')
                        
                        if description:
                            print(f"     ✅ Description/Name: {description}")
                        else:
                            print("     ❌ Missing description/name field")
                            fix2_passed = False
                        
                        if quantity:
                            print(f"     ✅ Quantity: {quantity}")
                        else:
                            print("     ❌ Missing quantity field")
                            fix2_passed = False
                        
                        if unit_price:
                            print(f"     ✅ Unit Price: ₹{unit_price}")
                        else:
                            print("     ❌ Missing unit_price/price field")
                            fix2_passed = False
                        
                        if amount:
                            print(f"     ✅ Amount/Total: ₹{amount}")
                        else:
                            print("     ❌ Missing amount/total field")
                            fix2_passed = False
                else:
                    print("   ❌ CRITICAL: No items found in invoice")
                    fix2_passed = False
                
                # Test Fix 3: PDF Generation Data Structure
                print("\n   🔍 TESTING FIX 3: PDF Generation Data Structure")
                
                success, pdf_response = self.run_test(
                    "Get Invoice for PDF Generation",
                    "GET",
                    f"invoices/{created_invoice_id}",
                    200
                )
                
                fix3_passed = True
                if success:
                    print("   ✅ Invoice data retrieved successfully for PDF generation")
                    
                    # Verify all required fields for PDF generation are present
                    required_pdf_fields = [
                        'invoice_number', 'customer_name', 'customer_address', 'customer_mobile',
                        'items', 'total_amount', 'issue_date', 'due_date'
                    ]
                    
                    missing_pdf_fields = []
                    for field in required_pdf_fields:
                        if field not in pdf_response or pdf_response[field] is None:
                            missing_pdf_fields.append(field)
                    
                    if not missing_pdf_fields:
                        print("   ✅ All required PDF fields present")
                    else:
                        print(f"   ❌ Missing PDF fields: {missing_pdf_fields}")
                        fix3_passed = False
                    
                    # Test item structure for PDF generation
                    items = pdf_response.get('items', [])
                    if items:
                        pdf_ready_items = 0
                        for item in items:
                            # Check if item has all fields needed for PDF
                            has_description = 'description' in item or 'name' in item
                            has_quantity = 'quantity' in item
                            has_price = 'unit_price' in item or 'price' in item
                            has_amount = 'amount' in item or 'total' in item
                            
                            if has_description and has_quantity and has_price and has_amount:
                                pdf_ready_items += 1
                        
                        if pdf_ready_items == len(items):
                            print(f"   ✅ All {len(items)} items are PDF-ready with proper field mapping")
                        else:
                            print(f"   ❌ Only {pdf_ready_items}/{len(items)} items are PDF-ready")
                            fix3_passed = False
                else:
                    print("   ❌ Failed to retrieve invoice data for PDF generation")
                    fix3_passed = False
                
                # Test Fix 4: Error Handling
                print("\n   🔍 TESTING FIX 4: Error Handling for PDF Generation")
                
                success, error_response = self.run_test(
                    "Get Non-existent Invoice (Should Fail)",
                    "GET",
                    "invoices/non-existent-invoice-id",
                    404
                )
                
                fix4_passed = not success  # Should fail with 404
                if fix4_passed:
                    print("   ✅ Correctly handled non-existent invoice request")
                else:
                    print("   ❌ Should have failed for non-existent invoice")
                
                # Test invoice listing
                success, list_response = self.run_test(
                    "Get All Invoices",
                    "GET",
                    "invoices",
                    200
                )
                
                if success:
                    invoices = list_response if isinstance(list_response, list) else []
                    print(f"   ✅ Retrieved {len(invoices)} invoices from system")
                    
                    # Find our created invoice in the list
                    our_invoice = None
                    for invoice in invoices:
                        if invoice.get('id') == created_invoice_id:
                            our_invoice = invoice
                            break
                    
                    if our_invoice:
                        print("   ✅ Created invoice found in invoice list")
                        
                        # Verify enhanced fields are preserved
                        if our_invoice.get('customer_address'):
                            print("   ✅ Customer address preserved in listing")
                        if our_invoice.get('customer_mobile'):
                            print("   ✅ Customer mobile preserved in listing")
                    else:
                        print("   ❌ Created invoice not found in invoice list")
                        fix4_passed = False
                
                # Summary of fixes
                print("\n" + "="*50)
                print("FIXES VERIFICATION SUMMARY")
                print("="*50)
                
                fixes_status = {
                    "Fix 1 - Enhanced Customer Fields (address, mobile)": fix1_passed,
                    "Fix 2 - Item Field Mapping (description, unit_price, amount)": fix2_passed,
                    "Fix 3 - PDF Generation Data Structure": fix3_passed,
                    "Fix 4 - Error Handling for PDF Generation": fix4_passed
                }
                
                for fix_name, passed in fixes_status.items():
                    status = "✅ VERIFIED" if passed else "❌ NOT VERIFIED"
                    print(f"{fix_name}: {status}")
                
                total_fixes = len(fixes_status)
                verified_fixes = sum(fixes_status.values())
                
                print(f"\n📊 OVERALL RESULT: {verified_fixes}/{total_fixes} fixes verified")
                
                if verified_fixes == total_fixes:
                    print("🎉 ALL INVOICE FIXES SUCCESSFULLY VERIFIED!")
                    return True
                else:
                    print("⚠️  Some fixes may need additional attention")
                    return False
            else:
                print("❌ CRITICAL: Failed to create event order invoice")
                return False
        
        finally:
            # Cleanup
            print("\n--- Cleaning up test data ---")
            
            if created_invoice_id:
                success, response = self.run_test(
                    "Delete Test Invoice",
                    "DELETE",
                    f"invoices/{created_invoice_id}",
                    200
                )
                if success:
                    print(f"   ✅ Deleted invoice {created_invoice_id[:8]}...")
            
            if created_event_order_id:
                success, response = self.run_test(
                    "Delete Test Event Order",
                    "DELETE",
                    f"event-orders/{created_event_order_id}",
                    200
                )
                if success:
                    print(f"   ✅ Deleted event order {created_event_order_id[:8]}...")
            
            if created_customer_id:
                success, response = self.run_test(
                    "Delete Test Customer",
                    "DELETE",
                    f"customers/{created_customer_id}",
                    200
                )
                if success:
                    print(f"   ✅ Deleted customer {created_customer_id[:8]}...")

    def run(self):
        """Run the invoice fix tests"""
        print("🚀 Starting Invoice Fix Tests")
        print(f"Base URL: {self.base_url}")
        
        if not self.authenticate():
            return 1
        
        success = self.test_invoice_fixes()
        
        print("\n" + "="*70)
        print("FINAL RESULTS")
        print("="*70)
        print(f"📊 Tests passed: {self.tests_passed}/{self.tests_run}")
        print(f"📈 Success rate: {(self.tests_passed/self.tests_run)*100:.1f}%")
        
        if success:
            print("🎉 ALL INVOICE FIXES VERIFIED SUCCESSFULLY!")
            return 0
        else:
            print("⚠️  Some invoice fixes need attention")
            return 1

if __name__ == "__main__":
    tester = InvoiceFixTester()
    sys.exit(tester.run())