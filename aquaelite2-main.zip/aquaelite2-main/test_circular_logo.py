#!/usr/bin/env python3

import sys
import os
sys.path.append('/app')

from backend_test import WaterKardAPITester

def main():
    """Run only the circular logo PDF export test"""
    print("🔍 Testing Circular Logo PDF Export Functionality")
    print("="*60)
    
    # Initialize tester
    tester = WaterKardAPITester()
    
    # Test authentication first
    print("Step 1: Authenticating...")
    if not tester.test_authentication():
        print("❌ Authentication failed - cannot proceed")
        return False
    
    print("✅ Authentication successful")
    
    # Run the circular logo PDF export test
    print("\nStep 2: Testing Circular Logo PDF Export...")
    success = tester.test_circular_logo_pdf_export()
    
    # Print summary
    print("\n" + "="*60)
    print("CIRCULAR LOGO PDF EXPORT TEST SUMMARY")
    print("="*60)
    print(f"Total Tests Run: {tester.tests_run}")
    print(f"Tests Passed: {tester.tests_passed}")
    print(f"Tests Failed: {tester.tests_run - tester.tests_passed}")
    
    if tester.tests_run > 0:
        success_rate = (tester.tests_passed / tester.tests_run) * 100
        print(f"Success Rate: {success_rate:.1f}%")
    
    if success and tester.tests_passed == tester.tests_run:
        print("🎉 ALL CIRCULAR LOGO PDF EXPORT TESTS PASSED!")
        return True
    else:
        print("⚠️  Some tests failed - check logs above")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)