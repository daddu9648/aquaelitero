from fastapi import FastAPI, APIRouter, HTTPException, Depends, status, UploadFile, File
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.staticfiles import StaticFiles
import io
import json
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, EmailStr, field_validator, validator
from typing import List, Optional
import uuid
from datetime import datetime, timedelta, timezone
import calendar
import jwt
from passlib.context import CryptContext
import hashlib
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from openpyxl import Workbook
from openpyxl.styles import Font

# Common PDF Header Function for All Reports
async def get_contact_details_for_pdf():
    """Fetch admin and manager contact details for PDF footer"""
    try:
        # Find admin user
        admin = await db.users.find_one({"role": "admin"})
        # Find manager user
        manager = await db.users.find_one({"role": "manager"})
        
        result = {
            "admin": {
                "name": admin.get("name", "Admin") if admin else "Admin",
                "phone": admin.get("mobile", "+91-98765-43210") if admin else "+91-98765-43210",
                "email": admin.get("email", "admin@aquaelite.com") if admin else "admin@aquaelite.com",
                "exists": admin is not None
            },
            "manager": {
                "name": manager.get("name", "Manager") if manager else None,
                "phone": manager.get("mobile", "+91-98765-43211") if manager else None,
                "email": manager.get("email", "manager@aquaelite.com") if manager else None,
                "exists": manager is not None
            }
        }
        return result
    except Exception as e:
        print(f"Error fetching contact details: {e}")
        # Return defaults if error
        return {
            "admin": {
                "name": "Admin",
                "phone": "+91-98765-43210",
                "email": "admin@aquaelite.com",
                "exists": True
            },
            "manager": {
                "name": None,
                "phone": None,
                "email": None,
                "exists": False
            }
        }

def draw_pdf_header_and_footer(canvas, doc, contact_details=None, is_last_page=False):
    """Common header and footer function for all PDF reports with circular logo and contact info"""
    canvas.saveState()
    
    # Company header with logo
    page_width = A4[0]
    
    # Draw company logo (circular)
    logo_path = "/app/frontend/public/logo.png"
    if os.path.exists(logo_path):
        try:
            from PIL import Image, ImageDraw, ImageOps
            
            # Load and process logo to make it circular
            img = Image.open(logo_path).convert('RGBA')
            
            # Resize to desired size (50x50 pixels)
            logo_size = 50
            img = img.resize((logo_size, logo_size), Image.Resampling.LANCZOS)
            
            # Create a circular mask
            mask = Image.new('L', (logo_size, logo_size), 0)
            draw = ImageDraw.Draw(mask)
            draw.ellipse((0, 0, logo_size, logo_size), fill=255)
            
            # Create circular logo
            circular_logo = Image.new('RGBA', (logo_size, logo_size), (255, 255, 255, 0))
            circular_logo.paste(img, (0, 0))
            circular_logo.putalpha(mask)
            
            # Add white circular background for better visibility
            background = Image.new('RGBA', (logo_size, logo_size), (255, 255, 255, 255))
            background_mask = Image.new('L', (logo_size, logo_size), 0)
            draw_bg = ImageDraw.Draw(background_mask)
            draw_bg.ellipse((0, 0, logo_size, logo_size), fill=255)
            background.putalpha(background_mask)
            
            # Combine background and logo
            final_logo = Image.alpha_composite(background, circular_logo)
            
            # Add sharp and thin circular border/outline
            border_draw = ImageDraw.Draw(final_logo)
            
            # Draw multiple thin lines for sharp, crisp border
            # Outer sharp border (dark)
            border_draw.ellipse((0, 0, logo_size-1, logo_size-1), 
                              outline=(32, 32, 32, 255), width=1)
            # Inner sharp border for definition
            border_draw.ellipse((1, 1, logo_size-2, logo_size-2), 
                              outline=(80, 80, 80, 255), width=1)
            
            # Save temp circular logo
            temp_logo_path = "/tmp/circular_logo.png"
            final_logo.save(temp_logo_path, "PNG")
            
            # Draw circular logo in header
            canvas.drawImage(temp_logo_path, 50, A4[1] - 75, width=logo_size, height=logo_size, mask='auto')
            
            # Clean up temp file
            if os.path.exists(temp_logo_path):
                os.remove(temp_logo_path)
                
        except Exception as e:
            print(f"Error creating circular logo: {e}")
            # Fallback to text logo
            canvas.setFont("Helvetica-Bold", 16)
            canvas.setFillColor(colors.blue)
            canvas.drawString(50, A4[1] - 50, "🌊 AquaElite")
    else:
        # Fallback to text logo
        canvas.setFont("Helvetica-Bold", 16)
        canvas.setFillColor(colors.blue)
        canvas.drawString(50, A4[1] - 50, "🌊 AquaElite")
        
    # Company name (center aligned)
    canvas.setFont("Helvetica-Bold", 18)
    canvas.setFillColor(colors.black)
    company_text = "AquaElite"
    text_width = canvas.stringWidth(company_text, "Helvetica-Bold", 18)
    canvas.drawString((page_width - text_width) / 2, A4[1] - 35, company_text)
    
    # Underline company name
    canvas.setStrokeColor(colors.black)
    canvas.setLineWidth(1)
    canvas.line((page_width - text_width) / 2, A4[1] - 38, 
               (page_width - text_width) / 2 + text_width, A4[1] - 38)
    
    # Subtitle (center aligned)
    canvas.setFont("Helvetica", 12)
    subtitle_text = "Premium Water Delivery System"
    subtitle_width = canvas.stringWidth(subtitle_text, "Helvetica", 12)
    canvas.drawString((page_width - subtitle_width) / 2, A4[1] - 55, subtitle_text)
    
    # Horizontal line under header
    canvas.setStrokeColor(colors.black)
    canvas.setLineWidth(2)
    canvas.line(20, A4[1] - 85, page_width - 20, A4[1] - 85)
    
    # FOOTER - Contact Information (only on last page)
    if contact_details and is_last_page:
        # Draw horizontal line above footer
        canvas.setStrokeColor(colors.black)
        canvas.setLineWidth(1)
        canvas.line(20, 60, page_width - 20, 60)
        
        # Footer text
        canvas.setFont("Helvetica-Bold", 9)
        canvas.setFillColor(colors.black)
        footer_title = "Contact Information:"
        canvas.drawString(40, 48, footer_title)
        
        # Admin contact
        canvas.setFont("Helvetica", 8)
        admin_info = contact_details.get("admin", {})
        admin_text = f"Admin ({admin_info.get('name', 'Admin')}): 📞 {admin_info.get('phone', 'N/A')} | 📧 {admin_info.get('email', 'N/A')}"
        canvas.drawString(40, 36, admin_text)
        
        # Manager contact - only show if manager exists
        manager_info = contact_details.get("manager", {})
        if manager_info.get("exists", False):
            manager_text = f"Manager ({manager_info.get('name', 'Manager')}): 📞 {manager_info.get('phone', 'N/A')} | 📧 {manager_info.get('email', 'N/A')}"
            canvas.drawString(40, 24, manager_text)
    
    canvas.restoreState()

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# JWT Configuration
SECRET_KEY = os.environ.get('SECRET_KEY', 'waterkard-secret-key-change-in-production')
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 1440  # 24 hours

# Password hashing - Use a simpler approach
import secrets

# MongoDB connection with proper timeout and pooling configuration
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(
    mongo_url,
    maxIdleTimeMS=30000,           # Close idle connections after 30 seconds
    serverSelectionTimeoutMS=15000, # 15 second timeout for server selection
    connectTimeoutMS=5000,          # 5 second connection timeout
    maxPoolSize=10,                 # Maximum 10 connections in pool
    retryWrites=True                # Retry failed writes
)
db = client[os.environ['DB_NAME']]

# Create the main app
app = FastAPI(title="AquaElite API", description="Premium Water Delivery Management System")
api_router = APIRouter(prefix="/api")
security = HTTPBearer()

# Create uploads directory for profile photos
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)
PROFILE_PHOTOS_DIR = UPLOAD_DIR / "profile_photos"
PROFILE_PHOTOS_DIR.mkdir(exist_ok=True)

# Mount static files for serving uploaded images
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# Models
class UserRole(str):
    ADMIN = "admin"
    MANAGER = "manager"
    EMPLOYEE = "employee"
    DELIVERY_BOY = "delivery_boy"
    CUSTOMER = "customer"

class User(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: Optional[EmailStr] = None
    name: str
    mobile: str
    role: str = UserRole.ADMIN
    is_active: bool = True
    permissions: List[str] = Field(default_factory=list)
    assigned_area: Optional[str] = None  # For delivery boys
    profile_photo: Optional[str] = None  # URL/path to profile photo
    gst_number: Optional[str] = None  # GST number for invoice generation
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class UserPermissions:
    # Admin permissions
    ADMIN_ALL = "admin.*"
    
    # Dashboard & Reports
    VIEW_DASHBOARD = "dashboard.view"
    VIEW_REPORTS = "reports.view"
    DOWNLOAD_REPORTS = "reports.download"
    EXPORT_REPORTS = "reports.export"
    
    # Customer management - CRUD operations
    VIEW_CUSTOMERS = "customers.view"
    ADD_CUSTOMERS = "customers.add"
    EDIT_CUSTOMERS = "customers.edit"
    DELETE_CUSTOMERS = "customers.delete"
    ACTIVATE_DEACTIVATE_CUSTOMERS = "customers.activate"
    
    # Regular Order management - CRUD operations  
    VIEW_ORDERS = "orders.view"
    ADD_ORDERS = "orders.add"
    EDIT_ORDERS = "orders.edit"
    DELETE_ORDERS = "orders.delete"
    DELIVER_ORDERS = "orders.deliver"
    
    # Event Order management - CRUD operations
    VIEW_EVENT_ORDERS = "event_orders.view"
    ADD_EVENT_ORDERS = "event_orders.add"
    EDIT_EVENT_ORDERS = "event_orders.edit"
    DELETE_EVENT_ORDERS = "event_orders.delete"
    DELIVER_EVENT_ORDERS = "event_orders.deliver"
    
    # Product management - CRUD operations
    VIEW_PRODUCTS = "products.view"
    ADD_PRODUCTS = "products.add"
    EDIT_PRODUCTS = "products.edit"
    DELETE_PRODUCTS = "products.delete"
    
    # Payment Management - CRUD operations
    VIEW_PAYMENTS = "payments.view"
    ADD_PAYMENTS = "payments.add"
    EDIT_PAYMENTS = "payments.edit"
    DELETE_PAYMENTS = "payments.delete"
    COLLECT_PAYMENTS = "payments.collect"
    
    # Expense Management - CRUD operations
    VIEW_EXPENSES = "expenses.view"
    ADD_EXPENSES = "expenses.add"
    EDIT_EXPENSES = "expenses.edit"
    DELETE_EXPENSES = "expenses.delete"
    
    # Invoice Management - CRUD operations
    VIEW_INVOICES = "invoices.view"
    ADD_INVOICES = "invoices.add"
    EDIT_INVOICES = "invoices.edit"
    DELETE_INVOICES = "invoices.delete"
    GENERATE_INVOICES = "invoices.generate"
    
    # Delivery Management - CRUD operations
    VIEW_DELIVERIES = "deliveries.view"
    ADD_DELIVERIES = "deliveries.add"
    EDIT_DELIVERIES = "deliveries.edit"
    DELETE_DELIVERIES = "deliveries.delete"
    MANAGE_DELIVERIES = "deliveries.manage"
    
    # User Management - CRUD operations
    VIEW_USERS = "users.view"
    ADD_USERS = "users.add"
    EDIT_USERS = "users.edit"
    DELETE_USERS = "users.delete"
    MANAGE_USER_PERMISSIONS = "users.permissions"
    
    # Group Management - CRUD operations
    VIEW_GROUPS = "groups.view"
    ADD_GROUPS = "groups.add"
    EDIT_GROUPS = "groups.edit"
    DELETE_GROUPS = "groups.delete"
    
    # Settings & Configuration - CRUD operations
    VIEW_SETTINGS = "settings.view"
    ADD_SETTINGS = "settings.add"
    EDIT_SETTINGS = "settings.edit"
    DELETE_SETTINGS = "settings.delete"
    
    # Loading/Unloading - CRUD operations
    VIEW_LOADING_UNLOADING = "loading_unloading.view"
    ADD_LOADING_UNLOADING = "loading_unloading.add"
    EDIT_LOADING_UNLOADING = "loading_unloading.edit"
    DELETE_LOADING_UNLOADING = "loading_unloading.delete"
    
    # Order Book - CRUD operations
    VIEW_ORDER_BOOK = "order_book.view"
    ADD_ORDER_BOOK = "order_book.add"
    EDIT_ORDER_BOOK = "order_book.edit"
    DELETE_ORDER_BOOK = "order_book.delete"
    QUICK_DELIVERY = "order_book.quick_delivery"
    COLLECT_EMPTY_JARS = "order_book.empty_jars"
    
    # Payment Reconciliation - CRUD operations
    VIEW_PAYMENT_RECONCILIATION = "payment_reconciliation.view"
    ADD_PAYMENT_RECONCILIATION = "payment_reconciliation.add"
    EDIT_PAYMENT_RECONCILIATION = "payment_reconciliation.edit"
    DELETE_PAYMENT_RECONCILIATION = "payment_reconciliation.delete"
    APPROVE_PAYMENTS = "payment_reconciliation.approve"

def get_default_permissions(role: str) -> List[str]:
    """Get default permissions for a role"""
    if role == UserRole.ADMIN:
        return [UserPermissions.ADMIN_ALL]
    elif role == UserRole.MANAGER:
        # Manager permissions - similar to admin but without user management and settings
        return [
            UserPermissions.VIEW_DASHBOARD,
            UserPermissions.VIEW_REPORTS,
            UserPermissions.DOWNLOAD_REPORTS,
            UserPermissions.EXPORT_REPORTS,
            UserPermissions.VIEW_CUSTOMERS,
            UserPermissions.ADD_CUSTOMERS,
            UserPermissions.EDIT_CUSTOMERS,
            UserPermissions.VIEW_ORDERS,
            UserPermissions.ADD_ORDERS,
            UserPermissions.EDIT_ORDERS,
            UserPermissions.DELIVER_ORDERS,
            UserPermissions.VIEW_EVENT_ORDERS,
            UserPermissions.ADD_EVENT_ORDERS,
            UserPermissions.EDIT_EVENT_ORDERS,
            UserPermissions.DELIVER_EVENT_ORDERS,
            UserPermissions.VIEW_PRODUCTS,
            UserPermissions.ADD_PRODUCTS,
            UserPermissions.EDIT_PRODUCTS,
            UserPermissions.VIEW_PAYMENTS,
            UserPermissions.ADD_PAYMENTS,
            UserPermissions.COLLECT_PAYMENTS,
            UserPermissions.VIEW_EXPENSES,
            UserPermissions.ADD_EXPENSES,
            UserPermissions.VIEW_INVOICES,
            UserPermissions.ADD_INVOICES,
            UserPermissions.GENERATE_INVOICES,
            UserPermissions.VIEW_DELIVERIES,
            UserPermissions.MANAGE_DELIVERIES,
            UserPermissions.VIEW_ORDER_BOOK,
            UserPermissions.QUICK_DELIVERY,
            UserPermissions.COLLECT_EMPTY_JARS,
            UserPermissions.VIEW_PAYMENT_RECONCILIATION,
            UserPermissions.APPROVE_PAYMENTS
        ]
    elif role == UserRole.EMPLOYEE:
        # Employee permissions - basic operational permissions
        return [
            UserPermissions.VIEW_DASHBOARD,
            UserPermissions.VIEW_CUSTOMERS,
            UserPermissions.VIEW_ORDERS,
            UserPermissions.ADD_ORDERS,
            UserPermissions.VIEW_EVENT_ORDERS,
            UserPermissions.VIEW_PRODUCTS,
            UserPermissions.VIEW_PAYMENTS,
            UserPermissions.COLLECT_PAYMENTS,
            UserPermissions.VIEW_INVOICES,
            UserPermissions.VIEW_DELIVERIES,
            UserPermissions.VIEW_ORDER_BOOK,
            UserPermissions.QUICK_DELIVERY,
            UserPermissions.COLLECT_EMPTY_JARS,
            UserPermissions.VIEW_PAYMENT_RECONCILIATION
        ]
    elif role == UserRole.DELIVERY_BOY:
        return [
            UserPermissions.VIEW_ORDERS,
            UserPermissions.DELIVER_ORDERS,
            UserPermissions.VIEW_PRODUCTS,
            UserPermissions.VIEW_DASHBOARD,
            UserPermissions.COLLECT_PAYMENTS
        ]
    elif role == UserRole.CUSTOMER:
        return []
    return []

def has_permission(user: User, permission: str) -> bool:
    """Check if user has specific permission"""
    if UserPermissions.ADMIN_ALL in user.permissions:
        return True
    return permission in user.permissions

class UserCreate(BaseModel):
    email: Optional[EmailStr] = None
    name: str
    mobile: str
    password: str
    role: str = UserRole.ADMIN
    
    @field_validator('email', mode='before')
    @classmethod
    def empty_str_to_none(cls, v):
        if v == "":
            return None
        return v

class UserLogin(BaseModel):
    email: Optional[EmailStr] = None
    mobile: Optional[str] = None
    password: str

class UserUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    mobile: Optional[str] = None
    profile_photo: Optional[str] = None
    permissions: Optional[List[str]] = None
    gst_number: Optional[str] = None

class UserPermissionUpdate(BaseModel):
    permissions: List[str]

class PasswordChange(BaseModel):
    current_password: str
    new_password: str

class Token(BaseModel):
    access_token: str
    token_type: str
    user: User

class Customer(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    mobile: str
    address: str
    water_type: str  # 20L, 10L, 1L etc
    bottle_deposit: float = 0.0
    balance_due: float = 0.0
    cash_balance: float = 0.0  # Alias for balance_due for frontend compatibility
    empty_jars_balance: int = 0  # Number of empty jars customer needs to return
    group_id: Optional[str] = None  # Reference to customer group
    customer_type: str = "regular"  # regular, event, both
    is_active: bool = True
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class CustomerCreate(BaseModel):
    name: str
    mobile: str
    address: str
    water_type: str
    bottle_deposit: float = 0.0
    
    @validator('mobile')
    def validate_mobile(cls, v):
        # Remove any whitespace
        v = v.strip()
        # Check if it's all digits
        if not v.isdigit():
            raise ValueError('Mobile number must contain only digits')
        # Check length
        if len(v) != 10:
            raise ValueError('Mobile number must be exactly 10 digits')
        # Check if it starts with valid digit (6-9 for Indian numbers)
        if v[0] not in ['6', '7', '8', '9']:
            raise ValueError('Mobile number must start with 6, 7, 8, or 9')
        return v

class CustomerUpdate(BaseModel):
    name: Optional[str] = None
    mobile: Optional[str] = None
    address: Optional[str] = None
    water_type: Optional[str] = None
    bottle_deposit: Optional[float] = None
    balance_due: Optional[float] = None
    empty_jars_balance: Optional[int] = None
    group_id: Optional[str] = None
    is_active: Optional[bool] = None
    
    @validator('mobile')
    def validate_mobile(cls, v):
        if v is None:
            return v
        # Remove any whitespace
        v = v.strip()
        # Check if it's all digits
        if not v.isdigit():
            raise ValueError('Mobile number must contain only digits')
        # Check length
        if len(v) != 10:
            raise ValueError('Mobile number must be exactly 10 digits')
        # Check if it starts with valid digit (6-9 for Indian numbers)
        if v[0] not in ['6', '7', '8', '9']:
            raise ValueError('Mobile number must start with 6, 7, 8, or 9')
        return v

class CustomerGroup(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    description: Optional[str] = None
    category: str  # Individual, Corporate, VIP, etc.
    discount_percentage: float = 0.0  # Group-based pricing discount
    is_active: bool = True
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class CustomerGroupCreate(BaseModel):
    name: str
    description: Optional[str] = None
    category: str
    discount_percentage: float = 0.0

class CustomerGroupUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    discount_percentage: Optional[float] = None

class Product(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    type: str  # jar, bottle
    capacity: str  # 20L, 10L, 1L etc
    price: float
    stock_filled: int = 0
    stock_empty: int = 0
    is_active: bool = True
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ProductCreate(BaseModel):
    name: str
    type: str
    capacity: str
    price: float
    stock_filled: int = 0
    stock_empty: int = 0

class Order(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    customer_id: str
    customer_name: str
    products: Optional[List[dict]] = []  # [{product_id, product_name, quantity, price}]
    total_amount: float
    payment_mode: str = "cash"  # cash, upi, online
    payment_status: str = "pending"  # pending, paid
    delivery_date: datetime
    delivery_status: str = "pending"  # pending, loading, in_transit, unloading, delivered, returned
    delivery_boy_id: Optional[str] = None
    delivery_boy_name: Optional[str] = None
    # Loading and Unloading tracking
    loading_started_at: Optional[datetime] = None
    loading_completed_at: Optional[datetime] = None
    loading_location: Optional[str] = None
    vehicle_number: Optional[str] = None
    unloading_started_at: Optional[datetime] = None
    unloading_completed_at: Optional[datetime] = None
    products_loaded: Optional[List[dict]] = None  # Products actually loaded
    empty_jars_collected: Optional[int] = 0
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class OrderCreate(BaseModel):
    customer_id: str
    products: List[dict]
    total_amount: float
    payment_mode: str
    delivery_date: datetime
    notes: Optional[str] = None

class OrderUpdate(BaseModel):
    delivery_status: Optional[str] = None
    payment_status: Optional[str] = None
    delivery_boy_id: Optional[str] = None
    delivery_boy_name: Optional[str] = None
    loading_started_at: Optional[datetime] = None
    loading_completed_at: Optional[datetime] = None
    loading_location: Optional[str] = None
    vehicle_number: Optional[str] = None
    unloading_started_at: Optional[datetime] = None
    unloading_completed_at: Optional[datetime] = None
    products_loaded: Optional[List[dict]] = None
    empty_jars_collected: Optional[int] = None
    notes: Optional[str] = None

class LoadingData(BaseModel):
    loading_location: Optional[str] = None
    vehicle_number: Optional[str] = None
    products_loaded: List[dict]  # Products actually loaded with quantities

class UnloadingData(BaseModel):
    empty_jars_collected: int = 0
    customer_notes: Optional[str] = None

class LoadingSession(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    delivery_boy_id: str
    delivery_boy_name: str
    vehicle_number: str
    loading_location: str
    products_to_load: List[dict]  # Products with quantities loaded
    status: str = "loaded"  # loaded, completed
    loading_completed_at: datetime
    unloaded_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class UnloadingSession(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    session_id: str  # Reference to loading session
    empty_jars_collected: List[dict]  # Customer wise empty jars
    total_empty_jars: int
    unloading_notes: Optional[str] = None
    unloading_completed_at: datetime
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Payment(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    order_id: str
    customer_id: str
    customer_name: str
    amount: float
    payment_method: str  # cash, upi, online, card
    payment_date: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    transaction_id: Optional[str] = None
    receipt_number: str
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class PaymentCreate(BaseModel):
    order_id: str
    customer_id: str
    amount: float
    payment_method: str
    transaction_id: Optional[str] = None
    notes: Optional[str] = None

class Expense(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    category: str  # fuel, salary, maintenance, office, transport, utilities, other
    amount: float
    description: Optional[str] = None
    expense_date: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    created_by: str
    receipt_attached: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ExpenseCreate(BaseModel):
    title: str
    category: str
    amount: float
    description: Optional[str] = None
    expense_date: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ExpenseUpdate(BaseModel):
    title: Optional[str] = None
    category: Optional[str] = None
    amount: Optional[float] = None
    description: Optional[str] = None
    expense_date: Optional[datetime] = None

class Invoice(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    invoice_number: str
    order_id: Optional[str] = None  # Made optional for event and monthly invoices
    customer_id: str
    customer_name: str
    customer_address: Optional[str] = None  # Made optional for event invoices
    customer_mobile: Optional[str] = None  # Made optional for event invoices
    items: List[dict]  # [{name, quantity, price, total}]
    subtotal: float
    tax_rate: float = 0.0  # GST rate
    tax_amount: float = 0.0
    discount_amount: float = 0.0
    total_amount: float
    amount_paid: float = 0.0  # Amount already paid
    issue_date: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    due_date: datetime
    status: str = "draft"  # draft, sent, paid, overdue, cancelled
    payment_terms: str = "Net 30"
    notes: Optional[str] = None
    created_by: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    # Enhanced invoice fields
    invoice_type: Optional[str] = "regular"  # regular, event_order, monthly_due
    event_order_id: Optional[str] = None  # For event order invoices
    issue_month: Optional[int] = None  # For monthly due invoices
    issue_year: Optional[int] = None  # For monthly due invoices

class InvoiceCreate(BaseModel):
    order_id: str
    customer_id: str
    items: List[dict]
    subtotal: float
    tax_rate: float = 0.0
    discount_amount: float = 0.0
    due_days: int = 30
    payment_terms: str = "Net 30"
    notes: Optional[str] = None

class InvoiceUpdate(BaseModel):
    status: Optional[str] = None
    tax_rate: Optional[float] = None
    discount_amount: Optional[float] = None
    due_date: Optional[datetime] = None
    payment_terms: Optional[str] = None
    notes: Optional[str] = None

class EventOrder(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    event_name: str
    event_type: str  # wedding, corporate, party, festival, conference, other
    customer_id: str
    customer_name: str
    customer_mobile: str
    event_date: datetime
    event_time: str
    venue_address: str
    products: List[dict]  # [{product_id, product_name, quantity, price, total}]
    total_amount: float
    advance_amount: float = 0.0
    balance_amount: float = 0.0
    special_requirements: Optional[str] = None
    setup_required: bool = False
    delivery_instructions: Optional[str] = None
    event_status: str = "confirmed"  # confirmed, in_progress, completed, cancelled
    payment_status: str = "pending"  # pending, advance_paid, fully_paid
    assigned_team: Optional[str] = None
    # Delivery management fields
    delivery_boy_id: Optional[str] = None
    delivery_boy_name: Optional[str] = None
    delivery_date: Optional[datetime] = None
    delivery_time: Optional[str] = None
    vehicle_number: Optional[str] = None
    delivery_status: str = "pending"  # pending, assigned, in_progress, completed
    # Delivery quantity calculation fields
    total_jars_required: Optional[int] = 0  # Total jars calculated from water products
    jars_to_deliver: Optional[int] = 0      # Jars that need to be delivered
    expected_jars: Optional[int] = 0        # Expected jars for delivery
    jars_delivered: Optional[int] = None
    empty_jars_collected: Optional[int] = None
    missing_empty_jars: Optional[int] = None
    setup_completed: bool = False
    delivery_notes: Optional[str] = None
    delivered_by: Optional[str] = None
    delivered_by_name: Optional[str] = None
    delivery_completed_at: Optional[datetime] = None
    # Payment tracking fields
    last_payment_amount: Optional[float] = None
    last_payment_date: Optional[datetime] = None
    last_payment_mode: Optional[str] = None
    payment_collected_by: Optional[str] = None
    # Cancellation fields
    cancellation_reason: Optional[str] = None
    cancelled_at: Optional[datetime] = None
    cancelled_by: Optional[str] = None
    cancelled_by_name: Optional[str] = None
    advance_forfeited: Optional[bool] = None
    refund_amount: Optional[float] = None
    created_by: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class EventOrderCreate(BaseModel):
    event_name: str
    event_type: str
    customer_id: str
    event_date: datetime
    event_time: str
    venue_address: str
    products: List[dict]
    total_amount: float
    advance_amount: float = 0.0
    special_requirements: Optional[str] = None
    setup_required: bool = False
    delivery_instructions: Optional[str] = None

class EventOrderUpdate(BaseModel):
    event_name: Optional[str] = None
    event_type: Optional[str] = None
    event_date: Optional[datetime] = None
    event_time: Optional[str] = None
    venue_address: Optional[str] = None
    products: Optional[List[dict]] = None  # Allow updating products
    total_amount: Optional[float] = None
    advance_amount: Optional[float] = None
    special_requirements: Optional[str] = None
    setup_required: Optional[bool] = None
    delivery_instructions: Optional[str] = None
    event_status: Optional[str] = None
    payment_status: Optional[str] = None
    assigned_team: Optional[str] = None
    # Delivery management fields
    delivery_boy_id: Optional[str] = None
    delivery_boy_name: Optional[str] = None
    delivery_date: Optional[datetime] = None
    delivery_time: Optional[str] = None
    vehicle_number: Optional[str] = None
    delivery_status: Optional[str] = None
    # Delivery quantity calculation fields
    total_jars_required: Optional[int] = None
    jars_to_deliver: Optional[int] = None
    expected_jars: Optional[int] = None
    jars_delivered: Optional[int] = None
    empty_jars_collected: Optional[int] = None
    missing_empty_jars: Optional[int] = None
    setup_completed: Optional[bool] = None
    delivery_notes: Optional[str] = None
    delivered_by: Optional[str] = None
    delivered_by_name: Optional[str] = None
    delivery_completed_at: Optional[datetime] = None
    # Payment tracking fields
    last_payment_amount: Optional[float] = None
    last_payment_date: Optional[datetime] = None
    last_payment_mode: Optional[str] = None
    payment_collected_by: Optional[str] = None
    # Cancellation fields
    cancellation_reason: Optional[str] = None
    cancelled_at: Optional[datetime] = None
    cancelled_by: Optional[str] = None
    cancelled_by_name: Optional[str] = None
    advance_forfeited: Optional[bool] = None
    refund_amount: Optional[float] = None

class ArchivedEventOrder(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    original_event_id: str
    customer_id: str
    customer_name: str
    customer_mobile: str
    event_date: datetime
    event_time: str
    venue_address: str
    products: List[dict]
    total_amount: float
    advance_amount: float
    balance_amount: float
    payment_status: str
    event_status: str
    delivery_instructions: Optional[str] = None
    setup_required: bool = False
    event_name: str
    event_type: str
    invoice_generated: bool = False
    jars_delivered: Optional[int] = None
    delivery_completed_at: Optional[str] = None
    empty_jars_collected: Optional[int] = None
    collection_completed_at: Optional[str] = None
    last_payment_amount: Optional[float] = None
    last_payment_date: Optional[str] = None
    last_payment_mode: Optional[str] = None
    payment_collected_by: Optional[str] = None
    archived_date: str
    archive_month: str  # Format: "2025-10"
    archive_year: str   # Format: "2025"
    created_at: str
    archived_by: str = "system"

class DeliveryBoyPayment(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    delivery_boy_id: str
    delivery_boy_name: str
    event_id: Optional[str] = None
    order_id: Optional[str] = None
    customer_id: str
    customer_name: str
    amount_collected: float
    payment_mode: str = "cash"  # cash, upi, online, cheque
    payment_type: str = "event_delivery"  # event_delivery, order_delivery, advance_payment
    collection_date: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    notes: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class DashboardStats(BaseModel):
    total_customers: int
    total_jars_delivered_today: int
    total_revenue_today: float
    pending_orders: int
    total_expenses_today: float
    outstanding_payments: float
    profit_today: float
    total_invoices: int
    pending_invoices: int
    overdue_invoices: int
    total_event_orders: int
    upcoming_events: int
    event_revenue_month: float
    # Event Order specific statistics
    event_jars_delivered_today: int
    event_empty_jars_collected_today: int
    event_revenue_today: float
    completed_events_today: int
    completed_events_month: int
    # Cancelled Event Statistics
    cancelled_events_today: int
    cancelled_events_month: int
    advance_forfeited_today: float
    advance_forfeited_month: float

# Helper functions
def hash_password(password: str) -> str:
    # Simple password hashing with salt
    salt = secrets.token_hex(16)
    hash_obj = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 100000)
    return f"{salt}:{hash_obj.hex()}"

def verify_password(plain_password: str, hashed_password: str) -> bool:
    try:
        salt, hash_hex = hashed_password.split(':')
        hash_obj = hashlib.pbkdf2_hmac('sha256', plain_password.encode('utf-8'), salt.encode('utf-8'), 100000)
        return hash_obj.hex() == hash_hex
    except Exception:
        return False

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
    except jwt.PyJWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
    
    user = await db.users.find_one({"id": user_id})
    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found")
    
    # Ensure permissions field exists, use defaults if missing
    if 'permissions' not in user or not user['permissions']:
        user['permissions'] = get_default_permissions(user.get('role', 'admin'))
    
    return User(**user)

# Helper function to prepare datetime for MongoDB
def prepare_for_mongo(data):
    if isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, datetime):
                data[key] = value.isoformat()
    return data

# Helper function to clean MongoDB documents (remove ObjectId)
def clean_mongo_doc(doc):
    if isinstance(doc, dict):
        cleaned = {}
        for key, value in doc.items():
            if key != '_id':  # Remove ObjectId field
                cleaned[key] = value
        return cleaned
    return doc

def clean_mongo_docs(docs):
    return [clean_mongo_doc(doc) for doc in docs]

# Authentication routes
@api_router.post("/auth/register", response_model=User)
async def register_user(user_data: UserCreate):
    # Handle empty email string by converting to None
    if user_data.email == "":
        user_data.email = None
    
    # Check if user already exists by email (if provided) or mobile
    query_conditions = []
    if user_data.email:
        query_conditions.append({"email": user_data.email})
    query_conditions.append({"mobile": user_data.mobile})
    
    existing_user = await db.users.find_one({"$or": query_conditions})
    if existing_user:
        if existing_user.get("email") == user_data.email:
            raise HTTPException(status_code=400, detail="Email already registered")
        else:
            raise HTTPException(status_code=400, detail="Mobile number already registered")
    
    # SECURITY: Check if any user exists in the system
    total_users = await db.users.count_documents({})
    
    # If this is the first user (database empty), make them admin
    # Otherwise, prevent admin role signup and force manager/delivery_boy role
    if total_users == 0:
        # First user - automatically admin
        user_data.role = 'admin'
    else:
        # Not first user - prevent admin signup
        if user_data.role == 'admin':
            raise HTTPException(
                status_code=403, 
                detail="Cannot signup as admin. Only the first user becomes admin. Please select Manager or Delivery Boy role."
            )
    
    # Hash password and create user
    hashed_password = hash_password(user_data.password)
    user_dict = user_data.dict()
    del user_dict['password']
    user_dict['password_hash'] = hashed_password
    
    # Set default permissions based on role
    user_dict['permissions'] = get_default_permissions(user_data.role)
    
    user_obj = User(**user_dict)
    user_doc = prepare_for_mongo(user_obj.dict())
    # Add password_hash separately since it's not in the User model
    user_doc['password_hash'] = hashed_password
    await db.users.insert_one(user_doc)
    
    return user_obj

@api_router.post("/auth/login", response_model=Token)
async def login_user(login_data: UserLogin):
    # Validate that at least email or mobile is provided
    if not login_data.email and not login_data.mobile:
        raise HTTPException(status_code=400, detail="Either email or mobile number is required")
    
    # Find user by email or mobile
    query_conditions = []
    if login_data.email:
        query_conditions.append({"email": login_data.email})
    if login_data.mobile:
        query_conditions.append({"mobile": login_data.mobile})
    
    user = await db.users.find_one({"$or": query_conditions})
    if not user or not verify_password(login_data.password, user.get('password_hash', '')):
        raise HTTPException(status_code=400, detail="Invalid credentials")
    
    # Create access token
    access_token = create_access_token(data={"sub": user["id"], "email": user.get("email", ""), "mobile": user.get("mobile", "")})
    
    # Ensure permissions field exists, use defaults if missing
    if 'permissions' not in user or not user['permissions']:
        user['permissions'] = get_default_permissions(user.get('role', 'admin'))
    
    user_obj = User(**user)
    
    return Token(access_token=access_token, token_type="bearer", user=user_obj)

@api_router.get("/auth/me", response_model=User)
async def get_current_user_info(current_user: User = Depends(get_current_user)):
    return current_user

@api_router.put("/profile", response_model=User)
async def update_profile(update_data: UserUpdate, current_user: User = Depends(get_current_user)):
    # Create update dictionary with only non-None values
    update_dict = {k: v for k, v in update_data.dict().items() if v is not None}
    
    if not update_dict:
        raise HTTPException(status_code=400, detail="No fields to update")
    
    # Add updated timestamp
    update_dict['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    # Update user in database
    result = await db.users.update_one(
        {"id": current_user.id},
        {"$set": update_dict}
    )
    
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="User not found or no changes made")
    
    # Return updated user
    updated_user = await db.users.find_one({"id": current_user.id})
    if not updated_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    return User(**updated_user)

@api_router.post("/profile/upload-photo")
async def upload_profile_photo(file: UploadFile = File(...), current_user: User = Depends(get_current_user)):
    # Validate file type
    allowed_types = ["image/jpeg", "image/jpg", "image/png", "image/webp"]
    if file.content_type not in allowed_types:
        raise HTTPException(status_code=400, detail="Invalid file type. Only JPEG, PNG, and WebP images are allowed.")
    
    # Validate file size (max 5MB)
    max_size = 5 * 1024 * 1024  # 5MB in bytes
    contents = await file.read()
    if len(contents) > max_size:
        raise HTTPException(status_code=400, detail="File size too large. Maximum size allowed is 5MB.")
    
    # Generate unique filename
    file_extension = file.filename.split('.')[-1] if '.' in file.filename else 'jpg'
    unique_filename = f"{current_user.id}_{uuid.uuid4().hex}.{file_extension}"
    file_path = PROFILE_PHOTOS_DIR / unique_filename
    
    # Save the file
    with open(file_path, "wb") as buffer:
        buffer.write(contents)
    
    # Update user's profile photo URL
    photo_url = f"/uploads/profile_photos/{unique_filename}"
    await db.users.update_one(
        {"id": current_user.id},
        {"$set": {
            "profile_photo": photo_url,
            "updated_at": datetime.now(timezone.utc).isoformat()
        }}
    )
    
    return {
        "message": "Profile photo uploaded successfully",
        "photo_url": photo_url
    }

@api_router.delete("/profile/delete-photo")
async def delete_profile_photo(current_user: User = Depends(get_current_user)):
    # Get current user to check if they have a photo
    user = await db.users.find_one({"id": current_user.id})
    if not user or not user.get("profile_photo"):
        raise HTTPException(status_code=404, detail="No profile photo found")
    
    # Delete the file from filesystem
    try:
        photo_path = user["profile_photo"]
        if photo_path.startswith("/uploads/"):
            file_path = Path(photo_path[1:])  # Remove leading slash
            if file_path.exists():
                file_path.unlink()
    except Exception as e:
        print(f"Error deleting file: {e}")
    
    # Update user record to remove photo
    await db.users.update_one(
        {"id": current_user.id},
        {"$set": {
            "profile_photo": None,
            "updated_at": datetime.now(timezone.utc).isoformat()
        }}
    )
    
    return {"message": "Profile photo deleted successfully"}

@api_router.put("/auth/change-password")
async def change_password(password_data: PasswordChange, current_user: User = Depends(get_current_user)):
    # Get current user from database to check current password
    user = await db.users.find_one({"id": current_user.id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Verify current password
    if not verify_password(password_data.current_password, user.get('password_hash', '')):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    
    # Hash new password
    new_password_hash = hash_password(password_data.new_password)
    
    # Update password in database
    result = await db.users.update_one(
        {"id": current_user.id},
        {"$set": {
            "password_hash": new_password_hash,
            "updated_at": datetime.now(timezone.utc).isoformat()
        }}
    )
    
    if result.modified_count == 0:
        raise HTTPException(status_code=500, detail="Failed to update password")
    
    return {"message": "Password changed successfully"}

@api_router.get("/users", response_model=List[User])
async def get_users(current_user: User = Depends(get_current_user)):
    # Only admin can access user management
    if not has_permission(current_user, UserPermissions.ADMIN_ALL):
        raise HTTPException(status_code=403, detail="Access denied. Admin privileges required.")
    
    users = await db.users.find({}).to_list(1000)
    return [User(**user) for user in users]

@api_router.get("/delivery-boys", response_model=List[User])
async def get_delivery_boys(current_user: User = Depends(get_current_user)):
    # Any logged in user can access delivery boys list for assignment purposes
    # No specific permission check - just need to be authenticated
    
    # Get only delivery boys
    delivery_boys = await db.users.find({"role": "delivery_boy", "is_active": True}).to_list(1000)
    return [User(**user) for user in delivery_boys]

@api_router.delete("/users/{user_id}")
async def delete_user(user_id: str, current_user: User = Depends(get_current_user)):
    # Only admin can delete users
    if not has_permission(current_user, UserPermissions.ADMIN_ALL):
        raise HTTPException(status_code=403, detail="Access denied. Admin privileges required.")
    
    # Prevent admin from deleting themselves
    if current_user.id == user_id:
        raise HTTPException(status_code=400, detail="Cannot delete your own account")
    
    # Find the user to delete
    user_to_delete = await db.users.find_one({"id": user_id})
    if not user_to_delete:
        raise HTTPException(status_code=404, detail="User not found")
    
    # SECURITY: Prevent deleting admin users
    if user_to_delete.get('role') == 'admin':
        raise HTTPException(
            status_code=403, 
            detail="Cannot delete admin users. Admin accounts are protected for security reasons."
        )
    
    # Delete the user
    result = await db.users.delete_one({"id": user_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    
    return {"message": f"User {user_to_delete.get('name', 'Unknown')} deleted successfully"}

@api_router.get("/users/{user_id}/permissions")
async def get_user_permissions(user_id: str, current_user: User = Depends(get_current_user)):
    # Only admin can view user permissions
    if not has_permission(current_user, UserPermissions.ADMIN_ALL):
        raise HTTPException(status_code=403, detail="Access denied. Admin privileges required.")
    
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    return {
        "user_id": user_id,
        "user_name": user.get("name"),
        "role": user.get("role"),
        "permissions": user.get("permissions", []),
        "default_permissions": get_default_permissions(user.get("role", ""))
    }

@api_router.put("/users/{user_id}/permissions")
async def update_user_permissions(user_id: str, permission_data: UserPermissionUpdate, current_user: User = Depends(get_current_user)):
    # Only admin can update user permissions
    if not has_permission(current_user, UserPermissions.ADMIN_ALL):
        raise HTTPException(status_code=403, detail="Access denied. Admin privileges required.")
    
    # Prevent admin from modifying their own permissions
    if current_user.id == user_id:
        raise HTTPException(status_code=400, detail="Cannot modify your own permissions")
    
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Validate permissions (check if they exist in UserPermissions class)
    valid_permissions = [getattr(UserPermissions, attr) for attr in dir(UserPermissions) 
                        if not attr.startswith('_') and isinstance(getattr(UserPermissions, attr), str)]
    
    invalid_perms = [perm for perm in permission_data.permissions if perm not in valid_permissions and perm != UserPermissions.ADMIN_ALL]
    if invalid_perms:
        raise HTTPException(status_code=400, detail=f"Invalid permissions: {', '.join(invalid_perms)}")
    
    # Update user permissions
    result = await db.users.update_one(
        {"id": user_id},
        {"$set": {
            "permissions": permission_data.permissions,
            "updated_at": datetime.now(timezone.utc).isoformat()
        }}
    )
    
    if result.modified_count == 0:
        raise HTTPException(status_code=500, detail="Failed to update permissions")
    
    return {
        "message": "User permissions updated successfully",
        "user_id": user_id,
        "permissions": permission_data.permissions
    }

@api_router.put("/users/{user_id}/reset-password")
async def reset_user_password(user_id: str, request: dict, current_user: User = Depends(get_current_user)):
    """Admin can reset any user's password"""
    # Only admin can reset passwords
    if not has_permission(current_user, UserPermissions.ADMIN_ALL):
        raise HTTPException(status_code=403, detail="Access denied. Admin privileges required.")
    
    # Get new password from request
    new_password = request.get("new_password")
    if not new_password or len(new_password) < 6:
        raise HTTPException(status_code=400, detail="Password must be at least 6 characters long")
    
    # Find user
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Hash the new password
    hashed_password = pwd_context.hash(new_password)
    
    # Update password in database
    result = await db.users.update_one(
        {"id": user_id},
        {"$set": {
            "password": hashed_password,
            "updated_at": datetime.now(timezone.utc).isoformat()
        }}
    )
    
    if result.modified_count == 0:
        raise HTTPException(status_code=500, detail="Failed to reset password")
    
    return {
        "message": f"Password reset successfully for user: {user.get('name', user.get('email'))}",
        "user_id": user_id,
        "email": user.get("email")
    }

@api_router.get("/permissions/available")
async def get_available_permissions(current_user: User = Depends(get_current_user)):
    # Only admin can view available permissions
    if not has_permission(current_user, UserPermissions.ADMIN_ALL):
        raise HTTPException(status_code=403, detail="Access denied. Admin privileges required.")
    
    # Get all available permissions organized by category with CRUD operations
    permissions = {
        "dashboard_reports": {
            "label": "Dashboard & Reports",
            "permissions": [
                {"key": UserPermissions.VIEW_DASHBOARD, "label": "View Dashboard"},
                {"key": UserPermissions.VIEW_REPORTS, "label": "View Reports"},
                {"key": UserPermissions.DOWNLOAD_REPORTS, "label": "Download Reports"},
                {"key": UserPermissions.EXPORT_REPORTS, "label": "Export Reports"}
            ]
        },
        "customers": {
            "label": "Customer Management",
            "permissions": [
                {"key": UserPermissions.VIEW_CUSTOMERS, "label": "View Customers"},
                {"key": UserPermissions.ADD_CUSTOMERS, "label": "Add Customers"},
                {"key": UserPermissions.EDIT_CUSTOMERS, "label": "Edit Customers"},
                {"key": UserPermissions.DELETE_CUSTOMERS, "label": "Delete Customers"},
                {"key": UserPermissions.ACTIVATE_DEACTIVATE_CUSTOMERS, "label": "Activate/Deactivate Customers"}
            ]
        },
        "orders": {
            "label": "Regular Order Management",
            "permissions": [
                {"key": UserPermissions.VIEW_ORDERS, "label": "View Orders"},
                {"key": UserPermissions.ADD_ORDERS, "label": "Add Orders"},
                {"key": UserPermissions.EDIT_ORDERS, "label": "Edit Orders"},
                {"key": UserPermissions.DELETE_ORDERS, "label": "Delete Orders"},
                {"key": UserPermissions.DELIVER_ORDERS, "label": "Deliver Orders"}
            ]
        },
        "event_orders": {
            "label": "Event Order Management",
            "permissions": [
                {"key": UserPermissions.VIEW_EVENT_ORDERS, "label": "View Event Orders"},
                {"key": UserPermissions.ADD_EVENT_ORDERS, "label": "Add Event Orders"},
                {"key": UserPermissions.EDIT_EVENT_ORDERS, "label": "Edit Event Orders"},
                {"key": UserPermissions.DELETE_EVENT_ORDERS, "label": "Delete Event Orders"},
                {"key": UserPermissions.DELIVER_EVENT_ORDERS, "label": "Deliver Event Orders"}
            ]
        },
        "products": {
            "label": "Product Management",
            "permissions": [
                {"key": UserPermissions.VIEW_PRODUCTS, "label": "View Products"},
                {"key": UserPermissions.ADD_PRODUCTS, "label": "Add Products"},
                {"key": UserPermissions.EDIT_PRODUCTS, "label": "Edit Products"},
                {"key": UserPermissions.DELETE_PRODUCTS, "label": "Delete Products"}
            ]
        },
        "payments": {
            "label": "Payment Management",
            "permissions": [
                {"key": UserPermissions.VIEW_PAYMENTS, "label": "View Payments"},
                {"key": UserPermissions.ADD_PAYMENTS, "label": "Add Payments"},
                {"key": UserPermissions.EDIT_PAYMENTS, "label": "Edit Payments"},
                {"key": UserPermissions.DELETE_PAYMENTS, "label": "Delete Payments"},
                {"key": UserPermissions.COLLECT_PAYMENTS, "label": "Collect Payments"}
            ]
        },
        "expenses": {
            "label": "Expense Management",
            "permissions": [
                {"key": UserPermissions.VIEW_EXPENSES, "label": "View Expenses"},
                {"key": UserPermissions.ADD_EXPENSES, "label": "Add Expenses"},
                {"key": UserPermissions.EDIT_EXPENSES, "label": "Edit Expenses"},
                {"key": UserPermissions.DELETE_EXPENSES, "label": "Delete Expenses"}
            ]
        },
        "invoices": {
            "label": "Invoice Management",
            "permissions": [
                {"key": UserPermissions.VIEW_INVOICES, "label": "View Invoices"},
                {"key": UserPermissions.ADD_INVOICES, "label": "Add Invoices"},
                {"key": UserPermissions.EDIT_INVOICES, "label": "Edit Invoices"},
                {"key": UserPermissions.DELETE_INVOICES, "label": "Delete Invoices"},
                {"key": UserPermissions.GENERATE_INVOICES, "label": "Generate Invoices"}
            ]
        },
        "deliveries": {
            "label": "Delivery Management",
            "permissions": [
                {"key": UserPermissions.VIEW_DELIVERIES, "label": "View Deliveries"},
                {"key": UserPermissions.ADD_DELIVERIES, "label": "Add Deliveries"},
                {"key": UserPermissions.EDIT_DELIVERIES, "label": "Edit Deliveries"},
                {"key": UserPermissions.DELETE_DELIVERIES, "label": "Delete Deliveries"},
                {"key": UserPermissions.MANAGE_DELIVERIES, "label": "Manage Deliveries"}
            ]
        },
        "users": {
            "label": "User Management",
            "permissions": [
                {"key": UserPermissions.VIEW_USERS, "label": "View Users"},
                {"key": UserPermissions.ADD_USERS, "label": "Add Users"},
                {"key": UserPermissions.EDIT_USERS, "label": "Edit Users"},
                {"key": UserPermissions.DELETE_USERS, "label": "Delete Users"},
                {"key": UserPermissions.MANAGE_USER_PERMISSIONS, "label": "Manage User Permissions"}
            ]
        },
        "groups": {
            "label": "Group Management",
            "permissions": [
                {"key": UserPermissions.VIEW_GROUPS, "label": "View Groups"},
                {"key": UserPermissions.ADD_GROUPS, "label": "Add Groups"},
                {"key": UserPermissions.EDIT_GROUPS, "label": "Edit Groups"},
                {"key": UserPermissions.DELETE_GROUPS, "label": "Delete Groups"}
            ]
        },
        "settings": {
            "label": "Settings & Configuration",
            "permissions": [
                {"key": UserPermissions.VIEW_SETTINGS, "label": "View Settings"},
                {"key": UserPermissions.ADD_SETTINGS, "label": "Add Settings"},
                {"key": UserPermissions.EDIT_SETTINGS, "label": "Edit Settings"},
                {"key": UserPermissions.DELETE_SETTINGS, "label": "Delete Settings"}
            ]
        },
        "loading_unloading": {
            "label": "Loading/Unloading",
            "permissions": [
                {"key": UserPermissions.VIEW_LOADING_UNLOADING, "label": "View Loading/Unloading"},
                {"key": UserPermissions.ADD_LOADING_UNLOADING, "label": "Add Loading/Unloading"},
                {"key": UserPermissions.EDIT_LOADING_UNLOADING, "label": "Edit Loading/Unloading"},
                {"key": UserPermissions.DELETE_LOADING_UNLOADING, "label": "Delete Loading/Unloading"}
            ]
        },
        "order_book": {
            "label": "Order Book Management",
            "permissions": [
                {"key": UserPermissions.VIEW_ORDER_BOOK, "label": "View Order Book"},
                {"key": UserPermissions.ADD_ORDER_BOOK, "label": "Add Order Book"},
                {"key": UserPermissions.EDIT_ORDER_BOOK, "label": "Edit Order Book"},
                {"key": UserPermissions.DELETE_ORDER_BOOK, "label": "Delete Order Book"},
                {"key": UserPermissions.QUICK_DELIVERY, "label": "Quick Delivery"},
                {"key": UserPermissions.COLLECT_EMPTY_JARS, "label": "Collect Empty Jars"}
            ]
        },
        "payment_reconciliation": {
            "label": "Payment Reconciliation",
            "permissions": [
                {"key": UserPermissions.VIEW_PAYMENT_RECONCILIATION, "label": "View Payment Reconciliation"},
                {"key": UserPermissions.ADD_PAYMENT_RECONCILIATION, "label": "Add Payment Reconciliation"},
                {"key": UserPermissions.EDIT_PAYMENT_RECONCILIATION, "label": "Edit Payment Reconciliation"},
                {"key": UserPermissions.DELETE_PAYMENT_RECONCILIATION, "label": "Delete Payment Reconciliation"},
                {"key": UserPermissions.APPROVE_PAYMENTS, "label": "Approve Payments"}
            ]
        }
    }
    
    return permissions

# Customer routes
@api_router.post("/customers", response_model=Customer)
async def create_customer(customer_data: CustomerCreate, current_user: User = Depends(get_current_user)):
    customer_obj = Customer(**customer_data.dict())
    customer_doc = prepare_for_mongo(customer_obj.dict())
    await db.customers.insert_one(customer_doc)
    return customer_obj

@api_router.get("/customers", response_model=List[Customer])
async def get_customers(current_user: User = Depends(get_current_user)):
    # Only show regular customers (not event-only customers)
    customers = await db.customers.find({
        "is_active": True,
        "customer_type": {"$in": ["regular", "both"]}
    }).to_list(1000)
    
    # Ensure cash_balance field exists for frontend compatibility
    for customer in customers:
        if 'cash_balance' not in customer:
            customer['cash_balance'] = customer.get('balance_due', 0.0)
        if 'customer_type' not in customer:
            customer['customer_type'] = 'regular'
    
    return [Customer(**customer) for customer in customers]

@api_router.get("/customers/all", response_model=List[Customer])
async def get_all_customers(current_user: User = Depends(get_current_user)):
    """Get all regular customers (active and inactive) for customer management"""
    # Only show regular customers (not event-only customers)
    customers = await db.customers.find({
        "customer_type": {"$in": ["regular", "both"]}
    }).to_list(1000)
    
    # Ensure cash_balance field exists for frontend compatibility
    for customer in customers:
        if 'cash_balance' not in customer:
            customer['cash_balance'] = customer.get('balance_due', 0.0)
        if 'customer_type' not in customer:
            customer['customer_type'] = 'regular'
    
    return [Customer(**customer) for customer in customers]

@api_router.get("/customers/event-customers", response_model=List[Customer])
async def get_event_customers(current_user: User = Depends(get_current_user)):
    """Get all event customers (for event order dropdown)"""
    # Show all customers who can have event orders
    customers = await db.customers.find({"is_active": True}).to_list(1000)
    
    # Ensure cash_balance and customer_type fields exist
    for customer in customers:
        if 'cash_balance' not in customer:
            customer['cash_balance'] = customer.get('balance_due', 0.0)
        if 'customer_type' not in customer:
            customer['customer_type'] = 'regular'
    
    return [Customer(**customer) for customer in customers]

# Get Monthly Due Customers - MUST be before /customers/{customer_id} to avoid route conflict
@api_router.get("/customers/monthly-due")
async def get_monthly_due_customers(minimum_due: float = 100.0, current_user: User = Depends(get_current_user)):
    """Get customers with monthly due amounts for invoice creation"""
    try:
        # Query customers with cash balance due (using both cash_balance and balance_due fields)
        customers = await db.customers.find({
            "$or": [
                {"cash_balance": {"$gte": minimum_due}},
                {"balance_due": {"$gte": minimum_due}}
            ],
            "is_active": True
        }).sort("cash_balance", -1).to_list(1000)
        
        # Add summary information
        total_due_amount = sum(max(customer.get("cash_balance", 0), customer.get("balance_due", 0)) for customer in customers)
        
        return {
            "customers": clean_mongo_docs(customers),
            "summary": {
                "total_customers": len(customers),
                "total_due_amount": total_due_amount,
                "minimum_due": minimum_due
            }
        }
        
    except Exception as e:
        print(f"Error getting monthly due customers: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to get monthly due customers: {str(e)}")

@api_router.get("/customers/{customer_id}", response_model=Customer)
async def get_customer(customer_id: str, current_user: User = Depends(get_current_user)):
    customer = await db.customers.find_one({"id": customer_id, "is_active": True})
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    return Customer(**customer)

@api_router.put("/customers/{customer_id}", response_model=Customer)
async def update_customer(customer_id: str, update_data: CustomerUpdate, current_user: User = Depends(get_current_user)):
    update_dict = {k: v for k, v in update_data.dict().items() if v is not None}
    update_dict['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    result = await db.customers.update_one(
        {"id": customer_id, "is_active": True},
        {"$set": update_dict}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    updated_customer = await db.customers.find_one({"id": customer_id})
    return Customer(**updated_customer)

@api_router.delete("/customers/{customer_id}")
async def delete_customer(customer_id: str, current_user: User = Depends(get_current_user)):
    # Check if customer exists and has outstanding balance
    customer = await db.customers.find_one({"id": customer_id})
    
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    # Prevent deletion if customer has outstanding balance
    cash_balance = customer.get("cash_balance", 0) or 0
    if cash_balance > 0:
        raise HTTPException(
            status_code=400, 
            detail=f"Cannot delete customer with outstanding balance of ₹{cash_balance:.2f}. Please collect payment first."
        )
    
    # Check if customer has empty jars balance
    empty_jars_balance = customer.get("empty_jars_balance", 0) or 0
    if empty_jars_balance > 0:
        raise HTTPException(
            status_code=400,
            detail=f"Cannot delete customer with {empty_jars_balance} empty jars pending. Please collect empty jars first."
        )
    
    # Actually delete the customer from database (hard delete)
    result = await db.customers.delete_one({"id": customer_id})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    return {"message": "Customer deleted successfully"}

# Customer Activation/Deactivation routes
@api_router.put("/customers/{customer_id}/activate")
async def activate_customer(customer_id: str, current_user: User = Depends(get_current_user)):
    """Activate a customer"""
    result = await db.customers.update_one(
        {"id": customer_id},
        {"$set": {"is_active": True, "updated_at": datetime.now(timezone.utc).isoformat()}}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    return {"message": "Customer activated successfully", "is_active": True}

@api_router.put("/customers/{customer_id}/deactivate")
async def deactivate_customer(customer_id: str, current_user: User = Depends(get_current_user)):
    """Deactivate a customer"""
    result = await db.customers.update_one(
        {"id": customer_id},
        {"$set": {"is_active": False, "updated_at": datetime.now(timezone.utc).isoformat()}}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    return {"message": "Customer deactivated successfully", "is_active": False}

# Event Order Archive Functions
async def archive_completed_cancelled_events():
    """Archive completed and cancelled event orders at month end"""
    try:
        # Get current date and calculate month end
        now = datetime.now(timezone.utc)
        # Set to last day of current month at 11:59:59 PM
        if now.month == 12:
            next_month = now.replace(year=now.year + 1, month=1, day=1, hour=23, minute=59, second=59, microsecond=0)
        else:
            next_month = now.replace(month=now.month + 1, day=1, hour=23, minute=59, second=59, microsecond=0)
        
        month_end = next_month - timedelta(days=1)
        
        # Check if today is month end
        if now.date() != month_end.date():
            return {"message": "Not month end, skipping archive"}
        
        archive_month = now.strftime("%Y-%m")
        archive_year = now.strftime("%Y")
        archive_date = month_end.isoformat()
        
        # Find completed and cancelled event orders to archive
        events_to_archive = await db.event_orders.find({
            "event_status": {"$in": ["completed", "cancelled"]}
        }).to_list(1000)
        
        if not events_to_archive:
            return {"message": "No events to archive"}
        
        archived_count = 0
        
        for event in events_to_archive:
            # Create archived event order
            archived_event = {
                "id": str(uuid.uuid4()),
                "original_event_id": event["id"],
                "customer_id": event["customer_id"],
                "customer_name": event["customer_name"],
                "customer_mobile": event["customer_mobile"],
                "event_date": event["event_date"],
                "event_time": event["event_time"],
                "venue_address": event.get("venue_address", ""),
                "products": event.get("products", []),
                "total_amount": event.get("total_amount", 0),
                "advance_amount": event.get("advance_amount", 0),
                "balance_amount": event.get("balance_amount", 0),
                "payment_status": event.get("payment_status", "pending"),
                "event_status": event["event_status"],
                "delivery_instructions": event.get("delivery_instructions"),
                "setup_required": event.get("setup_required", False),
                "event_name": event.get("event_name", ""),
                "event_type": event.get("event_type", ""),
                "invoice_generated": event.get("invoice_generated", False),
                "jars_delivered": event.get("jars_delivered"),
                "delivery_completed_at": event.get("delivery_completed_at"),
                "empty_jars_collected": event.get("empty_jars_collected"),
                "collection_completed_at": event.get("collection_completed_at"),
                "last_payment_amount": event.get("last_payment_amount"),
                "last_payment_date": event.get("last_payment_date"),
                "last_payment_mode": event.get("last_payment_mode"),
                "payment_collected_by": event.get("payment_collected_by"),
                "archived_date": archive_date,
                "archive_month": archive_month,
                "archive_year": archive_year,
                "created_at": event.get("created_at", ""),
                "archived_by": "system"
            }
            
            # Insert into archived collection
            await db.archived_event_orders.insert_one(archived_event)
            
            # Remove from active event orders
            await db.event_orders.delete_one({"id": event["id"]})
            
            archived_count += 1
        
        return {
            "message": f"Successfully archived {archived_count} event orders",
            "archived_count": archived_count,
            "archive_month": archive_month,
            "archived_date": archive_date
        }
        
    except Exception as e:
        print(f"Error during archival: {e}")
        return {"error": f"Archive failed: {str(e)}"}

# Archive API Endpoints
@api_router.post("/event-orders/archive")
async def manual_archive_events(current_user: User = Depends(get_current_user)):
    """Manually trigger event order archival (Admin only)"""
    if not has_permission(current_user, UserPermissions.ADMIN_ALL):
        raise HTTPException(status_code=403, detail="Admin access required")
    
    result = await archive_completed_cancelled_events()
    return result

@api_router.get("/archived-event-orders", response_model=List[ArchivedEventOrder])
async def get_archived_event_orders(
    month: Optional[str] = None,  # Format: "2025-10"
    year: Optional[str] = None,   # Format: "2025"
    status: Optional[str] = None, # completed or cancelled
    current_user: User = Depends(get_current_user)
):
    """Get archived event orders with optional filters"""
    filter_dict = {}
    
    if month:
        filter_dict["archive_month"] = month
    if year:
        filter_dict["archive_year"] = year
    if status:
        filter_dict["event_status"] = status
    
    archived_events = await db.archived_event_orders.find(filter_dict).sort("archived_date", -1).to_list(1000)
    return [ArchivedEventOrder(**event) for event in archived_events]

@api_router.get("/archived-event-orders/months")
async def get_available_archive_months(current_user: User = Depends(get_current_user)):
    """Get list of months that have archived event orders"""
    pipeline = [
        {"$group": {"_id": "$archive_month", "count": {"$sum": 1}}},
        {"$sort": {"_id": -1}}
    ]
    
    months = await db.archived_event_orders.aggregate(pipeline).to_list(100)
    return [{"month": month["_id"], "count": month["count"]} for month in months]

# Customer Group routes
@api_router.post("/customer-groups", response_model=CustomerGroup)
async def create_customer_group(group_data: CustomerGroupCreate, current_user: User = Depends(get_current_user)):
    # Only admin can create customer groups
    if not has_permission(current_user, UserPermissions.ADMIN_ALL):
        raise HTTPException(status_code=403, detail="Access denied. Admin privileges required.")
    
    # Check if group name already exists
    existing_group = await db.customer_groups.find_one({"name": group_data.name, "is_active": True})
    if existing_group:
        raise HTTPException(status_code=400, detail="Customer group with this name already exists")
    
    group_obj = CustomerGroup(**group_data.dict())
    group_doc = prepare_for_mongo(group_obj.dict())
    await db.customer_groups.insert_one(group_doc)
    return group_obj

@api_router.get("/customer-groups", response_model=List[CustomerGroup])
async def get_customer_groups(current_user: User = Depends(get_current_user)):
    groups = await db.customer_groups.find({"is_active": True}).to_list(1000)
    return [CustomerGroup(**group) for group in groups]

@api_router.get("/customer-groups/{group_id}", response_model=CustomerGroup)
async def get_customer_group(group_id: str, current_user: User = Depends(get_current_user)):
    group = await db.customer_groups.find_one({"id": group_id, "is_active": True})
    if not group:
        raise HTTPException(status_code=404, detail="Customer group not found")
    return CustomerGroup(**group)

@api_router.put("/customer-groups/{group_id}", response_model=CustomerGroup)
async def update_customer_group(group_id: str, update_data: CustomerGroupUpdate, current_user: User = Depends(get_current_user)):
    # Only admin can update customer groups
    if not has_permission(current_user, UserPermissions.ADMIN_ALL):
        raise HTTPException(status_code=403, detail="Access denied. Admin privileges required.")
    
    update_dict = {k: v for k, v in update_data.dict().items() if v is not None}
    update_dict['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    result = await db.customer_groups.update_one(
        {"id": group_id, "is_active": True},
        {"$set": update_dict}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Customer group not found")
    
    updated_group = await db.customer_groups.find_one({"id": group_id})
    return CustomerGroup(**updated_group)

@api_router.delete("/customer-groups/{group_id}")
async def delete_customer_group(group_id: str, current_user: User = Depends(get_current_user)):
    # Only admin can delete customer groups
    if not has_permission(current_user, UserPermissions.ADMIN_ALL):
        raise HTTPException(status_code=403, detail="Access denied. Admin privileges required.")
    
    # Check if any customers are assigned to this group
    customers_in_group = await db.customers.find_one({"group_id": group_id, "is_active": True})
    if customers_in_group:
        raise HTTPException(status_code=400, detail="Cannot delete group with assigned customers. Please reassign customers first.")
    
    result = await db.customer_groups.update_one(
        {"id": group_id},
        {"$set": {"is_active": False, "updated_at": datetime.now(timezone.utc).isoformat()}}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Customer group not found")
    
    return {"message": "Customer group deleted successfully"}

@api_router.get("/customer-groups/{group_id}/customers", response_model=List[Customer])
async def get_customers_in_group(group_id: str, current_user: User = Depends(get_current_user)):
    # Verify group exists
    group = await db.customer_groups.find_one({"id": group_id, "is_active": True})
    if not group:
        raise HTTPException(status_code=404, detail="Customer group not found")
    
    customers = await db.customers.find({"group_id": group_id, "is_active": True}).to_list(1000)
    return [Customer(**customer) for customer in customers]

@api_router.post("/customer-groups/{group_id}/add-customer/{customer_id}")
async def add_customer_to_group(group_id: str, customer_id: str, current_user: User = Depends(get_current_user)):
    # Only admin can manage group assignments
    if not has_permission(current_user, UserPermissions.ADMIN_ALL):
        raise HTTPException(status_code=403, detail="Access denied. Admin privileges required.")
    
    # Verify group exists
    group = await db.customer_groups.find_one({"id": group_id, "is_active": True})
    if not group:
        raise HTTPException(status_code=404, detail="Customer group not found")
    
    # Verify customer exists
    customer = await db.customers.find_one({"id": customer_id, "is_active": True})
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    # Add customer to group
    await db.customers.update_one(
        {"id": customer_id},
        {"$set": {"group_id": group_id, "updated_at": datetime.now(timezone.utc).isoformat()}}
    )
    
    return {"message": f"Customer added to group {group['name']} successfully"}

@api_router.post("/customer-groups/{group_id}/remove-customer/{customer_id}")
async def remove_customer_from_group(group_id: str, customer_id: str, current_user: User = Depends(get_current_user)):
    # Only admin can manage group assignments
    if not has_permission(current_user, UserPermissions.ADMIN_ALL):
        raise HTTPException(status_code=403, detail="Access denied. Admin privileges required.")
    
    # Remove customer from group
    result = await db.customers.update_one(
        {"id": customer_id, "group_id": group_id},
        {"$set": {"group_id": None, "updated_at": datetime.now(timezone.utc).isoformat()}}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Customer not found in this group")
    
    return {"message": "Customer removed from group successfully"}

@api_router.post("/customers/{customer_id}/update-balance")
async def update_customer_balance(customer_id: str, balance_data: dict, current_user: User = Depends(get_current_user)):
    return await process_customer_balance_update(customer_id, balance_data, current_user)

@api_router.put("/customers/{customer_id}/balance")
async def update_customer_balance_put(customer_id: str, balance_data: dict, current_user: User = Depends(get_current_user)):
    return await process_customer_balance_update(customer_id, balance_data, current_user)

async def process_customer_balance_update(customer_id: str, balance_data: dict, current_user: User = Depends(get_current_user)):
    # Find customer
    customer = await db.customers.find_one({"id": customer_id, "is_active": True})
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    transaction_type = balance_data.get("type", "payment")
    notes = balance_data.get("notes", "")
    
    # Handle different transaction types
    if transaction_type == "empty_jar_collection":
        # Handle empty jar collection (reduce empty jar balance)
        jar_count = balance_data.get("jar_count", 0)
        current_jar_balance = customer.get("empty_jars_balance", 0)
        new_jar_balance = max(0, current_jar_balance - jar_count)
        
        # Update customer empty jar balance
        result = await db.customers.update_one(
            {"id": customer_id},
            {"$set": {
                "empty_jars_balance": new_jar_balance,
                "updated_at": datetime.now(timezone.utc).isoformat()
            }}
        )
        
        if result.modified_count == 0:
            raise HTTPException(status_code=500, detail="Failed to update customer empty jar balance")
        
        return {
            "message": "Customer empty jar balance updated successfully",
            "previous_jar_balance": current_jar_balance,
            "new_jar_balance": new_jar_balance,
            "jars_collected": jar_count
        }
    elif transaction_type == "empty_jars_add":
        # Handle empty jars addition (increase empty jar balance after delivery)
        jar_count = int(balance_data.get("amount", 0))
        current_jar_balance = customer.get("empty_jars_balance", 0)
        new_jar_balance = current_jar_balance + jar_count
        
        # Update customer empty jar balance
        result = await db.customers.update_one(
            {"id": customer_id},
            {"$set": {
                "empty_jars_balance": new_jar_balance,
                "updated_at": datetime.now(timezone.utc).isoformat()
            }}
        )
        
        if result.modified_count == 0:
            raise HTTPException(status_code=500, detail="Failed to update customer empty jar balance")
        
        return {
            "message": "Customer empty jar balance updated successfully",
            "previous_jar_balance": current_jar_balance,
            "new_jar_balance": new_jar_balance,
            "jars_added": jar_count
        }
    else:
        # Handle cash balance updates (payment or charge)
        amount = balance_data.get("amount", 0)
        current_balance = customer.get("balance_due", 0.0)
        
        if transaction_type == "payment":
            # Payment reduces the balance due
            new_balance = current_balance - amount
        else:  # charge
            # Charge increases the balance due
            new_balance = current_balance + amount
        
        # Update customer cash balance
        result = await db.customers.update_one(
            {"id": customer_id},
            {"$set": {
                "balance_due": new_balance,
                "cash_balance": new_balance,  # Keep both fields in sync
                "updated_at": datetime.now(timezone.utc).isoformat()
            }}
        )
        
        if result.modified_count == 0:
            raise HTTPException(status_code=500, detail="Failed to update customer balance")
        
        # Record the transaction
        transaction_record = {
            "id": str(uuid.uuid4()),
            "customer_id": customer_id,
            "type": transaction_type,
            "amount": amount,
            "previous_balance": current_balance,
            "new_balance": new_balance,
            "notes": notes,
            "processed_by": current_user.id,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        
        await db.balance_transactions.insert_one(transaction_record)
        
        return {
            "message": "Customer balance updated successfully",
            "previous_balance": current_balance,
            "new_balance": new_balance,
            "transaction_id": transaction_record["id"]
        }

@api_router.get("/customers/{customer_id}/balance-history")
async def get_customer_balance_history(customer_id: str, current_user: User = Depends(get_current_user)):
    # Verify customer exists
    customer = await db.customers.find_one({"id": customer_id, "is_active": True})
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    # Get balance transaction history
    transactions = await db.balance_transactions.find(
        {"customer_id": customer_id}
    ).sort("created_at", -1).to_list(1000)
    
    # Convert transactions to JSON-serializable format
    serialized_transactions = []
    for transaction in transactions:
        # Remove MongoDB ObjectId field and convert to dict
        if '_id' in transaction:
            del transaction['_id']
        serialized_transactions.append(transaction)
    
    return {
        "customer_id": customer_id,
        "current_balance": customer.get("balance_due", 0.0),
        "transactions": serialized_transactions
    }

# Customer Reports endpoints
@api_router.get("/reports/customers-by-cash-balance")
async def get_customers_by_cash_balance(
    balance_type: str = "due",  # "due", "credit", "all"
    min_amount: float = 0.0,
    current_user: User = Depends(get_current_user)
):
    """Get customers filtered by cash balance"""
    
    # Build query based on balance type
    if balance_type == "due":
        query = {"balance_due": {"$gt": min_amount}, "is_active": True}
        sort_order = -1  # Highest due first
    elif balance_type == "credit":
        query = {"balance_due": {"$lt": -min_amount}, "is_active": True}
        sort_order = 1   # Lowest (most credit) first
    else:  # all
        query = {"balance_due": {"$ne": 0}, "is_active": True}
        sort_order = -1  # Highest due first
    
    customers = await db.customers.find(query).sort("balance_due", sort_order).to_list(1000)
    
    # Calculate totals
    total_customers = len(customers)
    total_amount_due = sum(c.get('balance_due', 0) for c in customers if c.get('balance_due', 0) > 0)
    total_credit = sum(abs(c.get('balance_due', 0)) for c in customers if c.get('balance_due', 0) < 0)
    
    return {
        "customers": [Customer(**customer) for customer in customers],
        "summary": {
            "total_customers": total_customers,
            "total_amount_due": total_amount_due,
            "total_credit": total_credit,
            "balance_type": balance_type,
            "min_amount": min_amount
        },
        "generated_at": datetime.now(timezone.utc).isoformat()
    }

@api_router.get("/reports/customers-by-empty-jars")
async def get_customers_by_empty_jars(
    jar_type: str = "pending",  # "pending", "all"
    min_jars: int = 1,
    current_user: User = Depends(get_current_user)
):
    """Get customers filtered by empty jar balance"""
    
    # Build query based on jar type
    if jar_type == "pending":
        query = {"empty_jars_balance": {"$gte": min_jars}, "is_active": True}
    else:  # all
        query = {"empty_jars_balance": {"$ne": 0}, "is_active": True}
    
    customers = await db.customers.find(query).sort("empty_jars_balance", -1).to_list(1000)
    
    # Calculate totals
    total_customers = len(customers)
    total_empty_jars = sum(c.get('empty_jars_balance', 0) for c in customers)
    
    return {
        "customers": [Customer(**customer) for customer in customers],
        "summary": {
            "total_customers": total_customers,
            "total_empty_jars": total_empty_jars,
            "jar_type": jar_type,
            "min_jars": min_jars
        },
        "generated_at": datetime.now(timezone.utc).isoformat()
    }

@api_router.get("/reports/combined-customer-balances")
async def get_combined_customer_balances(current_user: User = Depends(get_current_user)):
    """Get customers with both cash and empty jar balances for comprehensive report"""
    
    customers = await db.customers.find({
        "$or": [
            {"balance_due": {"$ne": 0}},
            {"empty_jars_balance": {"$ne": 0}}
        ],
        "is_active": True
    }).sort("balance_due", -1).to_list(1000)
    
    # Calculate totals
    total_customers = len(customers)
    total_cash_due = sum(c.get('balance_due', 0) for c in customers if c.get('balance_due', 0) > 0)
    total_credit = sum(abs(c.get('balance_due', 0)) for c in customers if c.get('balance_due', 0) < 0)
    total_empty_jars = sum(c.get('empty_jars_balance', 0) for c in customers)
    
    return {
        "customers": [Customer(**customer) for customer in customers],
        "summary": {
            "total_customers": total_customers,
            "total_cash_due": total_cash_due,
            "total_credit": total_credit,
            "total_empty_jars": total_empty_jars
        },
        "generated_at": datetime.now(timezone.utc).isoformat()
    }

# Archived Event Orders Reports
@api_router.get("/reports/archived-events")
async def get_archived_events_report(
    month: Optional[str] = None,
    year: Optional[str] = None,
    report_type: str = "monthly",
    current_user: User = Depends(get_current_user)
):
    """Get archived event orders report with statistics"""
    try:
        # Set default filters
        filter_dict = {}
        if month:
            filter_dict["archive_month"] = month
        if year:
            filter_dict["archive_year"] = year
            
        # Get archived events
        archived_events = await db.archived_event_orders.find(filter_dict).sort("archived_date", -1).to_list(1000)
        
        # Calculate statistics
        total_events = len(archived_events)
        completed_events = len([e for e in archived_events if e["event_status"] == "completed"])
        cancelled_events = len([e for e in archived_events if e["event_status"] == "cancelled"])
        
        total_revenue = sum(e.get("total_amount", 0) for e in archived_events if e["event_status"] == "completed")
        advance_collected = sum(e.get("advance_amount", 0) for e in archived_events)
        balance_pending = sum(e.get("balance_amount", 0) for e in archived_events if e["event_status"] == "completed")
        
        total_jars = sum(e.get("jars_delivered", 0) or 0 for e in archived_events if e["event_status"] == "completed")
        empty_jars_collected = sum(e.get("empty_jars_collected", 0) or 0 for e in archived_events if e["event_status"] == "completed")
        
        # Group by month for monthly breakdown
        monthly_stats = {}
        for event in archived_events:
            month_key = event["archive_month"]
            if month_key not in monthly_stats:
                monthly_stats[month_key] = {
                    "month": month_key,
                    "total_events": 0,
                    "completed": 0,
                    "cancelled": 0,
                    "total_revenue": 0,
                    "total_jars": 0
                }
            
            monthly_stats[month_key]["total_events"] += 1
            if event["event_status"] == "completed":
                monthly_stats[month_key]["completed"] += 1
                monthly_stats[month_key]["total_revenue"] += event.get("total_amount", 0)
                monthly_stats[month_key]["total_jars"] += event.get("jars_delivered", 0) or 0
            elif event["event_status"] == "cancelled":
                monthly_stats[month_key]["cancelled"] += 1
        
        return {
            "summary": {
                "total_events": total_events,
                "completed_events": completed_events,
                "cancelled_events": cancelled_events,
                "total_revenue": total_revenue,
                "advance_collected": advance_collected,
                "balance_pending": balance_pending,
                "total_jars_delivered": total_jars,
                "empty_jars_collected": empty_jars_collected,
                "completion_rate": round((completed_events / total_events * 100), 2) if total_events > 0 else 0
            },
            "monthly_breakdown": list(monthly_stats.values()),
            "events": archived_events,
            "filters": {
                "month": month,
                "year": year,
                "report_type": report_type
            }
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating archived events report: {str(e)}")

@api_router.get("/reports/archived-events/export")
async def export_archived_events_report(
    month: Optional[str] = None,
    year: Optional[str] = None,
    format: str = "pdf",
    current_user: User = Depends(get_current_user)
):
    """Export archived event orders report as PDF or Excel"""
    try:
        # Get report data
        report_data = await get_archived_events_report(month, year, "monthly", current_user)
        
        if format.lower() == "excel":
            # Create Excel file
            output = io.BytesIO()
            wb = Workbook()
            
            # Summary sheet
            ws = wb.active
            ws.title = "Archived Events Summary"
            
            # Headers
            ws['A1'] = "🗄️ Archived Event Orders Report"
            ws['A1'].font = Font(bold=True, size=16)
            ws['A3'] = f"Archive Period: {month or 'All Months'} {year or 'All Years'}"
            
            # Summary statistics
            summary = report_data["summary"]
            ws['A5'] = "Summary Statistics"
            ws['A5'].font = Font(bold=True, size=14)
            
            ws['A7'] = "Total Events"
            ws['B7'] = summary["total_events"]
            ws['A8'] = "Completed Events"
            ws['B8'] = summary["completed_events"]
            ws['A9'] = "Cancelled Events" 
            ws['B9'] = summary["cancelled_events"]
            ws['A10'] = "Total Revenue"
            ws['B10'] = summary["total_revenue"]
            ws['A11'] = "Completion Rate"
            ws['B11'] = f"{summary['completion_rate']}%"
            
            # Monthly breakdown
            ws['A13'] = "Monthly Breakdown"
            ws['A13'].font = Font(bold=True, size=14)
            
            headers = ["Month", "Total Events", "Completed", "Cancelled", "Revenue", "Jars Delivered"]
            for col, header in enumerate(headers, 1):
                ws.cell(row=15, column=col, value=header).font = Font(bold=True)
            
            for row, month_data in enumerate(report_data["monthly_breakdown"], 16):
                ws.cell(row=row, column=1, value=month_data["month"])
                ws.cell(row=row, column=2, value=month_data["total_events"])
                ws.cell(row=row, column=3, value=month_data["completed"])
                ws.cell(row=row, column=4, value=month_data["cancelled"])
                ws.cell(row=row, column=5, value=month_data["total_revenue"])
                ws.cell(row=row, column=6, value=month_data["total_jars"])
            
            wb.save(output)
            output.seek(0)
            
            filename = f"archived_events_report_{month or 'all'}_{year or 'all'}.xlsx"
            return StreamingResponse(
                io.BytesIO(output.read()),
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
        
        elif format.lower() == "pdf":
            # Create PDF with common header
            buffer = io.BytesIO()
            from reportlab.platypus import PageTemplate, Frame, BaseDocTemplate
            
            # Get contact details for footer
            contact_details = await get_contact_details_for_pdf()
            
            def draw_header(canvas, doc):
                draw_pdf_header_and_footer(canvas, doc, contact_details)
            
            # Create document with custom template
            doc = BaseDocTemplate(buffer, pagesize=A4, rightMargin=20, leftMargin=20, topMargin=100, bottomMargin=30)
            
            # Create frame for content
            content_frame = Frame(20, 30, A4[0] - 40, A4[1] - 130, id='content')
            
            # Add page template with common header
            template = PageTemplate('header_template', [content_frame], onPage=draw_header)
            doc.addPageTemplates([template])
            
            elements = []
            styles = getSampleStyleSheet()
            
            # Report title
            report_title = f"""
            <para align=center>
            <b><font size=18>ARCHIVED EVENT ORDERS REPORT</font></b>
            </para>
            """
            
            title_style = ParagraphStyle('ReportTitle',
                parent=styles['Normal'],
                alignment=1,
                spaceAfter=15,
                spaceBefore=20,
                textColor=colors.black)
            
            elements.append(Paragraph(report_title, title_style))
            
            # Report details
            report_details = f"""
            <para>
            <b>Report Number:</b> AER-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}<br/>
            <b>Archive Period:</b> {month or 'All Months'} {year or 'All Years'}<br/>
            <b>Generated Date:</b> {datetime.now(timezone.utc).strftime('%d %B %Y at %H:%M UTC')}<br/>
            <b>Report Type:</b> Archived Event Orders Summary Report
            </para>
            """
            
            details_style = ParagraphStyle('ReportDetails',
                parent=styles['Normal'],
                fontSize=11,
                spaceAfter=20,
                leftIndent=0,
                textColor=colors.black)
            
            elements.append(Paragraph(report_details, details_style))
            elements.append(Spacer(1, 20))
            
            # Summary statistics table
            summary = report_data["summary"]
            summary_data = [
                ["Metric", "Value"],
                ["Total Archived Events", str(summary["total_events"])],
                ["Completed Events", str(summary["completed_events"])],
                ["Cancelled Events", str(summary["cancelled_events"])],
                ["Total Revenue", f"₹{summary['total_revenue']:,.2f}"],
                ["Total Jars Delivered", str(summary["total_jars_delivered"])],
                ["Completion Rate", f"{summary['completion_rate']}%"]
            ]
            
            summary_table = Table(summary_data, colWidths=[3*inch, 2*inch])
            summary_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            elements.append(Paragraph("Summary Statistics", styles['Heading2']))
            elements.append(summary_table)
            elements.append(Spacer(1, 20))
            
            # Monthly breakdown
            if report_data["monthly_breakdown"]:
                elements.append(Paragraph("Monthly Breakdown", styles['Heading2']))
                
                monthly_data = [["Month", "Total", "Completed", "Cancelled", "Revenue"]]
                for month_stat in report_data["monthly_breakdown"]:
                    monthly_data.append([
                        month_stat["month"],
                        str(month_stat["total_events"]),
                        str(month_stat["completed"]),
                        str(month_stat["cancelled"]),
                        f"₹{month_stat['total_revenue']:,.2f}"
                    ])
                
                monthly_table = Table(monthly_data, colWidths=[1.5*inch, 1*inch, 1*inch, 1*inch, 1.5*inch])
                monthly_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 9),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                
                elements.append(monthly_table)
            
            # Build PDF
            doc.build(elements)
            buffer.seek(0)
            
            filename = f"archived_events_report_{month or 'all'}_{year or 'all'}.pdf"
            return StreamingResponse(
                io.BytesIO(buffer.read()),
                media_type="application/pdf",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error exporting archived events report: {str(e)}")

# Product routes
@api_router.post("/products", response_model=Product)
async def create_product(product_data: ProductCreate, current_user: User = Depends(get_current_user)):
    product_obj = Product(**product_data.dict())
    product_doc = prepare_for_mongo(product_obj.dict())
    await db.products.insert_one(product_doc)
    return product_obj

@api_router.get("/products", response_model=List[Product])
async def get_products(current_user: User = Depends(get_current_user)):
    products = await db.products.find({"is_active": True}).to_list(1000)
    return [Product(**product) for product in products]

@api_router.delete("/products/{product_id}")
async def delete_product(product_id: str, current_user: User = Depends(get_current_user)):
    result = await db.products.update_one(
        {"id": product_id},
        {"$set": {"is_active": False, "updated_at": datetime.now(timezone.utc).isoformat()}}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Product not found")
    
    return {"message": "Product deleted successfully"}

# Order routes
@api_router.post("/orders", response_model=Order)
async def create_order(order_data: OrderCreate, current_user: User = Depends(get_current_user)):
    # Get customer info
    customer = await db.customers.find_one({"id": order_data.customer_id})
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    # Check if customer has any event orders
    has_event_orders = await db.event_orders.count_documents({"customer_id": order_data.customer_id}) > 0
    
    # Update customer type based on whether they have event orders
    current_type = customer.get('customer_type', 'regular')
    if has_event_orders and current_type == 'event':
        # Customer now has both event and regular orders
        await db.customers.update_one(
            {"id": order_data.customer_id},
            {"$set": {"customer_type": "both"}}
        )
    elif current_type != 'regular' and current_type != 'both':
        # Set to regular if not already
        await db.customers.update_one(
            {"id": order_data.customer_id},
            {"$set": {"customer_type": "regular"}}
        )
    
    order_dict = order_data.dict()
    order_dict['customer_name'] = customer['name']
    order_obj = Order(**order_dict)
    order_doc = prepare_for_mongo(order_obj.dict())
    await db.orders.insert_one(order_doc)
    
    return order_obj

@api_router.get("/orders", response_model=List[Order])
async def get_orders(current_user: User = Depends(get_current_user)):
    orders = await db.orders.find().sort("created_at", -1).to_list(1000)
    return [Order(**order) for order in orders]

@api_router.get("/orders/{order_id}", response_model=Order)
async def get_order(order_id: str, current_user: User = Depends(get_current_user)):
    order = await db.orders.find_one({"id": order_id})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return Order(**order)

@api_router.put("/orders/{order_id}", response_model=Order)
async def update_order(order_id: str, update_data: OrderUpdate, current_user: User = Depends(get_current_user)):
    update_dict = {k: v for k, v in update_data.dict().items() if v is not None}
    update_dict['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    if 'delivery_boy_id' in update_dict and update_dict['delivery_boy_id']:
        # Get delivery boy name
        delivery_boy = await db.users.find_one({"id": update_dict['delivery_boy_id']})
        if delivery_boy:
            update_dict['delivery_boy_name'] = delivery_boy['name']
    
    result = await db.orders.update_one(
        {"id": order_id},
        {"$set": update_dict}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Order not found")
    
    updated_order = await db.orders.find_one({"id": order_id})
    return Order(**updated_order)

# Loading and Unloading Operations
@api_router.post("/orders/{order_id}/start-loading")
async def start_loading(order_id: str, loading_data: LoadingData, current_user: User = Depends(get_current_user)):
    # Check if user has delivery permissions
    if not has_permission(current_user, UserPermissions.DELIVER_ORDERS):
        raise HTTPException(status_code=403, detail="Access denied")
    
    order = await db.orders.find_one({"id": order_id})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    # Validate current status
    if order.get("delivery_status") not in ["pending"]:
        raise HTTPException(status_code=400, detail="Cannot start loading. Order is not in pending status")
    
    # Update order with loading start information
    update_data = {
        "delivery_status": "loading",
        "loading_started_at": datetime.now(timezone.utc).isoformat(),
        "loading_location": loading_data.loading_location,
        "vehicle_number": loading_data.vehicle_number,
        "products_loaded": loading_data.products_loaded,
        "delivery_boy_id": current_user.id,
        "delivery_boy_name": current_user.name,
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.orders.update_one(
        {"id": order_id},
        {"$set": update_data}
    )
    
    return {"message": "Loading started successfully", "status": "loading"}

@api_router.post("/orders/{order_id}/complete-loading")
async def complete_loading(order_id: str, current_user: User = Depends(get_current_user)):
    # Check if user has delivery permissions
    if not has_permission(current_user, UserPermissions.DELIVER_ORDERS):
        raise HTTPException(status_code=403, detail="Access denied")
    
    order = await db.orders.find_one({"id": order_id})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    # Validate current status
    if order.get("delivery_status") != "loading":
        raise HTTPException(status_code=400, detail="Cannot complete loading. Order is not in loading status")
    
    # Update order with loading completion
    update_data = {
        "delivery_status": "in_transit",
        "loading_completed_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.orders.update_one(
        {"id": order_id},
        {"$set": update_data}
    )
    
    return {"message": "Loading completed successfully", "status": "in_transit"}

@api_router.post("/orders/{order_id}/start-unloading")
async def start_unloading(order_id: str, current_user: User = Depends(get_current_user)):
    # Check if user has delivery permissions
    if not has_permission(current_user, UserPermissions.DELIVER_ORDERS):
        raise HTTPException(status_code=403, detail="Access denied")
    
    order = await db.orders.find_one({"id": order_id})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    # Validate current status
    if order.get("delivery_status") not in ["in_transit", "loading"]:
        raise HTTPException(status_code=400, detail="Cannot start unloading. Order must be in transit")
    
    # Update order with unloading start
    update_data = {
        "delivery_status": "unloading",
        "unloading_started_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.orders.update_one(
        {"id": order_id},
        {"$set": update_data}
    )
    
    return {"message": "Unloading started successfully", "status": "unloading"}

@api_router.post("/orders/{order_id}/complete-unloading")
async def complete_unloading(order_id: str, unloading_data: UnloadingData, current_user: User = Depends(get_current_user)):
    # Check if user has delivery permissions
    if not has_permission(current_user, UserPermissions.DELIVER_ORDERS):
        raise HTTPException(status_code=403, detail="Access denied")
    
    order = await db.orders.find_one({"id": order_id})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    
    # Validate current status
    if order.get("delivery_status") != "unloading":
        raise HTTPException(status_code=400, detail="Cannot complete unloading. Order is not in unloading status")
    
    # Update order with unloading completion
    update_data = {
        "delivery_status": "delivered",
        "unloading_completed_at": datetime.now(timezone.utc).isoformat(),
        "empty_jars_collected": unloading_data.empty_jars_collected,
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    # Add customer notes if provided
    if unloading_data.customer_notes:
        update_data["notes"] = order.get("notes", "") + f" | Delivery Notes: {unloading_data.customer_notes}"
    
    await db.orders.update_one(
        {"id": order_id},
        {"$set": update_data}
    )
    
    # Update customer's empty jar balance
    if unloading_data.empty_jars_collected > 0:
        customer = await db.customers.find_one({"id": order["customer_id"]})
        if customer:
            current_balance = customer.get("empty_jars_balance", 0)
            new_balance = current_balance - unloading_data.empty_jars_collected
            await db.customers.update_one(
                {"id": order["customer_id"]},
                {"$set": {"empty_jars_balance": max(0, new_balance)}}
            )
    
    return {"message": "Delivery completed successfully", "status": "delivered"}

# Loading and Unloading Sessions API
@api_router.post("/loading-sessions", response_model=LoadingSession)
async def create_loading_session(session_data: dict, current_user: User = Depends(get_current_user)):
    # Check permissions
    if not has_permission(current_user, UserPermissions.DELIVER_ORDERS):
        raise HTTPException(status_code=403, detail="Access denied")
    
    # Create loading session
    session_obj = LoadingSession(
        delivery_boy_id=session_data["delivery_boy_id"],
        delivery_boy_name=session_data["delivery_boy_name"],
        vehicle_number=session_data["vehicle_number"],
        loading_location=session_data["loading_location"],
        products_to_load=session_data["products_to_load"],
        loading_completed_at=datetime.now(timezone.utc)
    )
    
    session_doc = prepare_for_mongo(session_obj.dict())
    await db.loading_sessions.insert_one(session_doc)
    
    return session_obj

# Jar Entries API
@api_router.post("/jar-entries")
async def create_jar_entry(entry_data: dict, current_user: User = Depends(get_current_user)):
    # Check permissions
    if not has_permission(current_user, UserPermissions.DELIVER_ORDERS):
        raise HTTPException(status_code=403, detail="Access denied")
    
    # Create jar entry document
    jar_entry = {
        "id": str(uuid.uuid4()),
        "operation_type": entry_data.get("operation_type"),
        "delivery_boy_id": entry_data.get("delivery_boy_id"),
        "delivery_boy_name": entry_data.get("delivery_boy_name"),
        "vehicle_number": entry_data.get("vehicle_number"),
        "jar_count": entry_data.get("jar_count"),
        "assignment_type": entry_data.get("assignment_type"),
        "assignment_id": entry_data.get("assignment_id"),
        "assignment_name": entry_data.get("assignment_name"),
        "notes": entry_data.get("notes"),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "created_by": current_user.id
    }
    
    await db.jar_entries.insert_one(jar_entry)
    return {"message": "Jar entry created successfully", "id": jar_entry["id"]}

@api_router.get("/jar-entries")
async def get_jar_entries(current_user: User = Depends(get_current_user)):
    # Check permissions
    if not has_permission(current_user, UserPermissions.VIEW_DELIVERY):
        raise HTTPException(status_code=403, detail="Access denied")
    
    entries = await db.jar_entries.find().sort("created_at", -1).to_list(1000)
    return entries

@api_router.get("/loading-sessions")
async def get_loading_sessions(delivery_boy_id: str = None, current_user: User = Depends(get_current_user)):
    # Check permissions
    if not has_permission(current_user, UserPermissions.VIEW_DELIVERY):
        raise HTTPException(status_code=403, detail="Access denied")
    
    # Build query
    query = {}
    if delivery_boy_id:
        query["delivery_boy_id"] = delivery_boy_id
    
    sessions = await db.loading_sessions.find(query).sort("created_at", -1).to_list(1000)
    return [LoadingSession(**session) for session in sessions]

@api_router.post("/unloading-sessions", response_model=UnloadingSession)
async def create_unloading_session(session_data: dict, current_user: User = Depends(get_current_user)):
    # Check permissions
    if not has_permission(current_user, UserPermissions.DELIVER_ORDERS):
        raise HTTPException(status_code=403, detail="Access denied")
    
    # Create unloading session
    session_obj = UnloadingSession(
        session_id=session_data["session_id"],
        empty_jars_collected=session_data["empty_jars_collected"],
        total_empty_jars=session_data["total_empty_jars"],
        unloading_notes=session_data.get("unloading_notes", ""),
        unloading_completed_at=datetime.now(timezone.utc)
    )
    
    session_doc = prepare_for_mongo(session_obj.dict())
    await db.unloading_sessions.insert_one(session_doc)
    
    # Update loading session as completed
    await db.loading_sessions.update_one(
        {"id": session_data["session_id"]},
        {"$set": {
            "unloaded_at": datetime.now(timezone.utc).isoformat(),
            "status": "completed"
        }}
    )
    
    # Update customer empty jar balances
    for jar_data in session_data["empty_jars_collected"]:
        if jar_data.get("empty_jars", 0) > 0:
            customer = await db.customers.find_one({"id": jar_data["customer_id"]})
            if customer:
                current_balance = customer.get("empty_jars_balance", 0)
                new_balance = max(0, current_balance - jar_data["empty_jars"])
                await db.customers.update_one(
                    {"id": jar_data["customer_id"]},
                    {"$set": {"empty_jars_balance": new_balance}}
                )
    
    return session_obj

@api_router.get("/unloading-sessions")
async def get_unloading_sessions(current_user: User = Depends(get_current_user)):
    # Check permissions
    if not has_permission(current_user, UserPermissions.VIEW_DELIVERY):
        raise HTTPException(status_code=403, detail="Access denied")
    
    sessions = await db.unloading_sessions.find({}).sort("created_at", -1).to_list(1000)
    return [UnloadingSession(**session) for session in sessions]

# Payment routes
@api_router.post("/payments", response_model=Payment)
async def create_payment(payment_data: PaymentCreate, current_user: User = Depends(get_current_user)):
    # Get customer and order info
    customer = await db.customers.find_one({"id": payment_data.customer_id})
    order = await db.orders.find_one({"id": payment_data.order_id})
    
    if not customer or not order:
        raise HTTPException(status_code=404, detail="Customer or Order not found")
    
    # Generate receipt number
    receipt_number = f"PAY{datetime.now().strftime('%Y%m%d')}{str(uuid.uuid4())[:6].upper()}"
    
    payment_dict = payment_data.dict()
    payment_dict['customer_name'] = customer['name']
    payment_dict['receipt_number'] = receipt_number
    
    payment_obj = Payment(**payment_dict)
    payment_doc = prepare_for_mongo(payment_obj.dict())
    await db.payments.insert_one(payment_doc)
    
    # Update order payment status
    await db.orders.update_one(
        {"id": payment_data.order_id},
        {"$set": {"payment_status": "paid"}}
    )
    
    return payment_obj

@api_router.get("/payments", response_model=List[Payment])
async def get_payments(current_user: User = Depends(get_current_user)):
    payments = await db.payments.find().sort("created_at", -1).to_list(1000)
    return [Payment(**payment) for payment in payments]

@api_router.get("/payments/customer/{customer_id}", response_model=List[Payment])
async def get_customer_payments(customer_id: str, current_user: User = Depends(get_current_user)):
    payments = await db.payments.find({"customer_id": customer_id}).sort("created_at", -1).to_list(1000)
    return [Payment(**payment) for payment in payments]

# Expense routes
@api_router.post("/expenses", response_model=Expense)
async def create_expense(expense_data: ExpenseCreate, current_user: User = Depends(get_current_user)):
    expense_dict = expense_data.dict()
    expense_dict['created_by'] = current_user.id
    
    expense_obj = Expense(**expense_dict)
    expense_doc = prepare_for_mongo(expense_obj.dict())
    await db.expenses.insert_one(expense_doc)
    
    return expense_obj

@api_router.get("/expenses", response_model=List[Expense])
async def get_expenses(current_user: User = Depends(get_current_user)):
    expenses = await db.expenses.find().sort("created_at", -1).to_list(1000)
    return [Expense(**expense) for expense in expenses]

@api_router.put("/expenses/{expense_id}", response_model=Expense)
async def update_expense(expense_id: str, update_data: ExpenseUpdate, current_user: User = Depends(get_current_user)):
    update_dict = {k: v for k, v in update_data.dict().items() if v is not None}
    update_dict['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    result = await db.expenses.update_one(
        {"id": expense_id},
        {"$set": update_dict}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Expense not found")
    
    updated_expense = await db.expenses.find_one({"id": expense_id})
    return Expense(**updated_expense)

@api_router.delete("/expenses/{expense_id}")
async def delete_expense(expense_id: str, current_user: User = Depends(get_current_user)):
    result = await db.expenses.delete_one({"id": expense_id})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Expense not found")
    
    return {"message": "Expense deleted successfully"}

# Invoice routes
@api_router.post("/invoices", response_model=Invoice)
async def create_invoice(invoice_data: InvoiceCreate, current_user: User = Depends(get_current_user)):
    # Get customer and order info
    customer = await db.customers.find_one({"id": invoice_data.customer_id})
    order = await db.orders.find_one({"id": invoice_data.order_id})
    
    if not customer or not order:
        raise HTTPException(status_code=404, detail="Customer or Order not found")
    
    # Generate invoice number
    invoice_count = await db.invoices.count_documents({}) + 1
    invoice_number = f"WK{datetime.now().strftime('%Y%m')}{invoice_count:04d}"
    
    # Calculate amounts
    tax_amount = invoice_data.subtotal * (invoice_data.tax_rate / 100)
    total_amount = invoice_data.subtotal + tax_amount - invoice_data.discount_amount
    
    # Set due date
    due_date = datetime.now(timezone.utc) + timedelta(days=invoice_data.due_days)
    
    invoice_dict = invoice_data.dict()
    invoice_dict.update({
        'invoice_number': invoice_number,
        'customer_name': customer['name'],
        'customer_address': customer['address'],
        'customer_mobile': customer['mobile'],
        'tax_amount': tax_amount,
        'total_amount': total_amount,
        'due_date': due_date,
        'created_by': current_user.id
    })
    
    invoice_obj = Invoice(**invoice_dict)
    invoice_doc = prepare_for_mongo(invoice_obj.dict())
    await db.invoices.insert_one(invoice_doc)
    
    return invoice_obj

@api_router.get("/invoices", response_model=List[Invoice])
async def get_invoices(current_user: User = Depends(get_current_user)):
    invoices = await db.invoices.find().sort("created_at", -1).to_list(1000)
    # Clean and prepare invoices for response
    cleaned_invoices = []
    for invoice in invoices:
        try:
            # Ensure all required fields have default values
            if 'customer_address' not in invoice:
                invoice['customer_address'] = None
            if 'customer_mobile' not in invoice:
                invoice['customer_mobile'] = None
            if 'order_id' not in invoice:
                invoice['order_id'] = None
            if 'invoice_type' not in invoice:
                invoice['invoice_type'] = 'regular'
            if 'event_order_id' not in invoice:
                invoice['event_order_id'] = None
            if 'issue_month' not in invoice:
                invoice['issue_month'] = None
            if 'issue_year' not in invoice:
                invoice['issue_year'] = None
            
            # Handle amount_paid for event order invoices
            if 'amount_paid' not in invoice and invoice.get('event_order_id'):
                # Fetch event order to get payment data
                event_order = await db.event_orders.find_one({"id": invoice['event_order_id']})
                if event_order:
                    advance_amount = event_order.get("advance_amount", 0)
                    last_payment_amount = event_order.get("last_payment_amount", 0)
                    invoice['amount_paid'] = advance_amount + last_payment_amount
                else:
                    invoice['amount_paid'] = 0
            elif 'amount_paid' not in invoice:
                invoice['amount_paid'] = 0
            
            cleaned_invoices.append(Invoice(**invoice))
        except Exception as e:
            print(f"Error processing invoice {invoice.get('id', 'unknown')}: {str(e)}")
            continue
    
    return cleaned_invoices

@api_router.get("/invoices/{invoice_id}", response_model=Invoice)
async def get_invoice(invoice_id: str, current_user: User = Depends(get_current_user)):
    invoice = await db.invoices.find_one({"id": invoice_id})
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    
    # Ensure all required fields have default values
    if 'customer_address' not in invoice:
        invoice['customer_address'] = None
    if 'customer_mobile' not in invoice:
        invoice['customer_mobile'] = None
    if 'order_id' not in invoice:
        invoice['order_id'] = None
    if 'invoice_type' not in invoice:
        invoice['invoice_type'] = 'regular'
    if 'event_order_id' not in invoice:
        invoice['event_order_id'] = None
    if 'issue_month' not in invoice:
        invoice['issue_month'] = None
    if 'issue_year' not in invoice:
        invoice['issue_year'] = None
    
    # Handle amount_paid for event order invoices
    if 'amount_paid' not in invoice and invoice.get('event_order_id'):
        # Fetch event order to get payment data
        event_order = await db.event_orders.find_one({"id": invoice['event_order_id']})
        if event_order:
            advance_amount = event_order.get("advance_amount", 0)
            last_payment_amount = event_order.get("last_payment_amount", 0)
            invoice['amount_paid'] = advance_amount + last_payment_amount
        else:
            invoice['amount_paid'] = 0
    elif 'amount_paid' not in invoice:
        invoice['amount_paid'] = 0
    
    return Invoice(**invoice)

@api_router.get("/invoices/{invoice_id}/download")
async def download_invoice_pdf(invoice_id: str, current_user: User = Depends(get_current_user)):
    """Download invoice as PDF with common header"""
    try:
        # Get invoice data
        invoice = await db.invoices.find_one({"id": invoice_id})
        if not invoice:
            raise HTTPException(status_code=404, detail="Invoice not found")
        
        # Handle amount_paid for event order invoices
        if 'amount_paid' not in invoice and invoice.get('event_order_id'):
            # Fetch event order to get payment data
            event_order = await db.event_orders.find_one({"id": invoice['event_order_id']})
            if event_order:
                advance_amount = event_order.get("advance_amount", 0)
                last_payment_amount = event_order.get("last_payment_amount", 0)
                invoice['amount_paid'] = advance_amount + last_payment_amount
            else:
                invoice['amount_paid'] = 0
        elif 'amount_paid' not in invoice:
            invoice['amount_paid'] = 0
        
        # Create PDF with common header
        buffer = io.BytesIO()
        # Create PDF with proper header space
        from reportlab.platypus import PageTemplate, Frame, BaseDocTemplate
        from reportlab.lib.pagesizes import A4
        import os
        
        # Get contact details for footer
        contact_details = await get_contact_details_for_pdf()
        
        def draw_header(canvas, doc):
            draw_pdf_header_and_footer(canvas, doc, contact_details)
        
        # Create document with custom template
        doc = BaseDocTemplate(buffer, pagesize=A4, rightMargin=20, leftMargin=20, topMargin=100, bottomMargin=30)
        
        # Create frame for content (starts below header)
        content_frame = Frame(20, 30, A4[0] - 40, A4[1] - 130, id='content')
        
        # Add page template with common header
        template = PageTemplate('header_template', [content_frame], onPage=draw_header)
        doc.addPageTemplates([template])
        
        elements = []
        styles = getSampleStyleSheet()
        
        # Invoice title (center aligned)
        invoice_title = f"""
        <para align=center>
        <b><font size=18>INVOICE</font></b>
        </para>
        """
        
        title_style = ParagraphStyle('InvoiceTitle',
            parent=styles['Normal'],
            alignment=1,
            spaceAfter=15,
            spaceBefore=20,
            textColor=colors.black)
        
        elements.append(Paragraph(invoice_title, title_style))
        
        # Invoice details
        invoice_details = f"""
        <para>
        <b>Invoice Number:</b> {invoice.get('invoice_number', 'N/A')}<br/>
        <b>Issue Date:</b> {invoice.get('issue_date', 'N/A')[:10] if invoice.get('issue_date') else 'N/A'}<br/>
        <b>Due Date:</b> {invoice.get('due_date', 'N/A')[:10] if invoice.get('due_date') else 'N/A'}<br/>
        <b>Status:</b> {invoice.get('status', 'draft').title()}<br/>
        <b>Payment Terms:</b> {invoice.get('payment_terms', 'Net 30')}
        </para>
        """
        
        details_style = ParagraphStyle('InvoiceDetails',
            parent=styles['Normal'],
            fontSize=11,
            spaceAfter=20,
            leftIndent=0,
            textColor=colors.black)
        
        elements.append(Paragraph(invoice_details, details_style))
        
        # Customer information
        customer_info = f"""
        <para>
        <b>Bill To:</b><br/>
        <b>{invoice.get('customer_name', 'N/A')}</b><br/>
        {invoice.get('customer_address', 'Address not provided')}<br/>
        {f"Mobile: {invoice.get('customer_mobile')}" if invoice.get('customer_mobile') else 'Mobile not provided'}
        </para>
        """
        
        elements.append(Paragraph(customer_info, details_style))
        elements.append(Spacer(1, 20))
        
        # Invoice items table
        items_data = [
            ["Item Description", "Qty", "Rate", "Amount"]
        ]
        
        # Add invoice items
        if invoice.get('items'):
            for item in invoice['items']:
                items_data.append([
                    item.get('description', ''),
                    str(item.get('quantity', 0)),
                    f"₹{item.get('rate', 0):.2f}",
                    f"₹{item.get('amount', 0):.2f}"
                ])
        
        # Add totals
        items_data.append(['', '', 'Subtotal:', f"₹{invoice.get('subtotal', 0):.2f}"])
        if invoice.get('tax_amount', 0) > 0:
            items_data.append(['', '', f"Tax ({invoice.get('tax_rate', 0)}%):", f"₹{invoice.get('tax_amount', 0):.2f}"])
        if invoice.get('discount_amount', 0) > 0:
            items_data.append(['', '', 'Discount:', f"-₹{invoice.get('discount_amount', 0):.2f}"])
        items_data.append(['', '', 'Total Amount:', f"₹{invoice.get('total_amount', 0):.2f}"])
        
        items_table = Table(items_data, colWidths=[3.5*inch, 1*inch, 1.5*inch, 1.5*inch])
        items_table.setStyle(TableStyle([
            # Header styling
            ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('TOPPADDING', (0, 0), (-1, 0), 12),
            
            # Data rows
            ('FONTNAME', (0, 1), (-1, -4), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -4), 9),
            ('TOPPADDING', (0, 1), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
            
            # Total rows
            ('FONTNAME', (0, -3), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, -1), (-1, -1), 11),
            ('BACKGROUND', (0, -1), (-1, -1), colors.lightblue),
            
            # Borders
            ('BOX', (0, 0), (-1, -1), 1, colors.black),
            ('LINEBELOW', (0, 0), (-1, 0), 2, colors.black),
            ('LINEABOVE', (0, -3), (-1, -3), 1, colors.black),
            ('LINEABOVE', (0, -1), (-1, -1), 2, colors.black),
        ]))
        
        elements.append(items_table)
        elements.append(Spacer(1, 30))
        
        # Payment status and terms
        payment_status = f"""
        <para align=center>
        <b>Payment Status: {invoice.get('status', 'draft').upper()}</b><br/>
        {invoice.get('notes', 'Thank you for your business!')}
        </para>
        """
        
        elements.append(Paragraph(payment_status, details_style))
        elements.append(Spacer(1, 20))
        
        # Signature section
        signature_data = [
            [
                "Terms & Conditions:\n• Payment due within terms specified\n• Late payments may incur charges\n• Goods once sold will not be taken back",
                "Authorized Signature:\n\n________________________________\n\nAquaElite Management Team\n\nDate: " + datetime.now(timezone.utc).strftime('%d %B %Y')
            ]
        ]
        
        signature_table = Table(signature_data, colWidths=[4*inch, 3.5*inch])
        signature_table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, 0), 'Helvetica'),
            ('FONTSIZE', (0, 0), (0, 0), 9),
            ('ALIGN', (0, 0), (0, 0), 'LEFT'),
            ('VALIGN', (0, 0), (0, 0), 'TOP'),
            
            ('FONTNAME', (1, 0), (1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (1, 0), (1, 0), 10),
            ('ALIGN', (1, 0), (1, 0), 'RIGHT'),
            ('VALIGN', (1, 0), (1, 0), 'TOP'),
            
            ('TOPPADDING', (0, 0), (-1, -1), 15),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
        ]))
        
        elements.append(signature_table)
        
        # Build PDF
        doc.build(elements)
        buffer.seek(0)
        
        # Return PDF file
        filename = f"invoice_{invoice.get('invoice_number', invoice_id)}.pdf"
        
        return StreamingResponse(
            io.BytesIO(buffer.read()),
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
        
    except Exception as e:
        print(f"Error generating invoice PDF: {e}")
        raise HTTPException(status_code=500, detail=f"Error generating PDF: {str(e)}")

@api_router.put("/invoices/{invoice_id}", response_model=Invoice)
async def update_invoice(invoice_id: str, update_data: InvoiceUpdate, current_user: User = Depends(get_current_user)):
    update_dict = {k: v for k, v in update_data.dict().items() if v is not None}
    update_dict['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    # Recalculate amounts if tax_rate or discount changed
    if 'tax_rate' in update_dict or 'discount_amount' in update_dict:
        invoice = await db.invoices.find_one({"id": invoice_id})
        if invoice:
            subtotal = invoice['subtotal']
            tax_rate = update_dict.get('tax_rate', invoice['tax_rate'])
            discount_amount = update_dict.get('discount_amount', invoice['discount_amount'])
            
            tax_amount = subtotal * (tax_rate / 100)
            total_amount = subtotal + tax_amount - discount_amount
            
            update_dict['tax_amount'] = tax_amount
            update_dict['total_amount'] = total_amount
    
    result = await db.invoices.update_one(
        {"id": invoice_id},
        {"$set": update_dict}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Invoice not found")
    
    updated_invoice = await db.invoices.find_one({"id": invoice_id})
    return Invoice(**updated_invoice)

@api_router.delete("/invoices/{invoice_id}")
async def delete_invoice(invoice_id: str, current_user: User = Depends(get_current_user)):
    result = await db.invoices.delete_one({"id": invoice_id})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Invoice not found")
    
    return {"message": "Invoice deleted successfully"}

@api_router.get("/invoices/customer/{customer_id}", response_model=List[Invoice])
async def get_customer_invoices(customer_id: str, current_user: User = Depends(get_current_user)):
    invoices = await db.invoices.find({"customer_id": customer_id}).sort("created_at", -1).to_list(1000)
    return [Invoice(**invoice) for invoice in invoices]

@api_router.post("/invoices/{invoice_id}/send")
async def send_invoice(invoice_id: str, current_user: User = Depends(get_current_user)):
    # Update invoice status to sent
    result = await db.invoices.update_one(
        {"id": invoice_id},
        {"$set": {"status": "sent", "updated_at": datetime.now(timezone.utc).isoformat()}}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Invoice not found")
    
    return {"message": "Invoice sent successfully"}

# Event Order Invoice API
@api_router.post("/invoices/event-order/{event_order_id}")
async def create_event_order_invoice(event_order_id: str, current_user: User = Depends(get_current_user)):
    """Create invoice for event order"""
    try:
        # Get event order details
        event_order = await db.event_orders.find_one({"id": event_order_id})
        if not event_order:
            raise HTTPException(status_code=404, detail="Event order not found")
        
        # Check if invoice already exists for this event order
        existing_invoice = await db.invoices.find_one({"event_order_id": event_order_id})
        if existing_invoice:
            raise HTTPException(status_code=400, detail="Invoice already exists for this event order")
        
        # Get customer details
        customer = await db.customers.find_one({"id": event_order["customer_id"]})
        if not customer:
            raise HTTPException(status_code=404, detail="Customer not found")
        
        # Create invoice items from event order
        items = []
        total_amount = event_order.get("total_amount", 0)
        
        # Enhanced jar calculation - try multiple sources
        jars_delivered = None
        
        # First try direct jar fields
        if event_order.get("jars_delivered") and event_order.get("jars_delivered") > 0:
            jars_delivered = event_order.get("jars_delivered")
        elif event_order.get("total_jars_delivered") and event_order.get("total_jars_delivered") > 0:
            jars_delivered = event_order.get("total_jars_delivered")
        elif event_order.get("water_jars") and event_order.get("water_jars") > 0:
            jars_delivered = event_order.get("water_jars")
        else:
            # Calculate from products if jar fields not available
            products = event_order.get("products", [])
            total_jars = 0
            for product in products:
                if isinstance(product, dict):
                    quantity = product.get("quantity", 0)
                    if quantity > 0:
                        total_jars += quantity
            jars_delivered = total_jars if total_jars > 0 else 1
        
        rate_per_jar = total_amount / max(1, jars_delivered)
        
        # Main water supply item with detailed jar information
        items.append({
            "description": f"Water Supply Service - {event_order.get('event_name', 'Event Order')}",
            "quantity": jars_delivered,
            "unit_price": rate_per_jar,
            "amount": total_amount
        })
        
        # Add detailed jar breakdown
        items.append({
            "description": f"  • Total Jars Delivered: {jars_delivered} jars @ ₹{rate_per_jar:.2f} per jar",
            "quantity": 0,
            "unit_price": 0,
            "amount": 0
        })
        
        # Add event date and time if available
        if event_order.get("event_date"):
            event_datetime_str = f"Event Date: {event_order['event_date']}"
            if event_order.get("event_time"):
                event_datetime_str += f" at {event_order['event_time']}"
            items.append({
                "description": f"  • {event_datetime_str}",
                "quantity": 0,
                "unit_price": 0,
                "amount": 0
            })
        
        # Add venue information
        if event_order.get("venue_address"):
            items.append({
                "description": f"  • Venue: {event_order['venue_address']}",
                "quantity": 0,
                "unit_price": 0,
                "amount": 0
            })
        
        # Note: Guest count and empty jars collected are excluded from invoice items as requested
        
        # Calculate amount_paid from event order payment data
        advance_amount = event_order.get("advance_amount", 0)
        last_payment_amount = event_order.get("last_payment_amount", 0)
        total_paid = advance_amount + last_payment_amount
        
        # Create invoice
        invoice_id = str(uuid.uuid4())
        invoice_number = f"INV-EVT-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        invoice = {
            "id": invoice_id,
            "invoice_number": invoice_number,
            "event_order_id": event_order_id,
            "order_id": None,  # Not applicable for event orders
            "customer_id": event_order["customer_id"],
            "customer_name": event_order["customer_name"],
            "customer_address": customer.get("address", event_order.get("venue_address", "Address not provided")),
            "customer_mobile": customer.get("mobile", customer.get("phone", "Mobile not provided")),
            "invoice_type": "event_order",
            "items": items,
            "subtotal": total_amount,
            "tax_rate": 0,  # Events usually don't have separate tax
            "tax_amount": 0,
            "discount_amount": 0,  # Add default discount amount
            "total_amount": total_amount,
            "amount_paid": total_paid,  # Include amount paid from event order payments
            "payment_terms": "7 days",  # Add default payment terms
            "status": "draft",
            "issue_date": datetime.now(timezone.utc).isoformat(),
            "due_date": (datetime.now(timezone.utc) + timedelta(days=7)).isoformat(),
            "notes": f"Invoice for event: {event_order.get('event_name', 'Event')} on {event_order.get('event_date', 'TBD')}",
            "created_by": current_user.id,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        
        await db.invoices.insert_one(invoice)
        return clean_mongo_doc(invoice)
        
    except Exception as e:
        print(f"Error creating event order invoice: {str(e)}")
        raise HTTPException(status_code=422, detail=f"Failed to create event order invoice: {str(e)}")

# Monthly Due Customers Invoice API
@api_router.post("/invoices/monthly-due")
async def create_monthly_due_invoices(invoice_data: dict, current_user: User = Depends(get_current_user)):
    """Create invoices for customers with monthly due amounts"""
    try:
        month = invoice_data.get("month", datetime.now().month)
        year = invoice_data.get("year", datetime.now().year)
        minimum_due = float(invoice_data.get("minimum_due", 100))  # Minimum due amount to create invoice
        
        # Get customers with cash balance due
        customers = await db.customers.find({
            "cash_balance": {"$gte": minimum_due},
            "is_active": True
        }).to_list(1000)
        
        created_invoices = []
        
        for customer in customers:
            try:
                # Check if invoice already exists for this customer for this month
                existing_invoice = await db.invoices.find_one({
                    "customer_id": customer["id"],
                    "invoice_type": "monthly_due",
                    "issue_month": month,
                    "issue_year": year
                })
                
                if existing_invoice:
                    continue  # Skip if invoice already exists
                
                # Get customer's transaction history for the month
                start_date = datetime(year, month, 1)
                if month == 12:
                    end_date = datetime(year + 1, 1, 1) - timedelta(days=1)
                else:
                    end_date = datetime(year, month + 1, 1) - timedelta(days=1)
                
                # Get deliveries for this month
                deliveries = await db.deliveries.find({
                    "customer_id": customer["id"],
                    "delivered_at": {
                        "$gte": start_date.isoformat(),
                        "$lte": end_date.isoformat()
                    }
                }).to_list(1000)
                
                # Create invoice items
                items = []
                total_jars_delivered = 0
                total_delivery_amount = 0
                
                # Group deliveries by date
                delivery_summary = {}
                for delivery in deliveries:
                    delivery_date = delivery.get("delivered_at", "")[:10]  # Get date part
                    jars = delivery.get("jars_delivered", 0)
                    
                    if delivery_date not in delivery_summary:
                        delivery_summary[delivery_date] = {"jars": 0, "count": 0}
                    
                    delivery_summary[delivery_date]["jars"] += jars
                    delivery_summary[delivery_date]["count"] += 1
                    total_jars_delivered += jars
                
                # Add delivery items to invoice
                if total_jars_delivered > 0:
                    # Estimate price per jar (you may want to get this from a products table)
                    price_per_jar = 25.0  # Default price, adjust as needed
                    total_delivery_amount = total_jars_delivered * price_per_jar
                    
                    items.append({
                        "description": f"Water Delivery - {calendar.month_name[month]} {year}",
                        "quantity": total_jars_delivered,
                        "unit_price": price_per_jar,
                        "amount": total_delivery_amount
                    })
                    
                    # Add delivery summary
                    for date, summary in delivery_summary.items():
                        items.append({
                            "description": f"  • {date}: {summary['jars']} jars ({summary['count']} deliveries)",
                            "quantity": 0,
                            "unit_price": 0,
                            "amount": 0
                        })
                
                # Add outstanding balance
                outstanding_balance = customer.get("cash_balance", 0)
                if outstanding_balance > 0:
                    items.append({
                        "description": "Outstanding Balance (Previous dues)",
                        "quantity": 1,
                        "unit_price": outstanding_balance,
                        "amount": outstanding_balance
                    })
                
                total_invoice_amount = total_delivery_amount + outstanding_balance
                
                # Create invoice
                invoice_id = str(uuid.uuid4())
                invoice_number = f"INV-DUE-{year}{month:02d}-{customer['id'][:8]}"
                
                invoice = {
                    "id": invoice_id,
                    "invoice_number": invoice_number,
                    "order_id": None,  # Not applicable for monthly due invoices
                    "customer_id": customer["id"],
                    "customer_name": customer["name"],
                    "customer_address": customer.get("address", "Address not provided"),
                    "customer_mobile": customer.get("mobile", customer.get("phone", "Mobile not provided")),
                    "invoice_type": "monthly_due",
                    "issue_month": month,
                    "issue_year": year,
                    "items": items,
                    "subtotal": total_invoice_amount,
                    "tax_rate": 0,
                    "tax_amount": 0,
                    "discount_amount": 0,  # Add default discount amount
                    "total_amount": total_invoice_amount,
                    "payment_terms": "15 days",  # Add default payment terms
                    "status": "draft",
                    "issue_date": datetime.now(timezone.utc).isoformat(),
                    "due_date": (datetime.now(timezone.utc) + timedelta(days=15)).isoformat(),
                    "notes": f"Monthly invoice for {calendar.month_name[month]} {year}. Total deliveries: {total_jars_delivered} jars.",
                    "created_by": current_user.id,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                    "updated_at": datetime.now(timezone.utc).isoformat()
                }
                
                await db.invoices.insert_one(invoice)
                created_invoices.append(clean_mongo_doc(invoice))
                
            except Exception as customer_error:
                print(f"Error creating invoice for customer {customer.get('name', 'Unknown')}: {str(customer_error)}")
                continue
        
        return {
            "message": f"Created {len(created_invoices)} monthly due invoices",
            "invoices_created": len(created_invoices),
            "invoices": created_invoices[:5]  # Return first 5 for preview
        }
        
    except Exception as e:
        print(f"Error creating monthly due invoices: {str(e)}")
        raise HTTPException(status_code=422, detail=f"Failed to create monthly due invoices: {str(e)}")

# Get Event Orders for Invoice Creation
@api_router.get("/event-orders/invoice-eligible")
async def get_event_orders_for_invoicing(current_user: User = Depends(get_current_user)):
    """Get event orders that are eligible for invoice creation"""
    try:
        # Get completed event orders that don't have invoices yet
        event_orders = await db.event_orders.find({
            "event_status": {"$in": ["completed", "in_progress"]},
        }).sort("created_at", -1).to_list(1000)
        
        # Filter out events that already have invoices
        eligible_events = []
        for event in event_orders:
            existing_invoice = await db.invoices.find_one({"event_order_id": event["id"]})
            if not existing_invoice:
                eligible_events.append(clean_mongo_doc(event))
        
        return eligible_events
        
    except Exception as e:
        print(f"Error getting invoice-eligible event orders: {str(e)}")
        raise HTTPException(status_code=422, detail=f"Failed to get event orders: {str(e)}")

# Get Event Orders that can be edited (incomplete and confirmed)
@api_router.get("/event-orders/editable")
async def get_editable_event_orders(current_user: User = Depends(get_current_user)):
    # Find event orders that can be edited (incomplete and confirmed status)
    editable_events = await db.event_orders.find({
        "event_status": {"$in": ["incomplete", "confirmed"]}
    }).sort("event_date", -1).to_list(100)
    
    return [EventOrder(**event) for event in editable_events]

# Get Event Orders by status for management
@api_router.get("/event-orders/by-status/{status}")
async def get_event_orders_by_status(status: str, current_user: User = Depends(get_current_user)):
    # Validate status
    valid_statuses = ["incomplete", "confirmed", "completed", "cancelled"]
    if status not in valid_statuses:
        raise HTTPException(status_code=400, detail=f"Invalid status. Valid options: {valid_statuses}")
    
    events = await db.event_orders.find({
        "event_status": status
    }).sort("event_date", -1).to_list(100)
    
    return [EventOrder(**event) for event in events]

# Event Order routes
@api_router.post("/event-orders", response_model=EventOrder)
async def create_event_order(event_data: EventOrderCreate, current_user: User = Depends(get_current_user)):
    # Get customer info
    customer = await db.customers.find_one({"id": event_data.customer_id})
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    
    # Check if customer has any regular orders
    has_regular_orders = await db.orders.count_documents({"customer_id": event_data.customer_id}) > 0
    
    # Update customer type based on whether they have regular orders
    if has_regular_orders:
        # Customer has both event and regular orders
        await db.customers.update_one(
            {"id": event_data.customer_id},
            {"$set": {"customer_type": "both"}}
        )
    else:
        # Customer only has event orders (no regular orders)
        await db.customers.update_one(
            {"id": event_data.customer_id},
            {"$set": {"customer_type": "event"}}
        )
    
    event_dict = event_data.dict()
    
    # Calculate total delivery quantity from water products
    total_delivery_qty = 0
    products = event_data.products
    
    for product in products:
        # Check if product is water-related (contains 'water' or 'jar' in name)
        product_name = product.get('name', '').lower()
        if 'water' in product_name or 'jar' in product_name or '20l' in product_name or '10l' in product_name:
            quantity = product.get('quantity', 0)
            total_delivery_qty += quantity
    
    event_dict.update({
        'customer_name': customer['name'],
        'customer_mobile': customer['mobile'],
        'balance_amount': event_data.total_amount - event_data.advance_amount,
        'created_by': current_user.id,
        'total_jars_required': total_delivery_qty,
        'jars_to_deliver': total_delivery_qty,
        'expected_jars': total_delivery_qty,
        'jars_delivered': 0,  # Initially no jars delivered
        'empty_jars_collected': 0  # Initially no empty jars collected
    })
    
    event_obj = EventOrder(**event_dict)
    event_doc = prepare_for_mongo(event_obj.dict())
    await db.event_orders.insert_one(event_doc)
    
    return event_obj

@api_router.get("/event-orders", response_model=List[EventOrder])
async def get_event_orders(current_user: User = Depends(get_current_user)):
    events = await db.event_orders.find().sort("event_date", 1).to_list(1000)
    return [EventOrder(**event) for event in events]

@api_router.get("/event-orders/{event_id}", response_model=EventOrder)
async def get_event_order(event_id: str, current_user: User = Depends(get_current_user)):
    event = await db.event_orders.find_one({"id": event_id})
    if not event:
        raise HTTPException(status_code=404, detail="Event order not found")
    return EventOrder(**event)

@api_router.put("/event-orders/{event_id}", response_model=EventOrder)
async def update_event_order(event_id: str, update_data: EventOrderUpdate, current_user: User = Depends(get_current_user)):
    # First check if event exists and get its current status
    existing_event = await db.event_orders.find_one({"id": event_id})
    if not existing_event:
        raise HTTPException(status_code=404, detail="Event order not found")
    
    current_status = existing_event.get('event_status', 'incomplete')
    
    # Define editable statuses - allow editing for incomplete and confirmed events
    editable_statuses = ['incomplete', 'confirmed']
    
    # Check if current status allows editing
    if current_status not in editable_statuses:
        # Allow specific operations for in_progress and completed events
        update_fields = set(update_data.dict(exclude_none=True).keys())
        
        # Fields allowed for in_progress and completed events (delivery operations + cancellation)
        allowed_for_operations = {
            'jars_delivered', 'delivery_completed_at', 'jars_to_deliver',
            'delivered_at', 'delivered_by', 'delivered_by_name', 'delivery_notes',
            'advance_amount', 'payment_status', 'last_payment_amount', 
            'last_payment_date', 'last_payment_mode', 'payment_collected_by',
            'empty_jars_collected', 'collection_completed_at', 'event_status',
            'updated_at', 'balance_amount', 'missing_empty_jars',
            'cancelled_at', 'cancelled_by', 'cancelled_by_name', 'cancellation_reason',
            'advance_forfeited', 'refund_amount'
        }
        
        if current_status in ['in_progress', 'completed']:
            # Allow delivery operations, payment collection, and empty jar collection
            if update_fields.issubset(allowed_for_operations):
                pass  # Allow these specific updates
            else:
                unauthorized_fields = update_fields - allowed_for_operations
                raise HTTPException(
                    status_code=403, 
                    detail=f"Cannot edit fields {unauthorized_fields} for {current_status} event order. Only delivery operations allowed."
                )
        elif current_status == 'cancelled':
            raise HTTPException(
                status_code=403, 
                detail="Cannot edit cancelled event order"
            )
        else:
            raise HTTPException(
                status_code=403, 
                detail=f"Cannot edit event order with status: {current_status}"
            )
    
    update_dict = {k: v for k, v in update_data.dict().items() if v is not None}
    update_dict['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    # CRITICAL FIX: Always update delivery_completed_at when jars_delivered is being updated
    # This ensures dashboard stats reflect the LATEST delivery timestamp
    if 'jars_delivered' in update_dict:
        # Use provided delivery_completed_at or set to now if not provided
        if 'delivery_completed_at' not in update_dict:
            update_dict['delivery_completed_at'] = datetime.now(timezone.utc).isoformat()
    
    # If event status is changing to completed and delivery_completed_at is not set, set it to now
    if update_dict.get('event_status') == 'completed' and 'delivery_completed_at' not in update_dict and not existing_event.get('delivery_completed_at'):
        update_dict['delivery_completed_at'] = datetime.now(timezone.utc).isoformat()
    
    # Recalculate delivery quantity if products changed
    if 'products' in update_dict:
        # Calculate total delivery quantity from water products
        total_delivery_qty = 0
        products = update_dict['products']
        
        for product in products:
            # Check if product is water-related (contains 'water' or 'jar' in name)
            product_name = product.get('name', '').lower()
            if 'water' in product_name or 'jar' in product_name or '20l' in product_name or '10l' in product_name:
                quantity = product.get('quantity', 0)
                total_delivery_qty += quantity
        
        # Update delivery quantity fields
        update_dict['total_jars_required'] = total_delivery_qty
        update_dict['jars_to_deliver'] = total_delivery_qty
        
        # If no jars delivered yet, update the expected delivery count
        if not existing_event.get('jars_delivered'):
            update_dict['expected_jars'] = total_delivery_qty
    
    # Recalculate balance if amounts changed
    if 'total_amount' in update_dict or 'advance_amount' in update_dict:
        total = update_dict.get('total_amount', existing_event['total_amount'])
        advance = update_dict.get('advance_amount', existing_event['advance_amount'])
        update_dict['balance_amount'] = total - advance
    
    result = await db.event_orders.update_one(
        {"id": event_id},
        {"$set": update_dict}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Event order not found")
    
    updated_event = await db.event_orders.find_one({"id": event_id})
    return EventOrder(**updated_event)

@api_router.delete("/event-orders/{event_id}")
async def delete_event_order(event_id: str, current_user: User = Depends(get_current_user)):
    # Check if event exists and get its current status
    existing_event = await db.event_orders.find_one({"id": event_id})
    if not existing_event:
        raise HTTPException(status_code=404, detail="Event order not found")
    
    # Prevent deletion of completed or cancelled events
    if existing_event.get('event_status') in ['completed', 'cancelled']:
        raise HTTPException(
            status_code=403, 
            detail=f"Cannot delete {existing_event.get('event_status')} event order"
        )
    
    result = await db.event_orders.delete_one({"id": event_id})
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Event order not found")
    
    return {"message": "Event order deleted successfully"}

@api_router.get("/event-orders/customer/{customer_id}", response_model=List[EventOrder])
async def get_customer_event_orders(customer_id: str, current_user: User = Depends(get_current_user)):
    events = await db.event_orders.find({"customer_id": customer_id}).sort("event_date", 1).to_list(1000)
    return [EventOrder(**event) for event in events]

@api_router.post("/event-orders/{event_id}/complete")
async def complete_event_order(event_id: str, current_user: User = Depends(get_current_user)):
    now = datetime.now(timezone.utc)
    result = await db.event_orders.update_one(
        {"id": event_id},
        {"$set": {
            "event_status": "completed",
            "delivery_completed_at": now.isoformat(),
            "updated_at": now.isoformat()
        }}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Event order not found")
    
    return {"message": "Event marked as completed"}

# Delivery Boy Payment Tracking
@api_router.post("/delivery-boy-payments", response_model=DeliveryBoyPayment)
async def record_delivery_boy_payment(payment_data: dict, current_user: User = Depends(get_current_user)):
    # Record payment collection by delivery boy
    payment_record = DeliveryBoyPayment(
        delivery_boy_id=payment_data["delivery_boy_id"],
        delivery_boy_name=payment_data["delivery_boy_name"],
        event_id=payment_data.get("event_id"),
        order_id=payment_data.get("order_id"),
        customer_id=payment_data["customer_id"],
        customer_name=payment_data["customer_name"],
        amount_collected=payment_data["amount_collected"],
        payment_mode=payment_data.get("payment_mode", "cash"),
        payment_type=payment_data.get("payment_type", "event_delivery"),
        notes=payment_data.get("notes", "")
    )
    
    # Insert payment record
    payment_dict = payment_record.dict()
    payment_dict["collection_date"] = payment_dict["collection_date"].isoformat()
    payment_dict["created_at"] = payment_dict["created_at"].isoformat()
    
    await db.delivery_boy_payments.insert_one(payment_dict)
    
    return payment_record

@api_router.get("/delivery-boy-payments/{delivery_boy_id}")
async def get_delivery_boy_payments(delivery_boy_id: str, current_user: User = Depends(get_current_user)):
    # Get all payments collected by a delivery boy
    payments = await db.delivery_boy_payments.find({"delivery_boy_id": delivery_boy_id}).sort("created_at", -1).to_list(1000)
    return payments

@api_router.get("/delivery-boy-payments")
async def get_all_delivery_boy_payments(current_user: User = Depends(get_current_user)):
    # Get all delivery boy payment collections
    if not has_permission(current_user, UserPermissions.ADMIN_ALL):
        raise HTTPException(status_code=403, detail="Access denied. Admin privileges required.")
    
    payments = await db.delivery_boy_payments.find({}).sort("created_at", -1).to_list(1000)
    return payments

# Dashboard routes
@api_router.get("/reports/event-orders")
async def get_event_order_reports(
    start_date: str = None,
    end_date: str = None, 
    status: str = None,
    current_user: User = Depends(get_current_user)
):
    """Get event order reports for specified date range and status"""
    try:
        # Parse dates
        if start_date:
            start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00')).replace(hour=0, minute=0, second=0, microsecond=0)
        else:
            start_dt = datetime.now(timezone.utc).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        
        if end_date:
            end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00')).replace(hour=23, minute=59, second=59, microsecond=999999)
        else:
            end_dt = datetime.now(timezone.utc).replace(hour=23, minute=59, second=59, microsecond=999999)
        
        # Build query
        query = {
            "created_at": {
                "$gte": start_dt.isoformat(),
                "$lte": end_dt.isoformat()
            }
        }
        
        # Add status filter if provided
        if status and status != 'all':
            query["event_status"] = status
        elif not status:
            # Default to cancelled and completed events
            query["event_status"] = {"$in": ["cancelled", "completed"]}
        
        # Get event orders
        events = await db.event_orders.find(query).to_list(1000)
        
        # Process daily aggregation
        daily_reports = {}
        total_stats = {
            "total_events": 0,
            "total_revenue": 0,
            "total_advance_forfeited": 0,
            "total_jars_delivered": 0,
            "total_empty_jars_collected": 0,
            "cancelled_events": 0,
            "completed_events": 0
        }
        
        for event in events:
            # Parse event date
            if event.get('created_at'):
                event_date = datetime.fromisoformat(event['created_at'].replace('Z', '+00:00')).date().isoformat()
            else:
                event_date = datetime.now(timezone.utc).date().isoformat()
            
            if event_date not in daily_reports:
                daily_reports[event_date] = {
                    "date": event_date,
                    "events": [],
                    "stats": {
                        "total_events": 0,
                        "revenue": 0,
                        "advance_forfeited": 0,
                        "jars_delivered": 0,
                        "empty_jars_collected": 0,
                        "cancelled": 0,
                        "completed": 0
                    }
                }
            
            # Calculate balance amount (0 for cancelled events)
            total_amount = event.get("total_amount", 0)
            advance_amount = event.get("advance_amount", 0)
            if event.get("event_status") == "cancelled":
                balance_amount = 0  # No balance for cancelled orders
            else:
                balance_amount = total_amount - advance_amount
            
            # Add event to daily report
            daily_reports[event_date]["events"].append({
                "id": event.get("id"),
                "event_name": event.get("event_name"),
                "customer_name": event.get("customer_name"),
                "event_status": event.get("event_status"),
                "total_amount": total_amount,
                "advance_amount": advance_amount,
                "balance_amount": balance_amount,
                "jars_delivered": event.get("jars_delivered", 0),
                "empty_jars_collected": event.get("empty_jars_collected", 0),
                "created_at": event.get("created_at"),
                "cancelled_at": event.get("cancelled_at"),
                "advance_forfeited": event.get("advance_forfeited", False)
            })
            
            # Update daily stats (handle None values)
            daily_reports[event_date]["stats"]["total_events"] += 1
            daily_reports[event_date]["stats"]["jars_delivered"] += (event.get("jars_delivered") or 0)
            daily_reports[event_date]["stats"]["empty_jars_collected"] += (event.get("empty_jars_collected") or 0)
            
            if event.get("event_status") == "cancelled":
                daily_reports[event_date]["stats"]["cancelled"] += 1
                # For cancelled events, only count advance forfeited as revenue, not total amount
                if event.get("advance_forfeited"):
                    daily_reports[event_date]["stats"]["advance_forfeited"] += (event.get("advance_amount") or 0)
                    daily_reports[event_date]["stats"]["revenue"] += (event.get("advance_amount") or 0)
                # No revenue from cancelled orders except forfeited advance
            elif event.get("event_status") == "completed":
                daily_reports[event_date]["stats"]["completed"] += 1
                # For completed events, count full amount as revenue
                daily_reports[event_date]["stats"]["revenue"] += (event.get("total_amount") or 0)
            else:
                # For other statuses, count full amount as revenue
                daily_reports[event_date]["stats"]["revenue"] += (event.get("total_amount") or 0)
            
            # Update total stats (handle None values)
            total_stats["total_events"] += 1
            total_stats["total_jars_delivered"] += (event.get("jars_delivered") or 0)
            total_stats["total_empty_jars_collected"] += (event.get("empty_jars_collected") or 0)
            
            if event.get("event_status") == "cancelled":
                total_stats["cancelled_events"] += 1
                # For cancelled events, only count advance forfeited as revenue
                if event.get("advance_forfeited"):
                    total_stats["total_advance_forfeited"] += (event.get("advance_amount") or 0)
                    total_stats["total_revenue"] += (event.get("advance_amount") or 0)
                # No revenue from cancelled orders except forfeited advance
            elif event.get("event_status") == "completed":
                total_stats["completed_events"] += 1
                # For completed events, count full amount as revenue
                total_stats["total_revenue"] += (event.get("total_amount") or 0)
            else:
                # For other statuses, count full amount as revenue
                total_stats["total_revenue"] += (event.get("total_amount") or 0)
        
        # Convert to sorted list
        daily_reports_list = sorted(daily_reports.values(), key=lambda x: x["date"], reverse=True)
        
        return {
            "daily_reports": daily_reports_list,
            "total_stats": total_stats,
            "date_range": {
                "start_date": start_dt.isoformat(),
                "end_date": end_dt.isoformat()
            }
        }
        
    except Exception as e:
        print(f"Error in event order reports: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/reports/event-orders/export")
async def export_event_order_reports(
    format: str = "excel",
    start_date: str = None,
    end_date: str = None,
    status: str = None,
    current_user: User = Depends(get_current_user)
):
    """Export event order reports as PDF or Excel"""
    try:
        # Get report data using existing function
        report_response = await get_event_order_reports(start_date, end_date, status, current_user)
        
        if format.lower() == "excel":
            # Create Excel file
            output = io.BytesIO()
            
            # Prepare data for Excel
            excel_data = []
            for daily_report in report_response["daily_reports"]:
                for event in daily_report["events"]:
                    excel_data.append({
                        "Date": daily_report["date"],
                        "Event Name": event["event_name"],
                        "Customer Name": event["customer_name"], 
                        "Status": event["event_status"],
                        "Total Amount": event["total_amount"],
                        "Advance Amount": event["advance_amount"],
                        "Balance Amount": event["balance_amount"],
                        "Jars Delivered": event["jars_delivered"],
                        "Empty Jars Collected": event["empty_jars_collected"],
                        "Advance Forfeited": "Yes" if event.get("advance_forfeited") else "No",
                        "Created At": event["created_at"],
                        "Cancelled At": event.get("cancelled_at", "")
                    })
            
            # Create Excel workbook with enhanced formatting
            try:
                import pandas as pd
                from openpyxl import Workbook
                from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
                from openpyxl.utils.dataframe import dataframe_to_rows
                
                # Create workbook
                wb = Workbook()
                
                # Summary sheet
                summary_ws = wb.active
                summary_ws.title = "Summary"
                
                # Add title
                summary_ws['A1'] = "🏢 AquaElite Event Orders Report"
                summary_ws['A1'].font = Font(size=16, bold=True, color='1F4E79')
                summary_ws.merge_cells('A1:D1')
                
                # Add date range
                summary_ws['A3'] = f"📅 Report Period: {report_response['date_range']['start_date'][:10]} to {report_response['date_range']['end_date'][:10]}"
                summary_ws['A3'].font = Font(size=12, bold=True)
                summary_ws.merge_cells('A3:D3')
                
                # Summary data with styling
                summary_headers = ['📊 Metric', '📈 Value', '📝 Details']
                summary_rows = [
                    ['Total Events', str(report_response['total_stats']['total_events']), 'All event orders in period'],
                    ['💰 Total Revenue', f"₹{report_response['total_stats']['total_revenue']:,.2f}", 'Actual collected amount'],
                    ['❌ Cancelled Events', str(report_response['total_stats']['cancelled_events']), 'Orders cancelled by customers'],
                    ['✅ Completed Events', str(report_response['total_stats']['completed_events']), 'Successfully completed orders'],
                    ['💸 Advance Forfeited', f"₹{report_response['total_stats']['total_advance_forfeited']:,.2f}", 'Non-refundable payments'],
                    ['🏺 Jars Delivered', str(report_response['total_stats']['total_jars_delivered']), 'Total water jars delivered'],
                    ['🔄 Empty Jars Collected', str(report_response['total_stats']['total_empty_jars_collected']), 'Empty jars returned']
                ]
                
                # Add headers
                for col, header in enumerate(summary_headers, 1):
                    cell = summary_ws.cell(row=5, column=col, value=header)
                    cell.font = Font(bold=True, color='FFFFFF')
                    cell.fill = PatternFill(start_color='1F4E79', end_color='1F4E79', fill_type='solid')
                    cell.alignment = Alignment(horizontal='center')
                
                # Add data rows
                for row_idx, row_data in enumerate(summary_rows, 6):
                    for col_idx, value in enumerate(row_data, 1):
                        cell = summary_ws.cell(row=row_idx, column=col_idx, value=value)
                        if row_idx % 2 == 0:
                            cell.fill = PatternFill(start_color='E8F4FD', end_color='E8F4FD', fill_type='solid')
                
                # Auto-adjust column widths
                for col in summary_ws.columns:
                    max_length = 0
                    for cell in col:
                        try:
                            if cell.value is not None and len(str(cell.value)) > max_length:
                                max_length = len(str(cell.value))
                        except:
                            pass
                    try:
                        # Check if col[0] is not a merged cell and has column_letter
                        if hasattr(col[0], 'column_letter') and col[0].column_letter:
                            summary_ws.column_dimensions[col[0].column_letter].width = min(max_length + 2, 50)
                    except (AttributeError, IndexError):
                        pass
                
                # Detailed data sheet
                if excel_data:
                    detail_ws = wb.create_sheet("Event Details")
                    df = pd.DataFrame(excel_data)
                    
                    # Add headers with styling
                    headers = list(df.columns)
                    for col_idx, header in enumerate(headers, 1):
                        cell = detail_ws.cell(row=1, column=col_idx, value=header)
                        cell.font = Font(bold=True, color='FFFFFF')
                        cell.fill = PatternFill(start_color='2E7D32', end_color='2E7D32', fill_type='solid')
                        cell.alignment = Alignment(horizontal='center')
                    
                    # Add data with alternating colors
                    for row_idx, row in df.iterrows():
                        for col_idx, value in enumerate(row, 1):
                            cell = detail_ws.cell(row=row_idx + 2, column=col_idx, value=value)
                            if row_idx % 2 == 0:
                                cell.fill = PatternFill(start_color='E8F5E8', end_color='E8F5E8', fill_type='solid')
                    
                    # Auto-adjust column widths
                    for col in detail_ws.columns:
                        max_length = 0
                        for cell in col:
                            try:
                                if cell.value is not None and len(str(cell.value)) > max_length:
                                    max_length = len(str(cell.value))
                            except:
                                pass
                        try:
                            # Check if col[0] is not a merged cell and has column_letter
                            if hasattr(col[0], 'column_letter') and col[0].column_letter:
                                detail_ws.column_dimensions[col[0].column_letter].width = min(max_length + 2, 40)
                        except (AttributeError, IndexError):
                            pass
                
                wb.save(output)
            except ImportError:
                # Fallback without pandas
                import csv
                output = io.StringIO()
                if excel_data:
                    writer = csv.DictWriter(output, fieldnames=excel_data[0].keys())
                    writer.writeheader()
                    writer.writerows(excel_data)
                
                # Convert to bytes
                csv_content = output.getvalue()
                output = io.BytesIO(csv_content.encode('utf-8'))
            
            output.seek(0)
            
            # Return Excel file
            filename = f"event_orders_report_{report_response['date_range']['start_date'][:10]}_{report_response['date_range']['end_date'][:10]}.xlsx"
            
            return StreamingResponse(
                io.BytesIO(output.read()),
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
            
        elif format.lower() == "pdf":
            # Create professional PDF using reportlab with common header
            buffer = io.BytesIO()
            # Create PDF with proper header space
            from reportlab.platypus import PageTemplate, Frame, BaseDocTemplate
            from reportlab.lib.pagesizes import A4
            import os
            
            # Get contact details for footer
            contact_details = await get_contact_details_for_pdf()
            
            def draw_header(canvas, doc):
                draw_pdf_header_and_footer(canvas, doc, contact_details)
            
            # Create document with custom template
            doc = BaseDocTemplate(buffer, pagesize=A4, rightMargin=20, leftMargin=20, topMargin=100, bottomMargin=30)
            
            # Create frame for content (starts below header)
            content_frame = Frame(20, 30, A4[0] - 40, A4[1] - 130, id='content')
            
            # Add page template with common header
            template = PageTemplate('header_template', [content_frame], onPage=draw_header)
            doc.addPageTemplates([template])
            
            elements = []
            styles = getSampleStyleSheet()
            
            # Report title (center aligned as in combined financial reports)
            report_title = f"""
            <para align=center>
            <b><font size=18>EVENT ORDERS REPORT</font></b>
            </para>
            """
            
            title_style = ParagraphStyle('ReportTitle',
                parent=styles['Normal'],
                alignment=1,
                spaceAfter=15,
                spaceBefore=20,
                textColor=colors.black)
            
            elements.append(Paragraph(report_title, title_style))
            
            # Report details (similar to combined financial reports)
            report_details = f"""
            <para>
            <b>Report Number:</b> EOR-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}<br/>
            <b>Report Period:</b> {report_response['date_range']['start_date'][:10]} to {report_response['date_range']['end_date'][:10]}<br/>
            <b>Generated Date:</b> {datetime.now(timezone.utc).strftime('%d %B %Y at %H:%M UTC')}<br/>
            <b>Report Type:</b> Event Orders Summary Report
            </para>
            """
            
            details_style = ParagraphStyle('ReportDetails',
                parent=styles['Normal'],
                fontSize=11,
                spaceAfter=20,
                leftIndent=0,
                textColor=colors.black)
            
            elements.append(Paragraph(report_details, details_style))
            elements.append(Spacer(1, 20))
            
            # Define other required styles
            heading_style = ParagraphStyle('CustomHeading', 
                parent=styles['Heading2'], 
                fontSize=14, 
                spaceAfter=15,
                textColor=colors.black,
                fontName='Helvetica-Bold')
                
            normal_style = ParagraphStyle('CustomNormal',
                parent=styles['Normal'],
                fontSize=10,
                spaceAfter=12,
                alignment=1,
                textColor=colors.black)
            
            # Executive Summary section
            summary_title = Paragraph("Executive Summary", heading_style)
            elements.append(summary_title)
            
            # Simple summary table without colors
            summary_data = [
                ['Metric', 'Value', 'Details'],
                ['Total Events', str(report_response['total_stats']['total_events']), 'All event orders in period'],
                ['Total Revenue', f"Rs. {report_response['total_stats']['total_revenue']:,.2f}", 'Actual collected amount'],
                ['Cancelled Events', str(report_response['total_stats']['cancelled_events']), 'Orders cancelled by customers'],
                ['Completed Events', str(report_response['total_stats']['completed_events']), 'Successfully completed orders'],
                ['Advance Forfeited', f"Rs. {report_response['total_stats']['total_advance_forfeited']:,.2f}", 'Non-refundable payments'],
                ['Jars Delivered', str(report_response['total_stats']['total_jars_delivered']), 'Total water jars delivered'],
                ['Empty Jars Collected', str(report_response['total_stats']['total_empty_jars_collected']), 'Empty jars returned']
            ]
            
            summary_table = Table(summary_data, colWidths=[2.2*inch, 1.8*inch, 2*inch])
            summary_table.setStyle(TableStyle([
                # Header styling - simple black and white
                ('BACKGROUND', (0, 0), (-1, 0), colors.white),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 11),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('TOPPADDING', (0, 0), (-1, 0), 12),
                
                # Data rows - all white background
                ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                
                # Text formatting
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 10),
                ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
                
                # Grid and borders
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('LEFTPADDING', (0, 0), (-1, -1), 8),
                ('RIGHTPADDING', (0, 0), (-1, -1), 8)
            ]))
            
            elements.append(summary_table)
            elements.append(Spacer(1, 40))
            
            # Daily breakdown if available
            if report_response["daily_reports"]:
                daily_title = Paragraph("Daily Breakdown", heading_style)
                elements.append(daily_title)
                
                for i, daily_report in enumerate(report_response["daily_reports"]):
                    # Date header with simple styling
                    date_str = datetime.fromisoformat(daily_report['date']).strftime('%A, %B %d, %Y')
                    date_header = Paragraph(f"<b>{date_str}</b>", 
                        ParagraphStyle('DateHeader', 
                            parent=styles['Normal'],
                            fontSize=12,
                            textColor=colors.black,
                            spaceAfter=8))
                    elements.append(date_header)
                    
                    # Daily stats summary without colors
                    stats_info = f"""
                    <para>
                    <b>Events:</b> {daily_report['stats']['total_events']} | 
                    <b>Revenue:</b> Rs. {daily_report['stats']['revenue']:,.2f} | 
                    <b>Cancelled:</b> {daily_report['stats']['cancelled']} | 
                    <b>Completed:</b> {daily_report['stats']['completed']}
                    </para>
                    """
                    elements.append(Paragraph(stats_info, styles['Normal']))
                    elements.append(Spacer(1, 10))
                    
                    # Events table for this date with better design
                    if daily_report['events']:
                        event_data = [['Event', 'Customer', 'Status', 'Total', 'Advance', 'Balance']]
                        
                        for event in daily_report['events']:
                            event_data.append([
                                event['event_name'][:20] + ('...' if len(event['event_name']) > 20 else ''),
                                event['customer_name'][:15] + ('...' if len(event['customer_name']) > 15 else ''),
                                event['event_status'].title(),
                                f"Rs. {event['total_amount']:,.0f}",
                                f"Rs. {event['advance_amount']:,.0f}",
                                f"Rs. {event['balance_amount']:,.0f}"
                            ])
                        
                        event_table = Table(event_data, colWidths=[1.6*inch, 1.3*inch, 1*inch, 0.9*inch, 0.9*inch, 0.9*inch])
                        event_table.setStyle(TableStyle([
                            # Header - simple black and white
                            ('BACKGROUND', (0, 0), (-1, 0), colors.white),
                            ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                            ('FONTSIZE', (0, 0), (-1, 0), 9),
                            ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                            ('TOPPADDING', (0, 0), (-1, 0), 8),
                            
                            # Data rows - all white
                            ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                            ('FONTSIZE', (0, 1), (-1, -1), 8),
                            ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
                            
                            # Grid
                            ('GRID', (0, 0), (-1, -1), 0.8, colors.black),
                            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                            ('LEFTPADDING', (0, 0), (-1, -1), 6),
                            ('RIGHTPADDING', (0, 0), (-1, -1), 6)
                        ]))
                        
                        elements.append(event_table)
                        elements.append(Spacer(1, 20))
                    
                    # Add page break after every 2 days to avoid crowding
                    if i > 0 and (i + 1) % 2 == 0:
                        elements.append(PageBreak())
            
            # Build PDF
            doc.build(elements)
            buffer.seek(0)
            
            # Return PDF file
            filename = f"event_orders_report_{report_response['date_range']['start_date'][:10]}_{report_response['date_range']['end_date'][:10]}.pdf"
            
            return StreamingResponse(
                buffer,
                media_type="application/pdf",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
        
        else:
            raise HTTPException(status_code=400, detail="Invalid format. Use 'excel' or 'pdf'")
            
    except Exception as e:
        print(f"Error in export: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Customer Management Reports APIs
@api_router.get("/reports/customer-management")
async def get_customer_management_reports(
    start_date: str, 
    end_date: str, 
    type: str = 'all',
    current_user: User = Depends(get_current_user)
):
    try:
        # Parse dates
        start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
        
        # Get all deliveries in date range
        deliveries = await db.deliveries.find({
            "delivered_at": {"$gte": start_dt.isoformat(), "$lte": end_dt.isoformat()}
        }).to_list(1000)
        
        # Get all payments in date range
        payments = await db.payments.find({
            "collected_at": {"$gte": start_dt.isoformat(), "$lte": end_dt.isoformat()}
        }).to_list(1000)
        
        # Get all empty jar collections in date range
        jar_collections = await db.empty_jar_collections.find({
            "collected_at": {"$gte": start_dt.isoformat(), "$lte": end_dt.isoformat()}
        }).to_list(1000)
        
        # Get all customers
        customers = await db.customers.find({"is_active": True}).to_list(1000)
        
        # Calculate statistics
        total_deliveries = len(deliveries)
        total_payments = sum(payment.get('amount', 0) for payment in payments)
        total_jars_collected = sum(jar.get('jars_collected', 0) for jar in jar_collections)
        
        # Calculate jar delivery statistics
        total_jars_delivered = 0
        customer_jar_deliveries = {}
        
        for delivery in deliveries:
            jars_delivered = delivery.get('jars_delivered', 0)
            total_jars_delivered += jars_delivered
            
            customer_id = delivery.get('customer_id')
            if customer_id:
                if customer_id not in customer_jar_deliveries:
                    customer_jar_deliveries[customer_id] = {
                        'customer_name': delivery.get('customer_name', 'Unknown'),
                        'total_jars': 0,
                        'deliveries': []
                    }
                
                customer_jar_deliveries[customer_id]['total_jars'] += jars_delivered
                customer_jar_deliveries[customer_id]['deliveries'].append({
                    'date': delivery.get('delivered_at', ''),
                    'jars_delivered': jars_delivered,
                    'delivery_boy': delivery.get('delivery_boy_name', ''),
                    'notes': delivery.get('delivery_notes', '')
                })
        
        active_customers = len(set(
            [d['customer_id'] for d in deliveries] + 
            [p['customer_id'] for p in payments] + 
            [j['customer_id'] for j in jar_collections]
        ))
        
        # Calculate reconciliation statistics
        pending_payments = [p for p in payments if p.get('reconciliation_status') == 'pending']
        received_payments = [p for p in payments if p.get('reconciliation_status') == 'received_by_admin']
        total_pending_amount = sum(p.get('amount', 0) for p in pending_payments)
        total_received_amount = sum(p.get('amount', 0) for p in received_payments)
        
        # Calculate uncollected empty jars from customers
        uncollected_empty_jars = sum(customer.get('empty_jars_balance', 0) for customer in customers)
        
        # Create customer-wise uncollected empty jar list
        customers_with_empty_jars = []
        for customer in customers:
            empty_jar_balance = customer.get('empty_jars_balance', 0)
            if empty_jar_balance > 0:
                customers_with_empty_jars.append({
                    'customer_id': customer['id'],
                    'customer_name': customer['name'],
                    'mobile': customer.get('mobile', ''),
                    'address': customer.get('address', ''),
                    'empty_jars_balance': empty_jar_balance
                })
        
        # Group by date for daily reports
        daily_reports = {}
        
        # Process deliveries by date
        for delivery in deliveries:
            date_key = delivery['delivered_at'][:10]  # YYYY-MM-DD
            if date_key not in daily_reports:
                daily_reports[date_key] = {
                    'date': date_key,
                    'deliveries': 0,
                    'payments': 0.0,
                    'jars_collected': 0,
                    'customers': set(),
                    'activities': []
                }
            
            daily_reports[date_key]['deliveries'] += 1
            daily_reports[date_key]['customers'].add(delivery['customer_id'])
            daily_reports[date_key]['activities'].append({
                'type': 'delivery',
                'customer_name': delivery['customer_name'],
                'jars_delivered': delivery['jars_delivered'],
                'time': delivery['delivered_at'],
                'notes': delivery.get('delivery_notes', '')
            })
        
        # Process payments by date
        for payment in payments:
            date_key = payment['collected_at'][:10]
            if date_key not in daily_reports:
                daily_reports[date_key] = {
                    'date': date_key,
                    'deliveries': 0,
                    'payments': 0.0,
                    'jars_collected': 0,
                    'customers': set(),
                    'activities': []
                }
            
            daily_reports[date_key]['payments'] += payment.get('amount', 0)
            daily_reports[date_key]['customers'].add(payment['customer_id'])
            daily_reports[date_key]['activities'].append({
                'type': 'payment',
                'customer_name': payment['customer_name'],
                'amount': payment['amount'],
                'payment_mode': payment.get('payment_mode', 'cash'),
                'time': payment['collected_at'],
                'notes': payment.get('notes', '')
            })
        
        # Process jar collections by date
        for jar in jar_collections:
            date_key = jar['collected_at'][:10]
            if date_key not in daily_reports:
                daily_reports[date_key] = {
                    'date': date_key,
                    'deliveries': 0,
                    'payments': 0.0,
                    'jars_collected': 0,
                    'customers': set(),
                    'activities': []
                }
            
            daily_reports[date_key]['jars_collected'] += jar.get('jars_collected', 0)
            daily_reports[date_key]['customers'].add(jar['customer_id'])
            daily_reports[date_key]['activities'].append({
                'type': 'empty_jar_collection',
                'customer_name': jar['customer_name'],
                'jars_collected': jar['jars_collected'],
                'time': jar['collected_at'],
                'notes': jar.get('collection_notes', '')
            })
        
        # Convert customers set to count and prepare final daily reports
        final_daily_reports = []
        for date_key in sorted(daily_reports.keys()):
            report = daily_reports[date_key]
            report['customers'] = len(report['customers'])
            final_daily_reports.append(report)
        
        return {
            "date_range": {
                "start_date": start_date,
                "end_date": end_date
            },
            "total_stats": {
                "total_deliveries": total_deliveries,
                "total_payments": total_payments,
                "total_jars_collected": total_jars_collected,
                "total_jars_delivered": total_jars_delivered,
                "active_customers": active_customers,
                "uncollected_empty_jars": uncollected_empty_jars,
                "total_pending_payments": total_pending_amount,
                "total_received_payments": total_received_amount,
                "pending_payments_count": len(pending_payments),
                "received_payments_count": len(received_payments)
            },
            "daily_reports": final_daily_reports,
            "customers_with_empty_jars": customers_with_empty_jars,
            "customer_jar_deliveries": customer_jar_deliveries
        }
        
    except Exception as e:
        print(f"Error fetching customer management reports: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/reports/customer-management/export")
async def export_customer_management_reports(
    start_date: str,
    end_date: str,
    format: str,
    type: str = 'all',
    current_user: User = Depends(get_current_user)
):
    try:
        # Get the report data
        report_response = await get_customer_management_reports(start_date, end_date, type, current_user)
        
        if format == 'excel':
            # Create Excel file
            from openpyxl import Workbook
            from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
            import io
            
            wb = Workbook()
            
            # Summary Sheet
            summary_ws = wb.active
            summary_ws.title = "Summary"
            
            # Title and headers
            summary_ws['A1'] = "AquaElite Customer Management Report"
            summary_ws['A1'].font = Font(bold=True, size=16)
            summary_ws['A1'].alignment = Alignment(horizontal='center')
            summary_ws.merge_cells('A1:D1')
            
            # Date range
            summary_ws['A3'] = f"Report Period: {report_response['date_range']['start_date'][:10]} to {report_response['date_range']['end_date'][:10]}"
            summary_ws['A3'].font = Font(bold=True)
            
            # Summary statistics
            summary_ws['A5'] = "Summary Statistics"
            summary_ws['A5'].font = Font(bold=True, size=14)
            
            summary_data = [
                ['Metric', 'Value'],
                ['Total Deliveries', report_response['total_stats']['total_deliveries']],
                ['Total Payments Collected', f"Rs. {report_response['total_stats']['total_payments']:.2f}"],
                ['Total Empty Jars Collected', report_response['total_stats']['total_jars_collected']],
                ['Uncollected Empty Jars', report_response['total_stats']['uncollected_empty_jars']],
                ['Active Customers', report_response['total_stats']['active_customers']]
            ]
            
            for row_num, row_data in enumerate(summary_data, start=6):
                for col_num, value in enumerate(row_data, start=1):
                    cell = summary_ws.cell(row=row_num, column=col_num, value=value)
                    if row_num == 6:  # Header row
                        cell.font = Font(bold=True)
                        cell.fill = PatternFill(start_color="E6E6FA", end_color="E6E6FA", fill_type="solid")
            
            # Daily Details Sheet
            detail_ws = wb.create_sheet("Daily Details")
            detail_headers = ['Date', 'Deliveries', 'Payments (Rs.)', 'Empty Jars', 'Active Customers']
            
            for col_num, header in enumerate(detail_headers, 1):
                cell = detail_ws.cell(row=1, column=col_num, value=header)
                cell.font = Font(bold=True)
                cell.fill = PatternFill(start_color="DDA0DD", end_color="DDA0DD", fill_type="solid")
            
            for row_num, daily_report in enumerate(report_response['daily_reports'], start=2):
                detail_ws.cell(row=row_num, column=1, value=daily_report['date'])
                detail_ws.cell(row=row_num, column=2, value=daily_report['deliveries'])
                detail_ws.cell(row=row_num, column=3, value=daily_report['payments'])
                detail_ws.cell(row=row_num, column=4, value=daily_report['jars_collected'])
                detail_ws.cell(row=row_num, column=5, value=daily_report['customers'])
            
            # Uncollected Empty Jars Sheet
            empty_jars_ws = wb.create_sheet("Uncollected Empty Jars")
            empty_jar_headers = ['Customer Name', 'Mobile', 'Address', 'Empty Jars Balance']
            
            for col_num, header in enumerate(empty_jar_headers, 1):
                cell = empty_jars_ws.cell(row=1, column=col_num, value=header)
                cell.font = Font(bold=True)
                cell.fill = PatternFill(start_color="FFB6C1", end_color="FFB6C1", fill_type="solid")
            
            for row_num, customer in enumerate(report_response['customers_with_empty_jars'], start=2):
                empty_jars_ws.cell(row=row_num, column=1, value=customer['customer_name'])
                empty_jars_ws.cell(row=row_num, column=2, value=customer['mobile'])
                empty_jars_ws.cell(row=row_num, column=3, value=customer['address'])
                empty_jars_ws.cell(row=row_num, column=4, value=customer['empty_jars_balance'])
            
            # Auto-adjust column widths
            for ws in [summary_ws, detail_ws, empty_jars_ws]:
                for col in ws.columns:
                    max_length = 0
                    for cell in col:
                        try:
                            if cell.value is not None and len(str(cell.value)) > max_length:
                                max_length = len(str(cell.value))
                        except:
                            pass
                    try:
                        if hasattr(col[0], 'column_letter') and col[0].column_letter:
                            ws.column_dimensions[col[0].column_letter].width = min(max_length + 2, 40)
                    except (AttributeError, IndexError):
                        pass
            
            # Save to BytesIO
            buffer = io.BytesIO()
            wb.save(buffer)
            buffer.seek(0)
            
            # Return Excel file
            filename = f"customer_management_report_{report_response['date_range']['start_date'][:10]}_{report_response['date_range']['end_date'][:10]}.xlsx"
            
            return StreamingResponse(
                buffer,
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
            
        elif format == 'pdf':
            # Create PDF file with common header
            import io
            buffer = io.BytesIO()
            # Create PDF with proper header space
            from reportlab.platypus import PageTemplate, Frame, BaseDocTemplate
            from reportlab.lib.pagesizes import A4
            import os
            
            # Get contact details for footer
            contact_details = await get_contact_details_for_pdf()
            
            def draw_header(canvas, doc):
                draw_pdf_header_and_footer(canvas, doc, contact_details)
            
            # Create document with custom template
            doc = BaseDocTemplate(buffer, pagesize=A4, rightMargin=20, leftMargin=20, topMargin=100, bottomMargin=30)
            
            # Create frame for content (starts below header)
            content_frame = Frame(20, 30, A4[0] - 40, A4[1] - 130, id='content')
            
            # Add page template with common header
            template = PageTemplate('header_template', [content_frame], onPage=draw_header)
            doc.addPageTemplates([template])
            
            elements = []
            styles = getSampleStyleSheet()
            
            # Report title (center aligned as in combined financial reports)
            report_title = f"""
            <para align=center>
            <b><font size=18>CUSTOMER MANAGEMENT REPORT</font></b>
            </para>
            """
            
            title_style = ParagraphStyle('ReportTitle',
                parent=styles['Normal'],
                alignment=1,
                spaceAfter=15,
                spaceBefore=20,
                textColor=colors.black)
            
            elements.append(Paragraph(report_title, title_style))
            
            # Report details (similar to combined financial reports)
            report_details = f"""
            <para>
            <b>Report Number:</b> CMR-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}<br/>
            <b>Report Period:</b> {report_response['date_range']['start_date'][:10]} to {report_response['date_range']['end_date'][:10]}<br/>
            <b>Generated Date:</b> {datetime.now(timezone.utc).strftime('%d %B %Y at %H:%M UTC')}<br/>
            <b>Report Type:</b> Customer Activity Summary Report
            </para>
            """
            
            details_style = ParagraphStyle('ReportDetails',
                parent=styles['Normal'],
                fontSize=11,
                spaceAfter=20,
                leftIndent=0,
                textColor=colors.black)
            
            elements.append(Paragraph(report_details, details_style))
            elements.append(Spacer(1, 20))
            
            # Define required styles
            heading_style = ParagraphStyle('CustomHeading', 
                parent=styles['Heading2'], 
                fontSize=14, 
                spaceAfter=15,
                textColor=colors.black,
                fontName='Helvetica-Bold')
                
            normal_style = ParagraphStyle('CustomNormal',
                parent=styles['Normal'],
                fontSize=10,
                spaceAfter=12,
                alignment=1,
                textColor=colors.black)
            
            # Executive Summary
            summary_title = Paragraph("Executive Summary", heading_style)
            elements.append(summary_title)
            
            # Summary table
            summary_data = [
                ['Metric', 'Value', 'Details'],
                ['Total Deliveries', str(report_response['total_stats']['total_deliveries']), 'Customer deliveries completed'],
                ['Total Payments', f"Rs. {report_response['total_stats']['total_payments']:,.2f}", 'Payments collected from customers'],
                ['Empty Jars Collected', str(report_response['total_stats']['total_jars_collected']), 'Empty jars returned by customers'],
                ['Uncollected Empty Jars', str(report_response['total_stats']['uncollected_empty_jars']), 'Empty jars pending collection from customers'],
                ['Active Customers', str(report_response['total_stats']['active_customers']), 'Customers with activities in period']
            ]
            
            summary_table = Table(summary_data, colWidths=[2*inch, 1.5*inch, 2.5*inch])
            summary_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.white),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 11),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('TOPPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 10),
                ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('LEFTPADDING', (0, 0), (-1, -1), 8),
                ('RIGHTPADDING', (0, 0), (-1, -1), 8)
            ]))
            elements.append(summary_table)
            elements.append(Spacer(1, 30))
            
            # Daily breakdown
            if report_response["daily_reports"]:
                daily_title = Paragraph("Daily Breakdown", heading_style)
                elements.append(daily_title)
                
                for daily_report in report_response["daily_reports"][:10]:  # Limit to 10 days
                    # Date header
                    date_str = daily_report['date']
                    date_header = Paragraph(f"<b>{date_str}</b>", 
                        ParagraphStyle('DateHeader', 
                            parent=styles['Normal'],
                            fontSize=12,
                            textColor=colors.black,
                            spaceAfter=8))
                    elements.append(date_header)
                    
                    # Daily stats
                    stats_info = f"""
                    <para>
                    <b>Deliveries:</b> {daily_report['deliveries']} | 
                    <b>Payments:</b> Rs. {daily_report['payments']:,.2f} | 
                    <b>Empty Jars:</b> {daily_report['jars_collected']} | 
                    <b>Customers:</b> {daily_report['customers']}
                    </para>
                    """
                    elements.append(Paragraph(stats_info, normal_style))
                    elements.append(Spacer(1, 15))
            
            # Uncollected Empty Jars Section
            if report_response["customers_with_empty_jars"]:
                elements.append(Spacer(1, 30))
                empty_jars_title = Paragraph("Customer-wise Uncollected Empty Jars", heading_style)
                elements.append(empty_jars_title)
                
                # Create table for customers with empty jars
                empty_jar_data = [['Customer Name', 'Mobile', 'Address', 'Empty Jars']]
                
                for customer in report_response["customers_with_empty_jars"][:20]:  # Limit to 20 customers
                    empty_jar_data.append([
                        customer['customer_name'][:25] + ('...' if len(customer['customer_name']) > 25 else ''),
                        customer['mobile'],
                        customer['address'][:30] + ('...' if len(customer['address']) > 30 else ''),
                        str(customer['empty_jars_balance'])
                    ])
                
                empty_jar_table = Table(empty_jar_data, colWidths=[2*inch, 1.2*inch, 2*inch, 0.8*inch])
                empty_jar_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.white),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                    ('TOPPADDING', (0, 0), (-1, 0), 8),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.white),
                    ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                    ('FONTSIZE', (0, 1), (-1, -1), 9),
                    ('TEXTCOLOR', (0, 1), (-1, -1), colors.black),
                    ('GRID', (0, 0), (-1, -1), 0.8, colors.black),
                    ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                    ('LEFTPADDING', (0, 0), (-1, -1), 6),
                    ('RIGHTPADDING', (0, 0), (-1, -1), 6)
                ]))
                elements.append(empty_jar_table)
                
                # Summary info
                total_customers_with_jars = len(report_response["customers_with_empty_jars"])
                summary_info = f"""
                <para>
                <b>Total Customers with Uncollected Empty Jars:</b> {total_customers_with_jars} | 
                <b>Total Uncollected Jars:</b> {report_response['total_stats']['uncollected_empty_jars']}
                </para>
                """
                elements.append(Spacer(1, 10))
                elements.append(Paragraph(summary_info, normal_style))
            
            # Build PDF
            doc.build(elements)
            buffer.seek(0)
            
            # Return PDF file
            filename = f"customer_management_report_{report_response['date_range']['start_date'][:10]}_{report_response['date_range']['end_date'][:10]}.pdf"
            
            return StreamingResponse(
                buffer,
                media_type="application/pdf",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
        
        else:
            raise HTTPException(status_code=400, detail="Invalid format. Use 'excel' or 'pdf'")
            
    except Exception as e:
        print(f"Error in customer management export: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/dashboard/stats", response_model=DashboardStats)
async def get_dashboard_stats(current_user: User = Depends(get_current_user)):
    today = datetime.now(timezone.utc).date()
    today_start = datetime.combine(today, datetime.min.time()).replace(tzinfo=timezone.utc)
    today_end = datetime.combine(today, datetime.max.time()).replace(tzinfo=timezone.utc)
    
    # Get total active customers (only regular and both types, not event-only)
    total_customers = await db.customers.count_documents({
        "is_active": True,
        "customer_type": {"$in": ["regular", "both"]}
    })
    
    # Get today's deliveries (completed today)
    today_deliveries = await db.deliveries.find({
        "delivered_at": {
            "$gte": today_start.isoformat(),
            "$lte": today_end.isoformat()
        },
        "delivery_status": "completed"
    }).to_list(1000)
    
    total_jars_delivered_today = sum(d.get('jars_delivered', 0) for d in today_deliveries)
    
    # Get today's payments (actual cash collected)
    today_payments = await db.payments.find({
        "collected_at": {
            "$gte": today_start.isoformat(),
            "$lte": today_end.isoformat()
        }
    }).to_list(1000)
    
    total_revenue_today = sum(p.get('amount', 0) for p in today_payments)
    
    # Get pending orders (not delivered yet)
    pending_orders = await db.orders.count_documents({"delivery_status": "pending"})
    
    # Get today's expenses
    today_expenses = await db.expenses.find({
        "expense_date": {
            "$gte": today_start.isoformat(),
            "$lte": today_end.isoformat()
        }
    }).to_list(1000)
    
    total_expenses_today = sum(expense['amount'] for expense in today_expenses)
    
    # Calculate outstanding payments (sum of all customer balances)
    all_customers = await db.customers.find({"is_active": True}).to_list(10000)
    outstanding_payments = sum(c.get('balance_due', 0) or 0 for c in all_customers)
    
    # Calculate profit (revenue - expenses)
    profit_today = total_revenue_today - total_expenses_today
    
    # Get invoice statistics
    total_invoices = await db.invoices.count_documents({})
    pending_invoices = await db.invoices.count_documents({"status": {"$in": ["draft", "sent"]}})
    
    # Get overdue invoices (due_date in past and not paid)
    try:
        overdue_invoices = await db.invoices.count_documents({
            "status": {"$ne": "paid"},
            "due_date": {"$lt": datetime.now(timezone.utc).isoformat()}
        })
    except:
        overdue_invoices = 0
    
    # Get event order statistics
    total_event_orders = await db.event_orders.count_documents({})
    
    # Get upcoming events (next 30 days, not cancelled)
    next_month = datetime.now(timezone.utc) + timedelta(days=30)
    upcoming_events = await db.event_orders.count_documents({
        "event_date": {
            "$gte": datetime.now(timezone.utc).isoformat(),
            "$lte": next_month.isoformat()
        },
        "event_status": {"$in": ["confirmed", "in_progress", "incomplete"]}
    })
    
    # Get this month's data
    month_start = datetime.now(timezone.utc).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    next_month_date = month_start.month + 1 if month_start.month < 12 else 1
    next_year = month_start.year if month_start.month < 12 else month_start.year + 1
    month_end = datetime(next_year, next_month_date, 1, tzinfo=timezone.utc)
    
    # Get month's event statistics (based on actual payment collection dates)
    all_events = await db.event_orders.find({"event_status": {"$ne": "cancelled"}}).to_list(10000)
    
    completed_events_month = 0
    event_revenue_month = 0.0
    
    # Track events completed in the month
    for event in all_events:
        completed_at = event.get("delivery_completed_at")
        if completed_at:
            try:
                if isinstance(completed_at, str):
                    completed_dt = datetime.fromisoformat(completed_at.replace('Z', '+00:00'))
                else:
                    completed_dt = completed_at
                    if completed_dt.tzinfo is None:
                        completed_dt = completed_dt.replace(tzinfo=timezone.utc)
                
                if month_start <= completed_dt < month_end:
                    completed_events_month += 1
            except:
                pass
    
    # Calculate event revenue for the month (based on payment collection dates)
    for event in all_events:
        payment_in_month = 0
        
        # Check if advance was collected this month
        advance_amount = event.get("advance_amount", 0) or 0
        advance_date = event.get("created_at")
        
        if advance_amount > 0 and advance_date:
            try:
                if isinstance(advance_date, str):
                    advance_dt = datetime.fromisoformat(advance_date.replace('Z', '+00:00'))
                else:
                    advance_dt = advance_date
                    if advance_dt.tzinfo is None:
                        advance_dt = advance_dt.replace(tzinfo=timezone.utc)
                
                if month_start <= advance_dt < month_end:
                    payment_in_month += advance_amount
            except:
                pass
        
        # Check if last payment was collected this month
        last_payment_amount = event.get("last_payment_amount", 0) or 0
        last_payment_date = event.get("last_payment_date")
        
        if last_payment_amount > 0 and last_payment_date:
            try:
                if isinstance(last_payment_date, str):
                    payment_dt = datetime.fromisoformat(last_payment_date.replace('Z', '+00:00'))
                else:
                    payment_dt = last_payment_date
                    if payment_dt.tzinfo is None:
                        payment_dt = payment_dt.replace(tzinfo=timezone.utc)
                
                if month_start <= payment_dt < month_end:
                    payment_in_month += last_payment_amount
            except:
                pass
        
        event_revenue_month += payment_in_month
    
    # Get today's completed events and revenue
    event_jars_delivered_today = 0
    event_empty_jars_collected_today = 0
    completed_events_today = 0
    event_revenue_today = 0.0
    
    for event in all_events:
        # Check if event was completed today
        completed_at = event.get("delivery_completed_at")
        if completed_at:
            try:
                if isinstance(completed_at, str):
                    completed_dt = datetime.fromisoformat(completed_at.replace('Z', '+00:00'))
                else:
                    completed_dt = completed_at
                    if completed_dt.tzinfo is None:
                        completed_dt = completed_dt.replace(tzinfo=timezone.utc)
                
                if today_start <= completed_dt <= today_end:
                    completed_events_today += 1
                    event_jars_delivered_today += event.get('jars_delivered', 0) or 0
                    event_empty_jars_collected_today += event.get('empty_jars_collected', 0) or 0
            except:
                pass
        
        # Check if payment was collected today (separate from completion)
        payment_today = 0
        
        advance_amount = event.get("advance_amount", 0) or 0
        advance_date = event.get("created_at")
        
        if advance_amount > 0 and advance_date:
            try:
                if isinstance(advance_date, str):
                    advance_dt = datetime.fromisoformat(advance_date.replace('Z', '+00:00'))
                else:
                    advance_dt = advance_date
                    if advance_dt.tzinfo is None:
                        advance_dt = advance_dt.replace(tzinfo=timezone.utc)
                
                if today_start <= advance_dt <= today_end:
                    payment_today += advance_amount
            except:
                pass
        
        last_payment_amount = event.get("last_payment_amount", 0) or 0
        last_payment_date = event.get("last_payment_date")
        
        if last_payment_amount > 0 and last_payment_date:
            try:
                if isinstance(last_payment_date, str):
                    payment_dt = datetime.fromisoformat(last_payment_date.replace('Z', '+00:00'))
                else:
                    payment_dt = last_payment_date
                    if payment_dt.tzinfo is None:
                        payment_dt = payment_dt.replace(tzinfo=timezone.utc)
                
                if today_start <= payment_dt <= today_end:
                    payment_today += last_payment_amount
            except:
                pass
        
        event_revenue_today += payment_today
    
    # Get cancelled events statistics
    all_cancelled = await db.event_orders.find({"event_status": "cancelled"}).to_list(10000)
    
    cancelled_events_today = 0
    cancelled_events_month = 0
    
    for event in all_cancelled:
        cancelled_at = event.get("cancelled_at")
        if cancelled_at:
            try:
                if isinstance(cancelled_at, str):
                    cancelled_dt = datetime.fromisoformat(cancelled_at.replace('Z', '+00:00'))
                else:
                    cancelled_dt = cancelled_at
                    if cancelled_dt.tzinfo is None:
                        cancelled_dt = cancelled_dt.replace(tzinfo=timezone.utc)
                
                if today_start <= cancelled_dt <= today_end:
                    cancelled_events_today += 1
                if month_start <= cancelled_dt < month_end:
                    cancelled_events_month += 1
            except:
                pass
    
    # Calculate forfeited advance amounts (for today and month)
    advance_forfeited_today = 0.0
    advance_forfeited_month = 0.0
    
    for event in all_cancelled:
        if event.get('advance_forfeited'):
            cancelled_at = event.get("cancelled_at")
            if cancelled_at:
                try:
                    if isinstance(cancelled_at, str):
                        cancelled_dt = datetime.fromisoformat(cancelled_at.replace('Z', '+00:00'))
                    else:
                        cancelled_dt = cancelled_at
                        if cancelled_dt.tzinfo is None:
                            cancelled_dt = cancelled_dt.replace(tzinfo=timezone.utc)
                    
                    advance_amt = event.get('advance_amount', 0) or 0
                    if today_start <= cancelled_dt <= today_end:
                        advance_forfeited_today += advance_amt
                    if month_start <= cancelled_dt < month_end:
                        advance_forfeited_month += advance_amt
                except:
                    pass
    
    return DashboardStats(
        total_customers=total_customers,
        total_jars_delivered_today=total_jars_delivered_today,
        total_revenue_today=total_revenue_today,
        pending_orders=pending_orders,
        total_expenses_today=total_expenses_today,
        outstanding_payments=outstanding_payments,
        profit_today=profit_today,
        total_invoices=total_invoices,
        pending_invoices=pending_invoices,
        overdue_invoices=overdue_invoices,
        total_event_orders=total_event_orders,
        upcoming_events=upcoming_events,
        event_revenue_month=event_revenue_month,
        event_jars_delivered_today=event_jars_delivered_today,
        event_empty_jars_collected_today=event_empty_jars_collected_today,
        event_revenue_today=event_revenue_today,
        completed_events_today=completed_events_today,
        completed_events_month=completed_events_month,
        cancelled_events_today=cancelled_events_today,
        cancelled_events_month=cancelled_events_month,
        advance_forfeited_today=advance_forfeited_today,
        advance_forfeited_month=advance_forfeited_month
    )

# Delivery boys routes
@api_router.get("/delivery-boys", response_model=List[User])
async def get_delivery_boys(current_user: User = Depends(get_current_user)):
    delivery_boys = await db.users.find({
        "role": UserRole.DELIVERY_BOY,
        "is_active": True
    }).to_list(1000)
    return [User(**boy) for boy in delivery_boys]

# Scheduled Deliveries API
@api_router.post("/scheduled-deliveries")
async def create_scheduled_delivery(delivery_data: dict, current_user: User = Depends(get_current_user)):
    scheduled_delivery = {
        "id": str(uuid.uuid4()),
        "customer_id": delivery_data["customer_id"],
        "customer_name": delivery_data["customer_name"],
        "jars_delivered": delivery_data["jars_delivered"],
        "delivery_notes": delivery_data.get("delivery_notes", ""),
        "scheduled_date": delivery_data["scheduled_date"],
        "scheduled_time_slot": delivery_data["scheduled_time_slot"],
        "scheduled_time": delivery_data["scheduled_time"],
        "payment_amount": delivery_data.get("payment_amount", 0),
        "payment_mode": delivery_data.get("payment_mode", "cash"),
        "delivery_status": delivery_data.get("delivery_status", "scheduled"),
        "scheduled_by": delivery_data["scheduled_by"],
        "scheduled_by_name": delivery_data["scheduled_by_name"],
        "scheduled_at": delivery_data["scheduled_at"],
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.scheduled_deliveries.insert_one(scheduled_delivery)
    return clean_mongo_doc(scheduled_delivery)

@api_router.get("/scheduled-deliveries")
async def get_scheduled_deliveries(current_user: User = Depends(get_current_user)):
    deliveries = await db.scheduled_deliveries.find({
        "delivery_status": "scheduled"
    }).sort("scheduled_date", 1).to_list(1000)
    
    return clean_mongo_docs(deliveries)

@api_router.put("/scheduled-deliveries/{delivery_id}")
async def update_scheduled_delivery(delivery_id: str, update_data: dict, current_user: User = Depends(get_current_user)):
    result = await db.scheduled_deliveries.update_one(
        {"id": delivery_id},
        {"$set": {**update_data, "updated_at": datetime.now(timezone.utc).isoformat()}}
    )
    
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Scheduled delivery not found")
    
    return {"message": "Scheduled delivery updated successfully"}

# Deliveries API
@api_router.post("/deliveries")
async def create_delivery(delivery_data: dict, current_user: User = Depends(get_current_user)):
    delivery = {
        "id": str(uuid.uuid4()),
        "customer_id": delivery_data["customer_id"],
        "customer_name": delivery_data["customer_name"],
        "jars_delivered": delivery_data["jars_delivered"],
        "delivery_notes": delivery_data.get("delivery_notes", ""),
        "payment_amount": delivery_data.get("payment_amount", 0),
        "payment_mode": delivery_data.get("payment_mode", "cash"),
        "delivered_by": delivery_data["delivered_by"],
        "delivered_by_name": delivery_data["delivered_by_name"],
        "delivered_at": delivery_data["delivered_at"],
        "delivery_status": delivery_data.get("delivery_status", "completed"),
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.deliveries.insert_one(delivery)
    return clean_mongo_doc(delivery)

@api_router.get("/deliveries")
async def get_deliveries(current_user: User = Depends(get_current_user)):
    deliveries = await db.deliveries.find().sort("delivered_at", -1).to_list(1000)
    return clean_mongo_docs(deliveries)

# Customer Payments API (for customer balance management)
@api_router.post("/customer-payments")
async def create_customer_payment_record(payment_data: dict, current_user: User = Depends(get_current_user)):
    try:
        # Validate required fields
        required_fields = ["customer_id", "customer_name", "amount", "collected_by", "collected_by_name", "collected_at"]
        for field in required_fields:
            if field not in payment_data or payment_data[field] is None:
                raise HTTPException(status_code=422, detail=f"Missing required field: {field}")
        
        payment = {
            "id": str(uuid.uuid4()),
            "customer_id": str(payment_data["customer_id"]),
            "customer_name": str(payment_data["customer_name"]),
            "amount": float(payment_data["amount"]),
            "payment_mode": str(payment_data.get("payment_mode", "cash")),
            "collected_by": str(payment_data["collected_by"]),
            "collected_by_name": str(payment_data["collected_by_name"]),
            "payment_type": str(payment_data.get("payment_type", "customer_payment")),
            "notes": str(payment_data.get("notes", "")),
            "collected_at": str(payment_data["collected_at"]),
            "created_at": datetime.now(timezone.utc).isoformat(),
            # Event order fields (optional)
            "event_id": str(payment_data.get("event_id", "")) if payment_data.get("event_id") else None,
            "event_name": str(payment_data.get("event_name", "")) if payment_data.get("event_name") else None,
            # Reconciliation fields
            "reconciliation_status": "pending",  # pending, received_by_admin
            "received_by_admin": None,
            "received_by_admin_name": None,
            "received_at": None,
            "reconciliation_notes": ""
        }
        
        await db.payments.insert_one(payment)
        
        # If this is an event order payment, update the event order's payment status
        if payment.get("event_id"):
            event_order = await db.event_orders.find_one({"id": payment["event_id"]})
            if event_order:
                # Calculate total paid amount for this event
                total_paid = event_order.get("advance_amount", 0)
                
                # Get all payments for this event
                event_payments = await db.payments.find({
                    "event_id": payment["event_id"]
                }).to_list(1000)
                
                # Sum up all payment collections (excluding advance)
                for pmt in event_payments:
                    if pmt.get("payment_type") in ["event_order_payment", "event_payment"]:
                        total_paid += pmt.get("amount", 0)
                
                # Determine payment status
                total_amount = event_order.get("total_amount", 0)
                if total_paid >= total_amount:
                    payment_status = "fully_paid"
                elif total_paid > event_order.get("advance_amount", 0):
                    payment_status = "advance_paid"  # Has advance + some payment
                else:
                    payment_status = "advance_paid" if event_order.get("advance_amount", 0) > 0 else "pending"
                
                # Update event order
                await db.event_orders.update_one(
                    {"id": payment["event_id"]},
                    {
                        "$set": {
                            "payment_status": payment_status,
                            "last_payment_amount": payment["amount"],
                            "last_payment_date": payment["collected_at"],
                            "last_payment_mode": payment["payment_mode"],
                            "payment_collected_by": payment["collected_by_name"],
                            "balance_amount": total_amount - total_paid,
                            "updated_at": datetime.now(timezone.utc).isoformat()
                        }
                    }
                )
        
        return clean_mongo_doc(payment)
        
    except Exception as e:
        print(f"Payment creation error: {str(e)}")
        print(f"Payment data received: {payment_data}")
        raise HTTPException(status_code=422, detail=f"Payment creation failed: {str(e)}")

@api_router.get("/customer-payments")
async def get_customer_payments(current_user: User = Depends(get_current_user)):
    payments = await db.payments.find().sort("collected_at", -1).to_list(1000)
    return clean_mongo_docs(payments)

# Payment Reconciliation APIs
@api_router.post("/payments/{payment_id}/receive")
async def admin_receive_payment(payment_id: str, reconciliation_data: dict, current_user: User = Depends(get_current_user)):
    """Admin receives payment from delivery boy/manager"""
    try:
        # Check if user is admin
        if current_user.role != "admin":
            raise HTTPException(status_code=403, detail="Only admin can receive payments")
        
        # Find the payment
        payment = await db.payments.find_one({"id": payment_id})
        if not payment:
            raise HTTPException(status_code=404, detail="Payment not found")
        
        # Check if payment is still pending
        if payment.get("reconciliation_status") != "pending":
            raise HTTPException(status_code=400, detail="Payment has already been received")
        
        # Update payment reconciliation status
        update_data = {
            "reconciliation_status": "received_by_admin",
            "received_by_admin": current_user.id,
            "received_by_admin_name": current_user.name,
            "received_at": datetime.now(timezone.utc).isoformat(),
            "reconciliation_notes": reconciliation_data.get("notes", "")
        }
        
        await db.payments.update_one(
            {"id": payment_id},
            {"$set": update_data}
        )
        
        # Get updated payment
        updated_payment = await db.payments.find_one({"id": payment_id})
        return clean_mongo_doc(updated_payment)
        
    except Exception as e:
        print(f"Payment reconciliation error: {str(e)}")
        raise HTTPException(status_code=422, detail=f"Payment reconciliation failed: {str(e)}")

@api_router.get("/payments/pending-reconciliation")
async def get_pending_payments(current_user: User = Depends(get_current_user)):
    """Get all payments pending admin reconciliation"""
    try:
        # Check if user is admin
        if current_user.role != "admin":
            raise HTTPException(status_code=403, detail="Only admin can view pending payments")
        
        # Get all pending payments
        pending_payments = await db.payments.find({
            "reconciliation_status": "pending"
        }).sort("collected_at", -1).to_list(1000)
        
        return clean_mongo_docs(pending_payments)
        
    except Exception as e:
        print(f"Error fetching pending payments: {str(e)}")
        raise HTTPException(status_code=422, detail=f"Failed to fetch pending payments: {str(e)}")

@api_router.get("/payments/reconciliation-summary")
async def get_reconciliation_summary(current_user: User = Depends(get_current_user)):
    """Get payment reconciliation summary by collector"""
    try:
        # Check if user is admin
        if current_user.role != "admin":
            raise HTTPException(status_code=403, detail="Only admin can view reconciliation summary")
        
        # Get all payments
        all_payments = await db.payments.find().sort("collected_at", -1).to_list(1000)
        
        # Group by collector and reconciliation status
        summary = {}
        total_pending = 0
        total_received = 0
        
        # Also calculate payment type breakdown
        payment_type_summary = {}
        
        for payment in all_payments:
            collector_id = payment.get("collected_by")
            collector_name = payment.get("collected_by_name", "Unknown")
            amount = payment.get("amount", 0)
            status = payment.get("reconciliation_status", "pending")
            payment_type = payment.get("payment_type", "customer_payment")
            
            if collector_id not in summary:
                summary[collector_id] = {
                    "collector_id": collector_id,
                    "collector_name": collector_name,
                    "pending_amount": 0,
                    "pending_count": 0,
                    "received_amount": 0,
                    "received_count": 0,
                    "total_amount": 0,
                    "total_count": 0,
                    "payment_types": {}
                }
            
            # Update collector summary
            summary[collector_id]["total_amount"] += amount
            summary[collector_id]["total_count"] += 1
            
            # Track payment types for each collector
            if payment_type not in summary[collector_id]["payment_types"]:
                summary[collector_id]["payment_types"][payment_type] = {"amount": 0, "count": 0}
            summary[collector_id]["payment_types"][payment_type]["amount"] += amount
            summary[collector_id]["payment_types"][payment_type]["count"] += 1
            
            # Overall payment type summary
            if payment_type not in payment_type_summary:
                payment_type_summary[payment_type] = {"amount": 0, "count": 0, "pending": 0, "received": 0}
            payment_type_summary[payment_type]["amount"] += amount
            payment_type_summary[payment_type]["count"] += 1
            
            if status == "pending":
                summary[collector_id]["pending_amount"] += amount
                summary[collector_id]["pending_count"] += 1
                payment_type_summary[payment_type]["pending"] += amount
                total_pending += amount
            else:
                summary[collector_id]["received_amount"] += amount
                summary[collector_id]["received_count"] += 1
                payment_type_summary[payment_type]["received"] += amount
                total_received += amount
        
        return {
            "collectors": list(summary.values()),
            "payment_types": payment_type_summary,
            "totals": {
                "total_pending_amount": total_pending,
                "total_received_amount": total_received,
                "total_amount": total_pending + total_received
            }
        }
        
    except Exception as e:
        print(f"Error fetching reconciliation summary: {str(e)}")
        raise HTTPException(status_code=422, detail=f"Failed to fetch reconciliation summary: {str(e)}")

# Empty Jar Collections API  
@api_router.post("/empty-jar-collections")
async def create_empty_jar_collection(collection_data: dict, current_user: User = Depends(get_current_user)):
    collection = {
        "id": str(uuid.uuid4()),
        "customer_id": collection_data["customer_id"],
        "customer_name": collection_data["customer_name"],
        "jars_collected": collection_data["jars_collected"],
        "collection_notes": collection_data.get("collection_notes", ""),
        "collected_by": collection_data["collected_by"],
        "collected_by_name": collection_data["collected_by_name"],
        "collected_at": collection_data["collected_at"],
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.empty_jar_collections.insert_one(collection)
    return clean_mongo_doc(collection)

@api_router.get("/empty-jar-collections")
async def get_empty_jar_collections(current_user: User = Depends(get_current_user)):
    collections = await db.empty_jar_collections.find().sort("collected_at", -1).to_list(1000)
    return clean_mongo_docs(collections)

# Combined Financial Reports API
@api_router.get("/reports/combined-financial")
async def get_combined_financial_reports(
    start_date: str,
    end_date: str,
    report_type: str = "daily",  # daily, monthly
    current_user: User = Depends(get_current_user)
):
    """Get combined financial reports including all collections and expenses"""
    try:
        # Parse dates
        start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
        
        # Collections from various sources
        collections_query = {
            "payment_date": {
                "$gte": start_dt,
                "$lte": end_dt
            }
        }
        
        # Get all payment collections
        regular_payments = await db.payments.find(collections_query).to_list(1000)
        customer_payments = await db.customer_payments.find(collections_query).to_list(1000)
        
        # Get delivered orders (cash collections)
        delivered_orders = await db.orders.find({
            "delivery_date": {
                "$gte": start_dt,
                "$lte": end_dt
            },
            "delivery_status": "delivered",
            "payment_status": "paid"
        }).to_list(1000)
        
        # Get completed event orders
        completed_events = await db.event_orders.find({
            "delivery_completed_at": {
                "$gte": start_dt,
                "$lte": end_dt
            },
            "event_status": "completed"
        }).to_list(1000)
        
        # Get expenses - handle both datetime and string formats
        expenses = await db.expenses.find({
            "$or": [
                {
                    "expense_date": {
                        "$gte": start_dt,
                        "$lte": end_dt
                    }
                },
                {
                    "expense_date": {
                        "$gte": start_date,
                        "$lte": end_date
                    }
                }
            ]
        }).to_list(1000)
        
        # Process data by date
        daily_reports = {}
        
        # Get cancelled event orders with forfeited advance
        cancelled_events = await db.event_orders.find({
            "event_status": "cancelled",
            "updated_at": {
                "$gte": start_dt,
                "$lte": end_dt
            },
            "advance_amount": {"$gt": 0}
        }).to_list(1000)
        
        # Process regular payments
        for payment in regular_payments:
            date_key = payment['payment_date'][:10] if isinstance(payment['payment_date'], str) else payment['payment_date'].strftime('%Y-%m-%d')
            
            if date_key not in daily_reports:
                daily_reports[date_key] = {
                    "date": date_key,
                    "collections": {
                        "regular_payments": 0,
                        "customer_payments": 0, 
                        "order_collections": 0,
                        "event_collections": 0,
                        "advance_forfeited": 0,  # New: Forfeited advance amounts
                        "admin_received": 0,     # New: Collections received by admin
                        "total": 0
                    },
                    "expenses": {
                        "fuel": 0,
                        "salary": 0,
                        "maintenance": 0,
                        "office": 0,
                        "transport": 0,
                        "utilities": 0,
                        "marketing": 0,         # New expense category
                        "repair": 0,           # New expense category
                        "insurance": 0,        # New expense category
                        "miscellaneous": 0,    # New expense category
                        "other": 0,
                        "total": 0
                    },
                    "admin_expenses": {        # New: Admin-specific expenses
                        "admin_approved": 0,
                        "admin_created": 0,
                        "total": 0
                    },
                    "net_profit": 0,
                    "collection_count": 0,
                    "expense_count": 0
                }
            
            amount = payment.get('amount', 0)
            daily_reports[date_key]["collections"]["regular_payments"] += amount
            daily_reports[date_key]["collection_count"] += 1
            
            # Check if collected by admin
            if payment.get('collected_by') and 'admin' in payment.get('collected_by', '').lower():
                daily_reports[date_key]["collections"]["admin_received"] += amount
        
        # Process customer payments
        for payment in customer_payments:
            date_key = payment['payment_date'][:10] if isinstance(payment['payment_date'], str) else payment['payment_date'].strftime('%Y-%m-%d')
            
            if date_key not in daily_reports:
                daily_reports[date_key] = {
                    "date": date_key,
                    "collections": {
                        "regular_payments": 0,
                        "customer_payments": 0,
                        "order_collections": 0,
                        "event_collections": 0,
                        "advance_forfeited": 0,
                        "admin_received": 0,
                        "total": 0
                    },
                    "expenses": {
                        "fuel": 0,
                        "salary": 0,
                        "maintenance": 0,
                        "office": 0,
                        "transport": 0,
                        "utilities": 0,
                        "marketing": 0,
                        "repair": 0,
                        "insurance": 0,
                        "miscellaneous": 0,
                        "other": 0,
                        "total": 0
                    },
                    "admin_expenses": {
                        "admin_approved": 0,
                        "admin_created": 0,
                        "total": 0
                    },
                    "net_profit": 0,
                    "collection_count": 0,
                    "expense_count": 0
                }
            
            amount = payment.get('amount', 0)
            daily_reports[date_key]["collections"]["customer_payments"] += amount
            daily_reports[date_key]["collection_count"] += 1
            
            # Check if collected by admin
            if payment.get('collected_by') and 'admin' in payment.get('collected_by', '').lower():
                daily_reports[date_key]["collections"]["admin_received"] += amount
        
        # Process order collections
        for order in delivered_orders:
            date_key = order['delivery_date'][:10] if isinstance(order['delivery_date'], str) else order['delivery_date'].strftime('%Y-%m-%d')
            
            if date_key not in daily_reports:
                daily_reports[date_key] = {
                    "date": date_key,
                    "collections": {
                        "regular_payments": 0,
                        "customer_payments": 0,
                        "order_collections": 0,
                        "event_collections": 0,
                        "advance_forfeited": 0,
                        "admin_received": 0,
                        "total": 0
                    },
                    "expenses": {
                        "fuel": 0,
                        "salary": 0,
                        "maintenance": 0,
                        "office": 0,
                        "transport": 0,
                        "utilities": 0,
                        "marketing": 0,
                        "repair": 0,
                        "insurance": 0,
                        "miscellaneous": 0,
                        "other": 0,
                        "total": 0
                    },
                    "admin_expenses": {
                        "admin_approved": 0,
                        "admin_created": 0,
                        "total": 0
                    },
                    "net_profit": 0,
                    "collection_count": 0,
                    "expense_count": 0
                }
            
            amount = order.get('total_amount', 0)
            daily_reports[date_key]["collections"]["order_collections"] += amount
            daily_reports[date_key]["collection_count"] += 1
            
            # Check if collected by admin (check delivery_boy_name or other admin indicators)
            delivery_boy = order.get('delivery_boy_name', '')
            if delivery_boy and 'admin' in delivery_boy.lower():
                daily_reports[date_key]["collections"]["admin_received"] += amount
        
        # Process event collections
        for event in completed_events:
            date_key = event['delivery_completed_at'][:10] if isinstance(event['delivery_completed_at'], str) else event['delivery_completed_at'].strftime('%Y-%m-%d')
            
            if date_key not in daily_reports:
                daily_reports[date_key] = {
                    "date": date_key,
                    "collections": {
                        "regular_payments": 0,
                        "customer_payments": 0,
                        "order_collections": 0,
                        "event_collections": 0,
                        "advance_forfeited": 0,
                        "admin_received": 0,
                        "total": 0
                    },
                    "expenses": {
                        "fuel": 0,
                        "salary": 0,
                        "maintenance": 0,
                        "office": 0,
                        "transport": 0,
                        "utilities": 0,
                        "marketing": 0,
                        "repair": 0,
                        "insurance": 0,
                        "miscellaneous": 0,
                        "other": 0,
                        "total": 0
                    },
                    "admin_expenses": {
                        "admin_approved": 0,
                        "admin_created": 0,
                        "total": 0
                    },
                    "net_profit": 0,
                    "collection_count": 0,
                    "expense_count": 0
                }
            
            amount = event.get('total_amount', 0)
            daily_reports[date_key]["collections"]["event_collections"] += amount
            daily_reports[date_key]["collection_count"] += 1
            
            # Check if collected by admin
            payment_collected_by = event.get('payment_collected_by', '')
            delivered_by = event.get('delivered_by_name', '')
            if (payment_collected_by and 'admin' in payment_collected_by.lower()) or \
               (delivered_by and 'admin' in delivered_by.lower()):
                daily_reports[date_key]["collections"]["admin_received"] += amount
        
        # Process cancelled events for forfeited advance
        for event in cancelled_events:
            date_key = event['updated_at'][:10] if isinstance(event['updated_at'], str) else event['updated_at'].strftime('%Y-%m-%d')
            
            if date_key not in daily_reports:
                daily_reports[date_key] = {
                    "date": date_key,
                    "collections": {
                        "regular_payments": 0,
                        "customer_payments": 0, 
                        "order_collections": 0,
                        "event_collections": 0,
                        "advance_forfeited": 0,
                        "admin_received": 0,
                        "total": 0
                    },
                    "expenses": {
                        "fuel": 0,
                        "salary": 0,
                        "maintenance": 0,
                        "office": 0,
                        "transport": 0,
                        "utilities": 0,
                        "marketing": 0,
                        "repair": 0,
                        "insurance": 0,
                        "miscellaneous": 0,
                        "other": 0,
                        "total": 0
                    },
                    "admin_expenses": {
                        "admin_approved": 0,
                        "admin_created": 0,
                        "total": 0
                    },
                    "net_profit": 0,
                    "collection_count": 0,
                    "expense_count": 0
                }
            
            # Add forfeited advance to collections
            forfeited_amount = event.get('advance_amount', 0)
            daily_reports[date_key]["collections"]["advance_forfeited"] += forfeited_amount
            daily_reports[date_key]["collections"]["total"] += forfeited_amount
            daily_reports[date_key]["collection_count"] += 1

        # Process expenses
        for expense in expenses:
            # Handle different date formats
            expense_date = expense.get('expense_date')
            if isinstance(expense_date, str):
                # Handle ISO string format
                if 'T' in expense_date:
                    date_key = expense_date.split('T')[0]  # Get date part only
                else:
                    date_key = expense_date[:10]
            else:
                # Handle datetime object
                date_key = expense_date.strftime('%Y-%m-%d') if expense_date else None
            
            if not date_key:
                continue  # Skip if no valid date
            
            if date_key not in daily_reports:
                daily_reports[date_key] = {
                    "date": date_key,
                    "collections": {
                        "regular_payments": 0,
                        "customer_payments": 0,
                        "order_collections": 0,
                        "event_collections": 0,
                        "advance_forfeited": 0,
                        "admin_received": 0,
                        "total": 0
                    },
                    "expenses": {
                        "fuel": 0,
                        "salary": 0,
                        "maintenance": 0,
                        "office": 0,
                        "transport": 0,
                        "utilities": 0,
                        "marketing": 0,
                        "repair": 0,
                        "insurance": 0,
                        "miscellaneous": 0,
                        "other": 0,
                        "total": 0
                    },
                    "admin_expenses": {
                        "admin_approved": 0,
                        "admin_created": 0,
                        "total": 0
                    },
                    "net_profit": 0,
                    "collection_count": 0,
                    "expense_count": 0
                }
            
            # Categorize expense by type
            expense_type = expense.get('category', 'other').lower()
            expense_amount = expense.get('amount', 0)
            
            if expense_type in daily_reports[date_key]["expenses"]:
                daily_reports[date_key]["expenses"][expense_type] += expense_amount
            else:
                daily_reports[date_key]["expenses"]["other"] += expense_amount
            
            daily_reports[date_key]["expenses"]["total"] += expense_amount
            daily_reports[date_key]["expense_count"] += 1
            
            # Track admin-related expenses
            created_by = expense.get('created_by', '')
            approved_by = expense.get('approved_by', '')
            
            if created_by and 'admin' in str(created_by).lower():
                daily_reports[date_key]["admin_expenses"]["admin_created"] += expense_amount
                
            if approved_by and 'admin' in str(approved_by).lower():
                daily_reports[date_key]["admin_expenses"]["admin_approved"] += expense_amount
                
            daily_reports[date_key]["admin_expenses"]["total"] = (
                daily_reports[date_key]["admin_expenses"]["admin_created"] + 
                daily_reports[date_key]["admin_expenses"]["admin_approved"]
            )
        
        # Calculate totals for each day
        for date_key in daily_reports:
            daily_report = daily_reports[date_key]
            
            # Calculate collection totals
            collections = daily_report["collections"]
            collections["total"] = (
                collections["regular_payments"] +
                collections["customer_payments"] +
                collections["order_collections"] +
                collections["event_collections"] +
                collections["advance_forfeited"]
            )
            
            # Calculate expense totals
            expenses = daily_report["expenses"]
            expenses["total"] = (
                expenses["fuel"] +
                expenses["salary"] +
                expenses["maintenance"] +
                expenses["office"] +
                expenses["transport"] +
                expenses["utilities"] +
                expenses["marketing"] +
                expenses["repair"] +
                expenses["insurance"] +
                expenses["miscellaneous"] +
                expenses["other"]
            )
            
            # Calculate net profit
            daily_report["net_profit"] = collections["total"] - expenses["total"]
        
        # Convert to sorted list
        daily_reports_list = sorted(daily_reports.values(), key=lambda x: x["date"])
        
        # Calculate overall totals
        total_stats = {
            "total_collections": sum(day["collections"]["total"] for day in daily_reports_list),
            "total_regular_payments": sum(day["collections"]["regular_payments"] for day in daily_reports_list),
            "total_customer_payments": sum(day["collections"]["customer_payments"] for day in daily_reports_list),
            "total_order_collections": sum(day["collections"]["order_collections"] for day in daily_reports_list),
            "total_event_collections": sum(day["collections"]["event_collections"] for day in daily_reports_list),
            "total_advance_forfeited": sum(day["collections"]["advance_forfeited"] for day in daily_reports_list),
            "total_admin_received": sum(day["collections"]["admin_received"] for day in daily_reports_list),
            "total_expenses": sum(day["expenses"]["total"] for day in daily_reports_list),
            "total_fuel_expenses": sum(day["expenses"]["fuel"] for day in daily_reports_list),
            "total_salary_expenses": sum(day["expenses"]["salary"] for day in daily_reports_list),
            "total_maintenance_expenses": sum(day["expenses"]["maintenance"] for day in daily_reports_list),
            "total_office_expenses": sum(day["expenses"]["office"] for day in daily_reports_list),
            "total_transport_expenses": sum(day["expenses"]["transport"] for day in daily_reports_list),
            "total_utilities_expenses": sum(day["expenses"]["utilities"] for day in daily_reports_list),
            "total_marketing_expenses": sum(day["expenses"]["marketing"] for day in daily_reports_list),
            "total_repair_expenses": sum(day["expenses"]["repair"] for day in daily_reports_list),
            "total_insurance_expenses": sum(day["expenses"]["insurance"] for day in daily_reports_list),
            "total_miscellaneous_expenses": sum(day["expenses"]["miscellaneous"] for day in daily_reports_list),
            "total_other_expenses": sum(day["expenses"]["other"] for day in daily_reports_list),
            "total_admin_expenses": sum(day["admin_expenses"]["total"] for day in daily_reports_list),
            "total_admin_created_expenses": sum(day["admin_expenses"]["admin_created"] for day in daily_reports_list),
            "total_admin_approved_expenses": sum(day["admin_expenses"]["admin_approved"] for day in daily_reports_list),
            "net_profit": sum(day["net_profit"] for day in daily_reports_list),
            "total_collection_transactions": sum(day["collection_count"] for day in daily_reports_list),
            "total_expense_transactions": sum(day["expense_count"] for day in daily_reports_list),
            "profit_margin": 0.0
        }
        
        # Calculate profit margin
        if total_stats["total_collections"] > 0:
            total_stats["profit_margin"] = (total_stats["net_profit"] / total_stats["total_collections"]) * 100
        
        return {
            "daily_reports": daily_reports_list,
            "total_stats": total_stats,
            "date_range": {
                "start_date": start_date,
                "end_date": end_date
            },
            "report_type": report_type,
            "generated_at": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        print(f"Error generating combined financial reports: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/reports/combined-financial/export")
async def export_combined_financial_reports(
    start_date: str,
    end_date: str,
    format: str = "excel",
    report_type: str = "daily",
    current_user: User = Depends(get_current_user)
):
    """Export combined financial reports as PDF or Excel"""
    try:
        # Get report data using existing function
        report_response = await get_combined_financial_reports(start_date, end_date, report_type, current_user)
        
        if format.lower() == "excel":
            # Create Excel file
            output = io.BytesIO()
            
            # Prepare data for Excel
            excel_data = []
            for daily_report in report_response["daily_reports"]:
                excel_data.append({
                    "Date": daily_report["date"],
                    "Regular Payments": daily_report["collections"]["regular_payments"],
                    "Customer Payments": daily_report["collections"]["customer_payments"],
                    "Order Collections": daily_report["collections"]["order_collections"],
                    "Event Collections": daily_report["collections"]["event_collections"],
                    "Advance Forfeited": daily_report["collections"]["advance_forfeited"],
                    "Admin Received": daily_report["collections"]["admin_received"],
                    "Total Collections": daily_report["collections"]["total"],
                    "Fuel Expenses": daily_report["expenses"]["fuel"],
                    "Salary Expenses": daily_report["expenses"]["salary"],
                    "Maintenance Expenses": daily_report["expenses"]["maintenance"],
                    "Office Expenses": daily_report["expenses"]["office"],
                    "Transport Expenses": daily_report["expenses"]["transport"],
                    "Utilities Expenses": daily_report["expenses"]["utilities"],
                    "Other Expenses": daily_report["expenses"]["other"],
                    "Total Expenses": daily_report["expenses"]["total"],
                    "Net Profit": daily_report["net_profit"],
                    "Collection Count": daily_report["collection_count"],
                    "Expense Count": daily_report["expense_count"]
                })
            
            try:
                import pandas as pd
                from openpyxl import Workbook
                from openpyxl.styles import Font, PatternFill
                
                # Create workbook
                wb = Workbook()
                ws = wb.active
                ws.title = "Financial Summary"
                
                # Add headers
                headers = list(excel_data[0].keys()) if excel_data else []
                for col_num, header in enumerate(headers, 1):
                    ws.cell(row=1, column=col_num, value=header)
                    ws.cell(row=1, column=col_num).font = Font(bold=True)
                    ws.cell(row=1, column=col_num).fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
                
                # Add data
                for row_num, record in enumerate(excel_data, 2):
                    for col_num, value in enumerate(record.values(), 1):
                        ws.cell(row=row_num, column=col_num, value=value)
                
                # Add summary sheet
                summary_ws = wb.create_sheet("Summary")
                summary_stats = report_response["total_stats"]
                
                summary_data = [
                    ["Total Collections", summary_stats["total_collections"]],
                    ["Regular Payments", summary_stats["total_regular_payments"]],
                    ["Customer Payments", summary_stats["total_customer_payments"]],
                    ["Order Collections", summary_stats["total_order_collections"]],
                    ["Event Collections", summary_stats["total_event_collections"]],
                    ["Advance Forfeited", summary_stats["total_advance_forfeited"]],
                    ["Admin Received", summary_stats["total_admin_received"]],
                    ["Total Expenses", summary_stats["total_expenses"]],
                    ["Net Profit", summary_stats["net_profit"]],
                    ["Profit Margin %", round(summary_stats["profit_margin"], 2)],
                    ["Collection Transactions", summary_stats["total_collection_transactions"]],
                    ["Expense Transactions", summary_stats["total_expense_transactions"]]
                ]
                
                for row_num, (label, value) in enumerate(summary_data, 1):
                    summary_ws.cell(row=row_num, column=1, value=label).font = Font(bold=True)
                    summary_ws.cell(row=row_num, column=2, value=value)
                
                wb.save(output)
                
            except ImportError:
                # Fallback without pandas
                import csv
                output = io.StringIO()
                if excel_data:
                    writer = csv.DictWriter(output, fieldnames=excel_data[0].keys())
                    writer.writeheader()
                    writer.writerows(excel_data)
                
                # Convert to bytes
                csv_content = output.getvalue()
                output = io.BytesIO(csv_content.encode('utf-8'))
            
            output.seek(0)
            
            # Return Excel file
            filename = f"combined_financial_report_{start_date[:10]}_{end_date[:10]}.xlsx"
            
            return StreamingResponse(
                io.BytesIO(output.read()),
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
            
        elif format.lower() == "pdf":
            # Create Invoice-style PDF using reportlab
            buffer = io.BytesIO()
            # Create PDF with proper header space
            from reportlab.platypus import PageTemplate, Frame, BaseDocTemplate
            from reportlab.lib.pagesizes import A4
            from reportlab.platypus.tableofcontents import SimpleIndex
            import os
            
            # Get contact details for footer
            contact_details = await get_contact_details_for_pdf()
            
            # Use common header function (footer will be added at end)
            def draw_header(canvas, doc):
                draw_pdf_header_and_footer(canvas, doc, None, False)
            
            # Create document with custom template
            doc = BaseDocTemplate(buffer, pagesize=A4, rightMargin=20, leftMargin=20, topMargin=100, bottomMargin=30)
            
            # Create frame for content (starts below header)
            content_frame = Frame(20, 30, A4[0] - 40, A4[1] - 130, id='content')
            
            # Add page template with header function
            template = PageTemplate('header_template', [content_frame], onPage=draw_header)
            doc.addPageTemplates([template])
            
            elements = []
            styles = getSampleStyleSheet()
            
            # Report title (center aligned as requested)
            report_title = f"""
            <para align=center>
            <b><font size=18>COMBINED FINANCIAL REPORT</font></b>
            </para>
            """
            
            title_style = ParagraphStyle('ReportTitle',
                parent=styles['Normal'],
                alignment=1,
                spaceAfter=15,
                spaceBefore=20,
                textColor=colors.black)
            
            elements.append(Paragraph(report_title, title_style))
            
            # Report details (invoice-style layout)
            total_stats = report_response["total_stats"]
            report_details = f"""
            <para>
            <b>Report Number:</b> CFR-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}<br/>
            <b>Report Period:</b> {start_date[:10]} to {start_date[:10] if start_date == end_date else end_date[:10]}<br/>
            <b>Generated Date:</b> {datetime.now(timezone.utc).strftime('%d %B %Y at %H:%M UTC')}<br/>
            <b>Report Type:</b> Financial Summary Report
            </para>
            """
            
            details_style = ParagraphStyle('ReportDetails',
                parent=styles['Normal'],
                fontSize=11,
                spaceAfter=20,
                leftIndent=0,
                textColor=colors.black)
            
            elements.append(Paragraph(report_details, details_style))
            
            # Financial Status Box - Fixed width table to prevent overflow
            profit_status = "PROFIT" if total_stats['net_profit'] >= 0 else "LOSS"
            status_symbol = "✓" if total_stats['net_profit'] >= 0 else "⚠️"
            
            status_data = [
                [f"{status_symbol} FINANCIAL STATUS: {profit_status}"],
                [f"Net Profit: ₹{total_stats['net_profit']:,.0f} | Margin: {total_stats['profit_margin']:.1f}%"]
            ]
            
            status_table = Table(status_data, colWidths=[7.5*inch])
            status_table.setStyle(TableStyle([
                # Status header
                ('BACKGROUND', (0, 0), (-1, 0), colors.lightblue if total_stats['net_profit'] >= 0 else colors.mistyrose),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('TOPPADDING', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                
                # Status details
                ('FONTNAME', (0, 1), (-1, 1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, 1), 10),
                ('TOPPADDING', (0, 1), (-1, 1), 8),
                ('BOTTOMPADDING', (0, 1), (-1, 1), 10),
                
                # Border
                ('BOX', (0, 0), (-1, -1), 2, colors.black),
                ('LINEBELOW', (0, 0), (-1, 0), 1, colors.black),
                
                # Text wrapping
                ('WORDWRAP', (0, 0), (-1, -1), True),
            ]))
            
            elements.append(status_table)
            elements.append(Spacer(1, 15))
            
            # Invoice-style financial summary table with proper sizing
            summary_data = [
                ["Financial Metric", "Amount", "Details"],
                ["Total Collections", f"₹{total_stats['total_collections']:,.0f}", f"{total_stats['total_collection_transactions']} txns"],
                ["Less: Total Expenses", f"₹{total_stats['total_expenses']:,.0f}", f"{total_stats['total_expense_transactions']} txns"],
                ["", "", ""],
                ["Net Profit/Loss", f"₹{total_stats['net_profit']:,.0f}", f"{total_stats['profit_margin']:.1f}% margin"]
            ]
            
            # Full width table with reduced margins
            summary_table = Table(summary_data, colWidths=[3.5*inch, 2.2*inch, 1.8*inch])
            summary_table.setStyle(TableStyle([
                # Invoice-style header
                ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('TOPPADDING', (0, 0), (-1, 0), 8),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                ('LEFTPADDING', (0, 0), (-1, -1), 8),
                ('RIGHTPADDING', (0, 0), (-1, -1), 8),
                
                # Invoice-style data rows
                ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -1), 9),
                ('TOPPADDING', (0, 1), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
                
                # Empty row for spacing
                ('TOPPADDING', (0, 3), (-1, 3), 2),
                ('BOTTOMPADDING', (0, 3), (-1, 3), 2),
                
                # Net Profit row - properly positioned at bottom like invoice total
                ('FONTNAME', (0, 4), (-1, 4), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 4), (-1, 4), 11),
                ('BACKGROUND', (0, 4), (-1, 4), colors.lightblue if total_stats['net_profit'] >= 0 else colors.mistyrose),
                
                # Invoice-style borders
                ('BOX', (0, 0), (-1, -1), 1, colors.black),
                ('LINEBELOW', (0, 0), (-1, 0), 2, colors.black),
                ('LINEABOVE', (0, 4), (-1, 4), 2, colors.black),
                ('LINEBELOW', (0, 4), (-1, 4), 2, colors.black),
                
                # Word wrapping for overflow prevention
                ('WORDWRAP', (0, 0), (-1, -1), True),
            ]))
            
            elements.append(summary_table)
            elements.append(Spacer(1, 20))
            
            # Collections Breakdown (Invoice Item Style)
            collections_heading = f"""
            <para>
            <b><font size=12>Collections Breakdown:</font></b>
            </para>
            """
            
            heading_style = ParagraphStyle('ItemHeading',
                parent=styles['Normal'],
                fontSize=12,
                spaceAfter=10,
                spaceBefore=15,
                fontName='Helvetica-Bold',
                textColor=colors.black)
            
            elements.append(Paragraph(collections_heading, heading_style))
            
            collections_data = [
                ["Source", "Amount", "Count"],
                ["Regular Payments", f"₹{total_stats['total_regular_payments']:,.0f}", f"{total_stats.get('regular_payment_count', 0)}"],
                ["Customer Payments", f"₹{total_stats['total_customer_payments']:,.0f}", f"{total_stats.get('customer_payment_count', 0)}"],
                ["Order Collections", f"₹{total_stats['total_order_collections']:,.0f}", f"{total_stats.get('order_collection_count', 0)}"],
                ["Event Collections", f"₹{total_stats['total_event_collections']:,.0f}", f"{total_stats.get('event_collection_count', 0)}"],
                ["Advance Forfeited", f"₹{total_stats['total_advance_forfeited']:,.0f}", f"{total_stats.get('advance_forfeited_count', 0)}"],
                ["Admin Received", f"₹{total_stats['total_admin_received']:,.0f}", f"{total_stats.get('admin_received_count', 0)}"],
                ["TOTAL", f"₹{total_stats['total_collections']:,.0f}", f"{total_stats['total_collection_transactions']}"]
            ]
            
            # Full width collections table
            collections_table = Table(collections_data, colWidths=[3.5*inch, 2.2*inch, 1.8*inch])
            collections_table.setStyle(TableStyle([
                # Invoice-style header
                ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('TOPPADDING', (0, 0), (-1, 0), 8),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                ('LEFTPADDING', (0, 0), (-1, -1), 8),
                ('RIGHTPADDING', (0, 0), (-1, -1), 8),
                
                # Data rows (invoice item style)
                ('FONTNAME', (0, 1), (-1, -2), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -2), 9),
                ('TOPPADDING', (0, 1), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
                
                # Total row (like invoice total)
                ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                ('FONTSIZE', (0, -1), (-1, -1), 10),
                ('BACKGROUND', (0, -1), (-1, -1), colors.lightblue),
                
                # Invoice-style borders
                ('BOX', (0, 0), (-1, -1), 1, colors.black),
                ('LINEBELOW', (0, 0), (-1, 0), 2, colors.black),
                ('LINEABOVE', (0, -1), (-1, -1), 2, colors.black),
                
                # Prevent text overflow
                ('WORDWRAP', (0, 0), (-1, -1), True),
            ]))
            
            elements.append(collections_table)
            elements.append(Spacer(1, 15))
            
            # Expenses Breakdown (Invoice Item Style)
            expenses_heading = f"""
            <para>
            <b><font size=12>Expenses Breakdown:</font></b>
            </para>
            """
            
            elements.append(Paragraph(expenses_heading, heading_style))
            
            expenses_data = [
                ["Category", "Amount", "Percent"],
                ["Fuel Expenses", f"₹{total_stats['total_fuel_expenses']:,.0f}", f"{(total_stats['total_fuel_expenses']/total_stats['total_expenses']*100) if total_stats['total_expenses'] > 0 else 0:.0f}%"],
                ["Salary Expenses", f"₹{total_stats['total_salary_expenses']:,.0f}", f"{(total_stats['total_salary_expenses']/total_stats['total_expenses']*100) if total_stats['total_expenses'] > 0 else 0:.0f}%"],
                ["Maintenance", f"₹{total_stats['total_maintenance_expenses']:,.0f}", f"{(total_stats['total_maintenance_expenses']/total_stats['total_expenses']*100) if total_stats['total_expenses'] > 0 else 0:.0f}%"],
                ["Other", f"₹{(total_stats['total_office_expenses'] + total_stats['total_transport_expenses'] + total_stats['total_utilities_expenses'] + total_stats['total_other_expenses']):,.0f}", f"{((total_stats['total_office_expenses'] + total_stats['total_transport_expenses'] + total_stats['total_utilities_expenses'] + total_stats['total_other_expenses'])/total_stats['total_expenses']*100) if total_stats['total_expenses'] > 0 else 0:.0f}%"],
                ["TOTAL", f"₹{total_stats['total_expenses']:,.0f}", "100%" if total_stats['total_expenses'] > 0 else "0%"]
            ]
            
            # Full width expenses table
            expenses_table = Table(expenses_data, colWidths=[3.5*inch, 2.2*inch, 1.8*inch])
            expenses_table.setStyle(TableStyle([
                # Invoice-style header
                ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('TOPPADDING', (0, 0), (-1, 0), 8),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                ('LEFTPADDING', (0, 0), (-1, -1), 8),
                ('RIGHTPADDING', (0, 0), (-1, -1), 8),
                
                # Data rows (invoice item style)
                ('FONTNAME', (0, 1), (-1, -2), 'Helvetica'),
                ('FONTSIZE', (0, 1), (-1, -2), 9),
                ('TOPPADDING', (0, 1), (-1, -1), 6),
                ('BOTTOMPADDING', (0, 1), (-1, -1), 6),
                
                # Total row (like invoice total)
                ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
                ('FONTSIZE', (0, -1), (-1, -1), 10),
                ('BACKGROUND', (0, -1), (-1, -1), colors.mistyrose),
                
                # Invoice-style borders
                ('BOX', (0, 0), (-1, -1), 1, colors.black),
                ('LINEBELOW', (0, 0), (-1, 0), 2, colors.black),
                ('LINEABOVE', (0, -1), (-1, -1), 2, colors.black),
                
                # Prevent text overflow
                ('WORDWRAP', (0, 0), (-1, -1), True),
            ]))
            
            elements.append(expenses_table)
            elements.append(Spacer(1, 20))
            
            # Footer with signature on right side
            footer_data = [
                [
                    f"""Report Summary:
• Total Transactions: {total_stats['total_collection_transactions']} collections, {total_stats['total_expense_transactions']} expenses
• Financial Period: {start_date[:10]} to {start_date[:10] if start_date == end_date else end_date[:10]}
• Report Status: Final Financial Summary

Contact Information:
📞 +91-98765-43210 | 📧 info@aquaelite.com
🌐 www.aquaelite.com""",
                    f"""Authorized Signature:

________________________________

AquaElite Management Team

Date: {datetime.now(timezone.utc).strftime('%d %B %Y')}"""
                ]
            ]
            
            footer_table = Table(footer_data, colWidths=[4.5*inch, 3.0*inch])
            footer_table.setStyle(TableStyle([
                # Left column (summary)
                ('FONTNAME', (0, 0), (0, 0), 'Helvetica'),
                ('FONTSIZE', (0, 0), (0, 0), 9),
                ('ALIGN', (0, 0), (0, 0), 'LEFT'),
                ('VALIGN', (0, 0), (0, 0), 'TOP'),
                ('LEFTPADDING', (0, 0), (0, 0), 0),
                ('RIGHTPADDING', (0, 0), (0, 0), 20),
                
                # Right column (signature)
                ('FONTNAME', (1, 0), (1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (1, 0), (1, 0), 10),
                ('ALIGN', (1, 0), (1, 0), 'RIGHT'),
                ('VALIGN', (1, 0), (1, 0), 'TOP'),
                ('LEFTPADDING', (1, 0), (1, 0), 20),
                ('RIGHTPADDING', (1, 0), (1, 0), 0),
                
                # No borders for clean look
                ('TOPPADDING', (0, 0), (-1, -1), 15),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
            ]))
            
            elements.append(footer_table)
            
            # Add contact information footer on last page
            elements.append(Spacer(1, 20))
            
            # Contact information section
            contact_heading = Paragraph("<b><font size=10>Contact Information:</font></b>", styles['Normal'])
            elements.append(contact_heading)
            elements.append(Spacer(1, 5))
            
            # Admin contact
            admin_info = contact_details.get("admin", {})
            admin_para = Paragraph(
                f"<font size=9>Admin ({admin_info.get('name', 'Admin')}): 📞 {admin_info.get('phone', 'N/A')} | 📧 {admin_info.get('email', 'N/A')}</font>",
                styles['Normal']
            )
            elements.append(admin_para)
            
            # Manager contact - only if exists
            manager_info = contact_details.get("manager", {})
            if manager_info.get("exists", False):
                elements.append(Spacer(1, 3))
                manager_para = Paragraph(
                    f"<font size=9>Manager ({manager_info.get('name', 'Manager')}): 📞 {manager_info.get('phone', 'N/A')} | 📧 {manager_info.get('email', 'N/A')}</font>",
                    styles['Normal']
                )
                elements.append(manager_para)
            
            # Build PDF
            doc.build(elements)
            buffer.seek(0)
            
            filename = f"combined_financial_report_{start_date[:10]}_{end_date[:10]}.pdf"
            
            return StreamingResponse(
                io.BytesIO(buffer.read()),
                media_type="application/pdf",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
            
    except Exception as e:
        print(f"Error exporting combined financial reports: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Payment Reconciliation Entry-wise Report
@api_router.get("/reports/payment-reconciliation")
async def get_payment_reconciliation_report(
    start_date: str,
    end_date: str,
    status: str = "all",  # all, pending, received_by_admin
    current_user: User = Depends(get_current_user)
):
    """Get payment reconciliation entry-wise report"""
    try:
        # Parse dates
        start = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        end = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
        
        # Build query
        query = {
            "collected_at": {
                "$gte": start.isoformat(),
                "$lte": end.isoformat()
            }
        }
        
        if status != "all":
            query["reconciliation_status"] = status
        
        # Get payments
        payments = await db.payments.find(query).sort("collected_at", -1).to_list(10000)
        
        # Calculate summary stats
        total_payments = len(payments)
        total_amount = sum(p.get("amount", 0) for p in payments)
        pending_count = sum(1 for p in payments if p.get("reconciliation_status") == "pending")
        pending_amount = sum(p.get("amount", 0) for p in payments if p.get("reconciliation_status") == "pending")
        received_count = sum(1 for p in payments if p.get("reconciliation_status") == "received_by_admin")
        received_amount = sum(p.get("amount", 0) for p in payments if p.get("reconciliation_status") == "received_by_admin")
        
        # Group by payment type
        payment_types = {}
        for payment in payments:
            ptype = payment.get("payment_type", "other")
            if ptype not in payment_types:
                payment_types[ptype] = {"count": 0, "amount": 0}
            payment_types[ptype]["count"] += 1
            payment_types[ptype]["amount"] += payment.get("amount", 0)
        
        return {
            "payments": clean_mongo_docs(payments),
            "summary": {
                "total_payments": total_payments,
                "total_amount": total_amount,
                "pending_count": pending_count,
                "pending_amount": pending_amount,
                "received_count": received_count,
                "received_amount": received_amount,
                "payment_types": payment_types
            },
            "date_range": {
                "start_date": start_date,
                "end_date": end_date
            },
            "generated_at": datetime.now(timezone.utc).isoformat()
        }
    except Exception as e:
        print(f"Error generating payment reconciliation report: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/reports/payment-reconciliation/export")
async def export_payment_reconciliation_report(
    start_date: str,
    end_date: str,
    status: str = "all",
    format: str = "excel",
    current_user: User = Depends(get_current_user)
):
    """Export payment reconciliation report as PDF or Excel"""
    try:
        # Get report data
        report_response = await get_payment_reconciliation_report(start_date, end_date, status, current_user)
        
        if format.lower() == "excel":
            # Create Excel file
            output = io.BytesIO()
            
            # Prepare data for Excel
            excel_data = []
            for payment in report_response["payments"]:
                excel_data.append({
                    "Date": payment.get("collected_at", "")[:10],
                    "Customer Name": payment.get("customer_name", ""),
                    "Amount": payment.get("amount", 0),
                    "Payment Mode": payment.get("payment_mode", ""),
                    "Payment Type": payment.get("payment_type", ""),
                    "Collected By": payment.get("collected_by_name", ""),
                    "Status": payment.get("reconciliation_status", ""),
                    "Received By": payment.get("received_by_admin_name", ""),
                    "Notes": payment.get("notes", "")
                })
            
            try:
                from openpyxl import Workbook
                from openpyxl.styles import Font, PatternFill, Alignment
                
                wb = Workbook()
                ws = wb.active
                ws.title = "Payment Reconciliation"
                
                # Add headers
                headers = list(excel_data[0].keys()) if excel_data else []
                for col_num, header in enumerate(headers, 1):
                    cell = ws.cell(row=1, column=col_num, value=header)
                    cell.font = Font(bold=True, color="FFFFFF")
                    cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
                    cell.alignment = Alignment(horizontal="center")
                
                # Add data
                for row_num, record in enumerate(excel_data, 2):
                    for col_num, value in enumerate(record.values(), 1):
                        ws.cell(row=row_num, column=col_num, value=value)
                
                # Adjust column widths
                for column in ws.columns:
                    max_length = 0
                    column = [cell for cell in column]
                    for cell in column:
                        try:
                            if len(str(cell.value)) > max_length:
                                max_length = len(cell.value)
                        except:
                            pass
                    adjusted_width = (max_length + 2)
                    ws.column_dimensions[column[0].column_letter].width = adjusted_width
                
                # Add summary sheet
                summary_ws = wb.create_sheet("Summary")
                summary_stats = report_response["summary"]
                
                summary_data = [
                    ["Total Payments", summary_stats["total_payments"]],
                    ["Total Amount", f"₹{summary_stats['total_amount']:,.2f}"],
                    ["Pending Payments", summary_stats["pending_count"]],
                    ["Pending Amount", f"₹{summary_stats['pending_amount']:,.2f}"],
                    ["Received Payments", summary_stats["received_count"]],
                    ["Received Amount", f"₹{summary_stats['received_amount']:,.2f}"]
                ]
                
                for row_num, (label, value) in enumerate(summary_data, 1):
                    summary_ws.cell(row=row_num, column=1, value=label).font = Font(bold=True)
                    summary_ws.cell(row=row_num, column=2, value=value)
                
                wb.save(output)
                
            except ImportError:
                # Fallback to CSV
                import csv
                output = io.StringIO()
                if excel_data:
                    writer = csv.DictWriter(output, fieldnames=excel_data[0].keys())
                    writer.writeheader()
                    writer.writerows(excel_data)
                
                csv_content = output.getvalue()
                output = io.BytesIO(csv_content.encode('utf-8'))
            
            output.seek(0)
            filename = f"payment_reconciliation_{start_date[:10]}_{end_date[:10]}.xlsx"
            
            return StreamingResponse(
                io.BytesIO(output.read()),
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
            
        elif format.lower() == "pdf":
            # Create PDF
            buffer = io.BytesIO()
            from reportlab.platypus import PageTemplate, Frame, BaseDocTemplate
            from reportlab.lib.pagesizes import A4
            
            # Get contact details for footer
            contact_details = await get_contact_details_for_pdf()
            
            def draw_header(canvas, doc):
                draw_pdf_header_and_footer(canvas, doc, contact_details)
            
            doc = BaseDocTemplate(buffer, pagesize=A4, rightMargin=20, leftMargin=20, topMargin=100, bottomMargin=30)
            content_frame = Frame(20, 30, A4[0] - 40, A4[1] - 130, id='content')
            template = PageTemplate('header_template', [content_frame], onPage=draw_header)
            doc.addPageTemplates([template])
            
            elements = []
            styles = getSampleStyleSheet()
            
            # Report title
            report_title = f"""
            <para align=center>
            <b><font size=18>PAYMENT RECONCILIATION REPORT</font></b>
            </para>
            """
            
            title_style = ParagraphStyle('ReportTitle',
                parent=styles['Normal'],
                alignment=1,
                spaceAfter=15,
                spaceBefore=20,
                textColor=colors.black)
            
            elements.append(Paragraph(report_title, title_style))
            
            # Report details
            summary_stats = report_response["summary"]
            report_details = f"""
            <para>
            <b>Report Period:</b> {start_date[:10]} to {end_date[:10]}<br/>
            <b>Generated Date:</b> {datetime.now(timezone.utc).strftime('%d %B %Y at %H:%M UTC')}<br/>
            <b>Status Filter:</b> {status.title()}<br/>
            <b>Total Payments:</b> {summary_stats['total_payments']} payments worth ₹{summary_stats['total_amount']:,.2f}
            </para>
            """
            
            details_style = ParagraphStyle('ReportDetails',
                parent=styles['Normal'],
                fontSize=10,
                spaceAfter=20,
                leftIndent=0,
                textColor=colors.black)
            
            elements.append(Paragraph(report_details, details_style))
            
            # Summary table
            summary_data = [
                ["Metric", "Count", "Amount"],
                ["Total Payments", str(summary_stats['total_payments']), f"₹{summary_stats['total_amount']:,.2f}"],
                ["Pending", str(summary_stats['pending_count']), f"₹{summary_stats['pending_amount']:,.2f}"],
                ["Received by Admin", str(summary_stats['received_count']), f"₹{summary_stats['received_amount']:,.2f}"]
            ]
            
            summary_table = Table(summary_data, colWidths=[2.5*inch, 2*inch, 2.5*inch])
            summary_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            elements.append(summary_table)
            elements.append(Spacer(1, 20))
            
            # Payment entries table (limited to first 50 for PDF)
            payments_heading = Paragraph("<b><font size=12>Payment Entries:</font></b>", styles['Normal'])
            elements.append(payments_heading)
            elements.append(Spacer(1, 10))
            
            payment_data = [["Date", "Customer", "Amount", "Type", "Collected By", "Status"]]
            for payment in report_response["payments"][:50]:  # Limit to 50 entries
                payment_data.append([
                    payment.get("collected_at", "")[:10],
                    payment.get("customer_name", "")[:18],
                    f"₹{payment.get('amount', 0):,.0f}",
                    payment.get("payment_type", "")[:12],
                    payment.get("collected_by_name", "N/A")[:15],
                    payment.get("reconciliation_status", "")[:10]
                ])
            
            payment_table = Table(payment_data, colWidths=[0.9*inch, 1.6*inch, 1*inch, 1.4*inch, 1.4*inch, 1.2*inch])
            payment_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 8),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black)
            ]))
            
            elements.append(payment_table)
            
            if len(report_response["payments"]) > 50:
                note = Paragraph(f"<i>Note: Showing first 50 of {len(report_response['payments'])} payments. Download Excel for complete data.</i>", styles['Normal'])
                elements.append(Spacer(1, 10))
                elements.append(note)
            
            # Add contact information footer
            elements.append(Spacer(1, 20))
            contact_heading = Paragraph("<b><font size=10>Contact Information:</font></b>", styles['Normal'])
            elements.append(contact_heading)
            elements.append(Spacer(1, 5))
            
            # Admin contact
            admin_info = contact_details.get("admin", {})
            admin_para = Paragraph(
                f"<font size=9>Admin ({admin_info.get('name', 'Admin')}): 📞 {admin_info.get('phone', 'N/A')} | 📧 {admin_info.get('email', 'N/A')}</font>",
                styles['Normal']
            )
            elements.append(admin_para)
            
            # Manager contact - only if exists
            manager_info = contact_details.get("manager", {})
            if manager_info.get("exists", False):
                elements.append(Spacer(1, 3))
                manager_para = Paragraph(
                    f"<font size=9>Manager ({manager_info.get('name', 'Manager')}): 📞 {manager_info.get('phone', 'N/A')} | 📧 {manager_info.get('email', 'N/A')}</font>",
                    styles['Normal']
                )
                elements.append(manager_para)
            
            doc.build(elements)
            buffer.seek(0)
            
            filename = f"payment_reconciliation_{start_date[:10]}_{end_date[:10]}.pdf"
            
            return StreamingResponse(
                io.BytesIO(buffer.read()),
                media_type="application/pdf",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
            
    except Exception as e:
        print(f"Error exporting payment reconciliation report: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Expense Entry-wise Report
@api_router.get("/reports/expenses")
async def get_expense_report(
    start_date: str,
    end_date: str,
    category: str = "all",
    current_user: User = Depends(get_current_user)
):
    """Get expense entry-wise report"""
    try:
        # Parse dates
        start = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        end = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
        
        # Build query
        query = {
            "expense_date": {
                "$gte": start.isoformat(),
                "$lte": end.isoformat()
            }
        }
        
        if category != "all":
            query["category"] = category
        
        # Get expenses
        expenses = await db.expenses.find(query).sort("expense_date", -1).to_list(10000)
        
        # Calculate summary stats
        total_expenses = len(expenses)
        total_amount = sum(e.get("amount", 0) for e in expenses)
        
        # Group by category
        categories = {}
        for expense in expenses:
            cat = expense.get("category", "other")
            if cat not in categories:
                categories[cat] = {"count": 0, "amount": 0}
            categories[cat]["count"] += 1
            categories[cat]["amount"] += expense.get("amount", 0)
        
        # Group by created_by
        created_by_stats = {}
        for expense in expenses:
            creator = expense.get("created_by", "unknown")
            if creator not in created_by_stats:
                created_by_stats[creator] = {"count": 0, "amount": 0}
            created_by_stats[creator]["count"] += 1
            created_by_stats[creator]["amount"] += expense.get("amount", 0)
        
        return {
            "expenses": clean_mongo_docs(expenses),
            "summary": {
                "total_expenses": total_expenses,
                "total_amount": total_amount,
                "categories": categories,
                "created_by_stats": created_by_stats
            },
            "date_range": {
                "start_date": start_date,
                "end_date": end_date
            },
            "generated_at": datetime.now(timezone.utc).isoformat()
        }
    except Exception as e:
        print(f"Error generating expense report: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/reports/expenses/export")
async def export_expense_report(
    start_date: str,
    end_date: str,
    category: str = "all",
    format: str = "excel",
    current_user: User = Depends(get_current_user)
):
    """Export expense report as PDF or Excel"""
    try:
        # Get report data
        report_response = await get_expense_report(start_date, end_date, category, current_user)
        
        if format.lower() == "excel":
            # Create Excel file
            output = io.BytesIO()
            
            # Prepare data for Excel
            excel_data = []
            for expense in report_response["expenses"]:
                excel_data.append({
                    "Date": expense.get("expense_date", "")[:10],
                    "Title": expense.get("title", ""),
                    "Category": expense.get("category", ""),
                    "Amount": expense.get("amount", 0),
                    "Description": expense.get("description", ""),
                    "Created By": expense.get("created_by", ""),
                    "Approved By": expense.get("approved_by", ""),
                    "Payment Method": expense.get("payment_method", "")
                })
            
            try:
                from openpyxl import Workbook
                from openpyxl.styles import Font, PatternFill, Alignment
                
                wb = Workbook()
                ws = wb.active
                ws.title = "Expenses"
                
                # Add headers
                headers = list(excel_data[0].keys()) if excel_data else []
                for col_num, header in enumerate(headers, 1):
                    cell = ws.cell(row=1, column=col_num, value=header)
                    cell.font = Font(bold=True, color="FFFFFF")
                    cell.fill = PatternFill(start_color="C00000", end_color="C00000", fill_type="solid")
                    cell.alignment = Alignment(horizontal="center")
                
                # Add data
                for row_num, record in enumerate(excel_data, 2):
                    for col_num, value in enumerate(record.values(), 1):
                        ws.cell(row=row_num, column=col_num, value=value)
                
                # Adjust column widths
                for column in ws.columns:
                    max_length = 0
                    column = [cell for cell in column]
                    for cell in column:
                        try:
                            if len(str(cell.value)) > max_length:
                                max_length = len(cell.value)
                        except:
                            pass
                    adjusted_width = (max_length + 2)
                    ws.column_dimensions[column[0].column_letter].width = adjusted_width
                
                # Add summary sheet
                summary_ws = wb.create_sheet("Summary")
                summary_stats = report_response["summary"]
                
                summary_data = [
                    ["Total Expenses", summary_stats["total_expenses"]],
                    ["Total Amount", f"₹{summary_stats['total_amount']:,.2f}"],
                    ["", ""],
                    ["Category Breakdown", ""]
                ]
                
                for category, stats in summary_stats["categories"].items():
                    summary_data.append([category.title(), f"₹{stats['amount']:,.2f} ({stats['count']} entries)"])
                
                for row_num, (label, value) in enumerate(summary_data, 1):
                    summary_ws.cell(row=row_num, column=1, value=label).font = Font(bold=True)
                    summary_ws.cell(row=row_num, column=2, value=value)
                
                wb.save(output)
                
            except ImportError:
                # Fallback to CSV
                import csv
                output = io.StringIO()
                if excel_data:
                    writer = csv.DictWriter(output, fieldnames=excel_data[0].keys())
                    writer.writeheader()
                    writer.writerows(excel_data)
                
                csv_content = output.getvalue()
                output = io.BytesIO(csv_content.encode('utf-8'))
            
            output.seek(0)
            filename = f"expenses_{start_date[:10]}_{end_date[:10]}.xlsx"
            
            return StreamingResponse(
                io.BytesIO(output.read()),
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
            
        elif format.lower() == "pdf":
            # Create PDF
            buffer = io.BytesIO()
            from reportlab.platypus import PageTemplate, Frame, BaseDocTemplate
            from reportlab.lib.pagesizes import A4
            
            # Get contact details for footer
            contact_details = await get_contact_details_for_pdf()
            
            def draw_header(canvas, doc):
                draw_pdf_header_and_footer(canvas, doc, contact_details)
            
            doc = BaseDocTemplate(buffer, pagesize=A4, rightMargin=20, leftMargin=20, topMargin=100, bottomMargin=30)
            content_frame = Frame(20, 30, A4[0] - 40, A4[1] - 130, id='content')
            template = PageTemplate('header_template', [content_frame], onPage=draw_header)
            doc.addPageTemplates([template])
            
            elements = []
            styles = getSampleStyleSheet()
            
            # Report title
            report_title = f"""
            <para align=center>
            <b><font size=18>EXPENSE REPORT</font></b>
            </para>
            """
            
            title_style = ParagraphStyle('ReportTitle',
                parent=styles['Normal'],
                alignment=1,
                spaceAfter=15,
                spaceBefore=20,
                textColor=colors.black)
            
            elements.append(Paragraph(report_title, title_style))
            
            # Report details
            summary_stats = report_response["summary"]
            report_details = f"""
            <para>
            <b>Report Period:</b> {start_date[:10]} to {end_date[:10]}<br/>
            <b>Generated Date:</b> {datetime.now(timezone.utc).strftime('%d %B %Y at %H:%M UTC')}<br/>
            <b>Category Filter:</b> {category.title()}<br/>
            <b>Total Expenses:</b> {summary_stats['total_expenses']} entries worth ₹{summary_stats['total_amount']:,.2f}
            </para>
            """
            
            details_style = ParagraphStyle('ReportDetails',
                parent=styles['Normal'],
                fontSize=10,
                spaceAfter=20,
                leftIndent=0,
                textColor=colors.black)
            
            elements.append(Paragraph(report_details, details_style))
            
            # Category summary table
            category_data = [["Category", "Count", "Amount"]]
            for cat, stats in summary_stats["categories"].items():
                category_data.append([
                    cat.title(),
                    str(stats['count']),
                    f"₹{stats['amount']:,.2f}"
                ])
            
            category_table = Table(category_data, colWidths=[2.5*inch, 2*inch, 2.5*inch])
            category_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            elements.append(category_table)
            elements.append(Spacer(1, 20))
            
            # Expense entries table (limited to first 50 for PDF)
            expenses_heading = Paragraph("<b><font size=12>Expense Entries:</font></b>", styles['Normal'])
            elements.append(expenses_heading)
            elements.append(Spacer(1, 10))
            
            expense_data = [["Date", "Title", "Category", "Amount", "Created By"]]
            for expense in report_response["expenses"][:50]:  # Limit to 50 entries
                expense_data.append([
                    expense.get("expense_date", "")[:10],
                    expense.get("title", "")[:22],
                    expense.get("category", "")[:12],
                    f"₹{expense.get('amount', 0):,.0f}",
                    expense.get("created_by", "N/A")[:15]
                ])
            
            expense_table = Table(expense_data, colWidths=[0.9*inch, 2.3*inch, 1.3*inch, 1.2*inch, 1.8*inch])
            expense_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 8),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.black)
            ]))
            
            elements.append(expense_table)
            
            if len(report_response["expenses"]) > 50:
                note = Paragraph(f"<i>Note: Showing first 50 of {len(report_response['expenses'])} expenses. Download Excel for complete data.</i>", styles['Normal'])
                elements.append(Spacer(1, 10))
                elements.append(note)
            
            # Add contact information footer
            elements.append(Spacer(1, 20))
            contact_heading = Paragraph("<b><font size=10>Contact Information:</font></b>", styles['Normal'])
            elements.append(contact_heading)
            elements.append(Spacer(1, 5))
            
            # Admin contact
            admin_info = contact_details.get("admin", {})
            admin_para = Paragraph(
                f"<font size=9>Admin ({admin_info.get('name', 'Admin')}): 📞 {admin_info.get('phone', 'N/A')} | 📧 {admin_info.get('email', 'N/A')}</font>",
                styles['Normal']
            )
            elements.append(admin_para)
            
            # Manager contact - only if exists
            manager_info = contact_details.get("manager", {})
            if manager_info.get("exists", False):
                elements.append(Spacer(1, 3))
                manager_para = Paragraph(
                    f"<font size=9>Manager ({manager_info.get('name', 'Manager')}): 📞 {manager_info.get('phone', 'N/A')} | 📧 {manager_info.get('email', 'N/A')}</font>",
                    styles['Normal']
                )
                elements.append(manager_para)
            
            doc.build(elements)
            buffer.seek(0)
            
            filename = f"expenses_{start_date[:10]}_{end_date[:10]}.pdf"
            
            return StreamingResponse(
                io.BytesIO(buffer.read()),
                media_type="application/pdf",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
            
    except Exception as e:
        print(f"Error exporting expense report: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Simplified Combined Financial Report
@api_router.get("/reports/financial-summary")
async def get_financial_summary_report(
    start_date: str,
    end_date: str,
    current_user: User = Depends(get_current_user)
):
    """Get simplified financial summary: Event Collections, Customer Collections, and Expenses"""
    try:
        # Parse dates
        start = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        end = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
        
        # 1. Calculate Total Event Collections
        # Get all events and filter by payment collection date
        all_event_orders = await db.event_orders.find({
            "event_status": {"$ne": "cancelled"}
        }).to_list(10000)
        
        total_event_collections = 0
        event_count = 0
        
        for event in all_event_orders:
            # Calculate payments collected in the date range
            advance_amount = event.get("advance_amount", 0) or 0  # Handle None
            advance_date = event.get("created_at")
            
            last_payment_amount = event.get("last_payment_amount", 0) or 0  # Handle None
            last_payment_date = event.get("last_payment_date")
            
            payment_in_range = 0
            
            # Check if advance was collected in date range
            if advance_amount and advance_amount > 0 and advance_date:
                try:
                    advance_dt = datetime.fromisoformat(advance_date.replace('Z', '+00:00'))
                    if start <= advance_dt <= end:
                        payment_in_range += advance_amount
                except (ValueError, AttributeError, TypeError):
                    pass
            
            # Check if last payment was collected in date range
            if last_payment_amount and last_payment_amount > 0 and last_payment_date:
                try:
                    if isinstance(last_payment_date, str):
                        payment_dt = datetime.fromisoformat(last_payment_date.replace('Z', '+00:00'))
                    else:
                        payment_dt = last_payment_date
                    if start <= payment_dt <= end:
                        payment_in_range += last_payment_amount
                except (ValueError, AttributeError, TypeError):
                    pass
            
            if payment_in_range > 0:
                total_event_collections += payment_in_range
                event_count += 1
        
        # 1.1 Calculate Advance Forfeited from Cancelled Events
        # Filter by cancellation date, not event date
        all_cancelled_events = await db.event_orders.find({
            "event_status": "cancelled",
            "advance_forfeited": True
        }).to_list(10000)
        
        total_advance_forfeited = 0
        advance_forfeited_count = 0
        
        for event in all_cancelled_events:
            cancelled_at = event.get("cancelled_at")
            if cancelled_at:
                try:
                    # Handle both string and datetime objects
                    if isinstance(cancelled_at, str):
                        cancelled_dt = datetime.fromisoformat(cancelled_at.replace('Z', '+00:00'))
                    else:
                        # Already a datetime object
                        cancelled_dt = cancelled_at
                        # Make timezone aware if needed
                        if cancelled_dt.tzinfo is None:
                            cancelled_dt = cancelled_dt.replace(tzinfo=timezone.utc)
                    
                    if start <= cancelled_dt <= end:
                        total_advance_forfeited += event.get("advance_amount", 0) or 0
                        advance_forfeited_count += 1
                except (ValueError, AttributeError, TypeError) as e:
                    print(f"Error parsing cancelled_at for event {event.get('event_name')}: {e}")
                    pass
        
        # 2. Calculate Regular Customer Collections
        # Get payments from customers
        customer_payments = await db.payments.find({
            "collected_at": {
                "$gte": start.isoformat(),
                "$lte": end.isoformat()
            }
        }).to_list(10000)
        
        total_customer_collections = sum(p.get("amount", 0) for p in customer_payments)
        customer_payment_count = len(customer_payments)
        
        # Get quick delivery orders
        orders = await db.orders.find({
            "order_date": {
                "$gte": start.isoformat(),
                "$lte": end.isoformat()
            }
        }).to_list(10000)
        
        total_order_collections = sum(o.get("total_amount", 0) for o in orders)
        order_count = len(orders)
        
        total_regular_collections = total_customer_collections + total_order_collections
        
        # 3. Calculate Total Expenses
        expenses = await db.expenses.find({
            "expense_date": {
                "$gte": start.isoformat(),
                "$lte": end.isoformat()
            }
        }).to_list(10000)
        
        total_expenses = sum(e.get("amount", 0) for e in expenses)
        expense_count = len(expenses)
        
        # Group expenses by category
        expenses_by_category = {}
        for expense in expenses:
            category = expense.get("category", "other")
            if category not in expenses_by_category:
                expenses_by_category[category] = {"count": 0, "amount": 0}
            expenses_by_category[category]["count"] += 1
            expenses_by_category[category]["amount"] += expense.get("amount", 0)
        
        # Calculate totals and profit
        total_collections = total_event_collections + total_regular_collections + total_advance_forfeited
        net_profit = total_collections - total_expenses
        profit_margin = (net_profit / total_collections * 100) if total_collections > 0 else 0
        
        return {
            "summary": {
                "event_collections": {
                    "amount": total_event_collections,
                    "count": event_count
                },
                "advance_forfeited": {
                    "amount": total_advance_forfeited,
                    "count": advance_forfeited_count
                },
                "regular_collections": {
                    "amount": total_regular_collections,
                    "customer_payments": total_customer_collections,
                    "order_collections": total_order_collections,
                    "count": customer_payment_count + order_count
                },
                "total_collections": total_collections,
                "expenses": {
                    "amount": total_expenses,
                    "count": expense_count,
                    "by_category": expenses_by_category
                },
                "net_profit": net_profit,
                "profit_margin": profit_margin
            },
            "date_range": {
                "start_date": start_date,
                "end_date": end_date
            },
            "generated_at": datetime.now(timezone.utc).isoformat()
        }
        
    except Exception as e:
        import traceback
        print(f"Error generating financial summary: {e}")
        print(f"Traceback: {traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/reports/financial-summary/export")
async def export_financial_summary(
    start_date: str,
    end_date: str,
    format: str = "pdf",
    current_user: User = Depends(get_current_user)
):
    """Export financial summary report as PDF or Excel"""
    try:
        # Get report data
        report_data = await get_financial_summary_report(start_date, end_date, current_user)
        summary = report_data["summary"]
        
        if format.lower() == "excel":
            # Create Excel file
            output = io.BytesIO()
            
            try:
                from openpyxl import Workbook
                from openpyxl.styles import Font, PatternFill, Alignment
                
                wb = Workbook()
                ws = wb.active
                ws.title = "Financial Summary"
                
                # Title
                ws['A1'] = "AquaElite Financial Summary Report"
                ws['A1'].font = Font(size=16, bold=True)
                ws.merge_cells('A1:C1')
                
                # Date range
                ws['A2'] = f"Period: {start_date[:10]} to {end_date[:10]}"
                ws.merge_cells('A2:C2')
                
                # Headers
                row = 4
                ws[f'A{row}'] = "Category"
                ws[f'B{row}'] = "Amount"
                ws[f'C{row}'] = "Count"
                for col in ['A', 'B', 'C']:
                    ws[f'{col}{row}'].font = Font(bold=True, color="FFFFFF")
                    ws[f'{col}{row}'].fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
                    ws[f'{col}{row}'].alignment = Alignment(horizontal="center")
                
                # Data
                row += 1
                ws[f'A{row}'] = "Event Collections"
                ws[f'B{row}'] = summary["event_collections"]["amount"]
                ws[f'C{row}'] = summary["event_collections"]["count"]
                
                row += 1
                ws[f'A{row}'] = "Advance Forfeited (Cancelled Events)"
                ws[f'B{row}'] = summary["advance_forfeited"]["amount"]
                ws[f'C{row}'] = summary["advance_forfeited"]["count"]
                
                row += 1
                ws[f'A{row}'] = "Regular Customer Collections"
                ws[f'B{row}'] = summary["regular_collections"]["amount"]
                ws[f'C{row}'] = summary["regular_collections"]["count"]
                
                row += 1
                ws[f'A{row}'] = "Total Collections"
                ws[f'B{row}'] = summary["total_collections"]
                ws[f'A{row}'].font = Font(bold=True)
                ws[f'B{row}'].font = Font(bold=True)
                
                row += 2
                ws[f'A{row}'] = "Total Expenses"
                ws[f'B{row}'] = summary["expenses"]["amount"]
                ws[f'C{row}'] = summary["expenses"]["count"]
                
                row += 2
                ws[f'A{row}'] = "Net Profit"
                ws[f'B{row}'] = summary["net_profit"]
                ws[f'A{row}'].font = Font(bold=True, color="00FF00" if summary["net_profit"] >= 0 else "FF0000")
                ws[f'B{row}'].font = Font(bold=True, color="00FF00" if summary["net_profit"] >= 0 else "FF0000")
                
                # Adjust column widths
                ws.column_dimensions['A'].width = 30
                ws.column_dimensions['B'].width = 20
                ws.column_dimensions['C'].width = 15
                
                wb.save(output)
                
            except ImportError:
                # Fallback to CSV
                import csv
                output = io.StringIO()
                writer = csv.writer(output)
                writer.writerow(["AquaElite Financial Summary Report"])
                writer.writerow([f"Period: {start_date[:10]} to {end_date[:10]}"])
                writer.writerow([])
                writer.writerow(["Category", "Amount", "Count"])
                writer.writerow(["Event Collections", summary["event_collections"]["amount"], summary["event_collections"]["count"]])
                writer.writerow(["Advance Forfeited (Cancelled Events)", summary["advance_forfeited"]["amount"], summary["advance_forfeited"]["count"]])
                writer.writerow(["Regular Customer Collections", summary["regular_collections"]["amount"], summary["regular_collections"]["count"]])
                writer.writerow(["Total Collections", summary["total_collections"], ""])
                writer.writerow([])
                writer.writerow(["Total Expenses", summary["expenses"]["amount"], summary["expenses"]["count"]])
                writer.writerow([])
                writer.writerow(["Net Profit", summary["net_profit"], ""])
                
                csv_content = output.getvalue()
                output = io.BytesIO(csv_content.encode('utf-8'))
            
            output.seek(0)
            filename = f"financial_summary_{start_date[:10]}_{end_date[:10]}.xlsx"
            
            return StreamingResponse(
                io.BytesIO(output.read()),
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
            
        elif format.lower() == "pdf":
            # Create PDF
            buffer = io.BytesIO()
            from reportlab.platypus import PageTemplate, Frame, BaseDocTemplate
            from reportlab.lib.pagesizes import A4
            
            # Get contact details for footer
            contact_details = await get_contact_details_for_pdf()
            
            # Use common header function (footer will be added at end)
            def draw_header(canvas, doc):
                draw_pdf_header_and_footer(canvas, doc, None, False)
            
            doc = BaseDocTemplate(buffer, pagesize=A4, rightMargin=20, leftMargin=20, topMargin=100, bottomMargin=30)
            content_frame = Frame(20, 30, A4[0] - 40, A4[1] - 130, id='content')
            template = PageTemplate('header_template', [content_frame], onPage=draw_header)
            doc.addPageTemplates([template])
            
            elements = []
            styles = getSampleStyleSheet()
            
            # Report title
            report_title = """
            <para align=center>
            <b><font size=18>FINANCIAL SUMMARY REPORT</font></b>
            </para>
            """
            
            title_style = ParagraphStyle('ReportTitle',
                parent=styles['Normal'],
                alignment=1,
                spaceAfter=15,
                spaceBefore=20,
                textColor=colors.black)
            
            elements.append(Paragraph(report_title, title_style))
            
            # Report details
            report_details = f"""
            <para>
            <b>Report Period:</b> {start_date[:10]} to {end_date[:10]}<br/>
            <b>Generated Date:</b> {datetime.now(timezone.utc).strftime('%d %B %Y at %H:%M UTC')}
            </para>
            """
            
            details_style = ParagraphStyle('ReportDetails',
                parent=styles['Normal'],
                fontSize=10,
                spaceAfter=20,
                leftIndent=0,
                textColor=colors.black)
            
            elements.append(Paragraph(report_details, details_style))
            
            # Summary table
            summary_data = [
                ["Category", "Amount", "Count"],
                ["Event Collections", f"₹{summary['event_collections']['amount']:,.2f}", str(summary['event_collections']['count'])],
                ["Advance Forfeited (Cancelled)", f"₹{summary['advance_forfeited']['amount']:,.2f}", str(summary['advance_forfeited']['count'])],
                ["Regular Customer Collections", f"₹{summary['regular_collections']['amount']:,.2f}", str(summary['regular_collections']['count'])],
                ["", "", ""],
                ["Total Collections", f"₹{summary['total_collections']:,.2f}", ""],
                ["", "", ""],
                ["Total Expenses", f"₹{summary['expenses']['amount']:,.2f}", str(summary['expenses']['count'])],
                ["", "", ""],
                ["Net Profit", f"₹{summary['net_profit']:,.2f}", ""],
                ["Profit Margin", f"{summary['profit_margin']:.2f}%", ""]
            ]
            
            summary_table = Table(summary_data, colWidths=[3*inch, 2.5*inch, 2*inch])
            summary_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('FONTNAME', (0, 5), (-1, 5), 'Helvetica-Bold'),  # Total Collections
                ('FONTNAME', (0, 7), (-1, 7), 'Helvetica-Bold'),  # Total Expenses
                ('FONTNAME', (0, 9), (-1, 10), 'Helvetica-Bold')  # Net Profit and Profit Margin
            ]))
            
            elements.append(summary_table)
            elements.append(Spacer(1, 20))
            
            # Expense breakdown by category
            if summary['expenses']['by_category']:
                expenses_heading = Paragraph("<b><font size=12>Expense Breakdown by Category:</font></b>", styles['Normal'])
                elements.append(expenses_heading)
                elements.append(Spacer(1, 10))
                
                expense_data = [["Category", "Amount", "Count"]]
                for category, stats in summary['expenses']['by_category'].items():
                    expense_data.append([
                        category.title(),
                        f"₹{stats['amount']:,.2f}",
                        str(stats['count'])
                    ])
                
                expense_table = Table(expense_data, colWidths=[3*inch, 2.5*inch, 2*inch])
                expense_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, -1), 9),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 8),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 0.5, colors.black)
                ]))
                
                elements.append(expense_table)
            
            # Add contact information footer
            elements.append(Spacer(1, 20))
            contact_heading = Paragraph("<b><font size=10>Contact Information:</font></b>", styles['Normal'])
            elements.append(contact_heading)
            elements.append(Spacer(1, 5))
            
            # Admin contact
            admin_info = contact_details.get("admin", {})
            admin_para = Paragraph(
                f"<font size=9>Admin ({admin_info.get('name', 'Admin')}): 📞 {admin_info.get('phone', 'N/A')} | 📧 {admin_info.get('email', 'N/A')}</font>",
                styles['Normal']
            )
            elements.append(admin_para)
            
            # Manager contact - only if exists
            manager_info = contact_details.get("manager", {})
            if manager_info.get("exists", False):
                elements.append(Spacer(1, 3))
                manager_para = Paragraph(
                    f"<font size=9>Manager ({manager_info.get('name', 'Manager')}): 📞 {manager_info.get('phone', 'N/A')} | 📧 {manager_info.get('email', 'N/A')}</font>",
                    styles['Normal']
                )
                elements.append(manager_para)
            
            doc.build(elements)
            buffer.seek(0)
            
            filename = f"financial_summary_{start_date[:10]}_{end_date[:10]}.pdf"
            
            return StreamingResponse(
                io.BytesIO(buffer.read()),
                media_type="application/pdf",
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
            
    except Exception as e:
        print(f"Error exporting financial summary: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Include router
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()