#!/usr/bin/env python3
"""
Database Reset Script for AquaElite Application
WARNING: This script will DELETE ALL DATA from the database!
Only one admin user will remain after reset.
"""

import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
import bcrypt
from datetime import datetime, timezone
import uuid
from dotenv import load_dotenv

# Load environment variables
load_dotenv('/app/backend/.env')

# MongoDB connection
MONGO_URL = os.getenv('MONGO_URL', 'mongodb://localhost:27017')
DB_NAME = os.getenv('DB_NAME', 'test_database')

client = AsyncIOMotorClient(MONGO_URL)
db = client[DB_NAME]

def hash_password(password: str) -> str:
    """Hash password using bcrypt"""
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')

# Collections to reset
COLLECTIONS = [
    'users',
    'customers',
    'customer_groups',
    'products',
    'orders',
    'event_orders',
    'archived_event_orders',
    'invoices',
    'payments',
    'expenses',
    'delivery_boys',
    'jar_entries',
    'scheduled_deliveries'
]

async def reset_database():
    """Reset entire database and create fresh admin user"""
    
    print("\n" + "="*70)
    print("🚨 DATABASE RESET SCRIPT - AquaElite Application 🚨")
    print("="*70)
    print(f"\n📊 Database: {DB_NAME}")
    print(f"📊 MongoDB URL: {MONGO_URL}")
    print("\n⚠️  WARNING: This will DELETE ALL DATA from the following collections:")
    for collection in COLLECTIONS:
        print(f"   • {collection}")
    
    print("\n📋 What will remain after reset:")
    print("   • One admin user (email: admin@aquaelite.com)")
    print("   • Password: admin123")
    print("   • All other data will be permanently deleted")
    
    print("\n" + "="*70)
    confirm = input("\n❓ Are you sure you want to proceed? Type 'YES' to confirm: ")
    
    if confirm != 'YES':
        print("\n❌ Reset cancelled. No changes made to database.")
        return
    
    print("\n🔄 Starting database reset...\n")
    
    # Delete all data from collections
    deleted_counts = {}
    for collection_name in COLLECTIONS:
        try:
            collection = db[collection_name]
            result = await collection.delete_many({})
            deleted_counts[collection_name] = result.deleted_count
            print(f"✅ Cleared {collection_name}: {result.deleted_count} documents deleted")
        except Exception as e:
            print(f"⚠️  Error clearing {collection_name}: {str(e)}")
    
    # Create fresh admin user
    print("\n👤 Creating admin user...")
    try:
        admin_user = {
            "id": str(uuid.uuid4()),
            "email": "admin@aquaelite.com",
            "name": "Admin",
            "mobile": "+91-9876543210",
            "role": "admin",
            "password_hash": hash_password("admin123"),
            "is_active": True,
            "permissions": ["admin.*"],
            "assigned_area": None,
            "profile_photo": None,
            "gst_number": None,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        
        await db.users.insert_one(admin_user)
        print("✅ Admin user created successfully")
        print(f"   • Email: admin@aquaelite.com")
        print(f"   • Password: admin123")
        print(f"   • Mobile: +91-9876543210")
        
    except Exception as e:
        print(f"❌ Error creating admin user: {str(e)}")
    
    # Summary
    print("\n" + "="*70)
    print("📊 RESET SUMMARY")
    print("="*70)
    total_deleted = sum(deleted_counts.values())
    print(f"\n✅ Total documents deleted: {total_deleted}")
    print("\n📋 Breakdown:")
    for collection, count in deleted_counts.items():
        if count > 0:
            print(f"   • {collection}: {count} documents")
    
    print("\n✅ Database reset completed successfully!")
    print("\n🔐 Login Credentials:")
    print("   • Email: admin@aquaelite.com")
    print("   • Password: admin123")
    print("   • Mobile: +91-9876543210 (can also login with mobile)")
    
    print("\n💡 Next Steps:")
    print("   1. Login to the application with above credentials")
    print("   2. Update admin profile (name, email, mobile, GST if needed)")
    print("   3. Add your customers, products, and start fresh!")
    
    print("\n" + "="*70 + "\n")

async def main():
    """Main function"""
    try:
        await reset_database()
    except Exception as e:
        print(f"\n❌ Fatal error: {str(e)}")
    finally:
        client.close()

if __name__ == "__main__":
    asyncio.run(main())
