#!/usr/bin/env python3
"""
Update Existing Customers with customer_type Field
This script sets customer_type based on their orders
"""

import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv

load_dotenv('/app/backend/.env')

MONGO_URL = os.getenv('MONGO_URL', 'mongodb://localhost:27017')
DB_NAME = os.getenv('DB_NAME', 'test_database')

async def update_customer_types():
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]
    
    print("\n" + "="*70)
    print("🔄 Updating Customer Types")
    print("="*70 + "\n")
    
    # Get all customers
    customers = await db.customers.find().to_list(1000)
    print(f"📋 Total customers: {len(customers)}\n")
    
    # Get all event orders
    event_orders = await db.event_orders.find().to_list(1000)
    event_customer_ids = {e['customer_id'] for e in event_orders}
    
    # Get all regular orders
    regular_orders = await db.orders.find().to_list(1000)
    regular_customer_ids = {o['customer_id'] for o in regular_orders}
    
    print(f"🎉 Customers with event orders: {len(event_customer_ids)}")
    print(f"📦 Customers with regular orders: {len(regular_customer_ids)}\n")
    
    updated_count = 0
    for customer in customers:
        customer_id = customer['id']
        has_events = customer_id in event_customer_ids
        has_regular = customer_id in regular_customer_ids
        
        # Determine customer type
        if has_events and has_regular:
            customer_type = 'both'
        elif has_events:
            customer_type = 'event'
        else:
            customer_type = 'regular'
        
        # Update customer
        result = await db.customers.update_one(
            {"id": customer_id},
            {"$set": {"customer_type": customer_type}}
        )
        
        if result.modified_count > 0:
            updated_count += 1
            print(f"✅ {customer['name']}: {customer_type}")
    
    print("\n" + "="*70)
    print(f"📊 Summary: Updated {updated_count} customers")
    print("="*70)
    
    print("\n✨ Customer type distribution:")
    regular_count = len([c for c in customers if c['id'] not in event_customer_ids])
    event_only_count = len([c for c in customers if c['id'] in event_customer_ids and c['id'] not in regular_customer_ids])
    both_count = len([c for c in customers if c['id'] in event_customer_ids and c['id'] in regular_customer_ids])
    
    print(f"   Regular only: {regular_count}")
    print(f"   Event only: {event_only_count}")
    print(f"   Both: {both_count}\n")
    
    print("💡 Next Steps:")
    print("   1. Refresh browser")
    print("   2. Customer Management will only show 'regular' and 'both' customers")
    print("   3. Event Order Management will show all customers")
    print("   4. Event-only customers will not appear in Customer Management\n")
    
    client.close()

if __name__ == "__main__":
    asyncio.run(update_customer_types())
