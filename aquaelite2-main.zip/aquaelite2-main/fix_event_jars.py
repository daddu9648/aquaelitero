#!/usr/bin/env python3
"""
Fix Event Jars Delivered - Assume delivered jars = empty jars collected
For historical data where jars_delivered was not tracked
"""

import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv

load_dotenv('/app/backend/.env')

MONGO_URL = os.getenv('MONGO_URL', 'mongodb://localhost:27017')
DB_NAME = os.getenv('DB_NAME', 'test_database')

async def fix_jars_delivered():
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]
    
    print("\n" + "="*70)
    print("🔧 Fixing Event Jars Delivered (Estimate from Empty Jars)")
    print("="*70 + "\n")
    
    # Find completed events with 0 jars_delivered but have empty_jars_collected
    events = await db.event_orders.find({
        "event_status": "completed",
        "jars_delivered": 0
    }).to_list(1000)
    
    print(f"📋 Found {len(events)} completed events with jars_delivered = 0\n")
    
    if len(events) == 0:
        print("✅ All events have jars_delivered set!")
        client.close()
        return
    
    fixed_count = 0
    for event in events:
        empty_jars = event.get('empty_jars_collected', 0)
        
        # If empty jars were collected, assume same number was delivered
        if empty_jars > 0:
            result = await db.event_orders.update_one(
                {"id": event['id']},
                {"$set": {"jars_delivered": empty_jars}}
            )
            
            if result.modified_count > 0:
                fixed_count += 1
                print(f"✅ Fixed: {event.get('event_name')}")
                print(f"   Empty Jars Collected: {empty_jars}")
                print(f"   Set Jars Delivered: {empty_jars}")
                print()
        else:
            print(f"⚠️  Skipped: {event.get('event_name')} (no empty jars collected)")
    
    print("="*70)
    print(f"📊 Summary: Fixed {fixed_count} events")
    print("="*70)
    
    print("\n💡 Assumption:")
    print("   - Empty jars collected = Jars delivered (1:1 ratio)")
    print("   - This is reasonable for completed events")
    print("\n🔄 Next Steps:")
    print("   1. Refresh dashboard")
    print("   2. Event jars delivered should now show correctly\n")
    
    client.close()

if __name__ == "__main__":
    asyncio.run(fix_jars_delivered())
