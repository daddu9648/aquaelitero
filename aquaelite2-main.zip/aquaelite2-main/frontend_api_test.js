// Simple frontend API test for Customer Management Reports
const axios = require('axios');

async function testCustomerManagementReports() {
    const API_BASE = 'https://jar-system.preview.emergentagent.com/api';
    
    try {
        // First login to get token
        console.log('🔐 Logging in...');
        const loginResponse = await axios.post(`${API_BASE}/auth/login`, {
            email: 'testadmin@waterkard.com',
            password: 'admin123'
        });
        
        const token = loginResponse.data.access_token;
        console.log('✅ Login successful');
        
        // Test Customer Management Reports API
        console.log('📊 Testing Customer Management Reports API...');
        
        const endDate = new Date();
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - 7);
        
        const params = new URLSearchParams({
            start_date: startDate.toISOString(),
            end_date: endDate.toISOString()
        });
        
        const response = await axios.get(`${API_BASE}/reports/customer-management?${params}`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        console.log('✅ Customer Management Reports API Response:');
        console.log('Status:', response.status);
        console.log('Data structure:');
        console.log('- date_range:', !!response.data.date_range);
        console.log('- total_stats:', !!response.data.total_stats);
        console.log('- daily_reports:', Array.isArray(response.data.daily_reports));
        console.log('- customers_with_empty_jars:', Array.isArray(response.data.customers_with_empty_jars));
        
        if (response.data.total_stats) {
            console.log('\n📈 Statistics:');
            console.log('- Total deliveries:', response.data.total_stats.total_deliveries);
            console.log('- Total payments: ₹', response.data.total_stats.total_payments);
            console.log('- Active customers:', response.data.total_stats.active_customers);
            console.log('- Uncollected empty jars:', response.data.total_stats.uncollected_empty_jars);
        }
        
        console.log('\n🎉 Customer Management Reports API is working correctly!');
        console.log('The issue is likely in frontend state management or rendering.');
        
    } catch (error) {
        console.error('❌ Error:', error.response?.data || error.message);
    }
}

testCustomerManagementReports();