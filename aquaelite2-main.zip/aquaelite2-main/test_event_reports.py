#!/usr/bin/env python3
"""
Focused test script for Event Order Reports functionality
Testing the specific issue reported by user: "event order reports ko load krne me fail ka error aa raha h"
"""

import requests
import sys
import json
from datetime import datetime, timedelta

class EventReportsAPITester:
    def __init__(self, base_url="https://jar-system.preview.emergentagent.com"):
        self.base_url = base_url
        self.api_url = f"{base_url}/api"
        self.token = None
        self.user_data = None
        self.tests_run = 0
        self.tests_passed = 0

    def run_test(self, name, method, endpoint, expected_status, data=None, headers=None):
        """Run a single API test"""
        url = f"{self.api_url}/{endpoint}"
        test_headers = {'Content-Type': 'application/json'}
        
        if self.token:
            test_headers['Authorization'] = f'Bearer {self.token}'
        
        if headers:
            test_headers.update(headers)

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=test_headers, timeout=30)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=test_headers, timeout=30)
            elif method == 'PUT':
                response = requests.put(url, json=data, headers=test_headers, timeout=30)
            elif method == 'DELETE':
                response = requests.delete(url, headers=test_headers, timeout=30)

            # Handle multiple expected status codes
            if isinstance(expected_status, list):
                success = response.status_code in expected_status
            else:
                success = response.status_code == expected_status
            
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    response_data = response.json()
                    if isinstance(response_data, dict) and len(str(response_data)) < 500:
                        print(f"   Response: {response_data}")
                    elif isinstance(response_data, list):
                        print(f"   Response: List with {len(response_data)} items")
                    return success, response_data
                except:
                    return success, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_data = response.json()
                    print(f"   Error: {error_data}")
                except:
                    print(f"   Error: {response.text}")
                return False, {}

        except requests.exceptions.Timeout:
            print(f"❌ Failed - Request timeout (30s)")
            return False, {}
        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def authenticate(self):
        """Authenticate with the API using testadmin credentials"""
        print("\n" + "="*50)
        print("AUTHENTICATING WITH API")
        print("="*50)
        
        # Try the specified credentials first
        login_data = {
            "email": "testadmin@waterkard.com",
            "password": "admin123"
        }
        
        success, response = self.run_test(
            "Login with testadmin@waterkard.com",
            "POST",
            "auth/login",
            200,
            data=login_data
        )
        
        if success and 'access_token' in response:
            self.token = response['access_token']
            self.user_data = response.get('user', {})
            print(f"   ✅ Authentication successful!")
            print(f"   Token obtained: {self.token[:20]}...")
            print(f"   User: {self.user_data.get('name', 'Unknown')} ({self.user_data.get('role', 'Unknown')})")
            return True
        else:
            print("❌ Authentication failed with testadmin@waterkard.com")
            return False

    def test_event_order_reports(self):
        """Test Event Order Reports functionality specifically"""
        print("\n" + "="*50)
        print("TESTING EVENT ORDER REPORTS FUNCTIONALITY")
        print("="*50)
        
        if not self.token:
            print("❌ Cannot test event order reports - no authentication token")
            return False
        
        # Test 1: Basic Event Order Reports API - GET /api/reports/event-orders
        print("\n--- Testing Basic Event Order Reports API ---")
        
        # Calculate date range (last 30 days)
        end_date = datetime.now()
        start_date = end_date - timedelta(days=30)
        
        # Test with basic parameters
        basic_params = f"start_date={start_date.isoformat()}&end_date={end_date.isoformat()}"
        
        success, response = self.run_test(
            "Event Order Reports - Basic Request",
            "GET",
            f"reports/event-orders?{basic_params}",
            200
        )
        
        if success:
            print("✅ Basic event order reports API working")
            
            # Validate response structure
            expected_fields = ['date_range', 'daily_reports', 'total_stats']
            missing_fields = [field for field in expected_fields if field not in response]
            
            if not missing_fields:
                print("✅ Response structure is correct")
                print(f"   Date range: {response.get('date_range', {}).get('start_date', 'Unknown')} to {response.get('date_range', {}).get('end_date', 'Unknown')}")
                
                # Check total stats
                total_stats = response.get('total_stats', {})
                print(f"   Total events: {total_stats.get('total_events', 0)}")
                print(f"   Completed events: {total_stats.get('completed_events', 0)}")
                print(f"   Cancelled events: {total_stats.get('cancelled_events', 0)}")
                print(f"   Total revenue: ₹{total_stats.get('total_revenue', 0.0)}")
                
                # Check daily reports structure
                daily_reports = response.get('daily_reports', [])
                print(f"   Daily reports count: {len(daily_reports)}")
                
                if daily_reports:
                    sample_report = daily_reports[0]
                    print(f"   Sample daily report date: {sample_report.get('date', 'Unknown')}")
                    print(f"   Sample daily events: {len(sample_report.get('events', []))}")
                else:
                    print("   ⚠️  No daily reports found (may be normal if no events in date range)")
                
            else:
                print(f"❌ Missing fields in response: {missing_fields}")
                return False
        else:
            print("❌ CRITICAL: Basic event order reports API failed")
            print("   This matches the user's reported issue!")
            return False
        
        # Test 2: Event Order Reports with Status Filters
        print("\n--- Testing Event Order Reports with Status Filters ---")
        
        status_filters = ['all', 'completed', 'cancelled']
        
        for status in status_filters:
            params = f"start_date={start_date.isoformat()}&end_date={end_date.isoformat()}&status={status}"
            
            success, response = self.run_test(
                f"Event Order Reports - Status Filter: {status}",
                "GET",
                f"reports/event-orders?{params}",
                200
            )
            
            if success:
                total_stats = response.get('total_stats', {})
                print(f"   Status '{status}': {total_stats.get('total_events', 0)} events, ₹{total_stats.get('total_revenue', 0.0)} revenue")
            else:
                print(f"❌ Failed to get reports for status: {status}")
        
        # Test 3: Event Order Reports Export API
        print("\n--- Testing Event Order Reports Export API ---")
        
        # Test PDF export
        pdf_params = f"start_date={start_date.isoformat()}&end_date={end_date.isoformat()}&format=pdf"
        
        success, response = self.run_test(
            "Event Order Reports Export - PDF",
            "GET",
            f"reports/event-orders/export?{pdf_params}",
            200
        )
        
        if success:
            print("✅ PDF export API working")
        else:
            print("❌ PDF export API failed")
        
        # Test Excel export
        excel_params = f"start_date={start_date.isoformat()}&end_date={end_date.isoformat()}&format=excel"
        
        success, response = self.run_test(
            "Event Order Reports Export - Excel",
            "GET",
            f"reports/event-orders/export?{excel_params}",
            200
        )
        
        if success:
            print("✅ Excel export API working")
        else:
            print("❌ Excel export API failed")
        
        # Test 4: Error Handling
        print("\n--- Testing Error Handling ---")
        
        # Test missing start_date
        success, response = self.run_test(
            "Event Order Reports - Missing start_date (Should Fail)",
            "GET",
            f"reports/event-orders?end_date={end_date.isoformat()}",
            422
        )
        
        if not success:
            print("✅ Correctly rejected request with missing start_date")
        else:
            print("❌ Should have rejected request with missing start_date")
        
        # Test missing end_date
        success, response = self.run_test(
            "Event Order Reports - Missing end_date (Should Fail)",
            "GET",
            f"reports/event-orders?start_date={start_date.isoformat()}",
            422
        )
        
        if not success:
            print("✅ Correctly rejected request with missing end_date")
        else:
            print("❌ Should have rejected request with missing end_date")
        
        # Test 5: Authentication Requirements
        print("\n--- Testing Authentication Requirements ---")
        
        success, response = self.run_test(
            "Event Order Reports - No Authentication (Should Fail)",
            "GET",
            f"reports/event-orders?{basic_params}",
            401,
            headers={"Authorization": "Bearer invalid_token"}
        )
        
        if not success:
            print("✅ Correctly blocked event order reports without authentication")
        else:
            print("❌ Should have blocked event order reports without authentication")
        
        return True

    def check_backend_logs(self):
        """Check backend logs for any errors related to event order reports"""
        print("\n--- Checking Backend Error Logs ---")
        print("Note: This would typically check server logs, but we'll simulate by testing error scenarios")
        
        # Test scenarios that might cause backend errors
        error_scenarios = [
            ("Invalid date range", "start_date=2024-13-01&end_date=2024-12-01"),
            ("Future start date", f"start_date={datetime.now() + timedelta(days=365)}&end_date={datetime.now()}"),
            ("Very large date range", f"start_date=2020-01-01&end_date={datetime.now().isoformat()}")
        ]
        
        for scenario_name, params in error_scenarios:
            success, response = self.run_test(
                f"Backend Error Test - {scenario_name}",
                "GET",
                f"reports/event-orders?{params}",
                [200, 400, 422, 500]  # Accept various error codes
            )
            
            if success:
                print(f"   {scenario_name}: Handled gracefully")
            else:
                print(f"   {scenario_name}: May cause backend errors")

    def run_focused_test(self):
        """Run focused test for event order reports issue"""
        print("🚀 Starting Focused Event Order Reports Testing...")
        print(f"Base URL: {self.base_url}")
        print(f"API URL: {self.api_url}")
        print("Testing specific issue: 'event order reports ko load krne me fail ka error aa raha h'")
        
        # Authenticate first
        if not self.authenticate():
            print("❌ Authentication failed - cannot proceed with testing")
            return 1
        
        # Run event order reports tests
        success = self.test_event_order_reports()
        
        # Check for potential backend issues
        self.check_backend_logs()
        
        # Print final results
        print("\n" + "="*60)
        print("🏁 EVENT ORDER REPORTS TEST RESULTS")
        print("="*60)
        print(f"Total tests run: {self.tests_run}")
        print(f"Tests passed: {self.tests_passed}")
        print(f"Tests failed: {self.tests_run - self.tests_passed}")
        print(f"Success rate: {(self.tests_passed/self.tests_run)*100:.1f}%")
        
        if success and self.tests_passed == self.tests_run:
            print("🎉 EVENT ORDER REPORTS ARE WORKING!")
            print("   The user's reported issue may be resolved or may be a frontend issue.")
        elif success and self.tests_passed < self.tests_run:
            print("⚠️  EVENT ORDER REPORTS PARTIALLY WORKING")
            print("   Some functionality works, but there are issues with certain features.")
        else:
            print("❌ EVENT ORDER REPORTS HAVE CRITICAL ISSUES")
            print("   This confirms the user's reported problem.")
        
        print("="*60)
        
        return 0 if success else 1

if __name__ == "__main__":
    tester = EventReportsAPITester()
    exit_code = tester.run_focused_test()
    sys.exit(exit_code)