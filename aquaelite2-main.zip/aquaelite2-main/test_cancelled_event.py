#!/usr/bin/env python3
"""
Test script to create and cancel an event order for testing dashboard stats
"""
import asyncio
import sys
import os
sys.path.append('/app/backend')

from motor.motor_asyncio import AsyncIOMotorClient
from datetime import datetime, timezone
import uuid

async def test_cancelled_event():
    # Connect to MongoDB
    mongo_url = os.environ.get('MONGO_URL', 'mongodb://localhost:27017')
    client = AsyncIOMotorClient(mongo_url)
    db = client.waterkard
    
    try:
        # Create a test event
        test_event = {
            "id": str(uuid.uuid4()),
            "event_name": "Test Cancel Event's Wedding",
            "event_type": "wedding",
            "customer_id": "test-customer-id",
            "customer_name": "Test Cancel Customer",
            "event_date": datetime.now(timezone.utc).isoformat(),
            "event_time": "10:00",
            "venue_address": "Test Venue Address",
            "guest_count": 50,
            "products": [
                {
                    "product_id": "15L",
                    "product_name": "15L Water Jar",
                    "quantity": 10,
                    "price": 25.0,
                    "total": 250.0
                }
            ],
            "total_amount": 250.0,
            "advance_amount": 100.0,
            "balance_amount": 150.0,
            "event_status": "confirmed",
            "payment_status": "advance_paid",
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        
        # Insert test event
        await db.event_orders.insert_one(test_event)
        print(f"✅ Created test event: {test_event['id']}")
        
        # Now cancel it
        cancel_update = {
            "event_status": "cancelled",
            "cancellation_reason": "Testing dashboard stats",
            "cancelled_at": datetime.now(timezone.utc).isoformat(),
            "cancelled_by": "test-admin",
            "cancelled_by_name": "Test Admin",
            "advance_forfeited": True,
            "refund_amount": 0
        }
        
        result = await db.event_orders.update_one(
            {"id": test_event['id']},
            {"$set": cancel_update}
        )
        
        if result.modified_count > 0:
            print(f"✅ Cancelled test event successfully")
            print(f"   - Advance forfeited: ₹{test_event['advance_amount']}")
            print(f"   - Cancelled at: {cancel_update['cancelled_at']}")
        else:
            print("❌ Failed to cancel event")
            
    except Exception as e:
        print(f"❌ Error: {e}")
    finally:
        client.close()

if __name__ == "__main__":
    asyncio.run(test_cancelled_event())