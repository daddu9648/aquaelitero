#!/usr/bin/env python3
"""
Fix Completed Events - Set delivery_completed_at timestamp
"""

import asyncio
import os
from motor.motor_asyncio import AsyncIOMotorClient
from dotenv import load_dotenv
from datetime import datetime, timezone

load_dotenv('/app/backend/.env')

MONGO_URL = os.getenv('MONGO_URL', 'mongodb://localhost:27017')
DB_NAME = os.getenv('DB_NAME', 'test_database')

async def fix_completed_events():
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]
    
    print("\n" + "="*70)
    print("🔧 Fixing Completed Events with Missing delivery_completed_at")
    print("="*70 + "\n")
    
    # Find completed events without delivery_completed_at
    completed_events = await db.event_orders.find({
        "event_status": "completed",
        "delivery_completed_at": None
    }).to_list(1000)
    
    print(f"📋 Found {len(completed_events)} completed events without timestamp\n")
    
    if len(completed_events) == 0:
        print("✅ All completed events already have timestamps!")
        client.close()
        return
    
    fixed_count = 0
    for event in completed_events:
        # Use last_payment_date if available, otherwise created_at
        completion_time = None
        
        # Try to use last_payment_date as completion timestamp
        if event.get('last_payment_date'):
            completion_time = event['last_payment_date']
        # Otherwise use updated_at if available
        elif event.get('updated_at'):
            completion_time = event['updated_at']
        # Fall back to created_at
        else:
            completion_time = event.get('created_at')
        
        # Update event
        result = await db.event_orders.update_one(
            {"id": event['id']},
            {"$set": {"delivery_completed_at": completion_time}}
        )
        
        if result.modified_count > 0:
            fixed_count += 1
            print(f"✅ Fixed: {event.get('event_name')}")
            print(f"   Set delivery_completed_at: {completion_time}\n")
    
    print("="*70)
    print(f"📊 Summary: Fixed {fixed_count} out of {len(completed_events)} events")
    print("="*70)
    
    print("\n💡 Next Steps:")
    print("   1. Refresh dashboard to see updated stats")
    print("   2. Event analytics should now show correctly\n")
    
    client.close()

if __name__ == "__main__":
    asyncio.run(fix_completed_events())
