#!/usr/bin/env python3
import asyncio
import motor.motor_asyncio
import bcrypt
import os
import uuid
from datetime import datetime, timezone
from dotenv import load_dotenv

load_dotenv('backend/.env')

async def create_delivery_boys():
    client = motor.motor_asyncio.AsyncIOMotorClient(os.getenv('MONGO_URL'))
    db = client.aquaelite

    # Create admin user first
    admin_password = bcrypt.hashpw("admin123".encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    admin_user = {
        "id": str(uuid.uuid4()),
        "name": "Test Admin",
        "email": "testadmin@waterkard.com",
        "mobile": "+91 9999999999",
        "password_hash": admin_password,
        "role": "admin",
        "is_active": True,
        "permissions": ["admin.*"],  # All admin permissions
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.users.delete_many({"email": "testadmin@waterkard.com"})  # Remove if exists
    await db.users.insert_one(admin_user)
    print("✅ Admin user created: testadmin@waterkard.com / admin123")

    # Create delivery boys
    delivery_boys = [
        {
            "id": str(uuid.uuid4()),
            "name": "Vikram Singh", 
            "email": "vikram@waterkard.com",
            "mobile": "+91 9876543210",
            "password_hash": bcrypt.hashpw("delivery123".encode('utf-8'), bcrypt.gensalt()).decode('utf-8'),
            "role": "delivery_boy",
            "is_active": True,
            "permissions": ["order.view", "delivery.update", "order.deliver", "product.view", "dashboard.view", "delivery.cash"],
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat()
        },
        {
            "id": str(uuid.uuid4()),
            "name": "Ravi Kumar",
            "email": "ravi@waterkard.com", 
            "mobile": "+91 9876543211",
            "password_hash": bcrypt.hashpw("delivery123".encode('utf-8'), bcrypt.gensalt()).decode('utf-8'),
            "role": "delivery_boy",
            "is_active": True,
            "permissions": ["order.view", "delivery.update", "order.deliver", "product.view", "dashboard.view", "delivery.cash"],
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat()
        },
        {
            "id": str(uuid.uuid4()),
            "name": "Suresh Yadav",
            "email": "suresh@waterkard.com",
            "mobile": "+91 9876543212",
            "password_hash": bcrypt.hashpw("delivery123".encode('utf-8'), bcrypt.gensalt()).decode('utf-8'),
            "role": "delivery_boy",
            "is_active": True,
            "permissions": ["order.view", "delivery.update", "order.deliver", "product.view", "dashboard.view", "delivery.cash"],
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
    ]
    
    # Clear existing delivery boys
    await db.users.delete_many({"role": "delivery_boy"})
    
    # Insert delivery boys
    result = await db.users.insert_many(delivery_boys)
    print(f"✅ Created {len(result.inserted_ids)} delivery boys")
    
    for boy in delivery_boys:
        print(f"   - {boy['name']} ({boy['email']}) / delivery123")
    
    print("\nDelivery boys are now available for assignment!")

if __name__ == "__main__":
    asyncio.run(create_delivery_boys())